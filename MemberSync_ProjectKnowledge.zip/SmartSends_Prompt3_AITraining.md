# SmartSends Prompt 3: AI Content Training & Tone Guardrails
## Replit Prompt — February 23, 2026

---

## GOAL

Improve the quality of AI-generated emails by giving the AI real institutional knowledge about Mainstreet REALTORS® and setting clear boundaries for tone and content. Fix the three problems we've seen: hallucinated events, over-the-top urgency, and generic association-speak that could belong to any organization.

**CRITICAL RULES:**
- Only modify `server/services/aiEmailService.ts`
- Do NOT touch any frontend files, routes, schema, or other services
- Do NOT change the API endpoints or response formats — the AI gets better instructions, but everything else stays the same

---

## CHANGE 1: Add the Mainstreet Briefing

The AI currently knows almost nothing about Mainstreet. Its system prompt says "You are an email marketing expert for Mainstreet REALTORS®, a professional real estate association." That's it. The AI has no idea what makes Mainstreet distinctive, what the organization values, or how it talks to its members.

### What to Add

In `server/services/aiEmailService.ts`, create a new constant called `MAINSTREET_BRIEFING` and place it near the top of the file, after the existing `EMAIL_STYLE_GUIDELINES` constant:

```typescript
const MAINSTREET_BRIEFING = `
ABOUT MAINSTREET REALTORS®:

Mainstreet REALTORS® is the largest regional real estate association in Chicagoland, serving 18,000+ members across 200+ municipalities. Headquartered in Downers Grove, Illinois with three additional campuses in Tinley Park, Rolling Meadows, and Libertyville. Founded in 1921, became Mainstreet through mergers in 2007.

WHAT MAINSTREET STANDS FOR:
- Purpose: To champion every member's goals with integrity, intelligence, and inspiration
- Mission: To empower real estate professionals to thrive and find joy in their careers
- Vision: To help every member realize their full potential
- Core values: We believe in EVERY member. We are obsessed with what works. We make it easy. We are change-makers. We do the right thing. We are really, really nice.

MAINSTREET'S VOICE:
- Warm, confident, practical, and focused. Never corporate or bureaucratic.
- Write like a smart colleague who genuinely wants you to succeed — not like a committee wrote it.
- Lead with VALUE, never with price. Mainstreet is the best association, not the cheapest. Don't say "only $25 for members" — say "walk out with a strategy you can use Monday morning."
- Use "you" constantly. Make the member the hero, not the association.
- Keep emails focused on ONE clear purpose. Never kitchen-sink newsletters that try to cover everything.
- Short paragraphs (2-3 sentences max). Scannable. Respect the reader's time.

WHAT MAINSTREET OFFERS:
- Education: Mainstreet offers both CE (continuing education) classes and non-CE professional development classes, all taught by the best instructors in Illinois. Every class is designed so you leave with something that improves your business. Includes New Member Jumpstart orientation, post-licensing courses, and specialty workshops.
  - CE classes fulfill license renewal requirements — members need them to stay licensed.
  - Non-CE classes (technology workshops, business strategy, market skills) are purely voluntary — members attend because they WANT to, not because they have to. This makes non-CE attendance an especially strong signal of an engaged member.
  - When promoting classes, emphasize what the member will walk away with, not whether it counts for CE credit.
- Events: Networking events, technology workshops, community service activities, annual awards (20 Under 40, REALTOR® of the Year), and professional development summits.
- Member engagement: 15+ committees and working groups including YPN (Young Professionals), Commercial Alliance, Global Gateway, Government Affairs, DEI, and Senior Services.
- Professional services: Advocacy, legal resources, Forewarn, Sentrilock, and member-driven programming designed around what actually works.

IMPORTANT CONTEXT:
- Illinois is unusual in that the state association handles most continuing education. Mainstreet's own classes are a differentiator — practical, useful, and taught by experienced professionals.
- Members include agents at every level: Foundation (0-5 sides/year), Builder (6-39 sides), and Rainmaker (40+ sides). Most members are Foundation tier. Emails should feel relevant regardless of production level.
- Mainstreet competes with five neighboring associations. The differentiator is member-centricity — leadership listens, programs deliver real value, and the staff is genuinely approachable.
- Never reference dues amounts, membership costs, or price comparisons in emails unless specifically asked to.
`;
```

### Where to Use It

Include `MAINSTREET_BRIEFING` in the system prompt of the `generateEmail` function. Find the system prompt string (starts around line 144 with `` `You are an email marketing expert for ${CLIENT_DISPLAY_NAME}` ``).

**Replace the existing system prompt** with:

```typescript
system: `You are a skilled email copywriter for ${CLIENT_DISPLAY_NAME}. You write emails that sound like they come from someone who actually works at Mainstreet — warm, practical, and focused.

${MAINSTREET_BRIEFING}

${EMAIL_STYLE_GUIDELINES}

${AVAILABLE_MERGE_FIELDS}

${eventsContext}

${eventsContext ? `
CRITICAL EVENT RULES:
- ONLY reference events that appear in the UPCOMING EVENTS list above.
- If no events are listed above, do NOT invent event names, dates, times, or locations.
- To mention events generically, say "our upcoming classes and events" without fabricating specifics.
- NEVER create fictional event names like "Market Trends Workshop" or "New Agent Coffee" unless they appear in the real event list above.
- When promoting a real event, use the registration URL provided — do not make up URLs.
` : `
NOTE: No specific upcoming events are available right now. Do NOT invent or fabricate any event names, dates, or times. If the email topic relates to events, use generic language like "check out our upcoming classes and events" and direct members to the Mainstreet website.
`}

IMPORTANT BRANDING:
- ${CLIENT_BRANDING_RULE}
- When referencing join date, say "joined ${CLIENT_SHORT_NAME}" NOT "joined NAR"
- Address: ${CLIENT_ADDRESS}
- Phone: ${CLIENT_PHONE}

Return ONLY valid JSON (no markdown, no preamble) with this structure:
{
  "subject": "Email subject line (under 60 chars, compelling, not clickbait)",
  "body": "HTML email body with merge fields and basic formatting",
  "preview_text": "First line for email preview (under 100 chars)",
  "merge_fields_used": ["list", "of", "merge", "fields", "used"]
}`,
```

**Also update the user message prompt** (around line 174). Replace the existing user message content with:

```typescript
content: `
Write an email for ${CLIENT_DISPLAY_NAME} members.

Audience: ${audience_description || 'General members'}
Purpose: ${purpose}
Tone: ${tone}
${special_offer ? `Special Offer: ${special_offer}` : ''}
Call to Action: ${cta}
${key_points ? `Key points to include:\n${key_points.map((p, i) => `${i + 1}. ${p}`).join('\n')}` : ''}
${context?.additional_info ? `Additional Context: ${context.additional_info}` : ''}

REQUIREMENTS:
- Start with a personalized greeting using {{FirstName}}
- Keep it focused on ONE clear message — do not try to cover multiple unrelated topics
- Short paragraphs (2-3 sentences each), scannable layout
- Use a ${tone} tone that sounds like a real person, not a committee
- Lead with value and relevance — why should the member care?
- ONE clear call-to-action button, centered, using the standard teal button style
- Do NOT mention dues amounts or membership costs
- Do NOT invent event names, dates, or locations — only use real events from the context provided

EVENT FORMATTING: When including a real event from the provided list, format it as:
<div style="border: 2px solid #3a8a8c; border-radius: 8px; padding: 16px; margin: 16px 0; background-color: #f0fafa;">
  <div style="font-weight: 700; font-size: 16px; color: #2c3e50; margin-bottom: 8px;">[Event Name]</div>
  <div style="font-size: 14px; color: #555; margin-bottom: 4px;">Date: [Date/Time]</div>
  <div style="font-size: 14px; color: #555; margin-bottom: 12px;">Location: [Location]</div>
  <div style="text-align: center;"><a href="[registration_url]" style="display: inline-block; background-color: #3a8a8c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: 600; font-size: 14px;">Register Now</a></div>
</div>

OFFER FORMATTING: When including special offers, format as:
<div style="border: 2px solid #d97706; border-radius: 8px; padding: 16px; margin: 16px 0; background-color: #fffbeb;">
  <div style="font-weight: 700; font-size: 16px; color: #92400e; margin-bottom: 8px;">SPECIAL OFFER</div>
  <div style="font-size: 14px; color: #78350f;">[Offer details]</div>
</div>

CTA BUTTON: One prominent button, centered:
<div style="text-align: center; margin: 24px 0;"><a href="[url]" style="display: inline-block; background-color: #3a8a8c; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600;">Button Text</a></div>
`
```

### Remove the Database Schema from Email Generation

The current code includes `${getDataAwarenessSummary()}` in the email generation system prompt. This injects the full database schema (table names, column descriptions, query patterns) into every email generation call. That context is designed for the AI Chat feature where Claude writes SQL queries — it's completely irrelevant for writing marketing emails and wastes ~10,000 tokens per call.

**Remove this line** from the `generateEmail` function's system prompt:
```typescript
${getDataAwarenessSummary()}
```

The `getDataAwarenessSummary()` import can stay in the file since it may be used elsewhere, but it should NOT appear in the email generation or refinement prompts.

---

## CHANGE 2: Add Tone Guardrails to the Refine Function

The `refineEmail` function (around line 241) is what runs when a user clicks "Edit with AI" and provides feedback like "make it more urgent." Currently, the AI interprets "urgent" as fire emojis, ALL CAPS, and infomercial language.

**Replace the system prompt** in the `refineEmail` function with:

```typescript
system: `You are a skilled email copywriter for ${CLIENT_DISPLAY_NAME}. You refine and improve emails based on user feedback while maintaining Mainstreet's voice.

${MAINSTREET_BRIEFING}

REFINEMENT RULES:
- Apply the requested changes while keeping the email focused and professional
- Preserve ${CLIENT_SHORT_NAME} branding and voice
- Maintain the original email's purpose and structure unless asked to change them
- Keep the same merge fields that were in the original

TONE DEFINITIONS — these are what each tone means at Mainstreet:
- "Professional" = Clear, confident, knowledgeable. Like a trusted advisor briefing you on something important.
- "Friendly" = Warm, encouraging, conversational. Like a colleague who's excited to share good news with you.
- "Urgent" = A firm, specific heads-up with a clear deadline and real consequence. Like a friend saying "Hey, this actually matters and here's why you need to act by Friday." NOT fire emojis, NOT countdown warnings, NOT ALL CAPS, NOT "ACT NOW" or "DON'T MISS OUT."

ABSOLUTE BOUNDARIES — never do these regardless of what the user asks:
- Never use fire emojis (🔥), alarm clocks (⏰), warning signs (⚠️), or sirens (🚨)
- Never use ALL CAPS for more than two consecutive words
- Never use "ACT NOW", "LAST CHANCE", "DON'T MISS OUT", "LIMITED TIME", "HURRY" — these feel like spam and are beneath Mainstreet's brand
- Never use more than one exclamation point per paragraph
- ONE call-to-action button per email, with calm professional text (not "REGISTER NOW BEFORE IT'S TOO LATE!!!")
- If the user asks to "make it more urgent," add a specific deadline date and explain the real consequence of missing it. That's urgency. Everything else is noise.
- Never mention dues amounts or membership costs unless the email is specifically about billing

${AVAILABLE_MERGE_FIELDS}

${CLIENT_BRANDING_RULE}

Return ONLY valid JSON (no markdown):
{
  "subject": "Refined subject line",
  "body": "Refined HTML email body",
  "preview_text": "Updated preview text",
  "changes_made": "Brief explanation of what changed"
}`,
```

---

## CHANGE 3: Remove Database Schema from Newsletter Function

The `generateNewsletterStories` function (around line 306) should also NOT include the database schema. Check whether `getDataAwarenessSummary()` is used in that function's prompt, and if so, remove it.

---

## WHAT THE FINISHED FILE SHOULD LOOK LIKE

After all changes, `aiEmailService.ts` should have these constants at the top:

1. `AVAILABLE_MERGE_FIELDS` — unchanged
2. `EMAIL_STYLE_GUIDELINES` — unchanged
3. `MAINSTREET_BRIEFING` — NEW (the briefing constant added above)

And three functions:

1. `generateEmail()` — updated system prompt with MAINSTREET_BRIEFING, anti-hallucination rules, NO database schema
2. `refineEmail()` — updated system prompt with MAINSTREET_BRIEFING, tone guardrails, ABSOLUTE BOUNDARIES
3. `generateNewsletterStories()` — verify no database schema, otherwise leave as-is

---

## VERIFICATION CHECKLIST

### AI Generation Quality
- [ ] Generate an email with purpose "promote our upcoming classes" → should reference REAL events from the database (if any exist), NOT invent fake ones
- [ ] Generate an email with purpose "welcome new members" → should sound warm and Mainstreet-specific, not generic association boilerplate
- [ ] Generate an email with purpose "remind members about continuing education requirements" → should lead with value ("stay ahead of your license requirements"), not with fear
- [ ] Generate an email where no events exist in the database → should use generic language like "check out our upcoming classes" without fabricating names or dates
- [ ] No generated email should mention dues amounts or membership costs

### AI Refinement Quality
- [ ] Generate an email, then refine with "make it more urgent" → should add a specific deadline and consequence, NOT emojis or ALL CAPS
- [ ] Refine with "make it shorter" → should actually get shorter while keeping the key message
- [ ] Refine with "make it friendlier" → should get warmer and more conversational without becoming unprofessional
- [ ] No refinement should ever produce fire emojis, ALL CAPS buttons, or "ACT NOW" language

### Cost Efficiency
- [ ] Verify that `getDataAwarenessSummary()` is NOT called in `generateEmail()` or `refineEmail()` system prompts
- [ ] The email generation prompt should be roughly 800-1000 tokens for the system message (not 10,000+)

---

## FILES CHANGED

**Modified:**
- `server/services/aiEmailService.ts` — Added MAINSTREET_BRIEFING, updated generateEmail system prompt, updated refineEmail system prompt, removed database schema from email prompts

**NOT modified:**
- Everything else

# MemberSync Project Summary — March 12, 2026 (CLAUDE.md Finalization)

## Session Purpose
Final polish and completion of CLAUDE.md before the Replit-to-Claude Code transition handoff. This session took the comprehensive rewrite produced earlier on March 12 and applied a series of targeted updates, additions, and corrections to produce the definitive version of the product bible.

---

## Changes Made to CLAUDE.md

### Editorial Updates (Tracy-Directed)

**Image Library section rewritten** — Replaced a single sentence about Replit Object Storage with a full framing of the image library as a low-fidelity prototype module. Establishes a two-phase implementation plan: keep the limited module through Mainstreet and HGAR onboarding; replace with a full-featured content library (full CRUD, SEO, documents, URLs, videos) before official product launch. Notes that the content library may also power the Membio Member Portal.

**Technical Debt section renamed** — "Technical Debt (Post-AEI)" → "Technical Debt (Resolve as Soon As Possible)". Removes the implication that these items could wait until after the conference.

**Proactive AI Engagement Engine renamed** — "Top Priority Post-AEI" → "Top Priority". Consistent with the governing principle that no deadline drives product decisions.

**AEI references scrubbed** — Two remaining AEI-as-driver references removed:
- Campaign Architect protection note rewritten to stand on its own merits (it's stable and mature) rather than being framed around the conference
- Member Journey "Post-AEI build" qualifier removed

**Merge fields note added** — "Additional merge fields will be added as needed." Simple but important signal to developers that the merge field system must be extensible.

**Product Tiers caveat added** — Blockquote note at the top of the Product Tiers section stating that tiers and pricing are still very much in development and not final.

**Compliance Module updated** — Full rewrite to reflect that compliance is two distinct modules (Association and MLS), not one association-only module. Added the edge case: an association that also owns an MLS gets a combined compliance tool. Architectural note added: do not build the two modules in a way that makes the combined case impossible. Both modules remain in development.

**Education & Events dual placement** — Added to Core (Always On) list because it's a primary reason clients buy MemberSync. Kept in the Modules table with an extended capabilities note gated by `has_website` or `has_member_portal`. Core tier description in Product Tiers also updated to include it.

---

### Structural Changes

**Two-Track Development Model retired** — Section replaced with "Development Model (Current — as of March 12, 2026)". Documents the new team structure:

- **Tracy** — Product vision, demo, and feature development. Works in her own branch with Claude as CTO/advisor and Claude Code as engineer. Pushes completed features to development.
- **Paula, Daniel, and Rogelio** — Administration screens, integration with existing Membio products, pricing/tiers (with Tracy), fit and finish (Daniel).
- **Mike, Dale, and Formos** — Production platform. Repository, deployment pipeline, monitoring, operations. Use Claude Code.
- **Common infrastructure** — Membio Common (shared read-only PostgreSQL); local PostgreSQL per developer for application tables; Claude Code across all tracks.

**Replit handoff documented** — Codebase warning replaced with a clean close: last Replit code pulled March 12, no future pulls, all documentation sent to Mike and Dale via zip and uploaded to Tracy's GitHub.

---

### Five Additions (Identified in Review)

**1. Client-Facing Role Permissions table** — Full four-role permissions matrix (Admin, Staff, Contributor, Leadership/Board) covering 15 capabilities. Authoritative reference for auth middleware. Notes that Leadership/Board is a premium read-only add-on; Contributor manages content but cannot send campaigns; AI memory editing is Admin-only by default but can be opened to Staff by Client Admin. Roles are still being finalized — table must remain extensible.

**2. Replit document context** — Both Replit companion documents (Orientation and Standing Rules Header) now explain *why* they exist: Replit agents are stateless, lose history on restart, and these documents were the mechanism for keeping them oriented. Both marked as retired as of March 12 and preserved as historical record only.

**3. Audiences — Canonical Reference** — New standalone section added before SmartSends. Covers all five audience types (AI Builder, Picklist, Member/Bill Type, Saved, Upload) with a table and six architectural rules: audience counts always reflect current data; audience language must reflect staff's own words; recipient list resolved at send time; 100% Coverage Test applies.

**4. `email_address` PK migration history** — Added the reasoning behind the irreversible migration: the original `member_key` PK meant external contacts (event guests, past members, non-member recipients) with no AMS record could not be suppressed. This was a deliverability and compliance risk. Decision is permanent. Rule now includes explicit instruction: do not revert, do not add parallel `member_key` lookups, do not bypass email address as suppression key.

**5. Open Questions section** — New section at the end of the document listing four pending decisions that must not be treated as settled:
- Leadership/Board seat pricing
- MLS compliance rule sets (will be defined by first MLS client)
- Billing integration timing (target: before client #4 onboards)
- Email Archive / Templates scope (needs Tracy clarification before any build)

---

### Rule 31 Added

> ⛔ **Do not build parallel systems.** If a feature already exists, extend or replace it — never build a second version alongside it. Do not leave dead code behind. When a feature is replaced, the old implementation is deleted entirely. When a function is refactored, the old version is removed. The codebase should contain exactly one way to do any given thing. Duplication is technical debt on day one.

---

## Output File

`CLAUDE.md` — final version, 1,219 lines. Ready to replace the repo root CLAUDE.md and go out in the handoff zip to Mike and Dale.

---

## Key Milestone

This is the last CLAUDE.md based exclusively on Replit development. As of March 12, 2026, MemberSync moves to a classic dev → staging → production environment with CI/CD and security. Claude Code is the engineering tool going forward. Future versions of CLAUDE.md will be updated by Claude based on Claude Code development work.

---

## Pending / Carry Forward

- Replace `CLAUDE.md` in repo root with this version before any Claude Code session begins
- Send zip of all documentation (prompts, summaries, CLAUDE.md) to Mike and Dale — target today
- Upload to Tracy's GitHub so Claude Code can come up to speed in the new environment
- Assign owners and soft deadlines to the four Open Questions
- Resolve the Compliance Module row in the Modular Architecture table (still says "Association clients only" — may need updating to reflect the two-module structure)

---

*Summary written: March 12, 2026*

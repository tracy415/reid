# MemberSync — AI Memory: Update "About Your Organization" Copy
*Written: March 12, 2026*
*Status: READY TO SEND TO REPLIT*

---

## STANDING RULES

- Do NOT modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts` for any reason.
- No parallel systems — extend existing files, never build duplicates.
- Don't break what works — verify before and after every change.
- No fake data, ever.
- Test your work before reporting complete.

---

## OVERVIEW

A single text update. The "About Your Organization" block that appears on the AI Memory page and is injected into every AI Chat call needs to be replaced with accurate, mission-aligned copy.

This is a one-line content change. Do not change any surrounding logic, layout, or functionality.

---

## THE CHANGE

Find where the "About Your Organization" text is defined. It will be a hardcoded string in one of the following places — search for the current text to locate it exactly:

> "Mainstreet REALTORS® serves the Chicago southwest suburbs and surrounding communities — one of the largest REALTOR® associations in Illinois"

It may live in:
- A constants file (e.g., `clientConfig.ts`, `aiQueryService.ts`, or a dedicated onboarding/memory constants file)
- A server-side route that returns the AI Memory page data
- A React component that renders the AI Memory page

Search for the phrase "one of the largest" to find it quickly.

**Replace the entire "About Your Organization" text string with the following — copy exactly:**

```
Mainstreet REALTORS® serves the Chicago southwest suburbs and surrounding communities — it is the largest REALTOR® association in Illinois with more than 18,000 members, and the ninth largest in the United States. Becoming a REALTOR® is a professional distinction, not simply a license to sell real estate; it means you have committed to upholding ethical and professional standards. Mainstreet offers members hundreds of continuing education and professional development classes, networking events, and advocacy and legal services designed to empower their success. Though approximately 75% of Mainstreet members conduct 0–5 transactions per year, every member pays dues and is critically important to the financial health and mission of the organization. Mainstreet's purpose is to help every member succeed on their own terms — not by how many homes they sell, but by how the organization helps them win personally and professionally.
```

---

## VERIFICATION

1. Navigate to Chats → AI Memory. Confirm the "About Your Organization" card displays the new text exactly as written above.
2. Go to the Dashboard and open the AI Assistant. Ask: "What do you know about Mainstreet Realtors?" Confirm the response reflects the new framing — mission and member value — not churn risk or competitive threat language.
3. Confirm nothing else on the AI Memory page has changed (the "What the AI Remembers" entries, the "Add to Memory" form, the layout).

---

## FILES CHANGED

**Modified:** Whichever single file contains the hardcoded "About Your Organization" string — one string replacement only.

**NOT modified:** Everything else.

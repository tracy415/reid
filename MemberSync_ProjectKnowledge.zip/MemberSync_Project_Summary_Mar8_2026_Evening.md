# MemberSync — Project Summary
## March 8, 2026 (Evening — End of Day)

This document is the authoritative state of the project as of the end of March 8, 2026. It supersedes all prior summaries. Use this to resume work in any new conversation.

---

## TABLE OF CONTENTS

1. Who We Are & Claude's Role
2. Product Vision & Philosophy
3. The 75/12 Rule — The Insight That Drives Everything
4. Member Tier Framework
5. Client Pipeline
6. Build Philosophy & Team Structure
7. Current State: What's Built
8. Navigation Structure (Current — Post-Redesign)
9. Campaign Architect — Full Status
10. AI Cost Controls — What Was Built Tonight
11. Admin Panel & Self-Service Onboarding — Vision
12. CLAUDE.md Update — Plan & Decisions (Next Chat Goal)
13. Prompt Queue — Current Status
14. Standing Rules (Canonical — 22 Rules)
15. All Architectural Decisions (Canonical)
16. Known Issues & Technical Debt
17. Key Files Reference
18. Parking Lot Summary

---

## 1. WHO WE ARE & CLAUDE'S ROLE

**Tracy** is CEO and founder of Membio — a proptech SaaS company. She has 30+ years of real estate industry experience on the business side. She is a non-technical founder building MemberSync exclusively with Claude, Julius.ai, and Replit Agent. She is aware of and deeply interested in technology and AI but cannot code.

**Claude's role** is CTO, product visionary, AI architecture expert, and strategic sparring partner. This means:
- Pressure-test every feature idea against multi-tenant scale, technical debt, and timing before speccing it
- Surface architectural risks proactively
- Translate tradeoffs into business terms, not jargon
- Push back when something doesn't make sense
- Hold the full product picture across conversations so nothing gets lost
- Write all Replit prompts (the specs Tracy sends to the Replit Agent for implementation)
- Write CLAUDE.md (the product bible for the dev team's Claude Code instance)

**The two-tool workflow:**
- **Claude** — strategy, architecture, Replit prompts, CLAUDE.md, project summaries
- **Julius.ai** — SQL development and data validation
- **Replit Agent** — prototype implementation (Track 1)
- **Claude Code** — production implementation by dev team (Track 2)

**Clean boundary:** Tracy + Claude decide the "what" and "why." The dev team owns the "how." Tracy reviews Replit's implementation plans with Claude before approving execution.

---

## 2. PRODUCT VISION & PHILOSOPHY

**MemberSync** is a member engagement and retention SaaS platform built by Membio for real estate associations and MLSs (Multiple Listing Services). It analyzes MLS listing data and AMS (Association Management System) data to help executives understand, engage, and retain members.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**Product philosophy:** "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

**The lightsaber:** Organized real estate is in an existential fight. MLSs are going non-Realtor, removing the last transactional justification for association membership. MemberSync is the lightsaber — real, specific, actionable intelligence about their own members AND the competitive environment those members operate in. Associations compete with neighboring organizations for members. MemberSync must help executives look outward, not just inward.

**The 5% rule:** Every screen must earn its place. We build what clients asked for or dreamed about — not features that sound good in a roadmap.

**Decision-first UX:** Every view surfaces a recommended action, not just data. The AI always has a next step to suggest.

**AI voice and trust philosophy (formalized March 8 — STANDING RULE):**
MemberSync AI observes real data and acts on it. It never invents, never infers beyond what the data actually shows, and never uses language that implies knowledge it doesn't have. Every claim shown to users is grounded in real, verifiable data about actual members. The AI is confident, warm, shows its work, and is always on the member's side — but never clinical, never alarming without a path forward, and "really nice about it" when delivering sensitive truths. Social proof is never invented. No testimonials, no fabricated member quotes, no "members like you" statistics that aren't grounded in real data from this specific organization.

---

## 3. THE 75/12 RULE

At a typical real estate association or MLS, roughly 75% of members produce only about 12% of real estate transaction volume — yet they pay approximately 75% of dues and fee revenue. These are "Foundation" members: people who maintain their license, pay dues, and may never sell a house. They are the financial backbone.

Most associations ignore the 75% because they don't appear to be selling at scale. But neither MLSs nor associations can exist without them.

**The 100% Coverage Test:** Any scoring signal that covers fewer than 10% of membership is a vanity metric, not a scoring input. Committee participation (the NAR-identified top retention predictor) covers less than 1% of members — useless as a universal signal. MemberSync refuses to make that mistake.

**Why it matters now:** MLSs opening access to non-Realtor licensees threatens association membership. But MLSs face the same math: if an MLS doesn't build relevance for Foundation members (0–5 sides/year), it's just as vulnerable. MemberSync serves both.

---

## 4. MEMBER TIER FRAMEWORK

Members classified by 12-month transaction sides:

| Display Name | Internal Code | Sides (12mo) | Mainstreet % |
|---|---|---|---|
| Rainmaker | `active_producer` | 40+ | ~1.4% |
| Builder | `occasional_producer` | 6–39 | ~21% |
| Foundation | `license_maintainer` | 0–5 | ~77% |

**Critical rules:**
- Display names only in UI — never internal names
- All tiers framed positively — we celebrate connection, not police compliance
- Foundation members who take classes, pay on time, and attend events can score 10/10 on engagement — even with zero transactions
- Engagement is not production
- Tier thresholds defined in `clientConfig.ts` / `tenant_config` — vary per client

---

## 5. CLIENT PIPELINE

| Client | Members | Status | Special Requirements |
|---|---|---|---|
| Mainstreet REALTORS® | 18,275 | First client, prototype stage | Chicago suburbs, IL compliance |
| HGAR / Hudson Gateway | 12,800 | Onboarding | Multi-tenant, NY compliance |
| GRAR / Greater Rochester | 3,400 | Third pilot | Multi-tenant, NY compliance |
| CRMLS | 103,000+ | Major pilot prospect | SOC 2, enterprise SLA, batch email at scale |

**AEI/RESO Conference:** Minneapolis, March 23–27. Campaign Architect is the demo centerpiece.

**Self-service onboarding:** Explicitly deferred until 4–5 clients have been manually onboarded. The AMS data landscape is too non-standard to automate before we've seen enough real systems. We need to know what the right steps are before automating them.

---

## 6. BUILD PHILOSOPHY & TEAM STRUCTURE

**Two-track development model:**
- **Track 1 (Tracy + Claude + Replit Agent):** Rapid prototype development and feature validation. Continue building and validating features in Replit.
- **Track 2 (Dev team + Claude Code):** Production platform. Port validated modules from Replit with proper multi-tenant architecture from day one.

**Weekend goal (March 8–9 — CRITICAL):**
Get the prototype into the best possible shape before handing to the dev team on Monday. Goal is feature completeness and vision clarity — not AEI demo prep. Dev team takes the GitHub repo and begins the production port: tearing apart the monolith, adding multi-tenancy, removing 110+ Mainstreet hardcoded references.

**Handoff artifacts:**
- `CLAUDE.md` — product bible in repo root (786 lines, needs major update — writing in next chat)
- Per-feature Replit prompts — spec artifacts in project knowledge
- `MemberSync_Parking_Lot.md` — strategic ideas backlog

---

## 7. CURRENT STATE: WHAT'S BUILT

### Core Platform
- Engagement scoring with tier classification (Rainmaker/Builder/Foundation)
- Member metrics cache (daily refresh, cache-first architecture)
- Dashboard with Association Pulse cards, Activity Feed, Member Recognition sidebar
- Member Detail pages with score breakdown, open/click timestamps
- Daily membership snapshot for trend analysis
- **Member profile data fix (March 8):** All tiles now show real data — IL CE Progress, Code of Ethics status, and engagement sub-scores (education/events, email, recency) now query live from `activity_cache`. Previously these were hardcoded placeholders.

### SmartSends
- Campaign creation: AI + manual + template
- All four audience types: AI builder, picklist, member/bill type, CSV upload
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking with open/click timestamps
- Email Governor: daily/weekly caps, sandbox mode, exempt categories
- Recognition Queue with full review/approve/send flow (Parts 1–8 complete)
- Email Health Dashboard (Performance, Send Queue, Email Archive tabs)
- Image Library upgraded: metadata, optimization, archive, delete/version rules
- AI duplicate detection at Preview step
- Archive-aware AI composition
- Automations with 7 trigger types

### Campaign Architect (AI-first campaign builder)
- Fully replaces the drip sequence builder — no parallel UI
- Conversational AI planning interface
- Session persistence — saved to Automations center
- Audience picker (Saved, Member/Bill Type, Picklist tabs inline)
- Event multi-select with anchor-date timing
- Live plan preview panel with watch-outs
- AI parse failure retry + hardening
- Email generation, editing, A/B test suggestion, activation
- Branch emails: registration_skip, registration_alternate, prior_attendance
- Planner voice and grouping logic (multi-event series recognition) — verified working
- Grouping rationale callout in plan panel

### Recognition Module (first-class top-level module)
- Recognition Queue with review/approve/send flow
- Recognition emails exempt from Email Governor (Lane 1, no cap)
- Campaign names: "Recognition: [milestone_label] — [Month Year]"
- Left nav badge showing pending count
- Recognition homepage (to be built — see Prompt Queue)

### AI Services
- AI Chat: natural language → SQL, cross-domain queries, retry loop, Julius-style analyst behavior
- AI email composition with archive-aware context
- AI audience builder
- AI duplicate detection
- AI campaign planner (Campaign Architect)
- Schema modularization for AI context (41–76% schema size reductions by query type)

### Analytics / Market Stats
- Office Volume, Agent Production, Market Concentration
- Market Stats with concentration thresholds
- Top 10 Offices and Agents
- Create Brief

### AI Cost Controls (built March 8 — plumbing only, no UI yet)
See Section 10 for full detail.

### Navigation (redesigned March 8)
See Section 8 for full structure.

---

## 8. NAVIGATION STRUCTURE (CURRENT — POST-REDESIGN)

```
Dashboard
SmartSends [collapsible — label navigates to /smartsends home]
  → Create              (/smartsends/create)
  → Reporting & Analytics (/smartsends/reporting)
  → Audiences [collapsible]
      → AI Builder      (/smartsends/audiences)
      → Picklist        (/smartsends/audiences/picklist)
      → Member/Bill Type (/smartsends/audiences/member-bill-type)
      → Saved           (/smartsends/audiences/saved)
      → Upload          (/smartsends/audiences?upload=true)
  → Content             (/smartsends/images — was Image Library)
  → Templates           (/smartsends/templates)
  → Settings            (/smartsends/settings)
Chats                   (/chats)
Recognition [collapsible — badge shows pending count]
  → Templates           (/recognition/templates — stub)
  → Performance         (/recognition/performance — stub)
  → Settings            (/recognition/settings — stub)
Engagement              (greyed — Coming Soon, inert)
Retention               (greyed — Coming Soon, inert)
Compliance [collapsible — label navigates to /compliance/communications]
  → Communications      (/compliance/communications)
  → Performance         (/compliance/performance — stub)
  → Settings            (/compliance/settings — stub)
Market Stats [collapsible — was Analytics]
  → Office Leaderboard  (/analytics/offices)
  → Agent Leaderboard   (/analytics/agents)
  → Create Brief        (/analytics/brief)
Members                 (/members — was All Members)
Offices                 (/offices — was All Offices)
```

**New pages built in nav redesign:**
- `SmartSendsHome.tsx` — newsroom homepage with today's activity strip, 4 performance pulse cards, top performer, quick actions
- `SmartSendsCreate.tsx` — 4-card orientation: Send an Email, Build a Sequence (→ Campaign Architect), Set Up a Trigger, Member Journey (Coming Soon)
- `SmartSendsReporting.tsx` — unified campaign list (all types), status/type filters, 90-day charts, member-level drill-down
- `SmartSendsSettings.tsx` — absorbs Email Controls tab (Governor, Performance, Send Queue, Archive)
- 5 stub pages: RecognitionTemplates, RecognitionPerformance, RecognitionSettings, CompliancePerformance, ComplianceSettings

**Key nav decisions:**
- Nav items are destinations. Actions live in buttons.
- Send Email, Drafts, Automations removed as standalone nav items
- Drafts accessible as a tab/status within Reporting & Analytics
- "Automations" → renamed throughout; entry point is SmartSendsCreate
- Compliance top-level label navigates to /compliance/communications until triage homepage built
- Coming Soon items: opacity-50, small badge, cursor-default, no hover, no onClick
- All URL paths unchanged — only display labels changed

**Post-nav cleanup (written March 8, ready to send):**
- Remove orphaned `Shield` import from AppSidebar.tsx
- Remove stale nav links from SmartSends.tsx (old Recognition Queue links, Drafts link, stale Automations navigation)
- Verify orphaned routes removed from App.tsx

---

## 9. CAMPAIGN ARCHITECT — FULL STATUS

Campaign Architect is the AI-first campaign builder that fully replaces the drip sequence builder. It is the AEI demo centerpiece.

### All Prompts Deployed
1. **Prompt 1** — conversation UI, planning, session persistence ✅
2. **Prompt 2** — email generation, editing, A/B, activation ✅
3. **Polish prompt** — 5 UX improvements ✅
4. **Hardening prompt** — 3 production fixes (negative delayDays fix, audience accumulation cleanup, rate limiting) ✅
5. **Planner Intelligence Fix** — multi-event series recognition ✅ Verified working
6. **Addendum** — branch emails, social proof prohibition, minimum 3 emails per event ✅ Deployed (March 8)
7. **Planner Voice & Grouping Fix** — new AI voice section, event grouping logic, groupingRationale callout 🔄 Replit building

### Campaign Architect Architecture
- **File:** `client/src/pages/CampaignArchitect.tsx` (~1,834 lines)
- **Planner service:** `server/services/aiCampaignPlannerService.ts`
- **Execution:** Reuses `triggeredCampaignProcessor.ts` — **DO NOT MODIFY this file for any reason**
- **Session persistence:** Sessions saved to Automations center
- **Rate limiter:** In-memory Map (per-process; needs Redis for multi-instance production)

### Branch Email Types
- `registration_skip` — skip event email if already registered
- `registration_alternate` — alternate content for already-registered members
- `prior_attendance` — different message for members who attended previously
- Branch routing stored in `sendCondition` column as JSON in `triggeredCampaignSteps`
- Branch emails display nested in plan panel (violet = registration_alternate, teal = prior_attendance)
- Prior attendance branches come from AI planner conversation ONLY — not from the "+ Add branch email" button

### Standing Rules for Campaign Architect
- **Social proof is never used.** No attendance numbers, no "members like you," no testimonials. Campaigns can be approved months before they send.
- **Minimum 3 emails per event.** Awareness + value reinforcement + urgency. 3-event series = minimum 9 emails.
- **Branch points are shallow.** Registration status and prior attendance only. Deep conditional logic belongs in Member Journey, not Campaign Architect.
- **Campaign Architect fully replaces the drip sequence builder.** No parallel UI.
- **AI suggestions are always actionable yes/no.** Never configuration forms.

---

## 10. AI COST CONTROLS — WHAT WAS BUILT TONIGHT

File: `MemberSync_AICostControls_Prompt.md` (in outputs — ready to send to Replit)

### What this builds (plumbing only — no UI)

**1. `ai_usage_logs` table (new)**
Logs every Anthropic API call: client_id, user_id, feature, input_tokens, output_tokens, estimated_cost_usd, model_used, success, error_message, metadata, created_at.

Feature constants: `ai_chat`, `campaign_architect`, `email_composer`, `audience_builder`, `duplicate_detection`, `content_summary`, `recognition_email`

**2. `aiUsageLogger.ts` service (new)**
Fire-and-forget wrapper. Never throws — if logging fails, the AI feature continues normally. Calculates estimated cost using current Anthropic Sonnet 4 pricing ($3/M input, $15/M output, 90% discount on cached input).

**3. Usage logging wired into all 4 AI services**
`aiQueryService.ts`, `aiCampaignPlannerService.ts`, `aiEmailService.ts`, `aiAudienceService.ts` — all now log every call.

**4. Per-feature daily rate limits in `tenant_config`**
New columns: `ai_chat_daily_limit` (default 100), `campaign_architect_daily_limit` (default 20), `email_composer_daily_limit` (default 50), `audience_builder_daily_limit` (default 30). All adjustable per client without code deploy.

**5. Kill switches per feature per client**
`ai_chat_enabled`, `campaign_architect_enabled`, `email_composer_enabled`, `audience_builder_enabled` — all boolean, all default true. Emergency brake if a client burns abnormally.

**6. `GET /api/admin/usage` endpoint (Membio internal, admin-only)**
Returns: total calls, total cost, errors; breakdown by feature; daily totals for sparkline. Filterable by clientId and period (1d/7d/30d).

### What's NOT built yet (intentionally deferred)
- Admin panel UI
- Client-facing usage dashboard
- Billing integration
- Automated anomaly alerts
- SendGrid usage logging

### Architectural notes for production port
- In-memory rate limit counters (`Map`) must move to Redis for multi-instance
- `clientId` hardcoded to `1` (Mainstreet) throughout — must pull from session in production

---

## 11. ADMIN PANEL & SELF-SERVICE ONBOARDING — VISION

Discussed in detail March 8. Must be in CLAUDE.md as its own section.

### Self-Service Onboarding Flow (future — after 4–5 clients manually onboarded)
1. Plan selection + payment
2. API key entry + connection test (MLS and AMS)
3. Field mapping verification (AMS non-standardization requires a mapping UI)
4. Initial data sync (background job, progress indicator)
5. **The wow moment** — first AI insights surface as soon as enough data exists
6. Email domain setup (parallel — not blocking)

**Critical:** Field mapping is the hard step. UI must show "MemberSync expects MemberStatus — we found these candidates in your data, which one is it?" Without this, the AI says something confidently wrong in the first 5 minutes.

### Client Account (what clients see)
- Billing: plan info, subscription type, invoices, payment methods
- Seats & roles: Admin, Staff, Contributor, Leadership/Board (read-only premium view)
- Usage: AI token consumption by feature vs. plan limits, ability to buy more
- API keys: MLS and AMS credentials, field mapping verification
- Email domain setup: SPF/DKIM/DMARC configuration

### Roles
- **Admin** — full access, manages users, billing, settings
- **Staff** — full operational access, can send campaigns, view all data
- **Contributor** — can create and edit but not send or approve
- **Leadership/Board** — read-only premium view: dashboard, tier distribution, campaign performance summaries. Beautiful, not functional. Shown to board. Charge extra — zero marginal cost, high perceived value.

### Membio Admin Panel (what Membio staff see)

**Client Information:**
- Contact and billing information (separate invoice email)
- Plan, subscription type, seats and roles
- Onboarding pipeline: where is each client in the funnel?

**Anthropic and SendGrid Usage:**
- Token consumption per client, per feature, per day/week/month
- Token burn rate with projection ("will exceed plan in 18 days")
- Anomaly detection (10x normal usage = alert)
- SendGrid volume, bounce rates, spam complaints per client
- Ability to troubleshoot specific campaigns in SendGrid
- Kill switch per feature per client

**Data:**
- MLS listings, agents, offices — record counts and freshness
- AMS volume
- Data verification / cross-check tools
- API connection health (is MLS feed responding? Did AMS credentials expire?)
- Last successful sync, records processed, errors

**Health & Monitoring:**
- Failed job alerts (Membio knows before client does)
- Email deliverability health per client
- System message push to specific client UI

**Support & Troubleshooting:**
- Impersonation (view exactly what client sees, with audit log)
- Manually trigger data sync or cache refresh
- Full audit log per client (who logged in, what did they do, what AI queries ran)

**Billing:**
- Invoice generation and payment status
- SOC 2 evidence collection dashboard

**Note for CLAUDE.md:** Document self-service onboarding as the intended end state, but explicitly note: "Do not build the self-service UI until Tracy explicitly says so. The first 4–5 clients are manually onboarded to learn what the right steps are before automating them."

---

## 12. CLAUDE.md UPDATE — PLAN & DECISIONS (NEXT CHAT GOAL)

**The CLAUDE.md update is the most important artifact for Monday's dev team handoff.** A well-written CLAUDE.md is the immune system that prevents the dev team from inadvertently simplifying away core philosophy, hardcoding client values, or building features that only serve power users.

### Things Most Likely to Get "Simplified Away" Without Strong Documentation
- The AI voice and trust philosophy
- The tenant_config gating requirement (every module, every feature)
- The 75/12 philosophy (features must serve Foundation members, not just Rainmakers)
- The no-fake-data rule
- The Campaign Architect branch logic and social proof prohibition

### Full Outline for New CLAUDE.md

**Sections that stay (minimal changes):**
- What Is MemberSync (add AI voice/trust philosophy)
- The 75/12 Rule
- Member Tier Framework
- Modular Architecture (add Campaign Architect, Recognition, Email Health)
- Product Tiers
- Tech Stack
- Database Architecture
- Engagement Scoring
- Compliance Configuration
- Multi-Tenant Migration Plan
- Client Pipeline
- Environment Variables

**Sections needing meaningful updates:**
- Standing Rules — add ~6 new rules from March 7–8
- Production Port Module Order — rename Celebrations→Recognition, add Campaign Architect
- What's Coming — move several items to "built," add new ones
- Companion Documents — add new prompt files

**New sections to add entirely:**
1. **Navigation Structure** — canonical reference for dev team
2. **Campaign Architect** — architecture, branch types, standing rules, do-not-touch files
3. **Recognition Module** — first-class module, queue, Email Governor exemption, homepage direction
4. **Email Health Dashboard** — three tabs, what each shows, archive as AI memory direction
5. **Image Library (upgraded)** — metadata, optimization, archive rules, delete/version rules
6. **AI Voice & Trust Philosophy** — observes real data, shows its work, never invents, always warm
7. **AI Cost Controls** — the plumbing built tonight, what's coming next, pricing reference
8. **Membio Admin Panel** — vision, what it shows, what's deferred
9. **Client Self-Service & Account Management** — roles, onboarding flow, wow moment
10. **Persistent Memory Architecture** — phased approach, so dev team builds toward it
11. **`tenant_config` Complete Field Reference** — full table with all fields, types, defaults, which features depend on them (explicitly called out as missing in Parking Lot Section 4)
12. **Prototype→Production Handoff** — how Tracy+Claude work in Replit → how validated features get specced for dev team → what artifacts are created at each handoff

### Standing Rules to Add (New Since March 4)
- Rule 17: Social proof never used in Campaign Architect emails
- Rule 18: Minimum 3 emails per event in any Campaign Architect sequence
- Rule 19: Campaign Architect branch points are shallow (registration + prior attendance only)
- Rule 20: Recognition is a top-level nav module — never nest inside SmartSends
- Rule 21: Nav items are destinations. Actions live in buttons.
- Rule 22: Every email sent through MemberSync must be real and verifiable. No hallucinated data, no invented member details, no fabricated statistics.
- Rule 23 (new from March 8): Every AI call must be logged. Every AI feature must have a rate limit and a kill switch.
- Rule 24 (new from March 8): `triggeredCampaignProcessor.ts` is not to be modified for any reason without explicit written approval.

---

## 13. PROMPT QUEUE — CURRENT STATUS

### In Progress with Replit (can run in parallel — different files)
1. **Campaign Architect Planner Voice & Grouping Fix** (`MemberSync_CampaignArchitect_PlannerVoice_GroupingFix.md` in outputs) 🔄 Building
2. **Navigation Redesign Final** (`MemberSync_NavigationRedesign_Final.md` in outputs) 🔄 Building
3. **Member Profile Real Data Fix** (inline plan reviewed and approved) 🔄 Building

### Ready to Send (send in order after verifications)
4. **Nav Cleanup** (`MemberSync_NavCleanup_Prompt.md` in outputs) — send after nav verified
5. **AI Cost Controls** (`MemberSync_AICostControls_Prompt.md` in outputs) — send anytime (backend only, no shared files)
6. **Prompt C: AI Duplicate Detection** (`MemberSync_PromptC_AIDuplicateDetection.md` in project files) — send after Prompt B verified

### To Be Written (in order — next chat)
7. **CLAUDE.md comprehensive update** — the main goal of the next chat. Most important artifact for Monday.
8. **Recognition Homepage** — stat cards, "What's resonating," "Coming up" queue, daily digest direction
9. **Compliance Homepage** — triage dashboard
10. **SmartSends Home polish** — after nav verified and SmartSends.tsx retirement plan clear

### On Hold (Intentionally)
- A/B Testing standalone — superseded by Campaign Architect
- Automation Priority + Global Contact Limit — waiting for stability
- Member Journey execution engine — post-AEI; architecturally distinct from Campaign Architect

---

## 14. STANDING RULES (CANONICAL — 22 RULES)

1. `member_metrics_cache` is the single source of truth for member data in the UI. Never compute on the fly what the cache already provides.
2. Every query against external AMS/MLS tables must deduplicate using DISTINCT ON / ROW_NUMBER pattern.
3. Every query against external tables must filter by ApmClientId.
4. Never SUM(ClosePrice) across listing + buyer sides without applying the volume split.
5. All client-specific values go in `clientConfig.ts` (or `tenant_config` table). No hardcoded client references anywhere else.
6. Every feature must work for multiple clients through configuration, not custom code.
7. Real data only. No fake/sample data in preview systems, demo screens, or test flows.
8. No manual schema changes in production. All changes go through versioned database migrations.
9. Cache-first architecture. If a value can be pre-computed daily, it should be.
10. One task at a time. Each PR/commit should be focused and testable.
11. Voluntary contributions (RPAC, REF) are excluded from risk scoring entirely.
12. Non-CE event attendance is a stronger engagement signal than CE attendance.
13. Office suspension is the gatekeeper for MLS/SentriLock access — when an office goes inactive, all agents lose access regardless of individual payment status.
14. Every module must be gated by `tenant_config`. A disabled module should not render in the UI, should not run background jobs, and should not consume AI budget.
15. The 5% rule. Every screen must earn its place.
16. Mobile-first, performance-always. Every UI component must be responsive. Every data view must load in under 2 seconds.
17. Social proof is never used in Campaign Architect emails. No attendance numbers, no "members like you," no testimonials.
18. Minimum 3 emails per event in any Campaign Architect sequence (awareness + value reinforcement + urgency).
19. Campaign Architect branch points are shallow — registration status and prior attendance only. Deep conditional logic belongs in Member Journey.
20. Recognition is a top-level nav module. Never nest it inside SmartSends.
21. Nav items are destinations. Actions live in buttons.
22. Every email sent through MemberSync must be real and verifiable. No hallucinated data, no invented member details, no fabricated statistics. The AI observes real data and acts on it — it never invents.

**Two new rules from March 8 to be formalized in CLAUDE.md:**
- Every AI call must be logged. Every AI feature must have a rate limit and a kill switch.
- `triggeredCampaignProcessor.ts` is not to be modified for any reason without explicit written approval from Tracy.

---

## 15. ALL ARCHITECTURAL DECISIONS (CANONICAL)

- **Single PostgreSQL database in production.** Two-database prototype split is a Replit-only workaround (Tracy has read-only access to production). Not an architectural decision.
- **Cache-first architecture.** `member_metrics_cache` pre-computed daily. `member_metrics_cache` is the source of truth.
- **Scoring engine is data-driven, not code-driven.** Weights and active signals come from tenant configuration, not if-statements in code.
- **`tenant_config` table is Stage 0** before any multi-tenant work. All client-specific values must live there.
- **Schema modularization for AI context injection.** Load only relevant schema sections per query type. 41–76% schema size reductions achieved.
- **Recognition emails are Lane 1.** Exempt from Email Governor. No daily/weekly cap.
- **Campaign names:** "Recognition: [milestone_label] — [Month Year]"
- **Webhook matching:** `campaign_id` + `member_key` (existing pattern preserved).
- **Branch routing stored in `sendCondition` column as JSON** in `triggeredCampaignSteps`. No new table needed.
- **`sendDripStepEmail` is the canonical send helper** in `triggeredCampaignProcessor.ts`.
- **Member Journey is architecturally distinct from Campaign Architect.** Different execution model, different infrastructure, different build timeline. Do not conflate.
- **All URL paths for nav items unchanged.** Only display labels changed in nav redesign.
- **Compliance module hidden entirely for MLS clients.** Not just empty — fully hidden.
- **AI model selection:** Claude Sonnet for complex queries (AI Chat, Audience Builder, Campaign Architect). Claude Haiku for short-form variations (subject line alternatives, short copy). Reduces cost significantly at scale.
- **One Anthropic API key for all clients.** Membio controls all AI usage, all cost visibility, all rate limits. Clients never see or touch the key.
- **In-memory rate limit counters** are acceptable for Replit prototype. Must move to Redis for production multi-instance deployment.
- **`triggeredCampaignProcessor.ts` is not to be modified for any reason** without explicit written approval. It is sensitive execution infrastructure.
- **`sequenceEnrollmentService.ts` is sensitive execution infrastructure.** Handle with extreme care.

---

## 16. KNOWN ISSUES & TECHNICAL DEBT

### Critical (Production Blockers)
- `routes.ts` is ~9,500 lines — most urgent refactoring target. Must be split into logical modules.
- No multi-tenant data isolation — only `users` table has `client_id`. All other tables lack it.
- 110+ hardcoded "MainStreet" references throughout codebase.
- Illinois-specific compliance hardcoded in `clientConfig.ts` — not parameterized for NY (HGAR/GRAR).

### Important (Quality Before Mainstreet Goes Live)
- AI Chat UI feels empty on full Chats page — no suggested starters, no conversation history sidebar
- `MAX_CAMPAIGN_RECIPIENTS = 1` — needs bumping before real sends
- Date range picker missing from Email Archive UI (backend supports it)
- 172-member gap between dashboard count and member type builder count
- Revenue data uses catalog prices, not actual invoiced amounts
- Campaign Architect rate limiter is per-process in-memory — needs Redis for multi-instance

### Technical Debt (Parking Lot)
- Missing event warning at activation when anchor event has been removed
- Drip Sequence Step Editor needs proper EmailComposer integration
- Templates system needs full rework (currently not useful enough)
- Duplicate detection threshold (70%) should become configurable per client in `tenant_config`

### Recently Fixed (March 8)
- Member profile IL CE Progress — was hardcoded, now real
- Member profile Code of Ethics status — was hardcoded, now real
- Member profile engagement sub-scores — were hardcoded zeros, now real
- AppSidebar `Shield` import — orphaned, cleaned up
- SmartSends.tsx stale nav links — removed
- Audiences nav section — restored as nested collapsible with all 5 sub-items

---

## 17. KEY FILES REFERENCE

### Sensitive Files — Handle With Extreme Care
- `server/services/triggeredCampaignProcessor.ts` — **DO NOT MODIFY for any reason**
- `server/services/sequenceEnrollmentService.ts` — **sensitive execution infrastructure**

### Key Application Files
- `server/routes.ts` — Monolith (~9,500 lines) — most urgent refactoring target
- `shared/schema.ts` — All tables and TypeScript types (~1,217 lines)
- `client/src/pages/CampaignArchitect.tsx` — Campaign Architect UI (~1,834 lines)
- `server/services/aiCampaignPlannerService.ts` — Campaign Architect planner
- `client/src/components/layout/AppSidebar.tsx` — Navigation (post-redesign)
- `server/services/clientConfig.ts` — All client-specific values (must become `tenant_config`)
- `server/services/aiQueryService.ts` — AI Chat query service
- `server/services/aiEmailService.ts` — AI email composition
- `server/services/aiAudienceService.ts` — AI audience generation
- `server/services/memberMetricsCacheService.ts` — Engagement scoring engine

### Prompt Files — Deployed to Replit ✅
- `MemberSync_CampaignArchitect_Prompt1.md`
- `MemberSync_CampaignArchitect_Prompt2.md`
- `MemberSync_CampaignArchitect_Polish_Prompt.md`
- `MemberSync_CampaignArchitect_Hardening.md`
- `MemberSync_CampaignArchitect_PlannerFix.md` — Verified working
- `MemberSync_CampaignArchitect_Addendum.md`
- `MemberSync_SchemaModularization_Prompt.md`
- `MemberSync_AIChat_JuliusUpgrade_Prompt.md`
- `MemberSync_QueryEngine_RetryAndCrossDomain.md`
- `MemberSync_PromptA_RecognitionQueue_EmailGovernor.md` (Parts 1–8)
- `MemberSync_PromptB_EmailHealth_ImageLibrary.md`
- `MemberSync_ImageLibrary_Upgrade_Prompt.md`
- `MemberSync_PromptC_AIDuplicateDetection.md` — Written, ready to send after Prompt B verified

### Prompt Files — In Progress / Ready to Send (in outputs)
- `MemberSync_CampaignArchitect_PlannerVoice_GroupingFix.md` 🔄
- `MemberSync_NavigationRedesign_Final.md` 🔄
- `MemberSync_NavCleanup_Prompt.md` 📝 Ready
- `MemberSync_AICostControls_Prompt.md` 📝 Ready

### Planning / Reference Documents
- `CLAUDE.md` — 786 lines, last updated March 4. **Comprehensive update is the goal of the next chat.**
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog
- `MemberSync_Development_Plan.docx`
- `Membio_AI_Workflow_Playbook.docx`
- `MemberSync_CRMLS_Scaling_Roadmap.docx`

---

## 18. PARKING LOT SUMMARY

Full detail in `MemberSync_Parking_Lot.md`. Key items by section:

### Section 1: Features to Build (Prioritized)
1. **Proactive AI Engagement Engine** — daily pattern detection, connects to SmartSends actions. More compelling for demos than lapse prevention (positive, not reactive). Premium tier.
2. **Lapse Prevention System** — calendar-aware risk scoring, automated intervention. Plus tier.
3. **AI Chart Rendering** — Recharts inline in AI Chat, download-as-image. Accelerated for CRMLS pilot.
4. **Persistent Organizational Intelligence / AI Memory Layer** ⭐ STRATEGIC PRIORITY — store chat history per org, inject context into every AI call. Phase 1 (session persistence) targeted post-Monday, pre-AEI (~5–7 days Replit work). Makes MemberSync "the first thing opened in the morning."
5. **Email Archive as AI Memory** — AI reads archive before composing/planning. Subject line suggestions informed by historical performance. Duplicate detection (Prompt C) is first step.
6. **Campaign Engagement Map** ⭐ DEMO-WORTHY — scatter/bubble chart: X=time, Y=category, dot size=audience, dot color=engagement. Every sent email = one dot. Living quality (colors shift as engagement data arrives over 48h). Buildable with D3.js or Recharts. 1–2 Replit prompts.
7. **Member Journey** — architecturally distinct from Campaign Architect. Post-AEI.
8. **Competitive Intelligence Module** — territory-aware AI Chat queries, competitive framing for lapse prevention.
9. **Broker Module** — office payment health, suspension impact analysis. Email stays in SmartSends.
10. **AI Learning / Network Effect Engine** — cross-client campaign performance learning.

### Section 2: Features to Improve
- Templates system — not useful enough
- Revenue data — actual invoiced amounts, not catalog prices

### Section 3: Infrastructure & Scale
- SOC 2 Certification (required for CRMLS)
- Prompt caching (90% cost reduction on input)
- Batch email sending (for CRMLS scale)
- Multi-tenant Admin Provisioning Dashboard
- Self-service onboarding (after 4–5 manual clients)
- Integration Marketplace (Zendesk, Google Analytics, lockbox, LMS)

### Section 4: Must Be Configured Per Client (tenant_config)
Full list in Parking Lot. Key items:
- Image Library Notifications category — gate on `has_member_portal`
- Compliance module — gate on `org_type === 'association'`
- Engagement scoring weights and tier thresholds
- State-specific compliance rules (IL vs NY)
- Office suspension model
- Org branding in email templates (110+ Mainstreet references)
- Billing calendar
- SmartSends portal-only features
- AI geographic context
- Duplicate detection threshold
- Competitive intelligence territory boundaries
- AI Chart default chart types per org type

**CLAUDE.md implication:** A dedicated `tenant_config` complete field reference section is explicitly called out as missing and must be added in the update.

---

## NEXT CHAT GOALS (Priority Order)

1. **Write the comprehensive CLAUDE.md update** — this is the primary goal. Use the outline in Section 12. Write it as the dev team's north star, not just a description of today's state.
2. **Write the Recognition Homepage prompt** — stat cards, "What's resonating," "Coming up" queue
3. **Write the Compliance Homepage prompt** — triage dashboard
4. Whatever else Replit builds tonight that needs speccing

---

*Session date: March 8, 2026 (evening).*
*Replit currently building: Campaign Architect Planner Voice fix, Navigation Redesign, Member Profile real data fix — all in parallel.*
*Next: Open new chat → upload this summary → write CLAUDE.md.*

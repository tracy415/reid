# MemberSync — Queue & Safety UX Redesign + Temporal Safeguards

## Date: February 24, 2026
## Priority: Send now — fixes the 75K email problem and cleans up the UI

---

## REPLIT STANDING RULES

**These rules apply to this prompt and ALL future prompts for this project. Treat them as permanent.**

### Rule 1: No Parallel Systems
Before building any new UI component, service, or utility function, search the existing codebase for similar functionality. If a component already exists that does 70% or more of what's needed, extend or adapt it with configuration flags rather than creating a new version. Never build a parallel implementation of something that already works. If you are unsure whether to reuse or rebuild, stop and ask before proceeding.

### Rule 2: Don't Break What Works
Before modifying any existing file, understand what it currently does. Run the app and verify the feature works before changing it. After your changes, verify the feature still works. If a prompt asks you to add something new, the existing functionality must continue to work exactly as it did before.

### Rule 3: Full-Page Patterns, Not Modals
This application uses full-page wizard flows for multi-step tasks (Send Email, Create Automation). Do not introduce modal dialogs for tasks that involve more than a single confirmation or a simple input. If an existing flow uses a modal where a full-page pattern would be more consistent, flag it — don't add another modal.

### Rule 4: Shared Components Over Duplicates
If two features need similar UI (e.g., email composition in Send Email and in Automations), they must use the same shared component configured with props or flags — not two separate implementations. Before creating any new component, check `/client/src/components/` and the existing page files for something reusable.

### Rule 5: Server-Side for Scale
Any operation that could involve more than 1,000 records (audience resolution, email queuing, CSV export) must happen on the server, not the client. Pass IDs and let the server do the heavy lifting.

### Rule 6: Test Your Work
After implementing changes, verify them yourself before marking complete. Check both the happy path (everything works as expected) and at least one edge case (empty data, large data set, missing fields).

---

## CONTEXT

The Email Safety prompt was implemented and the backend works correctly — queue export, flush, throttle all functional. But the frontend UX needs three changes:

1. **The Dashboard has two large alert banners** (Email Safety Controls + Email Queue) that consume too much screen space. These should become compact inline status badges next to the existing "SendGrid Connected" badge.
2. **The Automations page has no queue visibility** — the queue control panel with per-automation breakdown, Download CSV, and Flush Queue needs to live there.
3. **The event registration trigger has no future-event filter** — it sweeps up all historical registrations, which caused 75,247 junk emails. This is the root cause of the queue explosion and must be fixed.

---

## PART 1: DASHBOARD — INLINE STATUS BADGES

### What to remove

**Remove entirely** from `SmartSends.tsx`:

1. The **"Email Safety Controls Active"** banner card (approximately lines 553–572) — the entire `{status?.safetyActive && ( <Card ...> ... </Card> )}` block.

2. The **"Email Queue"** status card (approximately lines 574–616) — the entire `{queueStatus && queueStatus.queuedCount > 0 && ( <Card ...> ... </Card> )}` block.

3. The **Flush Queue confirmation dialog** (approximately lines 618–640) — move this to the Automations page (Part 2).

4. The `flushDialogOpen` state, `flushQueueMutation`, and `handleDownloadQueueCSV` function — move these to the Automations page (Part 2).

**Keep** the `queueStatus` query — the Dashboard still needs the count for the badge.

### What to add

In the existing badge row where "SendGrid Connected" appears (approximately line 645–657), add two new badges after the SendGrid badge. The result should look like:

```tsx
<div className="flex items-center gap-2 flex-wrap">
  {/* Existing SendGrid badge — keep exactly as-is */}
  {status?.configured ? (
    <Badge variant="secondary" className="bg-green-500/10 text-green-600 border-green-200">
      <CheckCircle className="h-3 w-3 mr-1" />
      SendGrid Connected
    </Badge>
  ) : (
    <Badge variant="destructive">
      <AlertTriangle className="h-3 w-3 mr-1" />
      SendGrid Not Configured
    </Badge>
  )}

  {/* NEW: Sandbox Mode badge — only shows when sandbox is active */}
  {status?.sandboxMode && (
    <Badge variant="secondary" className="bg-amber-500/10 text-amber-700 border-amber-200 dark:text-amber-400 dark:border-amber-700">
      <ShieldCheck className="h-3 w-3 mr-1" />
      Sandbox Mode
    </Badge>
  )}

  {/* NEW: Queue count badge — only shows when emails are queued, clickable */}
  {queueStatus && queueStatus.queuedCount > 0 && (
    <Badge 
      variant="secondary" 
      className="bg-blue-500/10 text-blue-700 border-blue-200 dark:text-blue-400 dark:border-blue-700 cursor-pointer hover:bg-blue-500/20 transition-colors"
      onClick={() => navigate('/smartsends/automations')}
      data-testid="badge-queue-count"
    >
      <Mail className="h-3 w-3 mr-1" />
      {queueStatus.queuedCount.toLocaleString()} Queued
    </Badge>
  )}
</div>
```

**The visual result** on the Dashboard:

When everything is active:
```
SmartSends Dashboard
✓ SendGrid Connected   🛡 Sandbox Mode   ✉ 75,330 Queued
```

When sandbox is off and queue is empty:
```
SmartSends Dashboard
✓ SendGrid Connected
```

When sandbox is off but there's a queue:
```
SmartSends Dashboard
✓ SendGrid Connected   ✉ 247 Queued
```

The queue badge is clickable — it navigates to `/smartsends/automations` where the full control panel lives. The sandbox badge is informational only (not clickable — it's an environment setting).

**Color coding:**
- Green badge = SendGrid connected (things are working)
- Amber badge = Sandbox mode (heads up — emails aren't going out)
- Blue badge = Queue count (action may be needed — click for details)

These colors match the existing application color conventions.

---

## PART 2: AUTOMATIONS PAGE — FULL QUEUE CONTROL PANEL

### New API Endpoint: Per-Automation Queue Breakdown

Add to `routes.ts`:

```
GET /api/smartsends/queue/breakdown
```

**Response:**

```json
{
  "totalQueued": 75330,
  "sandboxMode": true,
  "byAutomation": [
    {
      "automation_campaign_id": "uuid",
      "automation_name": "Generic Event Registration Confirmation",
      "trigger_type": "event_reminder",
      "automation_status": "paused",
      "queued_count": 75247,
      "oldest_queued": "2026-02-24T14:39:00Z",
      "newest_queued": "2026-02-24T14:39:01Z"
    },
    {
      "automation_campaign_id": "uuid",
      "automation_name": "Membership Anniversary Celebration",
      "trigger_type": "membership_anniversary",
      "automation_status": "active",
      "queued_count": 38,
      "oldest_queued": "2026-02-24T14:39:01Z",
      "newest_queued": "2026-02-24T14:39:01Z"
    }
  ],
  "manualQueued": 16,
  "scheduledQueued": 0
}
```

**Implementation:**

```typescript
app.get("/api/smartsends/queue/breakdown", authMiddleware, async (req, res) => {
  try {
    const { getEmailSafetyStatus } = await import('./services/emailService');
    const safety = getEmailSafetyStatus();

    const result = await db.execute(sql`
      WITH queued_recipients AS (
        SELECT er.campaign_id, COUNT(*)::int AS cnt,
               MIN(er.queued_at) AS oldest,
               MAX(er.queued_at) AS newest
        FROM email_recipients er
        WHERE er.status IN ('queued', 'sending')
        GROUP BY er.campaign_id
      ),
      automation_queued AS (
        SELECT 
          tc.campaign_id AS automation_campaign_id,
          tc.campaign_name AS automation_name,
          tc.trigger_type,
          tc.status AS automation_status,
          SUM(qr.cnt)::int AS queued_count,
          MIN(qr.oldest) AS oldest_queued,
          MAX(qr.newest) AS newest_queued
        FROM queued_recipients qr
        JOIN triggered_campaign_sends tcs ON tcs.email_campaign_id = qr.campaign_id
        JOIN triggered_campaigns tc ON tc.campaign_id = tcs.campaign_id
        GROUP BY tc.campaign_id, tc.campaign_name, tc.trigger_type, tc.status
        ORDER BY SUM(qr.cnt) DESC
      ),
      non_automation AS (
        SELECT 
          COALESCE(SUM(CASE 
            WHEN EXISTS (SELECT 1 FROM scheduled_campaigns sc WHERE sc.campaign_id = qr.campaign_id) 
            THEN qr.cnt ELSE 0 END), 0)::int AS scheduled_count,
          COALESCE(SUM(CASE 
            WHEN NOT EXISTS (SELECT 1 FROM triggered_campaign_sends tcs WHERE tcs.email_campaign_id = qr.campaign_id)
            AND NOT EXISTS (SELECT 1 FROM scheduled_campaigns sc WHERE sc.campaign_id = qr.campaign_id)
            THEN qr.cnt ELSE 0 END), 0)::int AS manual_count
        FROM queued_recipients qr
      )
      SELECT 
        (SELECT COALESCE(SUM(cnt), 0)::int FROM queued_recipients) AS total_queued,
        (SELECT json_agg(row_to_json(aq)) FROM automation_queued aq) AS by_automation,
        na.scheduled_count,
        na.manual_count
      FROM non_automation na
    `);

    const row = (result.rows as any[])[0] || {};

    res.json({
      totalQueued: Number(row.total_queued || 0),
      sandboxMode: safety.sandboxMode,
      byAutomation: row.by_automation || [],
      manualQueued: Number(row.manual_count || 0),
      scheduledQueued: Number(row.scheduled_count || 0),
    });
  } catch (error) {
    console.error("Queue breakdown error:", error);
    res.status(500).json({ message: "Failed to get queue breakdown" });
  }
});
```

### Add Queue Control Panel to Automations Page

Find the Automations page component. It is a separate page from SmartSends.tsx — look in `client/src/pages/` for an Automations component, or find where the SmartSends sidebar navigation routes to when "Automations" is clicked. The volume summary bar ("1 active automations · ~12 emails generated in last 24h · Daily send limit: 2 per member") is already on this page — the queue control panel goes ABOVE the volume summary bar, between the stat cards (Active/Paused/Drafts/Total Sent) and the volume summary.

**Only show the control panel when there are queued emails (totalQueued > 0).**

**Add query:**

```tsx
const { data: queueBreakdown } = useQuery<{
  totalQueued: number;
  sandboxMode: boolean;
  byAutomation: Array<{
    automation_campaign_id: string;
    automation_name: string;
    trigger_type: string;
    automation_status: string;
    queued_count: number;
    oldest_queued: string;
    newest_queued: string;
  }>;
  manualQueued: number;
  scheduledQueued: number;
}>({
  queryKey: ["/api/smartsends/queue/breakdown"],
  refetchInterval: 30000,
});
```

**Add flush mutation and CSV download** (moved from SmartSends.tsx — do NOT duplicate):

```tsx
const [flushDialogOpen, setFlushDialogOpen] = useState(false);

const flushQueueMutation = useMutation({
  mutationFn: async () => {
    const response = await apiRequest('POST', '/api/smartsends/queue/flush');
    return response.json();
  },
  onSuccess: (data: { flushed: number }) => {
    queryClient.invalidateQueries({ queryKey: ['/api/smartsends/queue/breakdown'] });
    queryClient.invalidateQueries({ queryKey: ['/api/smartsends/queue-count'] });
    queryClient.invalidateQueries({ queryKey: ['/api/smartsends/automations/volume-summary'] });
    setFlushDialogOpen(false);
    toast({
      title: "Queue Flushed",
      description: `${data.flushed.toLocaleString()} queued emails have been permanently deleted.`,
    });
  },
});

const handleDownloadQueueCSV = () => {
  window.open('/api/smartsends/queue/export?status=queued', '_blank');
};
```

**Render the control panel (between stat cards and volume summary bar):**

```tsx
{queueBreakdown && queueBreakdown.totalQueued > 0 && (
  <Card className="border-blue-200 dark:border-blue-800">
    <CardContent className="p-4">
      <div className="space-y-3">
        {/* Header row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mail className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <span className="font-medium text-sm">
              Email Queue: {queueBreakdown.totalQueued.toLocaleString()} waiting
            </span>
            {queueBreakdown.sandboxMode && (
              <Badge variant="outline" className="text-xs border-amber-300 text-amber-700 dark:border-amber-700 dark:text-amber-400">
                Sandbox — Not Sending
              </Badge>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleDownloadQueueCSV}>
              <Download className="h-3.5 w-3.5 mr-1.5" />
              Download CSV
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-red-600 hover:text-red-700 border-red-200 hover:border-red-300 hover:bg-red-50 dark:text-red-400 dark:border-red-800 dark:hover:bg-red-950/30"
              onClick={() => setFlushDialogOpen(true)}
            >
              <Trash2 className="h-3.5 w-3.5 mr-1.5" />
              Flush Queue
            </Button>
          </div>
        </div>

        {/* Per-automation breakdown table */}
        {queueBreakdown.byAutomation && queueBreakdown.byAutomation.length > 0 && (
          <div className="border rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50 border-b">
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Automation</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Trigger</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Status</th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground">Queued</th>
                </tr>
              </thead>
              <tbody>
                {queueBreakdown.byAutomation.map((item, index) => (
                  <tr key={item.automation_campaign_id || index} className="border-b last:border-b-0">
                    <td className="px-3 py-2 font-medium">{item.automation_name}</td>
                    <td className="px-3 py-2">
                      <Badge variant="secondary" className="text-xs">
                        {item.trigger_type?.replace(/_/g, ' ')}
                      </Badge>
                    </td>
                    <td className="px-3 py-2">
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${
                          item.automation_status === 'active' 
                            ? 'border-green-300 text-green-700 dark:border-green-700 dark:text-green-400' 
                            : item.automation_status === 'paused'
                            ? 'border-orange-300 text-orange-700 dark:border-orange-700 dark:text-orange-400'
                            : 'border-gray-300 text-gray-500'
                        }`}
                      >
                        {item.automation_status}
                      </Badge>
                    </td>
                    <td className="px-3 py-2 text-right font-mono">
                      {item.queued_count.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Non-automation queued items */}
        {(queueBreakdown.manualQueued > 0 || queueBreakdown.scheduledQueued > 0) && (
          <div className="text-xs text-muted-foreground flex gap-4">
            {queueBreakdown.manualQueued > 0 && (
              <span>Manual campaigns: {queueBreakdown.manualQueued.toLocaleString()}</span>
            )}
            {queueBreakdown.scheduledQueued > 0 && (
              <span>Scheduled: {queueBreakdown.scheduledQueued.toLocaleString()}</span>
            )}
          </div>
        )}
      </div>
    </CardContent>
  </Card>
)}

{/* Flush confirmation dialog */}
<Dialog open={flushDialogOpen} onOpenChange={setFlushDialogOpen}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Flush Email Queue</DialogTitle>
      <DialogDescription>
        This will permanently delete all {queueBreakdown?.totalQueued.toLocaleString()} queued emails. They will NOT be sent. Are you sure?
      </DialogDescription>
    </DialogHeader>
    <DialogFooter>
      <Button variant="outline" onClick={() => setFlushDialogOpen(false)}>
        Cancel
      </Button>
      <Button
        variant="destructive"
        onClick={() => flushQueueMutation.mutate()}
        disabled={flushQueueMutation.isPending}
      >
        {flushQueueMutation.isPending ? 'Flushing...' : `Delete ${queueBreakdown?.totalQueued.toLocaleString()} Emails`}
      </Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

The control panel renders as:

```
┌──────────────────────────────────────────────────────────────────────┐
│  ✉ Email Queue: 75,330 waiting   [Sandbox — Not Sending]           │
│                                        [Download CSV] [Flush Queue] │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ Automation                          │ Trigger     │Status│Queued│  │
│  ├────────────────────────────────────────────────────────────────┤  │
│  │ Generic Event Registration Confirm. │event reminder│paused│75,247│ │
│  │ Membership Anniversary Celebration  │membership an.│active│   38│  │
│  └────────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  Manual campaigns: 16                                                │
└──────────────────────────────────────────────────────────────────────┘
```

---

## PART 3: TEMPORAL SAFEGUARDS — NO HISTORICAL EMAILS

### The Root Cause of the 75,000-Email Problem

The `evaluateEventRegistration()` function in `triggeredCampaignProcessor.ts` queries `activity_cache` for registrations cached in the last N days — but it has **no filter for whether the event itself is in the future.** The activity cache gets refreshed daily, so `cached_at` reflects when the cache was rebuilt, NOT when the event takes place. This means every single historical event registration gets swept up on every cache refresh, generating emails for events that happened months or years ago.

### Universal Rule: No automation should ever generate emails about events, dates, or milestones that have already passed.

Apply the following fixes to each trigger evaluator in `triggeredCampaignProcessor.ts`:

### Fix 1: `evaluateEventRegistration()` — Add future-event filter

The current query (approximately line 268) looks like:

```sql
SELECT DISTINCT a.member_key, m.member_name, m.member_email,
  a.activity_name, a.event_id, a.start_datetime
FROM activity_cache a
JOIN member_metrics_cache m ON a.member_key = m.member_key
WHERE m.member_status = 'Active'
  AND m.member_email IS NOT NULL
  AND a.cached_at >= NOW() - INTERVAL 'X days'
```

**Change it to:**

```sql
SELECT DISTINCT a.member_key, m.member_name, m.member_email,
  a.activity_name, a.event_id, a.start_datetime
FROM activity_cache a
JOIN member_metrics_cache m ON a.member_key = m.member_key
WHERE m.member_status = 'Active'
  AND m.member_email IS NOT NULL
  AND a.cached_at >= NOW() - INTERVAL 'X days'
  AND a.start_datetime >= CURRENT_DATE
```

The added `AND a.start_datetime >= CURRENT_DATE` line ensures we only send registration confirmations for events that haven't happened yet. If someone registered for a class last month, they don't get a confirmation email today.

### Fix 2: `evaluateEventReminder()` — Already correct, no change needed

This function already filters by:
```sql
AND e."StartDateTime"::date = (CURRENT_DATE + INTERVAL 'X days')::date
```
This correctly finds only future events happening X days from now.

### Fix 3: `evaluateEventFollowup()` — Add max lookback cap

This function queries for events that ended X days ago, which is correct for its purpose. **But add a safety cap** so nobody can accidentally configure a follow-up that reaches months into the past.

Change the line that reads the `daysAfter` config:

```typescript
// BEFORE:
const daysAfter = config.daysAfter || 1;

// AFTER:
const daysAfter = Math.min(config.daysAfter || 1, 14); // Cap at 14 days max
```

### Fix 4: `evaluateMembershipAnniversary()` — Already correct, no change needed

Correctly matches on today's exact month and day only.

### Fix 5: `evaluateProductionMilestone()` — Already correct, no change needed

Correctly looks back only 7 days from milestone detection date.

### Fix 6: `evaluateScheduledSeries()` — Already correct, no change needed

Correctly fires only on the exact scheduled send date.

### Summary of Changes

| Trigger Type | Issue | Fix |
|---|---|---|
| `event_registration` | No future-event filter — sweeps all historical registrations | Add `AND a.start_datetime >= CURRENT_DATE` |
| `event_reminder` | None | No change |
| `event_followup` | No max lookback cap | Clamp `daysAfter` to max 14 |
| `membership_anniversary` | None | No change |
| `production_milestone` | None | No change |
| `scheduled_series` | None | No change |

---

## VERIFICATION CHECKLIST

### Dashboard Badges (SmartSends.tsx)
- [ ] "Email Safety Controls Active" banner card is completely removed
- [ ] "Email Queue" status card is completely removed
- [ ] Flush dialog, flush mutation, and download function are removed from SmartSends.tsx
- [ ] "SendGrid Connected" badge still works exactly as before
- [ ] New "Sandbox Mode" badge appears in amber when `status.sandboxMode` is true
- [ ] New queue count badge appears in blue when `queueStatus.queuedCount > 0`
- [ ] Queue count badge shows the number formatted with commas (e.g., "75,330 Queued")
- [ ] Queue count badge is clickable and navigates to `/smartsends/automations`
- [ ] Sandbox badge is NOT clickable (informational only)
- [ ] When sandbox mode is off, the sandbox badge disappears
- [ ] When queue is empty, the queue badge disappears
- [ ] When both are off/empty, only "SendGrid Connected" shows
- [ ] All three badges wrap gracefully on narrow screens (flex-wrap)
- [ ] All existing SmartSends Dashboard functionality still works
- [ ] Campaign metrics cards, campaign list, tabs all still work

### Automations Page Control Panel
- [ ] Queue control panel appears between stat cards and volume summary bar
- [ ] Control panel only appears when totalQueued > 0
- [ ] Per-automation breakdown table shows each automation's name, trigger type, status, and queued count
- [ ] Table is sorted by queued count descending (biggest contributor at top)
- [ ] Sandbox mode badge appears in the control panel header when sandbox is active
- [ ] "Download CSV" button triggers browser download of queue export
- [ ] "Flush Queue" button shows confirmation dialog before deleting
- [ ] Flush confirmation dialog shows the total count
- [ ] After flushing, the control panel disappears (queue is empty)
- [ ] After flushing, the Dashboard queue badge also disappears (queries are invalidated)
- [ ] Manual and scheduled queued counts appear below the table when > 0
- [ ] Volume summary bar still works below the control panel
- [ ] All existing Automations page functionality still works (automation cards, create, edit, pause, resume)

### Backend
- [ ] `GET /api/smartsends/queue/breakdown` endpoint returns per-automation breakdown
- [ ] Breakdown includes automation name, trigger type, automation status, and queued count
- [ ] Breakdown is sorted by queued_count descending
- [ ] Non-automation queued emails are counted separately (manual vs. scheduled)
- [ ] Endpoint handles empty queue gracefully (returns totalQueued: 0, empty byAutomation array)
- [ ] Existing queue-count, queue/export, and queue/flush endpoints still work unchanged

### Temporal Safeguards
- [ ] `evaluateEventRegistration()` only returns members registered for events today or in the future
- [ ] Historical event registrations (past events) are never matched
- [ ] `evaluateEventFollowup()` clamps daysAfter to a maximum of 14
- [ ] `evaluateEventReminder()` still works correctly (no change needed)
- [ ] `evaluateMembershipAnniversary()` still works correctly (no change needed)
- [ ] `evaluateProductionMilestone()` still works correctly (no change needed)
- [ ] Existing deduplication still prevents repeat sends
- [ ] After deploying, the event registration trigger produces a reasonable number of sends (tens or low hundreds, not tens of thousands)

---

## FILES TO MODIFY

- `server/routes.ts` — Add `GET /api/smartsends/queue/breakdown` endpoint
- `server/services/triggeredCampaignProcessor.ts` — Add `AND a.start_datetime >= CURRENT_DATE` to `evaluateEventRegistration()`, clamp daysAfter in `evaluateEventFollowup()`
- `client/src/pages/SmartSends.tsx` — Remove both banner cards, remove flush controls, add Sandbox Mode and Queue Count badges to the existing badge row
- The Automations page component (find it — check `client/src/pages/` for the component that renders when "Automations" is clicked in the sidebar; the volume summary bar is already on this page) — Add queue control panel with breakdown table, flush mutation, CSV download, flush confirmation dialog

## FILES NOT MODIFIED (do not touch)

- `server/services/emailService.ts` — No changes
- `server/services/scheduledEmailProcessor.ts` — No changes
- `client/src/pages/SendEmail.tsx` — No changes
- `client/src/pages/CampaignDetail.tsx` — No changes

# SmartSends: Audience Builder Improvements
## Replit Prompt â€” February 2026

This prompt adds three improvements to the SmartSends audience system:
1. **Two new audience creation methods** added alongside the existing AI builder
2. **Inline audience creation** during email composition so users stay in the flow
3. **AI Query Service awareness** of member associations and bill types

**CRITICAL: Do NOT modify, replace, or break the existing AI Audience Builder page or its functionality.** The AI Builder page, the "Generate Audience" flow, the saved audiences table, and the Upload page all stay exactly as they are. We are adding new options alongside them.

---

## HOW IT WORKS TODAY (Do Not Break This)

### Standalone Audience Section (Left Nav: SmartSends â†’ Audiences)

The Audiences section has three sub-pages in the left nav:
- **AI Builder** â€” Text input describing the audience, "Generate Audience" button, preview, save. Below it: saved audiences table showing name, type badge, member count, date, delete action.
- **Saved** â€” List of all saved audiences
- **Upload** â€” CSV/Excel upload flow

### Send Email Flow (Left Nav: SmartSends â†’ Send Email)

The "Send Email" page has a 5-step stepper: Choose Audience â†’ Create Email â†’ Compose â†’ Preview â†’ Send.

Step 1 ("Choose Audience") currently has:
- Two tabs at the top: "Saved Audiences" and "AI Audience Builder"
- The "AI Audience Builder" tab shows a card with an "Open AI Audience Builder" button that **navigates the user away** from the Send Email page to the standalone AI Builder page. This is the bad experience we're fixing.
- Below the tabs: a dropdown labeled "Or select a previously saved audience" with a "Choose a saved audience..." placeholder
- A "Next" button at the bottom right

### Audience Data Model

The `saved_audiences` table stores all audiences. It already supports these `sourceType` values:
- `'ai_generated'` â€” Smart AI audiences with SQL queries
- `'manual'` â€” Manual member selection
- `'csv_upload'` â€” Uploaded CSV files matched to members
- `'external_contacts'` â€” Non-member email lists

Key fields:
- `isSmart` (boolean) â€” `true` = re-query every time; `false` = fixed member list
- `memberKeys` (text[]) â€” stores fixed member key arrays for static audiences
- `sqlQuery` (text) â€” stores SQL for smart audiences
- `memberCount` (integer) â€” cached count
- `sourceType` (text) â€” how the audience was created
- `externalContacts` (jsonb) â€” stores non-member contact entries as JSON array
- `isExternal` (boolean) â€” true if audience is entirely external contacts
- `termsAccepted` (boolean) â€” whether CSV upload terms were accepted
- `termsAcceptedAt` (timestamp) â€” when terms were accepted
- `termsAcceptanceIp` (text) â€” IP address at time of acceptance

The `getAudienceMembers()` function in `aiAudienceService.ts` handles all audience types by branching on `isSmart`, `isExternal`, and `memberKeys`. New audience types must plug into this same pattern.

---

## PART 1: ADD TWO NEW AUDIENCE CREATION METHODS

### 1A. New Left Nav Items Under Audiences

Add two new sub-pages under SmartSends â†’ Audiences in the left navigation:

```
SmartSends
  â”œâ”€â”€ Dashboard
  â”œâ”€â”€ Send Email
  â”œâ”€â”€ Campaigns
  â”œâ”€â”€ Audiences â–¾
  â”‚     â”œâ”€â”€ AI Builder      (existing â€” do not change)
  â”‚     â”œâ”€â”€ Picklist         â† NEW
  â”‚     â”œâ”€â”€ Member/Bill Type â† NEW
  â”‚     â”œâ”€â”€ Saved            (existing â€” do not change)
  â”‚     â””â”€â”€ Upload           (existing â€” do not change)
  â”œâ”€â”€ Templates
  â”œâ”€â”€ Drafts
  â””â”€â”€ Image Library
```

---

### 1B. Picklist Page (New: SmartSends â†’ Audiences â†’ Picklist)

**What it is:** A page where the user searches for members by name and picks them one at a time to build a fixed audience. They can also add non-members (VIP guests, board visitors, etc.) by typing in a name and email. They can optionally upload a CSV/Excel file to add more people in bulk â€” the CSV can contain both members and non-members. The audience is **static** (`isSmart: false`) â€” it only changes when a human edits it.

**Page Layout:**

```
SmartSends > Picklist

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  ðŸ“‹ Picklist Audience Builder                                â”‚
â”‚  Hand-pick specific members for your audience.               â”‚
â”‚                                                              â”‚
â”‚  Search members:                                             â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”        â”‚
â”‚  â”‚ ðŸ” Type a name or email...                       â”‚        â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜        â”‚
â”‚                                                              â”‚
â”‚  (Search results appear as user types â€” min 2 characters)    â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”        â”‚
â”‚  â”‚ + Sarah Johnson                                  â”‚        â”‚
â”‚  â”‚   RE/MAX Premier â€¢ sarah.johnson@email.com       â”‚        â”‚
â”‚  â”‚ + Sarah Jones                                    â”‚        â”‚
â”‚  â”‚   Keller Williams â€¢ sjones@kw.com                â”‚        â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜        â”‚
â”‚                                                              â”‚
â”‚  â”€â”€ or add a non-member â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€        â”‚
â”‚  [+ Add Non-Member]                                          â”‚
â”‚                                                              â”‚
â”‚  â”€â”€ or add from file â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€        â”‚
â”‚  [Upload CSV/Excel]  Matches by email or MemberKey           â”‚
â”‚                                                              â”‚
â”‚  â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€       â”‚
â”‚                                                              â”‚
â”‚  Selected (5):                                   [Clear All] â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”    â”‚
â”‚  â”‚ Name              â”‚ Office            â”‚ Email     â”‚   â”‚    â”‚
â”‚  â”‚ Michael Brown     â”‚ Century 21 North  â”‚ mb@c21.comâ”‚ âœ• â”‚    â”‚
â”‚  â”‚ Lisa Chen         â”‚ Berkshire Hathawayâ”‚ lc@bh.com â”‚ âœ• â”‚    â”‚
â”‚  â”‚ David Martinez    â”‚ Smith & Associatesâ”‚ dm@sa.com â”‚ âœ• â”‚    â”‚
â”‚  â”‚ John Doe (non-member) â”‚ City of Naperville â”‚ jd@city.gov â”‚ âœ• â”‚
â”‚  â”‚ Jane Smith (non-member) â”‚              â”‚ js@co.com â”‚ âœ• â”‚    â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜    â”‚
â”‚                                                              â”‚
â”‚  Audience Name: [________________________]                   â”‚
â”‚  Description:   [________________________] (optional)        â”‚
â”‚                                                              â”‚
â”‚  [Save Audience]                                             â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Search Dropdown Style:**

Use the same dropdown search component style used on the **Agent Production Leaderboard** page (the office filter search box in the top-right corner). Each search result row should show:
- **Primary text:** Member name (bold)
- **Secondary text:** Office name â€¢ email address
- Clicking a result adds the member to the selected list below and clears the search

**New API Endpoint â€” Member Search (for autocomplete):**

```
GET /api/members/search?q=sarah&limit=10
```

Query the `member_metrics_cache` table (fast local database, NOT the external production database):

```sql
SELECT member_key, member_name, member_email, office_name
FROM member_metrics_cache
WHERE member_status = 'Active'
  AND (
    member_name ILIKE '%' || $1 || '%'
    OR member_email ILIKE '%' || $1 || '%'
  )
ORDER BY member_name
LIMIT 10
```

Require at least 2 characters before firing the search. Debounce input on the frontend (300ms).

**Adding Non-Members (VIP Guests, Board Visitors, etc.):**

Below the member search, add a link/button to add people who are NOT in the Mainstreet membership database:

```
[+ Add Non-Member]

(Clicking opens a small inline form:)
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  First Name: [____________]  Last Name: [____________]â”‚
â”‚  Email:      [____________]  Company:   [____________]â”‚
â”‚                              (optional)               â”‚
â”‚  [Add to List]  [Cancel]                              â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

Email is required. Non-members appear in the selected list with a "(non-member)" label next to their name so the user can tell them apart from real members.

Non-members are stored in the `externalContacts` JSONB field on the `saved_audiences` record (this field already exists and is used by external contact audiences). Each non-member entry:

```json
{
  "firstName": "John",
  "lastName": "Doe",
  "fullName": "John Doe",
  "email": "john.doe@example.com",
  "company": "City of Naperville",
  "isNonMember": true
}
```

**CSV Upload â€” Handling Both Members and Non-Members:**

When the user clicks "Upload CSV/Excel":

1. **Terms acceptance first.** Show the **same terms acceptance dialog** used by the existing CSV Upload page (SmartSends â†’ Audiences â†’ Upload). The user must accept terms before the file is processed. Store `termsAccepted`, `termsAcceptedAt`, and `termsAcceptanceIp` on the saved audience record.

2. **Parse the file** using the existing `csvUploadService.ts` logic. The user maps columns (the existing field-mapping preview step).

3. **Match rows against active members** using email or MemberKey against `member_metrics_cache`.

4. **Three outcomes per row:**
   - **Matched:** Row matched an active member â†’ add to the member list (stored in `memberKeys`)
   - **Unmatched but has valid email:** Row didn't match a member but has a valid email address â†’ treat as a non-member (stored in `externalContacts`)
   - **Unusable:** No email and no matching MemberKey â†’ skip

5. **Show the user a clear summary:**
   ```
   Upload Results:
   âœ“ 12 rows matched to active members
   âœ“ 3 rows added as non-members (no member match, valid email)
   âœ— 1 row skipped (no email or member key)
   
   [Add All to List]  [Cancel]
   ```
   
   The user confirms before the rows are added to the selected list.

6. **Deduplication:** If a CSV row matches a member already in the selected list, skip it. If a non-member email already exists in the selected non-members, skip it.

**Save Picklist Audience:**

Use the existing `POST /api/audiences` (or `saveAudience()` function). Payload for a picklist that includes both members and non-members:

```json
{
  "name": "Board Dinner Invitees",
  "description": "Board members plus VIP guests",
  "isSmart": false,
  "memberKeys": ["259036", "184522", "301887"],
  "externalContacts": [
    {
      "firstName": "John",
      "lastName": "Doe",
      "fullName": "John Doe",
      "email": "john.doe@example.com",
      "company": "City of Naperville",
      "isNonMember": true
    }
  ],
  "sourceType": "picklist",
  "termsAccepted": true,
  "termsAcceptedAt": "2026-02-12T...",
  "termsAcceptanceIp": "...",
  "createdBy": "user-uuid"
}
```

`memberKeys` stores real members; `externalContacts` stores non-members. The `memberCount` should reflect the total (members + non-members).

**Update `getAudienceMembers()` for Picklist with Mixed Members:**

The existing `getAudienceMembers()` function has separate branches for `memberKeys` and `externalContacts`, but a picklist can have BOTH. Add a combined handling path:

When `audience.sourceType === 'picklist'`:
1. If `memberKeys` has entries, look up member details from external DB (existing logic)
2. If `externalContacts` has entries, include them directly (existing logic)
3. Combine both lists into a single result, with non-members clearly flagged with `isNonMember: true`
4. Return the combined `totalCount` as the sum of both

When sending emails to a picklist audience, non-members receive the email at their provided address. Personalization merge fields like `{{OfficeName}}` will use the `company` field if provided, or be blank. The existing `personalizeMergeFields()` function in `emailService.ts` already handles missing fields gracefully by substituting empty strings.

**Type Badge:** Show "Picklist" badge in blue on the saved audiences table (distinct from the purple "Smart" badge).

---

### 1C. Member/Bill Type Page (New: SmartSends â†’ Audiences â†’ Member/Bill Type)

**What it is:** A page where the user selects from two sets of checkboxes â€” **Associations** and **Bill Types** â€” to build a smart audience. The system queries `AMS.apmmemberassociation` using these filters and returns all matching, deduplicated members.

Because it's smart (`isSmart: true`), the audience re-evaluates every time it's used. New members who match the criteria are automatically included.

**The Data Source:**

Table: `"AMS"."apmmemberassociation"` â€” This is a junction table that connects members to the administrative "associations" (divisions) within Mainstreet. Each record has a `BillType` code that identifies the member's relationship type within that association.

Key fields:
- `"MemberKey"` â€” links to member
- `"AssociationId"` â€” which association (e.g., 'RWS', 'MB', 'KEY')
- `"BillType"` â€” member relationship type (e.g., 'R', 'DR', 'AFF')
- `"Status"` â€” filter to `'Active'` only
- `"ApmClientId"` â€” always filter = `'MainStreet'`
- `"ApmSourceModificationTimestamp"` â€” for deduplication

Deduplication pattern (same as all AMS tables):
```sql
DISTINCT ON ("ApmClientId", "MemberKey", "AssociationId")
... ORDER BY "ApmClientId", "MemberKey", "AssociationId",
             "ApmSourceModificationTimestamp" DESC
```

**Important:** A single member can appear in multiple association/bill type combinations. The audience must deduplicate by `MemberKey` so each person receives only one email.

**Page Layout:**

```
SmartSends > Member/Bill Type

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  ðŸ¢ Member/Bill Type Audience Builder                        â”‚
â”‚  Select associations and bill types to build your audience.  â”‚
â”‚                                                              â”‚
â”‚  â”Œâ”€ Associations â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  CORE MEMBERSHIP                                         â”‚ â”‚
â”‚  â”‚  â˜‘ RWS â€” Mainstreet Organization of REALTORSÂ®            â”‚ â”‚
â”‚  â”‚  â˜ MLSN â€” Mainstreet MLS                                â”‚ â”‚
â”‚  â”‚  â˜ MB â€” Membership                                       â”‚ â”‚
â”‚  â”‚  â˜ KEY â€” Key Association (SentriLock)                    â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  SERVICES & PRODUCTS                                     â”‚ â”‚
â”‚  â”‚  â˜ FW â€” ForeWarn                                         â”‚ â”‚
â”‚  â”‚  â˜ PX â€” Proxio                                           â”‚ â”‚
â”‚  â”‚  â˜ WEB â€” Contracts On Line                               â”‚ â”‚
â”‚  â”‚  â˜ FOX â€” RWSSC                                           â”‚ â”‚
â”‚  â”‚  â˜ SPON â€” Sponsorship Agreements                         â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  EDUCATION & EVENTS                                      â”‚ â”‚
â”‚  â”‚  â˜ CEDU â€” Continuing Education                           â”‚ â”‚
â”‚  â”‚  â˜ EDUC â€” Education Non-Members                          â”‚ â”‚
â”‚  â”‚  â˜ EVNT â€” Event Non-Members                              â”‚ â”‚
â”‚  â”‚  â˜ FAIR â€” REALTOR Trade Fair Exhibitors                  â”‚ â”‚
â”‚  â”‚  â˜ CONV â€” Convention Non-Members                         â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  OTHER                                                   â”‚ â”‚
â”‚  â”‚  â˜ COMM â€” Commercial Members                             â”‚ â”‚
â”‚  â”‚  â˜ IMS â€” IMS Non-Member Association                      â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  [Select All]  [Clear]                                   â”‚ â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â”‚                                                              â”‚
â”‚  â”Œâ”€ Bill Types â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  REALTOR MEMBERS                                         â”‚ â”‚
â”‚  â”‚  â˜‘ R â€” REALTOR (14,771)                                  â”‚ â”‚
â”‚  â”‚  â˜ DR â€” Designated REALTOR (1,768)                       â”‚ â”‚
â”‚  â”‚  â˜ SM â€” Secondary Member (351)                           â”‚ â”‚
â”‚  â”‚  â˜ SDR â€” Secondary Designated REALTOR (235)              â”‚ â”‚
â”‚  â”‚  â˜ EM â€” Emeritus Member (118)                            â”‚ â”‚
â”‚  â”‚  â˜ HM â€” Honorary Member (23)                             â”‚ â”‚
â”‚  â”‚  â˜ RAA â€” REALTOR-ASSOCIATE, Appraiser (24)               â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  APPRAISERS                                              â”‚ â”‚
â”‚  â”‚  â˜ LAD â€” Licensed Appraiser, Designated (249)            â”‚ â”‚
â”‚  â”‚  â˜ LAR â€” Licensed Appraiser, REALTOR (80)                â”‚ â”‚
â”‚  â”‚  â˜ AST â€” Appraiser, State Licensed (51)                  â”‚ â”‚
â”‚  â”‚  â˜ LA â€” Licensed Appraiser (27)                          â”‚ â”‚
â”‚  â”‚  â˜ NIA â€” Non-Member, Inactive Appraiser (9)              â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  AFFILIATES & OTHER                                      â”‚ â”‚
â”‚  â”‚  â˜ AFF â€” Affiliate (82)                                  â”‚ â”‚
â”‚  â”‚  â˜ AFCI â€” Affiliate, Corporate/Institutional (44)        â”‚ â”‚
â”‚  â”‚  â˜ AFC â€” Affiliate, Corporate (14)                       â”‚ â”‚
â”‚  â”‚  â˜ PA â€” Personal Assistant (224)                         â”‚ â”‚
â”‚  â”‚  â˜ MO â€” MLS Only (4)                                    â”‚ â”‚
â”‚  â”‚  â˜ DM â€” Other (1)                                        â”‚ â”‚
â”‚  â”‚  â˜ SAD â€” Other (1)                                        â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  [Select All]  [Clear]                                   â”‚ â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â”‚                                                              â”‚
â”‚  â”Œâ”€ Preview â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â”‚  [Generate Preview]                                      â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  (After clicking: shows count and sample members)        â”‚ â”‚
â”‚  â”‚  Matching members: 14,771                                â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  Name              â”‚ Email          â”‚ Office             â”‚ â”‚
â”‚  â”‚  Sarah Johnson     â”‚ sj@email.com   â”‚ RE/MAX Premier     â”‚ â”‚
â”‚  â”‚  Michael Brown     â”‚ mb@c21.com     â”‚ Century 21 North   â”‚ â”‚
â”‚  â”‚  ... (showing first 15)                                  â”‚ â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â”‚                                                              â”‚
â”‚  Audience Name: [________________________]                   â”‚
â”‚  Description:   [________________________] (optional)        â”‚
â”‚                                                              â”‚
â”‚  [Save Audience]                                             â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Bill Type Label Mapping (hardcoded in frontend):**

Since there is no bill type description table in the database, define this mapping as a constant. Use this both in the UI and share it with the backend for the AI query service context:

```typescript
export const BILL_TYPE_LABELS: Record<string, string> = {
  'R': 'REALTOR',
  'DR': 'Designated REALTOR',
  'SM': 'Secondary Member',
  'LAD': 'Licensed Appraiser, Designated',
  'SDR': 'Secondary Designated REALTOR',
  'PA': 'Personal Assistant',
  'EM': 'Emeritus Member',
  'AFF': 'Affiliate',
  'LAR': 'Licensed Appraiser, REALTOR',
  'AST': 'Appraiser, State Licensed',
  'AFCI': 'Affiliate, Corporate/Institutional',
  'LA': 'Licensed Appraiser',
  'RAA': 'REALTOR-ASSOCIATE, Appraiser',
  'HM': 'Honorary Member',
  'AFC': 'Affiliate, Corporate',
  'NIA': 'Non-Member, Inactive Appraiser',
  'MO': 'MLS Only',
  'DM': 'Other',
  'SAD': 'Other',
};

export const BILL_TYPE_GROUPS = [
  {
    label: 'REALTOR Members',
    codes: ['R', 'DR', 'SM', 'SDR', 'EM', 'HM', 'RAA'],
  },
  {
    label: 'Appraisers',
    codes: ['LAD', 'LAR', 'AST', 'LA', 'NIA'],
  },
  {
    label: 'Affiliates & Other',
    codes: ['AFF', 'AFCI', 'AFC', 'PA', 'MO', 'DM', 'SAD'],
  },
];

export const ASSOCIATION_GROUPS = [
  {
    label: 'Core Membership',
    items: [
      { id: 'RWS', name: 'Mainstreet Organization of REALTORSÂ®' },
      { id: 'MLSN', name: 'Mainstreet MLS' },
      { id: 'MB', name: 'Membership' },
      { id: 'KEY', name: 'Key Association (SentriLock)' },
    ],
  },
  {
    label: 'Services & Products',
    items: [
      { id: 'FW', name: 'ForeWarn' },
      { id: 'PX', name: 'Proxio' },
      { id: 'WEB', name: 'Contracts On Line' },
      { id: 'FOX', name: 'RWSSC' },
      { id: 'SPON', name: 'Sponsorship Agreements' },
    ],
  },
  {
    label: 'Education & Events',
    items: [
      { id: 'CEDU', name: 'Continuing Education' },
      { id: 'EDUC', name: 'Education Non-Members' },
      { id: 'EVNT', name: 'Event Non-Members' },
      { id: 'FAIR', name: 'REALTOR Trade Fair Exhibitors' },
      { id: 'CONV', name: 'Convention Non-Members' },
    ],
  },
  {
    label: 'Other',
    items: [
      { id: 'COMM', name: 'Commercial Members' },
      { id: 'IMS', name: 'IMS Non-Member Association' },
    ],
  },
];
```

**New API Endpoint â€” Preview Member/Bill Type Audience:**

```
POST /api/audiences/member-bill-type/preview
```

Request body:
```json
{
  "associationIds": ["RWS"],
  "billTypeCodes": ["R", "DR"],
  "previewOnly": true
}
```

At least one association OR one bill type must be selected. If only associations are selected (no bill types), return all bill types within those associations. If only bill types are selected (no associations), return that bill type across all associations.

**Backend query** (runs against the external production database):

```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."AssociationId",
    ma."BillType",
    ma."Status"
  FROM "AMS"."apmmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT DISTINCT la."MemberKey" AS "MemberKey",
  m."MemberFullName",
  m."MemberEmail",
  o."OfficeName"
FROM latest_assoc la
JOIN (
  SELECT DISTINCT ON ("ApmClientId", "MemberKey")
    "MemberKey", "MemberFullName", "MemberEmail", "OfficeKey"
  FROM "AMS"."apmmember"
  WHERE "ApmClientId" = 'MainStreet'
    AND "MemberStatus" = 'Active'
  ORDER BY "ApmClientId", "MemberKey", "ApmSourceModificationTimestamp" DESC
) m ON la."MemberKey" = m."MemberKey"
LEFT JOIN (
  SELECT DISTINCT ON ("ApmClientId", "OfficeKey")
    "OfficeKey", "OfficeName"
  FROM "AMS"."apmoffice"
  WHERE "ApmClientId" = 'MainStreet'
  ORDER BY "ApmClientId", "OfficeKey", "ApmSourceModificationTimestamp" DESC
) o ON m."OfficeKey" = o."OfficeKey"
WHERE la."Status" = 'Active'
  AND la."AssociationId" = ANY($1)
  AND la."BillType" = ANY($2)
LIMIT 15
```

When only associations are selected (no bill types), remove the `AND la."BillType" = ANY($2)` clause. When only bill types are selected (no associations), remove the `AND la."AssociationId" = ANY($1)` clause.

Also run a count query (same WHERE clause but `SELECT COUNT(DISTINCT la."MemberKey")`) to show the total.

**New API Endpoint â€” Get Bill Type Counts:**

To show the member counts next to each bill type checkbox, fetch current counts on page load:

```
GET /api/audiences/member-bill-type/counts
```

```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."AssociationId",
    ma."BillType",
    ma."Status"
  FROM "AMS"."apmmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT "BillType" as bill_type_code, COUNT(DISTINCT "MemberKey") as member_count
FROM latest_assoc
WHERE "Status" = 'Active'
  AND COALESCE(NULLIF(TRIM("BillType"), ''), '') <> ''
GROUP BY "BillType"
ORDER BY member_count DESC
```

Cache this result for 1 hour (it changes slowly). Return as:
```json
{
  "counts": { "R": 14771, "DR": 1768, "SM": 351, ... }
}
```

**Save Member/Bill Type Audience:**

This is a **smart** audience. Store the SQL query so it re-runs every time the audience is used.

When the user clicks "Save Audience", construct the SQL from their checkbox selections and save via the existing `saveAudience()` function:

```json
{
  "name": "All REALTORS in Mainstreet",
  "description": "RWS association, R bill type",
  "isSmart": true,
  "sqlQuery": "WITH latest_assoc AS (...) SELECT DISTINCT ... WHERE ... AND la.\"AssociationId\" = ANY(ARRAY['RWS']) AND la.\"BillType\" = ANY(ARRAY['R']) LIMIT 1000",
  "sourceType": "member_bill_type",
  "filterConfig": {
    "associationIds": ["RWS"],
    "billTypeCodes": ["R"]
  },
  "createdBy": "user-uuid"
}
```

**IMPORTANT:** Store the selected filter values in `filterConfig` (JSONB) so the UI can reconstruct the checkbox state when viewing/editing this audience later. See Part 4 for the database change.

**Type Badge:** Show "Bill Type" badge in teal on the saved audiences table (distinct from purple "Smart" and blue "Picklist").

**Updating `getAudienceMembers()` for Member/Bill Type:**

The existing smart audience branch (`if (audience.isSmart && audience.sqlQuery)`) already handles running SQL queries. Since member/bill type audiences store their SQL, they work through this existing code path automatically. No changes needed to `getAudienceMembers()`.

However, the SQL validation function `validateSQLQuery()` needs to allow the new table. Find the `allowedTables` array and add:

```typescript
const allowedTables = [
  'apmmember',
  'apmproperty',
  'apmmemberdues',
  'apmevent',
  'apmeventregistration',
  'apmmembereducation',
  'apmoffice',
  'apmmemberassociation',  // ADD THIS
];
```

---

## PART 2: INLINE AUDIENCE CREATION IN SEND EMAIL FLOW

### The Problem

On the "Send Email" page, Step 1 ("Choose Audience"), the "AI Audience Builder" tab shows an "Open AI Audience Builder" button that navigates the user away from the email they're composing. This is disorienting.

### The Solution

Replace the current Step 1 layout with a design that lets users create any type of audience without leaving the page.

**New Step 1 Layout:**

```
Send Email
Create and send targeted email campaigns

[Choose Audience] â†’ [Create Email] â†’ [Compose] â†’ [Preview] â†’ [Send]

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  ðŸ‘¥ Who should receive this email?                           â”‚
â”‚  Select your target audience for this campaign               â”‚
â”‚                                                              â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”       â”‚
â”‚  â”‚ Saved Audiencesâ”‚ â”‚ Picklist â”‚ â”‚ Member/Bill Type â”‚       â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜       â”‚
â”‚                                                              â”‚
â”‚  [Active tab content appears here â€” see below]               â”‚
â”‚                                                              â”‚
â”‚                                              [Next â†’]        â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Tab 1: Saved Audiences (default)**

Shows the existing saved audience selector dropdown. Also add a button to open the AI Audience Builder in a **modal**:

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  Choose a saved audience:                                    â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”        â”‚
â”‚  â”‚ Choose a saved audience...                    â–¾  â”‚        â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜        â”‚
â”‚                                                              â”‚
â”‚  (When selected, show brief preview: name, count, type,      â”‚
â”‚   and first few member names)                                â”‚
â”‚                                                              â”‚
â”‚  â”€â”€ or create a new audience â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€      â”‚
â”‚  [âœ¨ Build with AI]                                          â”‚
â”‚                                                              â”‚
â”‚  Opens a modal with the AI text input, generate, preview,    â”‚
â”‚  and save â€” identical to the standalone AI Builder but in a  â”‚
â”‚  modal. On save, the new audience auto-selects in the        â”‚
â”‚  dropdown above and the modal closes.                        â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Tab 2: Picklist**

The same picklist interface (member search, non-member add, CSV upload, selected members table) embedded directly in the step. On save, the audience is created and automatically selected, and "Next" is enabled.

**Tab 3: Member/Bill Type**

The same association and bill type checkboxes with preview and save. On save, the audience is created and automatically selected.

### Implementation: Reusable Components

Create **shared components** that render the same audience creation UI in both contexts:

- `PicklistBuilder` component â€” used on the standalone Picklist page AND in Send Email Tab 2
- `MemberBillTypeBuilder` component â€” used on the standalone Member/Bill Type page AND in Send Email Tab 3
- `AIAudienceBuilderModal` component â€” wraps the existing AI builder in a modal for Send Email Tab 1

Each component accepts an optional `onAudienceSaved(audienceId: string)` callback prop:
- **On standalone pages:** `onAudienceSaved` shows a success toast and resets the form
- **In Send Email flow:** `onAudienceSaved` selects the new audience in the parent form and enables "Next"

This avoids duplicating code while allowing both contexts to work properly.

**AI Builder Modal Details:**

The modal contains the same functionality as the standalone AI Builder:
- Text input to describe the audience
- "Generate Audience" button
- Preview results (count + sample members)
- Audience name field
- "Save & Select" button

On "Save & Select": save via existing `saveAudience()`, auto-select in the saved audience dropdown, close modal. The standalone AI Builder page remains accessible via the left nav â€” the modal is an additional convenience, not a replacement.

---

## PART 3: SAVED AUDIENCES TABLE UPDATES

### New Type Badges

The saved audiences table currently shows a purple "Smart" badge. Add distinct badges for new types:

| Source Type | Badge Label | Badge Color | Smart? |
|-------------|-------------|-------------|--------|
| `ai_generated` | Smart | Purple (existing) | Yes |
| `member_bill_type` | Bill Type | Teal | Yes |
| `picklist` | Picklist | Blue | No |
| `csv_upload` | Upload | Gray (existing) | No |
| `external_contacts` | External | Orange | No |
| `manual` | Manual | Gray | No |

### Member Count Display

- **Smart/Bill Type audiences:** Show count with a refresh icon (â‰ˆ1,497 ðŸ”„) to indicate it's approximate and recalculated on use
- **Picklist audiences:** Show exact count without refresh icon (5 members) since it's fixed. If the picklist contains non-members, show them in the count (e.g., "3 members + 2 non-members")

---

## PART 4: DATABASE CHANGES

### New Column on saved_audiences

```sql
ALTER TABLE saved_audiences ADD COLUMN IF NOT EXISTS filter_config JSONB;
```

This stores structured filter data for audience types that need it:

For `member_bill_type`:
```json
{
  "associationIds": ["RWS", "MLSN"],
  "billTypeCodes": ["R", "DR"]
}
```

For other audience types, this field is `null`.

### Update Schema Definition

In `schema.ts`, add to the `savedAudiences` table definition:

```typescript
filterConfig: jsonb("filter_config"),
```

### Update SQL Validation

In `aiAudienceService.ts`, find the `allowedTables` array in the `validateSQLQuery` function and add:

```typescript
'apmmemberassociation',  // For member/bill type audiences
```

---

## PART 5: AI QUERY SERVICE AWARENESS

The AI Query Service (Chats) and AI Audience Builder both use the shared database schema defined in `sharedDatabaseSchema.ts`. Currently, the schema documents `apmassociations` (the list of associations) but does NOT document `apmmemberassociation` (the junction table that connects members to associations with bill types).

This means if a user asks "how many Designated REALTORs do we have?" in Chats, Claude won't know how to answer because it doesn't know about the `BillType` field or the `apmmemberassociation` table.

### Add to sharedDatabaseSchema.ts

Add a new schema section for member associations. Place it after the existing `REFERENCE_DATA_SCHEMA` section:

```typescript
export const MEMBER_ASSOCIATION_SCHEMA = `
=== MEMBER ASSOCIATIONS & BILL TYPES ===

"AMS"."apmmemberassociation" - Links members to associations with their billing/membership type
- "MemberKey" (text) - Foreign key to member
- "AssociationId" (text) - Association identifier (see list below)
- "BillType" (text) - Member's billing/relationship type within the association (see list below)
- "Status" (text) - Status of this membership record. Filter to 'Active' for current members.
- "ApmSourceModificationTimestamp" (timestamp) - For deduplication
- "ApmClientId" (text) - ALWAYS filter = 'MainStreet'
DEDUPLICATION: Use DISTINCT ON ("ApmClientId", "MemberKey", "AssociationId") ORDER BY "ApmSourceModificationTimestamp" DESC
IMPORTANT: A single member can appear multiple times with different AssociationId/BillType combinations. Always DISTINCT on MemberKey when counting unique members.

ASSOCIATIONS (administrative divisions within Mainstreet):
Core Membership:
  RWS = Mainstreet Organization of REALTORSÂ® (the main trade association)
  MLSN = Mainstreet MLS (MLS access)
  MB = Membership (general membership administration)
  KEY = Key Association (SentriLock lockbox access)
Services & Products:
  FW = ForeWarn (agent safety app)
  PX = Proxio
  WEB = Contracts On Line
  FOX = RWSSC
  SPON = Sponsorship Agreements
Education & Events:
  CEDU = Continuing Education
  EDUC = Education Non-Members
  EVNT = Event Non-Members
  FAIR = REALTOR Trade Fair Exhibitors
  CONV = Convention Non-Members
Other:
  COMM = Commercial Members
  IMS = IMS Non-Member Association

BILL TYPES (member relationship categories):
REALTOR Members:
  R = REALTOR (~14,771 active) â€” Standard REALTOR member
  DR = Designated REALTOR (~1,768) â€” Office broker/owner, responsible for the office
  SM = Secondary Member (~351) â€” Member whose primary association is another board
  SDR = Secondary Designated REALTOR (~235) â€” DR whose primary is another board
  EM = Emeritus Member (~118) â€” Retired members with honorary status
  HM = Honorary Member (~23) â€” Honorary designation
  RAA = REALTOR-ASSOCIATE, Appraiser (~24)
Appraisers:
  LAD = Licensed Appraiser, Designated (~249)
  LAR = Licensed Appraiser, REALTOR (~80)
  AST = Appraiser, State Licensed (~51)
  LA = Licensed Appraiser (~27)
  NIA = Non-Member, Inactive Appraiser (~9)
Affiliates & Other:
  AFF = Affiliate (~82) â€” Non-licensee allied members (lenders, title companies, etc.)
  AFCI = Affiliate, Corporate/Institutional (~44)
  AFC = Affiliate, Corporate (~14)
  PA = Personal Assistant (~224) â€” Unlicensed assistants
  MO = MLS Only (~4) â€” MLS access without association membership

EXAMPLE QUERIES:
-- Count of Designated REALTORs (brokers):
WITH latest AS (
  SELECT DISTINCT ON ("ApmClientId", "MemberKey", "AssociationId")
    "MemberKey", "BillType", "Status"
  FROM "AMS"."apmmemberassociation"
  WHERE "ApmClientId" = 'MainStreet'
  ORDER BY "ApmClientId", "MemberKey", "AssociationId", "ApmSourceModificationTimestamp" DESC
)
SELECT COUNT(DISTINCT "MemberKey") FROM latest WHERE "Status" = 'Active' AND "BillType" = 'DR'

-- All affiliates with their details:
WITH latest AS (
  SELECT DISTINCT ON ("ApmClientId", "MemberKey", "AssociationId")
    "MemberKey", "BillType", "AssociationId", "Status"
  FROM "AMS"."apmmemberassociation"
  WHERE "ApmClientId" = 'MainStreet'
  ORDER BY "ApmClientId", "MemberKey", "AssociationId", "ApmSourceModificationTimestamp" DESC
)
SELECT DISTINCT m."MemberKey", m."MemberFullName", m."MemberEmail"
FROM latest la
JOIN "AMS"."apmmember" m ON la."MemberKey" = m."MemberKey" AND m."ApmClientId" = 'MainStreet' AND m."MemberStatus" = 'Active'
WHERE la."Status" = 'Active' AND la."BillType" IN ('AFF', 'AFCI', 'AFC')
`;
```

### Update getSharedDatabaseSchema()

Add `MEMBER_ASSOCIATION_SCHEMA` to the array in the `getSharedDatabaseSchema()` function:

```typescript
export function getSharedDatabaseSchema(): string {
  return [
    SHARED_DATABASE_OVERVIEW,
    AMS_MEMBER_SCHEMA,
    MLS_MEMBER_SCHEMA,
    OFFICE_SCHEMA,
    LISTINGS_SCHEMA,
    INVOICES_SCHEMA,
    EVENTS_EDUCATION_SCHEMA,
    REFERENCE_DATA_SCHEMA,
    MEMBER_ASSOCIATION_SCHEMA,  // ADD THIS
    CACHE_TABLES_SCHEMA,
    KEY_FORMAT_RULES,
    CANONICAL_STATS,
    OFFICE_SWITCHING,
    BUSINESS_INTELLIGENCE,
    CACHE_VS_RAW_GUIDANCE,
    DATABASE_ROUTING_RULE,
    ANNIVERSARY_QUERIES,
  ].join('\n');
}
```

Since both the AI Audience Builder and the AI Query Service (Chats) import from `getSharedDatabaseSchema()`, this single change makes both AI services aware of associations and bill types. Users will be able to ask questions like:
- "How many Designated REALTORs do we have?"
- "Show me all affiliates"
- "List members in the ForeWarn association"
- "Build an audience of all appraisers"

### Update allowedTables in aiAudienceService.ts

Also ensure `apmmemberassociation` is in the allowed tables list for SQL validation (mentioned in Part 1C above, repeating here for completeness):

```typescript
const allowedTables = [
  'apmmember',
  'apmproperty',
  'apmmemberdues',
  'apmevent',
  'apmeventregistration',
  'apmmembereducation',
  'apmoffice',
  'apmmemberassociation',  // ADD THIS
];
```

---

## IMPLEMENTATION ORDER

1. **Database changes** â€” Add `filter_config` column to `saved_audiences`, update `schema.ts`
2. **Shared schema update** â€” Add `MEMBER_ASSOCIATION_SCHEMA` to `sharedDatabaseSchema.ts`
3. **SQL validation** â€” Add `apmmemberassociation` to `allowedTables`
4. **Backend endpoints** â€” Member search API, bill type counts API, member/bill type preview API
5. **Reusable components** â€” `PicklistBuilder`, `MemberBillTypeBuilder`
6. **Standalone pages** â€” Add Picklist and Member/Bill Type pages under Audiences nav
7. **Send Email inline** â€” Restructure Step 1 tabs, add AI Builder modal, embed reusable components
8. **Saved audiences table** â€” Add new type badges and count display logic
9. **getAudienceMembers() update** â€” Handle picklist audiences with both members and non-members

---

## TESTING CHECKLIST

- [ ] AI Audience Builder standalone page works exactly as before (unchanged)
- [ ] Saved Audiences page works exactly as before (unchanged)
- [ ] Upload page works exactly as before (unchanged)
- [ ] AI Chats can answer questions about bill types and associations (e.g., "how many DRs?")
- [ ] New Picklist page: member search works with same dropdown style as Agent Production Leaderboard
- [ ] New Picklist page: can add non-members with name and email
- [ ] New Picklist page: CSV upload shows terms acceptance, handles matched members + unmatched non-members
- [ ] New Picklist page: selected list shows members and non-members distinctly
- [ ] New Picklist page: save creates audience with `sourceType: 'picklist'`, stores `memberKeys` + `externalContacts`
- [ ] New Member/Bill Type page: checkboxes load with correct labels and counts
- [ ] New Member/Bill Type page: preview shows correct deduplicated count
- [ ] New Member/Bill Type page: save creates smart audience with `sourceType: 'member_bill_type'` and `filterConfig`
- [ ] Send Email Step 1: Saved Audiences tab has dropdown + "Build with AI" modal button
- [ ] Send Email Step 1: AI Builder modal works end-to-end (generate â†’ preview â†’ save â†’ auto-select â†’ close)
- [ ] Send Email Step 1: Picklist tab works inline, save auto-selects audience
- [ ] Send Email Step 1: Member/Bill Type tab works inline, save auto-selects audience
- [ ] All audience types appear in saved audiences table with correct badges
- [ ] Member/Bill Type audiences re-query on use (smart behavior)
- [ ] Picklist audiences return same fixed members + non-members on use (static behavior)
- [ ] Deduplication: member in multiple associations only appears once in bill type audience
- [ ] Deduplication: member added via search AND CSV only appears once in picklist
- [ ] Left nav shows all 5 items under Audiences: AI Builder, Picklist, Member/Bill Type, Saved, Upload
- [ ] Sending email to picklist with non-members works (non-members receive email, merge fields gracefully handle missing data)

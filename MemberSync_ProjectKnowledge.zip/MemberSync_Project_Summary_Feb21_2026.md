# MemberSync / SmartSends — Project Summary
## February 21, 2026

This document captures all decisions, architecture, prompts, and current state through February 21, 2026. Use this to resume work in a new conversation.

---

## TABLE OF CONTENTS

1. Project Overview
2. Client and Membership Context
3. Technical Architecture
4. What Has Been Built (Complete)
5. What Was Accomplished Feb 21, 2026
6. Current Database Schema (Key Tables)
7. Production Database Schema (Read-Only)
8. Daily Jobs Schedule
9. AI Services Architecture
10. Engagement Scoring System
11. Dashboard Architecture
12. SmartSends Current State
13. Triggered Campaigns / Automations Current State
14. Prompts Ready for Replit (Not Yet Built)
15. Known Issues Still Open
16. Strategic Roadmap
17. Key Architectural Decisions
18. Key Files Reference
19. Production Data Reference

---

# 1. PROJECT OVERVIEW

## What We Are Building

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs. SmartSends is the email marketing and automation layer within MemberSync. The first client is Mainstreet REALTORS®, a trade association with approximately 18,275 active members and approximately 2,800 offices in the Chicago suburbs.

The platform uses predictive analytics to help association executives retain and engage members by analyzing residential real estate listings and association management system (AMS) data.

## Product Model

MemberSync is a **SaaS product** — not a custom build for Mainstreet. Every feature should work for any association through configuration, not custom code.

## Build Philosophy

Tracy (founder of Membio) is a non-technical business leader building exclusively with AI tools:
- **Claude** for strategy, specifications, and Replit prompts
- **Julius.AI** for SQL development against the production database
- **Replit Agent** for all coding implementation

Tracy maintains creative control over product design and UX decisions. The development team hardens for production (error handling, edge cases, performance). Tracy builds the first 80% through prototyping; the team does the production-ready 20%.

## Product Philosophy: Celebrating Connection Over Compliance

The core insight: 75% of association members produce only 12% of real estate volume, yet pay 75% of dues revenue. MemberSync exists to help associations prove their value to all members by measuring and improving engagement with the organization itself. All member tiers are framed positively. We celebrate connection, not police compliance.

---

# 2. CLIENT AND MEMBERSHIP CONTEXT

**Client:** Mainstreet REALTORS® — suburban Chicago
**Members:** ~18,275 active
**Offices:** ~2,800
**Member Tiers (by 12-month transaction sides):**
- Foundation (0–5 sides): 14,144 agents (77%)
- Builder (6–39 sides): 3,885 agents (21%)
- Rainmaker (40+ sides): 247 agents (1.4%)

**Key Insight:** Top 25% of agents control 88% of volume; 40% of agents have zero transactions.

---

# 3. TECHNICAL ARCHITECTURE

- **Frontend:** React with Tailwind CSS, shadcn/ui components
- **Backend:** Node.js / Express
- **Database:** PostgreSQL (local via Drizzle ORM + read-only external AWS production DB via `externalPool`)
- **Hosting:** Replit (application) + AWS (production database)
- **Email:** SendGrid (currently in sandbox/dev mode)
- **AI:** Anthropic Claude API (Sonnet 4 for email generation, audience building, data queries)
- **ORM:** Drizzle

---

# 4. WHAT HAS BEEN BUILT (COMPLETE)

- Full dashboard with AI Chat, Pulse cards, Activity Feed, Member Recognition, Mainstreet Community
- Tier-aware engagement scoring system
- Member detail pages with engagement breakdown
- Office detail pages with agent rosters
- SmartSends email campaign creation (AI + manual + template)
- Audience building (AI builder, picklist, member/bill type, CSV upload)
- Saved audiences with preview and count
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail pages
- Triggered campaigns / Automations engine with 7 trigger types
- Automations UX upgrade (full-page wizard)
- Email analytics overview
- Office visit brief PDF generation
- Compliance tracking
- Image library for emails
- Draft management
- Scheduled email sending

---

# 5. WHAT WAS ACCOMPLISHED FEBRUARY 21, 2026

## Prompts Delivered to Replit (Being Implemented)

### 1. SmartSends Automations UX Upgrade (`SmartSends_Automations_UX_Upgrade.md`)
Full-page wizard replacing the basic dialog for creating/editing automations. Matches the Send Email wizard pattern: Configure Trigger → Compose Email → Preview → Settings & Activate. Includes:
- 7 trigger type cards (Event Registration, Event Reminder, Post-Event Follow-up, Membership Anniversary, Production Milestone, Drip Sequence, **Scheduled Series**)
- Trigger-specific configuration UI for each type
- Drip sequence step builder with per-step email editing
- **Scheduled Series** — new trigger type for fixed-date multi-email campaigns (date pickers instead of relative delays, audience resolved fresh at send time)
- Automation list cards with status-aware styling (active/paused/draft)
- View History page for automation sends
- Backend: `scheduled_series` processor addition, `send_date` column on steps table

### 2. SmartSends Email Composer Enhancements (`SmartSends_EmailComposer_Enhancements.md`)
AI email creation in automations, event block formatting improvements, pre-population of compose step based on trigger selection, Insert Offer block, Insert CTA Button, toolbar organization.

### 3. SmartSends Bug Fixes and Composer Polish (`SmartSends_BugFixes_ComposerPolish.md`)
Comprehensive fix prompt addressing all issues found during testing of both flows:

**Critical bugs:**
- **413 "Request entity too large"** when sending to 18K+ members — fix: send audienceId to server, resolve recipients server-side
- **key_points.map is not a function** in automations AI generation — fix: normalize key_points to array in aiEmailService.ts
- **Next button grayed out** after saving audience via member type builder — fix: ensure builder callbacks update wizard state

**UX consistency (Send Email ↔ Automations):**
- Method card order wrong in automations (should be Template → AI → Scratch)
- Automations splits method cards and AI fields across two screens (should be one page like Send Email)
- Insert Event, Insert Offer, Insert Button exist in automations but not Send Email compose step — need both
- Resend Campaign uses a stripped-down modal instead of routing to full wizard
- Milestone trigger uses checkboxes (multi-select) — changed to radio buttons (single select) because each milestone type needs its own tailored email

**Improvements:**
- AI-generated events should use styled cards with portal registration URLs, not plain text bullet points
- AI-generated offers should use styled amber callout blocks, not inline text
- Settings & Activate step should show trigger configuration summary and estimated audience reach
- Per-recipient engagement table on Campaign Detail page (who opened, who clicked)
- Open/click badges on Member Detail email history
- Unsaved changes warning when navigating away from wizard

## Key Decisions Made

1. **Scheduled Series trigger type:** Sends to a specific audience on fixed calendar dates (March 1, March 15, April 1). Unlike drip sequences (relative delays from enrollment), everyone gets the same email on the same date. Audience resolved fresh at each send date, so roster changes are automatically reflected.

2. **Milestone triggers must be single-select:** You can't write one email that naturally covers "50th transaction" AND "$5M in volume." Each milestone type needs its own automation with tailored messaging. Radio buttons enforce this.

3. **Founder's role in product development:** Tracy stays in Replit on staging, builds prototypes at speed. Team hardens for production. Tracy decides what gets built and how it looks (product vision from 30+ years of industry expertise). Team handles deployment process, code review, automated tests. Speed and decisiveness are competitive advantage — protect at all costs.

4. **UX consistency principle:** Every path to composing/editing an email goes through the same full wizard. No modal shortcuts, no stripped-down dialogs. Users should never have to learn a new interface for the same task.

5. **Server-side audience resolution for large sends:** Instead of sending 20K recipient objects from the client, send the audienceId and let the server resolve members. Solves the 413 error and is architecturally cleaner.

---

# 6–11. [UNCHANGED FROM FEB 20 SUMMARY]

Refer to the Feb 20 project summary for these sections — no changes to database schema, production schema, daily jobs, AI services, engagement scoring, or dashboard architecture.

---

# 12. SMARTSENDS CURRENT STATE

## What's Built and Working
- Campaign creation with AI-composed or manual email body
- Three method cards: Use a Template, Generate with AI, Create from Scratch
- Audience selection (AI-built, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail page with aggregate stats
- Analytics overview with office leaderboards
- PDF generation for office visit briefs
- Saved audiences with count and preview
- Email templates
- Draft management
- Image library

## What's Built But Has Issues (Fixes in Progress)
- Send button fails with 413 for large audiences (fix: server-side resolution)
- AI generation fails in automations with key_points error (fix: normalize input)
- Insert Offer and Insert Button exist in automations but not Send Email
- Resend Campaign uses modal instead of full wizard
- Next button disabled after member type audience save
- AI-generated events are plain text, not styled cards

---

# 13. TRIGGERED CAMPAIGNS / AUTOMATIONS CURRENT STATE

## What's Built
- Triggered campaign processor running every 15 minutes
- 6 active trigger types: event_registration, event_reminder, event_followup, membership_anniversary, production_milestone, drip_sequence
- 7th type (scheduled_series) spec'd and in UX Upgrade prompt
- Full-page wizard for create/edit (Configure Trigger → Compose → Preview → Settings & Activate)
- Trigger-specific configuration UI for each type
- Drip sequence step builder with per-step editing
- Automation list with status sections (Active, Paused, Drafts, Archived)
- Send window configuration (start/end time, weekday toggle)
- Auto-stop date
- Deduplication to prevent repeat sends
- Anniversary trigger verified working (14 sends processed)

## What's Prompt-Ready But Not Built
- **Scheduled Series** trigger type (in UX Upgrade prompt)
- **A/B Testing** for triggered campaigns (`SmartSends_ABTesting_Part2.md`)
- Method card + AI field consolidation on one page
- Milestone radio buttons (single select)
- Trigger summary on Settings & Activate step

## Key Architecture
- `triggered_campaigns` table: campaign config, trigger type, status
- `triggered_campaign_steps` table: multi-step campaigns (drip, scheduled series)
- `triggered_campaign_sends` table: per-member send records with dedup
- Processor: `triggeredCampaignProcessor.ts` — evaluates triggers, queues sends, processes pending
- Each trigger type has its own evaluator function
- `triggerReference` field prevents duplicate sends (e.g., same event + same member)
- `campaignVersion` integer field (1 and 2) supports future A/B testing

---

# 14. PROMPTS READY FOR REPLIT (NOT YET BUILT)

**Priority order:**

1. **Bug Fixes and Composer Polish** (`SmartSends_BugFixes_ComposerPolish.md`) — Critical bugs blocking email sends and AI generation. UX consistency between flows. SEND THIS FIRST.

2. **A/B Testing for Triggered Campaigns** (`SmartSends_ABTesting_Part2.md`) — A/B split on subject line and body, automatic winner selection, variant performance tracking. Depends on triggered campaigns working cleanly.

3. **Automations Polish Round 2** (NOT YET WRITTEN) — Delete automation capability, audience visibility/estimated reach on trigger config, automation-specific analytics (rolling performance timeline + cumulative stats), event override priority system (specific event automation overrides "all events" automation).

---

# 15. KNOWN ISSUES STILL OPEN

### Critical (Blocking)
- 413 error on large audience sends (fix in Bug Fixes prompt)
- key_points.map error in automations AI generation (fix in Bug Fixes prompt)
- Next button disabled after member type audience save (fix in Bug Fixes prompt)

### Important
- Insert Offer / Insert Button missing from Send Email compose step
- Resend Campaign modal should route to full wizard
- AI-generated events are plain text (no styled cards, no portal URLs)
- No per-recipient engagement data on Campaign Detail page
- No open/click badges on Member Detail email history
- Milestone trigger allows multi-select (should be single-select radio)

### Lower Priority
- The 172-member gap (dashboard vs. member type builder count)
- AI Query Service sometimes generates wrong SQL
- Cache health monitoring (no admin visibility into cron job status)
- Email engagement data cold start
- Revenue data uses catalog prices, not actual invoiced amounts

---

# 16. STRATEGIC ROADMAP

## Immediate (In Progress)
1. **Bug Fixes + Composer Polish** — Unblock email sends, fix AI generation, UX consistency
2. **Scheduled Series trigger** — Fixed-date campaign sequences
3. **A/B Testing** — Variant testing for triggered campaigns

## Near-Term
4. **Automations Polish Round 2** — Delete, audience visibility, automation analytics, event override
5. **Lapse Prevention System** — Status tracking, risk scoring, intervention management

## Medium-Term
6. **AI Data Intelligence Stage 2** — Inline chart rendering in AI Chat
7. **Broker Module** — Office management dashboards
8. **Education/Event Revenue from Invoices** — Actual revenue instead of catalog estimates

## Longer-Term
9. **AI Presentation Generation (Stages 3–5)** — Board meeting presentations from data
10. **Lapse Pattern Analysis** — Predictive models from pre-departure behavior
11. **Trend Sparklines** — Membership trend visualization from daily snapshots

---

# 17. KEY ARCHITECTURAL DECISIONS

All decisions from Feb 20 summary remain in effect, plus:

- **Server-side audience resolution for sends:** Large audiences pass audienceId; server resolves recipients. Client never sends 20K+ recipient arrays.
- **Milestone triggers are mutually exclusive:** One automation per milestone type. Radio buttons enforce single selection. Each achievement needs tailored messaging.
- **Scheduled Series resolves audience fresh at each send date:** Unlike drip (which enrolls members at activation), scheduled series queries the current audience for each email in the series. Roster changes are automatically reflected.
- **UX consistency is non-negotiable:** Both email flows (Send Email and Automations) use the same wizard pattern, same component order, same tools, same card order. No modal shortcuts for any email editing task.
- **Every email editing path goes through the full wizard:** Resend, duplicate, edit — all route to the standard wizard with pre-loaded content. No stripped-down modals.

---

# 18. KEY FILES REFERENCE

### Prompts in Progress
- `SmartSends_BugFixes_ComposerPolish.md` — Bug fixes + UX consistency (SEND FIRST)
- `SmartSends_Automations_UX_Upgrade.md` — Full wizard + Scheduled Series (DEPLOYED/IN PROGRESS)
- `SmartSends_EmailComposer_Enhancements.md` — AI in automations, Insert Offer/Button (SUPERSEDED by BugFixes prompt which covers everything)
- `SmartSends_ABTesting_Part2.md` — A/B testing for automations (SEND AFTER BUG FIXES)

### Previously Implemented Prompts
- `SmartSends_TriggeredCampaigns_Part1.md` — Automation engine (DEPLOYED)
- `SmartSends_AudienceBuilder_Improvements.md` — Inline creation, Picklist, Member/Bill Type (COMPLETE)
- `MemberSync_Volume_Fix_Replit_Prompt.md` — Double-counting fix (COMPLETE)
- `MemberSync_Consolidated_Fix_Prompt_Feb18_2026.md` — 9-issue fix batch (COMPLETE)
- `MemberSync_Dashboard_Redesign_Prompt.md` — Full dashboard overhaul (COMPLETE)
- `MemberSync_Dashboard_Redesign_Part2.md` — Mainstreet Community section (COMPLETE)
- `MemberSync_Dashboard_Cleanup.md` — Visual polish (COMPLETE)
- `MemberSync_Dashboard_Fixes_Round2.md` — Targeted fixes (COMPLETE)
- `MemberSync_Dashboard_QuickFixes.md` — Height matching, donuts (COMPLETE)
- `MemberSync_Dashboard_CRMLS_Demo.md` — Member Recognition tiles, Discovery cards (COMPLETE)
- `MemberSync_EngagementScore_Redesign_Prompt.md` — Tier-aware scoring (COMPLETE)
- `MemberSync_EngagementScore_Rebalancing_Prompt.md` — Threshold + weight corrections (COMPLETE)
- `MemberDetail_ScoreLabels_and_DashboardConsistency_Fix.md` — Score breakdown fix (COMPLETE)
- `MemberSync_Stability_DataConsistency_Prompt.md` — Atomic cache, staleness detection (COMPLETE)
- `CodeCleanup_DeadCode_and_Fixes.md` — Mock data removal (COMPLETE)

### Backend Services
- `triggeredCampaignProcessor.ts` — Triggered campaign evaluation and send processing (NEW)
- `storage.ts` — Main data layer, dashboard metrics, member/office queries
- `memberMetricsCacheService.ts` — Daily cache refresh with tier-aware engagement scoring
- `engagementScoreService.ts` — Engagement score calculation logic
- `aiQueryService.ts` — AI SQL generation, query execution, insights
- `aiAudienceService.ts` — Audience CRUD, smart audience execution, enrichment
- `aiEmailService.ts` — AI email composition (generate + refine endpoints)
- `emailService.ts` — Email sending, queue processing, campaign management
- `scheduledEmailProcessor.ts` — Processes scheduled campaigns
- `milestoneDetectionService.ts` — Celebration/milestone detection
- `analyticsProductionCacheService.ts` — Office/agent production analytics
- `activityCacheService.ts` — Activity feed data
- `visitBriefService.ts` — Office visit PDF generation

### Frontend — Pages
- `SendEmail.tsx` — Email composition wizard (201K — largest file)
- `CreateAutomation.tsx` — Automation creation wizard (NEW)
- `SmartSends.tsx` — SmartSends dashboard + automations list
- `AudienceBuilder.tsx` — AI audience builder
- `CampaignDetail.tsx` — Campaign detail with resend capability
- `MemberDetail.tsx` — Member profile with engagement, email history (needs open/click badges)

### Configuration
- `schema.ts` — Drizzle ORM schema (includes triggered_campaigns, triggered_campaign_steps, triggered_campaign_sends tables)
- `routes.ts` — All API endpoints (223K — largest backend file)

---

# 19. PRODUCTION DATA REFERENCE

From Tracy's Julius analysis of Mainstreet production data:
- Total active agents: 18,275
- Producing agents: 10,895 (59.6%)
- Non-producing: 7,380 (40.4% with zero sides)
- Top 25% (4,569 agents): 87.6% of volume
- Rainmaker (40+ sides): 247 agents (1.4%)
- Builder (6–39 sides): 3,885 agents (21%)
- Foundation (0–5 sides): 14,144 agents (77%)

## The Office Suspension Discovery
For Mainstreet Advantage fees, the **office** gets suspended for non-payment (not individual agents). All agents lose MLS/SentriLock access. This creates broker-level pressure.

---

*End of project summary. This document supersedes all previous project summaries.*

# SmartSends: Post-Implementation Cleanup & Fixes
## Replit Prompt — February 24, 2026

---

## OVERVIEW

Testing of the Prompt 1 and Prompt 2 implementations revealed several issues that need to be addressed. This prompt is organized by priority. Fix each section and verify before moving to the next.

**CRITICAL RULES:**
- Do NOT touch `triggeredCampaignProcessor.ts`, `emailService.ts`, `scheduledEmailProcessor.ts`, or `shared/schema.ts`
- Test each fix individually before moving to the next section
- Clean up dead code as you go

---

## FIX 1: Remove "Pause Before Editing" Frontend Dialog

### Problem
Every active automation shows a "Pause Before Editing?" modal dialog when you try to edit it (see: the Automations list page shows this dialog with "Cancel" and "Pause & Edit" buttons). This dialog was added as a frontend workaround for a backend restriction that has already been removed in Prompt 2.

The backend PATCH endpoint (`server/routes.ts`) now allows content edits on active campaigns — it only blocks changing the trigger type. The frontend dialog is no longer needed and blocks the user from a simple edit flow.

### Fix
Find the "Pause Before Editing" dialog in the Automations page components (likely in `Automations.tsx` or `CreateAutomation.tsx`). Remove:
- The confirmation dialog that asks "Pause Before Editing?"
- Any state variables controlling that dialog (e.g., `showPauseDialog`, `pauseBeforeEdit`, etc.)
- Any logic that checks campaign status before allowing navigation to the edit page

**The correct behavior:** When a user clicks Edit (or the three-dot menu → Edit) on an active automation, navigate directly to the edit page. No pause required. No dialog.

If you want to show a subtle informational note on the edit page itself (like a small banner that says "This automation is currently active — changes will take effect immediately"), that's fine but optional. The blocking modal must go.

### Verification
- [ ] Click Edit on an active automation → goes directly to the edit page, no dialog
- [ ] Edit the email content on an active automation → Save → no errors
- [ ] The automation remains active after saving content edits

---

## FIX 2: Kill the Modal Step Editor in Drip Sequences

### Problem
The drip sequence step editor is still a modal dialog (Image 8 in testing). Prompt 1 specified that this modal should be replaced with inline expand/collapse — when you click "Edit Email Content" on a step card, the card expands to show the editor inline. No modal.

### What Was Supposed to Happen
Per Prompt 1: "Remove the step editor modal entirely. Delete the `stepEditorOpen` state, the `Dialog` that renders the modal step editor, and the `stepQuillRef`."

Instead of the modal, each step card should expand inline to show the email composer when the user clicks "Edit Email Content." Only one step can be expanded at a time. A "Done" button at the bottom of the expanded editor collapses it.

### Fix
In `CreateAutomation.tsx`:

1. **Delete the step editor `<Dialog>` component** — the modal that pops up with "Your Personal Invitation to YPN" / "Write the email content for this step" header, Subject Line, Email Body editor, and Insert buttons at the bottom. This entire Dialog must be removed.

2. **Delete these state variables** if they still exist:
   - `stepEditorOpen` / `setStepEditorOpen`
   - `stepQuillRef`

3. **Replace the "Edit Email Content" button** on each step card with an expand/collapse pattern:

When `editingStepIndex === index`, the step card expands to show the full email editor inline (subject line input, email body editor with toolbar, Insert Event/Offer/Button buttons, merge field buttons, Edit with AI button, and a "Done" button). When the user clicks Done, `setEditingStepIndex(null)` collapses it.

When `editingStepIndex !== index`, show the compact step card with just the "Edit Email Content" button and word count.

Only one step can be expanded at a time — clicking "Edit Email Content" on step 2 should close step 1 (by setting `editingStepIndex` to the new index).

4. **The inline editor should have the same tools as Send Email's Review & Edit:**
   - Edit with AI button (opens the refine dialog)
   - ReactQuill rich text editor
   - Insert Event button (opens event picker)
   - Insert Offer button (opens offer dialog)
   - Insert Button (opens CTA button dialog)
   - Merge field buttons
   - Done button to collapse

### Verification
- [ ] Create a new Drip Sequence → Build Sequence step → click "Edit Email Content" on Step 1 → editor expands INLINE (no modal)
- [ ] The expanded editor has: subject line, email body editor, Insert Event/Offer/Button, merge fields, Edit with AI, Done button
- [ ] Click "Done" → editor collapses, step card shows word count
- [ ] Click "Edit Email Content" on Step 2 → Step 1 collapses, Step 2 expands
- [ ] No modal dialogs appear at any point during step editing (except for Insert Event picker, Insert Offer dialog, Insert Button dialog, and AI Refine dialog — those are expected as small focused dialogs, not full-page modals)

---

## FIX 3: "Create from Scratch" Should Open the Editor Ready to Type

### Problem
When a user chooses "Create from Scratch" in Send Email, they land on the Review & Edit screen with an empty read-only view that says "Enter your email content here..." They have to know to click "Edit Manually" to actually start typing. This is confusing — if you chose to create from scratch, you expect to start writing immediately.

### Fix
When `emailMethod === 'scratch'` and there is no existing email body content, the compose/Review & Edit step should:
1. Automatically enter manual editing mode (set `isManualEditing = true`)
2. Show the ReactQuill editor immediately, ready for typing
3. Show the Insert Event/Offer/Button toolbar below the editor
4. Show the subject line input above the editor (editable)

The user should never see an empty read-only view when they chose "Create from Scratch."

### Verification
- [ ] Choose Audience → Create Email → pick "Create from Scratch" → click Next
- [ ] You land on an editor that is immediately ready to type in (cursor in editor, no need to click "Edit Manually")
- [ ] Insert Event/Offer/Button buttons are visible and work
- [ ] Subject line is editable above the editor

---

## FIX 4: Merge Field Preview Data

### Problem
The email preview step sometimes shows raw merge field tags (`{{FirstName}}`, `{{EventName}}`, etc.) instead of sample data. The preview function has a `EXAMPLE_MERGE_DATA` mapping that should replace tags with example values (e.g., `{{FirstName}}` → "Sarah"), but it's not being applied consistently.

### Fix
Ensure that the preview rendering function (`getEmailPreviewHtml` or equivalent) ALWAYS replaces merge fields with sample data before rendering. This applies in:

1. **Send Email preview step** — the iframe that shows the full email preview
2. **Automations preview step** — the iframe that shows the email preview
3. **Both single-email and multi-step automation previews**

The example data mapping should include ALL merge fields the system uses. Check the current `EXAMPLE_MERGE_DATA` constant and add any missing fields. It should include at minimum:

```typescript
const EXAMPLE_MERGE_DATA: Record<string, string> = {
  "{{FirstName}}": "Sarah",
  "{{LastName}}": "Johnson",
  "{{FullName}}": "Sarah Johnson",
  "{{Email}}": "sarah.johnson@email.com",
  "{{OfficeName}}": "Coldwell Banker Realty",
  "{{MemberSince}}": "February 21, 2016",
  "{{YearsWithMainstreet}}": "10",
  "{{YearsAsMember}}": "10",
  "{{JoinDate}}": "February 21, 2016",
  "{{Designations}}": "CRS, ABR",
  "{{TotalTransactions}}": "47",
  "{{CEHours}}": "12",
  "{{CEHoursTotal}}": "156",
  "{{HoursRemaining}}": "18",
  "{{EventsAttended}}": "8",
  "{{Amount}}": "$425.00",
  "{{InvoiceDate}}": "January 15, 2026",
  "{{DaysOverdue}}": "30",
  "{{ClassName}}": "Pitfalls & Possibilities - Presenting and Negotiating Contracts",
  "{{ClassDate}}": "March 15, 2026",
  "{{ClassTime}}": "9:00 AM",
  "{{MilestoneLabel}}": "50th Transaction Milestone",
  "{{MilestoneValue}}": "50",
  "{{LicenseType}}": "Managing Broker",
  "{{LicenseRenewalDate}}": "April 30, 2026",
  "{{EventName}}": "Pitfalls & Possibilities - Presenting and Negotiating Contracts",
  "{{EventDate}}": "March 15, 2026",
  "{{EventTime}}": "9:00 AM",
  "{{EventLocation}}": "Mainstreet REALTORS® - Downers Grove Campus",
  "{{EventDuration}}": "3 hours",
};
```

The preview function should do a global replace of ALL known merge fields. Apply this replacement in every preview context — Send Email, Automations single-email, Automations multi-step (for each step's preview).

### Verification
- [ ] Send Email preview shows "Hi Sarah," not "Hi {{FirstName}},"
- [ ] Automations preview for event registration shows real sample data for event fields
- [ ] Automations preview for membership anniversary shows "10" for YearsAsMember
- [ ] Multi-step drip preview shows sample data for each step
- [ ] No raw `{{...}}` merge tags visible in any preview

---

## FIX 5: Add Delete/Discard for Automations

### Problem
There is no way to delete or discard an automation from the Automations list page. Users need to be able to remove automations they no longer want.

### Fix
Add a "Delete" option to the three-dot menu (the `...` button) on each automation card in the Automations list page. The behavior should be:

- **Draft automations:** Show "Delete" in the menu. Click → confirmation dialog ("Delete this draft automation? This cannot be undone.") → on confirm, call `DELETE /api/triggered-campaigns/:id` → remove from list.
- **Paused automations:** Show "Delete" in the menu. Same confirmation flow.
- **Active automations:** Show "Delete" in the menu, but the confirmation dialog should say "This automation is currently active and will stop sending. Delete it? This cannot be undone." → on confirm, call DELETE endpoint → remove from list.
- **Archived automations:** Show "Delete" in the menu. Simple confirmation.

The DELETE endpoint already exists at `DELETE /api/triggered-campaigns/:id` in routes.ts.

### Verification
- [ ] Three-dot menu on a draft automation shows "Delete" option
- [ ] Clicking Delete shows a confirmation dialog
- [ ] Confirming deletes the automation and removes it from the list
- [ ] Delete works for paused, active, and archived automations
- [ ] Canceling the confirmation dialog does nothing

---

## FIX 6: "Generate Email" Button Flow in Automations

### Problem
The Automations compose step now has an explicit "Generate Email" button that must be clicked before Next is enabled. The previous flow was better: user picks AI method, fills in purpose/tone/CTA, clicks Next, and the system generates the email and advances. The separate Generate button adds friction and confusion.

### Fix
Remove the separate "Generate Email" button from the Automations compose step. Restore the flow where:

1. User selects "Generate with AI" method card
2. User fills in purpose, tone, CTA, optional offer
3. User clicks **Next**
4. The system generates the email (show a loading state on the Next button: spinner + "Generating...")
5. On success: advance to the Preview step with the generated content
6. On failure: show a toast error and stay on the compose step

This matches the flow pattern from before and is more intuitive — the user's mental model is "fill in the fields and click Next," not "fill in the fields, click Generate, wait, then click Next."

### Verification
- [ ] Automations → Compose Email → select "Generate with AI" → fill in fields → click Next → email generates and advances to Preview
- [ ] There is no separate "Generate Email" button on the compose step
- [ ] The Next button shows a loading spinner while generating
- [ ] If generation fails, a toast error appears and you stay on the compose step

---

## FIX 7: Copyright Year in AI-Generated Content

### Problem
AI-generated email content sometimes includes "© 2024 Mainstreet REALTORS®" in the email body. The AI should never include a copyright footer in the email body because the email template already adds a footer automatically. But if it does include one, it should use the current year (2026).

### Fix
In `server/services/aiEmailService.ts`, add this line to the system prompt in the `generateEmail` function (add it near the other formatting instructions):

```
- Do NOT include a copyright notice, footer, or unsubscribe link in the email body. These are added automatically by the email template. The email body should end with a sign-off like "The Mainstreet REALTORS® Team" and nothing else.
- The current year is 2026. Never reference 2024 or 2025 as the current year.
```

Also add the same instruction to the `refineEmail` function's system prompt.

### Verification
- [ ] Generate an email → no copyright notice in the body
- [ ] No "© 2024" or "© 2025" appears in any generated content
- [ ] The email body ends with a sign-off, not a footer

---

## FIX 8: ReactQuill Formatting Loss When Editing Inserted Blocks

### Problem
When a user inserts a styled event block (the teal-bordered card) into an empty email, then clicks "Edit Manually," the ReactQuill editor strips the inline styles from the HTML. The event block loses its teal border, background color, and styled layout, reverting to plain text.

This is a known limitation of ReactQuill — it doesn't preserve complex inline HTML styles when switching between rendered view and edit mode.

### Fix
This is a deeper architectural issue that we should not try to fully solve right now. Instead, apply this practical workaround:

**When the user is in Edit Manually mode**, show a small info banner above the editor:
```
ℹ️ Styled blocks (events, offers, buttons) may look different in the editor but will display correctly in the final email. Use the Preview step to see the actual appearance.
```

This sets expectations without trying to fix Quill's HTML handling, which would be a major undertaking.

**Additionally:** When the user clicks "Edit Manually" and there are styled blocks in the content, preserve the original HTML in state. When saving changes from the manual editor, only replace the text content — keep the styled HTML blocks intact if they weren't modified. This is a best-effort approach.

### Verification
- [ ] Insert an event block → click Edit Manually → info banner appears explaining styled blocks may look different
- [ ] Preview step shows the event block with correct teal styling regardless of manual edits
- [ ] The sent email renders the event block correctly with full styling

---

## IMPLEMENTATION ORDER

1. Fix 1: Remove Pause Before Editing dialog (quick, high impact)
2. Fix 5: Add Delete for automations (quick, essential missing feature)
3. Fix 3: Create from Scratch auto-edit mode (quick, UX improvement)
4. Fix 4: Merge field preview data (moderate, affects both flows)
5. Fix 6: Remove Generate Email button (moderate, restore better flow)
6. Fix 7: Copyright year fix (quick, one-line additions)
7. Fix 2: Kill the modal step editor (largest change, save for focused effort)
8. Fix 8: ReactQuill formatting banner (small, informational)

---

## FILES LIKELY AFFECTED

- `client/src/pages/Automations.tsx` — Remove pause dialog, add delete option
- `client/src/pages/CreateAutomation.tsx` — Kill modal step editor, fix Generate button flow
- `client/src/pages/SendEmail.tsx` — Auto-edit mode for scratch, merge field preview
- `server/services/aiEmailService.ts` — Copyright year, footer instructions
- `client/src/lib/emailBlocks.ts` — May need to update EXAMPLE_MERGE_DATA if it lives here

**NOT modified:**
- `server/routes.ts` — Already fixed in Prompt 2
- `shared/schema.ts`
- `triggeredCampaignProcessor.ts`
- `emailService.ts`
- `scheduledEmailProcessor.ts`

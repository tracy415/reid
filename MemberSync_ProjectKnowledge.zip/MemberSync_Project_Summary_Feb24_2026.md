# MemberSync / SmartSends — Project Summary
## February 24, 2026

This document captures all decisions, architecture, prompts, and current state through February 24, 2026. Use this to resume work in a new conversation.

---

## TABLE OF CONTENTS

1. Project Overview
2. Client Pipeline and Membership Context
3. Technical Architecture
4. What Has Been Built (Complete)
5. What Was Accomplished Feb 23–24, 2026
6. Current Database Schema (Key Tables)
7. Production Database Schema (Read-Only)
8. Daily Jobs Schedule
9. AI Services Architecture
10. Engagement Scoring System
11. Dashboard Architecture
12. SmartSends Current State
13. Triggered Campaigns / Automations Current State
14. Prompts Ready for Replit (Not Yet Built)
15. Known Issues Still Open
16. CRMLS Pilot Program
17. AI Cost Model and Pricing Strategy
18. Security & Data Protection Roadmap
19. Multi-Tenant Architecture Roadmap
20. Strategic Roadmap (Updated)
21. Key Architectural Decisions
22. Key Files Reference
23. Production Data Reference
24. Mainstreet Brand and AI Content Training

---

# 1. PROJECT OVERVIEW

## What We Are Building

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs. SmartSends is the email marketing and automation layer within MemberSync. The platform uses predictive analytics to help MLS and association executives retain and engage members by analyzing residential real estate listings and association management system (AMS) data.

The product vision: MemberSync should be the organization's **second brain** — the system that is always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

## Product Model

MemberSync is a **SaaS product** — not a custom build for any single client. Every feature should work for any association or MLS through configuration, not custom code. The long-term goal is self-service onboarding: a new organization signs up with a credit card, connects their API keys, and goes.

## Build Philosophy

Tracy (founder of Membio) is a non-technical business leader with 30+ years in proptech, building exclusively with AI tools:
- **Claude** for strategy, specifications, and Replit prompts
- **Julius.AI** for SQL development against the production database
- **Replit Agent** for all coding implementation

Tracy maintains creative control over product design and UX decisions. The development team hardens for production (error handling, edge cases, performance). Tracy builds the first 80% through prototyping; the team does the production-ready 20%.

## Product Philosophy: Celebrating Connection Over Compliance

The core insight: 75% of association members produce only 12% of real estate volume, yet pay 75% of dues revenue. MemberSync exists to help associations prove their value to all members by measuring and improving engagement with the organization itself. All member tiers are framed positively. We celebrate connection, not police compliance.

---

# 2. CLIENT PIPELINE AND MEMBERSHIP CONTEXT

## Three-Client Growth Trajectory

| | Client | Members | Cumulative | Status |
|---|---|---|---|---|
| Client 1 | Mainstreet REALTORS® (suburban Chicago) | 18,275 | 18,275 | **Live** — production-proven |
| Client 2 | Hudson Gateway Association of REALTORS® (New York) | 12,800 | 31,075 | **Preparing to onboard** |
| Client 3 | CRMLS | 103,000+ | 134,000+ | **Pilot proposed** — CMO has expressed strong interest |

Additional clients have already expressed interest beyond these three. Multi-tenant architecture is essential regardless of whether CRMLS proceeds.

## Mainstreet REALTORS® (Client 1) Detail

**Members:** ~18,275 active
**Offices:** ~2,800
**Current email volume:** ~300,000 emails/month (existing, pre-MemberSync)
**Member Tiers (by 12-month transaction sides):**
- Foundation (0–5 sides): 14,144 agents (77%)
- Builder (6–39 sides): 3,885 agents (21%)
- Rainmaker (40+ sides): 247 agents (1.4%)

**Key Insight:** Top 25% of agents control 88% of volume; 40% of agents have zero transactions.

---

# 3. TECHNICAL ARCHITECTURE

- **Frontend:** React with Tailwind CSS, shadcn/ui components
- **Backend:** Node.js / Express
- **Database:** PostgreSQL (local via Drizzle ORM + read-only external AWS production DB via `externalPool`)
- **Hosting:** Replit (application) + AWS (production database)
- **Email:** SendGrid — Membio is an established SendGrid channel partner with dedicated IP experience across existing property search products
- **AI:** Anthropic Claude API (Sonnet 4 for email generation, audience building, data queries)
- **ORM:** Drizzle
- **Infrastructure:** Membio is an existing AWS shop. Production database and supporting infrastructure run on AWS. Scaling to dedicated cloud hosting is an extension of existing infrastructure, not a platform migration.

---

# 4. WHAT HAS BEEN BUILT (COMPLETE)

- Full dashboard with AI Chat, Pulse cards, Activity Feed, Member Recognition, Mainstreet Community
- Tier-aware engagement scoring system
- Member detail pages with engagement breakdown
- Office detail pages with agent rosters
- SmartSends email campaign creation (AI + manual + template)
- Audience building (AI builder, picklist, member/bill type, CSV upload)
- Saved audiences with preview and count
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail pages
- Triggered campaigns / Automations engine with 7 trigger types
- Automations UX upgrade (full-page wizard)
- Email analytics overview
- Office visit brief PDF generation
- Compliance tracking
- Image library for emails
- Draft management
- Scheduled email sending

---

# 5. WHAT WAS ACCOMPLISHED FEBRUARY 23–24, 2026

## Feb 23–24: Unified Composer Architecture, AI Content Training, Post-Implementation Fixes

### Root Cause Analysis: Parallel Systems Problem

Tracy tested the Prompt 1 (Automations UX Upgrade) and Prompt 2 (Bug Fixes) implementations and discovered that **Replit built parallel systems instead of fixing the existing ones**. The key problems:

1. **Modal-on-modal architecture** — Automations used a separate modal dialog for email composition instead of the full-page composer that Send Email uses. This created three-layer stacking when "Edit with AI" opened on top of the step editor modal.
2. **Broken insert tools in automations** — Insert Event, Insert Offer, Insert Button tools worked in Send Email but not in the automations modal because they were wired to separate editor instances.
3. **AI hallucinating events** — The AI generated fictional events (e.g., "Market Trends Workshop - March 15th") because it had no access to real event data from the database when generating automations emails.
4. **AI urgency = fire emojis** — When asked to "make it more urgent," the AI produced fire emojis, ALL CAPS, and infomercial language because it had no tone guardrails.
5. **500 error on automation updates** — Backend couldn't save automations with empty auto-stop dates because Postgres can't cast empty strings to timestamps.

### Decision: Three-Prompt Strategy

Rather than one large fix prompt, the work was split into three focused prompts to prevent Replit from half-implementing each:

**Prompt 1: Unified Email Composer** (`SmartSends_Prompt1_UnifiedComposer.md`) — SENT TO REPLIT
- Extract shared `EmailComposer` component from SendEmail.tsx
- Use it in both Send Email and CreateAutomation flows
- Kill all modal-based email editors in Automations — replace with inline expand/collapse
- Fix cursor position bug where inserts land in random positions (save cursor before opening dialogs)
- Delete all dead code (duplicated state, refs, functions, dialogs)
- Verification checkpoint after SendEmail refactor before touching Automations

**Prompt 2: Backend Fixes** (`SmartSends_Prompt2_BackendFixes.md`) — SENT TO REPLIT, IMPLEMENTED
- Fix 500 error: convert empty `autoStopDate` strings to null before database write
- Relax active edit restriction: allow content edits on active campaigns, only block trigger type changes
- Frontend safety: explicit null handling for autoStopDate in both create and update mutations

**Prompt 3: AI Content Training** (`SmartSends_Prompt3_AITraining.md`) — READY TO SEND
- Add `MAINSTREET_BRIEFING` constant — 350-word institutional knowledge document giving the AI real context about Mainstreet's identity, values, voice, geography, programs, and offerings
- Anti-hallucination rules: only reference real events from the database, never fabricate
- Tone guardrails: define what "professional," "friendly," and "urgent" mean at Mainstreet specifically. Absolute boundaries prohibiting fire emojis, ALL CAPS, spam phrases
- CE vs. non-CE class distinction: non-CE classes are voluntary, making attendance a stronger engagement signal
- Value-first language: "the best association, not the cheapest"
- Remove database schema (`getDataAwarenessSummary()`) from email generation prompts — saves ~10K tokens per call
- Copyright year: instruct AI that current year is 2026, never include copyright footer in body

### Post-Implementation Testing (After Prompt 1 & 2 Applied)

Tracy tested the implementations and found additional issues. A cleanup prompt was written:

**Post-Implementation Cleanup** (`SmartSends_PostImplementation_Cleanup.md`) — READY TO SEND
Eight prioritized fixes:
1. **Remove "Pause Before Editing" dialog** — Backend fix is in, but frontend still shows blocking modal
2. **Kill the modal step editor** — Drip sequence still using popup modal instead of inline expand/collapse
3. **"Create from Scratch" should open ready to type** — Currently lands on empty read-only view
4. **Merge field preview data** — `{{FirstName}}` showing instead of "Sarah" in previews
5. **Add Delete for automations** — No way to discard/delete automations
6. **Remove separate "Generate Email" button** — Restore better flow: fill fields → click Next → generates
7. **Copyright year 2026** — AI-generated content shows "© 2024"
8. **ReactQuill formatting info banner** — Set expectations about styled blocks looking different in editor vs. sent email

### Cursor Position Fix (New Feature)

Discovered that Insert Event/Offer/Button functions insert content at unpredictable positions because clicking toolbar buttons moves focus away from the Quill editor, causing `getSelection()` to return null. The fix — baked into Prompt 1's EmailComposer spec — saves the cursor position before opening any dialog and uses the saved position when inserting:

```typescript
function saveCursorPosition() {
  const quill = quillRef.current?.getEditor();
  if (quill) {
    const selection = quill.getSelection();
    setSavedCursorPosition(selection ? selection.index : quill.getLength());
  }
}
```

### Replit Q&A Decisions

Replit asked four clarifying questions during Prompt 1 implementation. Answers provided:

1. **Templates in Automations:** Use the `onSelectTemplate` callback prop. When not provided, show "Coming soon" on the Template card. Don't build a separate template system.
2. **Who owns the Generate flow:** EmailComposer owns it entirely with its own Generate button. Parent's Next button just validates that content exists.
3. **Trigger event picker:** Stays in CreateAutomation. Only the "insert event into email body" picker moves to EmailComposer. Separate the shared `isEventPickerOpen` state.
4. **Scope boundary:** Purely frontend refactor. No backend changes needed for the unified composer.

### Mainstreet Brand Discovery

Gathered comprehensive Mainstreet brand positioning and institutional knowledge for AI training:

**Positioning (created by Tracy/Membio in 2023):**
"To professionals who want or have a career in real estate, Mainstreet REALTORS® is THE member-centric association that provides the practical know-how, guidance, training, protection, and industry connections you need so you can achieve your goals."

**Values:** We believe in EVERY member. We are obsessed with what works. We make it easy. We are change-makers. We do the right thing. We are really, really nice.

**Geography:** Largest regional real estate association in Chicagoland. All of DuPage County plus portions of Cook County, Lake County, Will County, and southern suburban areas. 200+ municipalities. Bordered by five competing associations. Four campuses: Downers Grove (HQ), Tinley Park, Rolling Meadows, Libertyville.

**Voice guidance:** Warm, confident, practical, focused. Write like a smart colleague who wants you to succeed. Lead with VALUE, never price. Mainstreet is the best association, not the cheapest. Short focused emails, not kitchen-sink newsletters.

**Education insight:** Mainstreet offers both CE and non-CE classes. Non-CE classes are purely voluntary, making attendance a stronger engagement signal than CE classes (which members must take to stay licensed).

### Key Decisions Made Feb 23–24

1. **Shared components over parallel systems:** When two flows need similar functionality, they must use the same component with configuration flags, not duplicate implementations. This is the same principle driving multi-tenant architecture.

2. **Three-prompt strategy for Replit:** Focused prompts get better results than comprehensive ones. Split by concern: (1) frontend architecture, (2) backend fixes, (3) AI intelligence.

3. **AI needs institutional knowledge, not just branding rules:** The difference between "write for a real estate association" and writing in Mainstreet's actual voice requires context about values, programs, geography, and tone.

4. **Database schema doesn't belong in email prompts:** `getDataAwarenessSummary()` adds ~10K tokens to every email generation call but only matters for AI Chat SQL queries. Removing it from email prompts saves cost and reduces noise.

5. **Value-first, never price-first:** AI emails should promote what members get from classes/events, not how cheap they are. "Walk out with a strategy you can use Monday morning" beats "only $25 for members."

6. **Non-CE attendance is a stronger engagement signal than CE:** Members who attend classes they're not required to take are demonstrating genuine engagement with the association.

---

# 6–11. [UNCHANGED FROM FEB 22 SUMMARY]

Refer to the Feb 22 project summary for these sections — no changes to database schema, production schema, daily jobs, AI services, engagement scoring, or dashboard architecture.

---

# 12. SMARTSENDS CURRENT STATE

## What's Built and Working
- Campaign creation with AI-composed or manual email body
- Three method cards: Use a Template, Generate with AI, Create from Scratch
- Audience selection (AI-built, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail page with aggregate stats
- Analytics overview with office leaderboards
- PDF generation for office visit briefs
- Saved audiences with count and preview
- Email templates (functional but needs future rework)
- Draft management
- Image library
- Insert Event shows real upcoming events from database and creates styled teal blocks
- Backend: active campaigns can now be edited without pausing (Prompt 2 fix applied)

## What's Built But Has Issues (Fixes in Progress)
- **"Pause Before Editing" frontend dialog still showing** — backend fix applied but frontend dialog not removed (Fix 1 in Cleanup prompt)
- **Modal-on-modal in automations drip sequences** — step editor still uses popup modal instead of inline editing (Fix 2 in Cleanup prompt)
- **"Create from Scratch" lands on confusing empty screen** — should auto-enter edit mode (Fix 3 in Cleanup prompt)
- **Merge field preview inconsistent** — sometimes shows raw `{{tags}}` instead of sample data (Fix 4 in Cleanup prompt)
- **No delete/discard for automations** — can't remove unwanted automations (Fix 5 in Cleanup prompt)
- **Separate "Generate Email" button in automations** — breaks the intuitive fill-fields-click-Next flow (Fix 6 in Cleanup prompt)
- **AI says © 2024** — needs current year instruction (Fix 7 in Cleanup prompt)
- **ReactQuill strips inline styles from inserted blocks** — event blocks lose formatting when switching to Edit Manually (Fix 8 in Cleanup prompt, workaround approach)
- **Scheduled Series validation bug** — requires all steps to have content even after deleting a step (discovered in testing, add to cleanup)
- Insert Offer and Insert Button exist but don't always work depending on editor context
- Resend Campaign uses modal instead of full wizard
- AI-generated events are sometimes plain text, not styled cards

---

# 13. TRIGGERED CAMPAIGNS / AUTOMATIONS CURRENT STATE

## What's Built
- Triggered campaign processor running every 15 minutes
- 7 trigger types: event_registration, event_reminder, event_followup, membership_anniversary, production_milestone, drip_sequence, scheduled_series
- Full-page wizard for create/edit (Configure Trigger → Compose → Preview → Settings & Activate)
- Trigger-specific configuration UI for each type
- Drip sequence step builder with per-step editing (modal — needs to be converted to inline)
- Scheduled Series step builder with date pickers (working but has validation bug)
- Automation list with status sections (Active, Paused, Drafts, Archived)
- Send window configuration (start/end time, weekday toggle)
- Auto-stop date (backend fix applied for empty date handling)
- Deduplication to prevent repeat sends
- Anniversary trigger verified working (26 sends processed)
- Active campaigns can now be edited without pausing (content edits allowed, only trigger type changes blocked)

## What's in Cleanup Prompt (Ready to Send)
- Remove "Pause Before Editing" frontend dialog
- Kill modal step editor → inline expand/collapse
- Add delete/discard automation capability
- Fix Generate Email button flow (restore fill-fields → Next → generates)
- Fix Scheduled Series step validation after deleting steps

## What's Prompt-Ready But Not Built
- **A/B Testing** for triggered campaigns (`SmartSends_ABTesting_Part2.md`)
- Automation-specific analytics
- Event override priority system

## Key Architecture
- `triggered_campaigns` table: campaign config, trigger type, status
- `triggered_campaign_steps` table: multi-step campaigns (drip, scheduled series)
- `triggered_campaign_sends` table: per-member send records with dedup
- Processor: `triggeredCampaignProcessor.ts` — evaluates triggers, queues sends, processes pending
- Each trigger type has its own evaluator function
- `triggerReference` field prevents duplicate sends
- `campaignVersion` integer field (1 and 2) supports future A/B testing

---

# 14. PROMPTS READY FOR REPLIT

**Send order:**

1. **Post-Implementation Cleanup** (`SmartSends_PostImplementation_Cleanup.md`) — 8 fixes from testing Prompts 1 and 2. SEND NEXT.

2. **AI Content Training** (`SmartSends_Prompt3_AITraining.md`) — Mainstreet briefing, anti-hallucination, tone guardrails, cost optimization. SEND AFTER CLEANUP (or simultaneously since it only touches `aiEmailService.ts`).

3. **A/B Testing for Triggered Campaigns** (`SmartSends_ABTesting_Part2.md`) — A/B split on subject line and body, automatic winner selection, variant performance tracking. SEND AFTER AUTOMATIONS ARE STABLE.

4. **AI Chart Rendering** (NOT YET WRITTEN — ACCELERATED FOR CRMLS PILOT) — AI Chat detects when results should be charts, renders Recharts inline, download-as-image button. Estimated 3–5 Replit prompts.

---

# 15. KNOWN ISSUES STILL OPEN

### Critical (Blocking User Flows)
- **"Pause Before Editing" dialog on all active automations** — Backend fix applied, frontend dialog remains (Cleanup Fix 1)
- **Modal step editor in drip sequences** — Prompt 1 spec'd inline editing but modal persists (Cleanup Fix 2)
- **Scheduled Series validation after step deletion** — Can't proceed after deleting a step (discovered in testing)

### Important (UX Quality)
- **"Create from Scratch" empty screen confusion** — Should auto-enter edit mode (Cleanup Fix 3)
- **Merge field preview inconsistency** — Raw tags instead of sample data (Cleanup Fix 4)
- **No delete/discard for automations** — Essential missing feature (Cleanup Fix 5)
- **Separate "Generate Email" button** — Breaks the intuitive flow (Cleanup Fix 6)
- **AI copyright year says 2024** — Minor but unprofessional (Cleanup Fix 7)
- **ReactQuill strips inline styles** — Styled blocks lose formatting in edit mode (Cleanup Fix 8)
- **Insert tools land at random positions** — Cursor position fix in Prompt 1 EmailComposer spec
- AI hallucinating events in automations — Fixed by Prompt 3 anti-hallucination rules
- AI urgency = fire emojis — Fixed by Prompt 3 tone guardrails
- No Audience Preview on Settings & Activate step (trigger-type-aware)
- Resend Campaign modal should route to full wizard

### Lower Priority
- Templates system needs future rework (functional but not useful enough)
- The 172-member gap (dashboard vs. member type builder count)
- AI Query Service sometimes generates wrong SQL
- Cache health monitoring (no admin visibility into cron job status)
- Email engagement data cold start
- Revenue data uses catalog prices, not actual invoiced amounts

---

# 16. CRMLS PILOT PROGRAM

## Pilot Structure
- **Duration:** 90 days, three phases
- **Phase 1 (Weeks 1–2):** Setup, data connection, configuration, training
- **Phase 2 (Weeks 3–10):** Active usage with minimum commitment targets
- **Phase 3 (Weeks 11–12):** Evaluation, results report, go/no-go decision
- **Pilot subset:** One CRMLS region or member segment (10,000–20,000 subscribers)

## Pilot Deliverables
1. Full MemberSync dashboard configured for CRMLS
2. AI Chat with **inline chart rendering and download** (accelerated from roadmap)
3. SmartSends email campaigns (up to 50,000 emails/month)
4. Automations engine with all 7 trigger types
5. Engagement scoring across all member tiers
6. Office visit PDF profiles
7. Weekly support and midpoint review

## Success Criteria (Agreed Before Pilot Starts)
- 80%+ of pilot team active weekly by Week 8
- Email open rates ≥20%, click rates ≥3%
- 50+ AI queries/week sustained for 4+ weeks
- AI charts used in 2+ board/executive reports
- Staff satisfaction ≥4.0/5.0
- 99.5%+ platform uptime

## Pricing
- $2,500/month × 3 months = $7,500 total
- Full credit toward Year 1 contract if pilot converts
- Walk away with no obligation if success criteria not met

## Key Pilot Principle
Both sides must have commitments. CRMLS designates a pilot lead, assigns 5–10 staff, meets usage targets, and attends reviews. Without client participation, pilots die from neglect.

---

# 17. AI COST MODEL AND PRICING STRATEGY

## Current Model: Claude Sonnet 4
- Input tokens: $3.00 per million tokens
- Output tokens: $15.00 per million tokens
- Cached input: $0.30 per million tokens (90% savings)

## Email Generation Cost
- Current: ~$0.06/email (includes unnecessary database schema)
- After Prompt 3 optimization: ~$0.03/email (schema removed, briefing adds minimal tokens)
- With prompt caching: ~$0.01/email for subsequent calls in same session

## Cost Control Strategies
1. **Remove database schema from email prompts** — saves ~10K tokens/call (Prompt 3)
2. **Prompt caching** — 90% reduction on repeated system prompts
3. **Model routing** — Haiku for simple queries, Sonnet for complex generation
4. **Token budget limits** — per-query and per-session caps

---

# 18. SECURITY & DATA PROTECTION ROADMAP

[UNCHANGED FROM FEB 22 SUMMARY]

---

# 19. MULTI-TENANT ARCHITECTURE ROADMAP

[UNCHANGED FROM FEB 22 SUMMARY]

---

# 20. STRATEGIC ROADMAP (UPDATED)

## Immediate (In Progress)
1. **Post-Implementation Cleanup** — 8 fixes from Prompt 1/2 testing
2. **AI Content Training** — Mainstreet briefing, anti-hallucination, tone guardrails
3. **Scheduled Series stabilization** — Fix validation bug after step deletion

## Near-Term (Pilot Preparation)
4. **A/B Testing** — Variant testing for triggered campaigns
5. **AI Chart Rendering** — Inline charts in AI Chat + download as image (ACCELERATED for CRMLS pilot)
6. **Prompt Caching Implementation** — 90% reduction on AI input costs
7. **Multi-Tenant Stage 1** — Database-driven tenant config for HGAR onboarding
8. **Batch Email Sending** — Rate-limited queue for Mainstreet's 300K/month + CRMLS scale
9. **SOC 2 Type I Preparation** — Compliance automation platform, audit logging, pen testing

## Medium-Term
10. **Templates Rework** — Make templates actually useful (past campaigns as templates, smart suggestions)
11. **Lapse Prevention System** — Status tracking, risk scoring, intervention management
12. **Multi-Tenant Stage 2** — Admin provisioning dashboard
13. **Broker Module** — Office management dashboards
14. **Exportable Charts** — PDF/PNG export, copy to clipboard

## Longer-Term
15. **AI Report Generation (Stage 4)** — Multi-section board reports from natural language
16. **Self-Service Onboarding (Multi-Tenant Stage 3)** — Credit card signup and GO
17. **Lapse Pattern Analysis** — Predictive models from pre-departure behavior
18. **Integration Marketplace** — Zendesk, Google Analytics, LMS connectors
19. **AI Presentation Generation (Stage 5)** — Slide-ready content from data

---

# 21. KEY ARCHITECTURAL DECISIONS

All decisions from previous summaries remain in effect, plus:

- **Shared components over parallel systems:** When two flows need similar functionality, they use the same component with configuration flags, not duplicate implementations. The EmailComposer component is shared between Send Email and Automations. This is the same principle driving multi-tenant architecture.
- **Three-prompt strategy for complex changes:** Split large changes by concern (frontend architecture, backend fixes, AI intelligence) rather than combining into one mega-prompt. Focused prompts get better Replit results.
- **AI needs institutional knowledge:** The Mainstreet Briefing gives the AI ~350 words of context about the association's identity, values, voice, geography, and programs. This prevents hallucination and produces brand-consistent content.
- **Database schema doesn't belong in email prompts:** `getDataAwarenessSummary()` is for AI Chat SQL queries, not email generation. Removing it from email prompts saves ~10K tokens per call.
- **Value-first, never price-first:** AI emails promote what members get, not how cheap it is. "Walk out with a strategy you can use Monday morning" beats "only $25."
- **Non-CE attendance is a stronger engagement signal than CE attendance:** Members who attend voluntary classes demonstrate genuine engagement.
- **Cursor position saved before dialogs:** All insert functions (event, offer, button, merge field) save cursor position before opening any dialog, ensuring content inserts where the user expects.
- **Server-side audience resolution for sends:** Large audiences pass audienceId; server resolves recipients.
- **Milestone triggers are mutually exclusive:** One automation per milestone type. Radio buttons enforce single selection.
- **Scheduled Series resolves audience fresh at each send date:** Unlike drip (which enrolls at activation), scheduled series queries current audience for each email.
- **UX consistency is non-negotiable:** Both email flows use the same wizard, same components, same tools, same card order.
- **Every email editing path goes through the full wizard:** Resend, duplicate, edit — all route to standard wizard.
- **AI Chart rendering is a pilot deliverable, not a post-launch roadmap item.**
- **Multi-tenant architecture starts now:** Every feature evaluated through "will this work for Client 4?" lens.
- **Paid pilots with credit-toward-contract:** Ensures mutual commitment.
- **SOC 2 is a sales advantage, not just compliance.**
- **Prompt caching is the #1 AI cost optimization.**
- **Model routing for cost control:** Haiku for simple queries; Sonnet for complex analysis and generation.

---

# 22. KEY FILES REFERENCE

### Prompts Sent to Replit (Current Round)
- `SmartSends_Prompt1_UnifiedComposer.md` — Shared EmailComposer, kill modals, cursor fix (SENT — PARTIALLY IMPLEMENTED, ISSUES FOUND)
- `SmartSends_Prompt2_BackendFixes.md` — autoStopDate fix, relax active edit check (SENT — IMPLEMENTED)
- `SmartSends_PostImplementation_Cleanup.md` — 8 fixes from testing (READY TO SEND)
- `SmartSends_Prompt3_AITraining.md` — Mainstreet briefing, anti-hallucination, tone guardrails (READY TO SEND)

### Strategy Documents
- `MemberSync_CRMLS_Scaling_Roadmap.docx` — Comprehensive scaling, AI cost, security, and multi-tenant roadmap
- `MemberSync_CRMLS_Pilot_Proposal.docx` — 90-day pilot structure, pricing, success criteria

### Previously Implemented Prompts
- `SmartSends_TriggeredCampaigns_Part1.md` — Automation engine (DEPLOYED)
- `SmartSends_Automations_UX_Upgrade.md` — Full wizard + Scheduled Series (DEPLOYED — ISSUES FOUND)
- `SmartSends_BugFixes_ComposerPolish.md` — Bug fixes + UX consistency (DEPLOYED — ISSUES FOUND)
- `SmartSends_AudienceBuilder_Improvements.md` — Inline creation, Picklist, Member/Bill Type (COMPLETE)
- `MemberSync_Volume_Fix_Replit_Prompt.md` — Double-counting fix (COMPLETE)
- `MemberSync_Consolidated_Fix_Prompt_Feb18_2026.md` — 9-issue fix batch (COMPLETE)
- `MemberSync_Dashboard_Redesign_Prompt.md` — Full dashboard overhaul (COMPLETE)
- `MemberSync_Dashboard_Redesign_Part2.md` — Mainstreet Community section (COMPLETE)
- `MemberSync_Dashboard_Cleanup.md` — Visual polish (COMPLETE)
- `MemberSync_Dashboard_Fixes_Round2.md` — Targeted fixes (COMPLETE)
- `MemberSync_Dashboard_QuickFixes.md` — Height matching, donuts (COMPLETE)
- `MemberSync_Dashboard_CRMLS_Demo.md` — Member Recognition tiles, Discovery cards (COMPLETE)
- `MemberSync_EngagementScore_Redesign_Prompt.md` — Tier-aware scoring (COMPLETE)
- `MemberSync_EngagementScore_Rebalancing_Prompt.md` — Threshold + weight corrections (COMPLETE)
- `MemberDetail_ScoreLabels_and_DashboardConsistency_Fix.md` — Score breakdown fix (COMPLETE)
- `MemberSync_Stability_DataConsistency_Prompt.md` — Atomic cache, staleness detection (COMPLETE)
- `CodeCleanup_DeadCode_and_Fixes.md` — Mock data removal (COMPLETE)

### Backend Services
- `triggeredCampaignProcessor.ts` — Triggered campaign evaluation and send processing
- `storage.ts` — Main data layer, dashboard metrics, member/office queries
- `memberMetricsCacheService.ts` — Daily cache refresh with tier-aware engagement scoring
- `engagementScoreService.ts` — Engagement score calculation logic
- `aiQueryService.ts` — AI SQL generation, query execution, insights
- `aiAudienceService.ts` — Audience CRUD, smart audience execution, enrichment
- `aiEmailService.ts` — AI email composition (generate + refine endpoints) — BEING UPDATED WITH MAINSTREET BRIEFING
- `emailService.ts` — Email sending, queue processing, campaign management
- `scheduledEmailProcessor.ts` — Processes scheduled campaigns
- `milestoneDetectionService.ts` — Celebration/milestone detection
- `analyticsProductionCacheService.ts` — Office/agent production analytics
- `activityCacheService.ts` — Activity feed data
- `visitBriefService.ts` — Office visit PDF generation
- `sharedDatabaseSchema.ts` — Database schema documentation for AI services (~37K chars, ~10K tokens)
- `anthropic.ts` — Claude API client (currently Sonnet 4, max_tokens: 2048)

### Frontend — Pages
- `SendEmail.tsx` — Email composition wizard (201K — largest file; being refactored to use shared EmailComposer)
- `CreateAutomation.tsx` — Automation creation wizard (being refactored to use shared EmailComposer, kill modals)
- `SmartSends.tsx` — SmartSends dashboard + automations list
- `AudienceBuilder.tsx` — AI audience builder
- `CampaignDetail.tsx` — Campaign detail with resend capability
- `MemberDetail.tsx` — Member profile with engagement, email history

### Frontend — Shared Components (New)
- `EmailComposer.tsx` — NEW shared email composition component (being created in Prompt 1 refactor)
- `emailBlocks.ts` — Shared utilities: generateEventBlockHtml, generateOfferBlockHtml, generateCtaButtonHtml

### Configuration
- `schema.ts` — Drizzle ORM schema (includes triggered_campaigns, triggered_campaign_steps, triggered_campaign_sends tables)
- `routes.ts` — All API endpoints (223K — largest backend file; PATCH triggered-campaigns updated in Prompt 2)
- `clientConfig.ts` — Client-specific configuration (to be promoted to tenant_config DB table in multi-tenant Stage 1)

---

# 23. PRODUCTION DATA REFERENCE

From Tracy's Julius analysis of Mainstreet production data:
- Total active agents: 18,275
- Producing agents: 10,895 (59.6%)
- Non-producing: 7,380 (40.4% with zero sides)
- Top 25% (4,569 agents): 87.6% of volume
- Rainmaker (40+ sides): 247 agents (1.4%)
- Builder (6–39 sides): 3,885 agents (21%)
- Foundation (0–5 sides): 14,144 agents (77%)

## The Office Suspension Discovery
For Mainstreet Advantage fees, the **office** gets suspended for non-payment (not individual agents). All agents lose MLS/SentriLock access. This creates broker-level pressure.

---

# 24. MAINSTREET BRAND AND AI CONTENT TRAINING

## Brand Positioning (Created by Membio, 2023)

"To professionals who want or have a career in real estate, Mainstreet REALTORS® is THE member-centric association that provides the practical know-how, guidance, training, protection, and industry connections you need so you can achieve your goals no matter where you work or the type of business you want to build."

"It works because Mainstreet believes in you."

**Purpose:** To champion every member's goals with integrity, intelligence, and inspiration.
**Mission:** To empower real estate professionals to thrive and find joy in their careers.
**Vision:** To help every member realize their full potential.

**Values:**
- We believe in EVERY member.
- We are obsessed with what works.
- We make it easy.
- We are change-makers.
- We do the right thing.
- We are really, really nice.

## Geography

Largest regional real estate association in Chicagoland. 18,000+ members. Headquarters at 6655 Main Street, Downers Grove, IL. Three additional campuses: Tinley Park (south suburbs), Rolling Meadows (northwest suburbs), Libertyville (Lake County). Covers all of DuPage County plus portions of Cook, Lake, Will, and surrounding counties — 200+ municipalities. Bordered by five competing associations: Chicago Association of REALTORS, REALTOR Association of Fox Valley, North Shore Barrington, Three Rivers, and Heartland.

## Voice and Tone for AI

**Default voice:** Warm, confident, practical, and focused. Write like a smart colleague who genuinely wants you to succeed — not like a committee wrote it.

**Key principles:**
- Lead with VALUE, never with price. Mainstreet is the best association, not the cheapest.
- Use "you" constantly. Make the member the hero, not the association.
- Keep emails focused on ONE clear purpose. Never kitchen-sink newsletters.
- Short paragraphs (2-3 sentences). Scannable. Respect the reader's time.

**Tone definitions:**
- "Professional" = Clear, confident, knowledgeable. Like a trusted advisor briefing you on something important.
- "Friendly" = Warm, encouraging, conversational. Like a colleague excited to share good news.
- "Urgent" = A firm, specific heads-up with a clear deadline and real consequence. Like a friend saying "Hey, this actually matters and here's why you need to act by Friday." Never emojis, ALL CAPS, or spam phrases.

## Education Context

Mainstreet offers both CE (continuing education) and non-CE professional development classes. Illinois is unusual in that the state association handles most CE, making Mainstreet's own classes a differentiator. CE classes fulfill license requirements; non-CE classes are purely voluntary, making attendance a stronger engagement signal. When promoting classes, emphasize what the member will walk out with, not whether it counts for CE credit.

## Competitive Landscape

Mainstreet's repositioning moved it from "the leading resource for our brokers and agents" (generic, could belong to any association) to "we believe in you" / "we empower YOU" (distinctly warm, personal, empowering). No competing association occupies this positioning space. The AI should write in this voice consistently.

---

*End of project summary. This document supersedes all previous project summaries.*

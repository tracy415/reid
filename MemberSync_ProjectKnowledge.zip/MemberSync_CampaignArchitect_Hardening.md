# Campaign Architect — Hardening Prompt
## Three Production Fixes

This prompt addresses three issues flagged after the Campaign Architect implementation:
1. Auto-generated audience accumulation (no cleanup)
2. Negative `delayDays` for "before event" timing not handled safely by the campaign processor
3. No rate limiting on the `/api/audiences/generate-from-criteria` endpoint

Complete all three parts. Do not modify anything outside the files listed in each part.

---

## PART 1 — Auto-Generated Audience Cleanup

### The problem
Every time the AI identifies audience criteria during a Campaign Architect conversation, it creates a new saved audience tagged with `createdIn: 'campaign_architect'`. A long back-and-forth session can produce several of these. Audiences that were never used in an activated campaign accumulate in the saved audiences list indefinitely.

### What to build

**Part 1a — Nightly cleanup job**

In `server/services/scheduledJobs.ts` (or wherever existing nightly jobs are registered), add a new job that runs once per day at 3:00 AM:

```
DELETE FROM saved_audiences
WHERE source_type = 'ai_generated'
  AND metadata->>'createdIn' = 'campaign_architect'
  AND created_at < NOW() - INTERVAL '7 days'
  AND id NOT IN (
    SELECT DISTINCT audience_id 
    FROM campaign_architect_sessions 
    WHERE audience_id IS NOT NULL
      AND status = 'activated'
  )
```

This deletes auto-generated Campaign Architect audiences that are:
- Older than 7 days
- Never used in an activated campaign

Audiences used in an activated campaign are permanently preserved regardless of age.

Log the count of deleted audiences: `[SCHEDULER] Cleaned up N stale Campaign Architect audiences`

**Part 1b — Soft deduplication on creation**

In the `POST /api/audiences/generate-from-criteria` endpoint in `server/routes.ts`, before creating a new audience, check if an identical criteria string already produced an audience in the last 24 hours for the same session:

```typescript
// Before calling generateAudienceSQL:
const existingAudience = await db.query.savedAudiences.findFirst({
  where: and(
    eq(savedAudiences.sourceType, 'ai_generated'),
    sql`metadata->>'createdIn' = 'campaign_architect'`,
    sql`metadata->>'criteria' = ${criteria}`,
    gt(savedAudiences.createdAt, sql`NOW() - INTERVAL '24 hours'`)
  )
});

if (existingAudience) {
  // Return the existing one instead of creating a duplicate
  return res.json({
    audienceId: existingAudience.id,
    audienceName: existingAudience.name,
    memberCount: existingAudience.memberCount,
    reused: true
  });
}
```

Store the criteria text in the audience metadata so the dedup check works:
```typescript
metadata: {
  createdIn: 'campaign_architect',
  criteria: criteria  // add this field
}
```

**Part 1c — Label auto-generated audiences clearly in the UI**

In `CampaignArchitect.tsx`, in the audience section where saved audiences are listed (Tab 1 — Saved), audiences with `sourceType === 'ai_generated'` and `metadata.createdIn === 'campaign_architect'` should show a small grey badge: `AI Generated`. This makes them visually distinguishable from staff-built audiences without cluttering the list.

### Files to modify
- `server/services/scheduledJobs.ts` (or equivalent scheduler file)
- `server/routes.ts` — `POST /api/audiences/generate-from-criteria`
- `client/src/pages/CampaignArchitect.tsx` — audience list display

### Acceptance criteria
- [ ] Nightly cleanup job is registered and logs output
- [ ] Running the cleanup SQL manually against the database deletes only qualifying rows (verify with a test row)
- [ ] Creating the same criteria twice in 24 hours returns the existing audience, not a new one
- [ ] Auto-generated audiences show "AI Generated" badge in the Campaign Architect saved audience list
- [ ] Audiences attached to activated campaigns are NOT deleted by the cleanup job

---

## PART 2 — Anchor Date Timing: Negative delayDays Fix

### The problem
The anchor date editor stores negative `delayDays` values to represent "X days before an event" (e.g., -3 = 3 days before). The existing triggered campaign processor and Campaign Architect activation logic assume `delay_days` is zero or positive. Negative values will produce incorrect send dates or errors.

### The correct data model
Negative `delayDays` is ambiguous and fragile. Replace it with explicit fields that make the intent unambiguous:

For plan emails in `currentPlan.emails[]`, add two fields alongside the existing `delayDays`:
- `anchorOffset: number` — always a positive integer (the number of days)
- `anchorDirection: 'before' | 'after'` — which side of the event

**The rule going forward:**
- `delayDays` is ONLY used for day-offset-from-enrollment timing. It must always be zero or positive.
- When timing is anchored to an event, use `anchorEventName` + `anchorOffset` + `anchorDirection` instead. Set `delayDays` to 0 in this case (it will be ignored at send time).
- When timing is a specific date, use `anchorDate`. Set `delayDays` to 0.

### Changes required

**Part 2a — Fix the anchor date editor (CampaignArchitect.tsx)**

In the inline timing editor, when the user selects "Anchored to event" and enters an offset:
- Store the offset number in `anchorOffset` (always positive)
- Store the direction in `anchorDirection` ('before' or 'after')
- Set `delayDays` to 0
- Never write a negative number to `delayDays`

When displaying the card header for an event-anchored email, derive the label from `anchorOffset` + `anchorDirection` + `anchorEventName`:
```
"3 days before Spring CE Summit"
"1 day after Affiliate Resource Mixer"
```

**Part 2b — Fix the PATCH route for timing updates (routes.ts)**

The `PATCH /api/campaign-architect/sessions/:sessionId/plan-emails/:stepNumber/timing` route currently accepts `delayDays` as a negative number for "before" timing. Change the accepted shape:

```typescript
// OLD (fragile):
{ delayDays?: number, anchorDate?: string, anchorEventName?: string }

// NEW (explicit):
{ 
  timingType: 'offset' | 'event' | 'date',
  delayDays?: number,           // only used when timingType === 'offset', must be >= 0
  anchorDate?: string | null,   // only used when timingType === 'date'
  anchorEventName?: string | null,  // only used when timingType === 'event'
  anchorOffset?: number,        // only used when timingType === 'event', must be >= 0
  anchorDirection?: 'before' | 'after'  // only used when timingType === 'event'
}
```

Add server-side validation:
```typescript
if (body.timingType === 'offset' && body.delayDays < 0) {
  return res.status(400).json({ error: 'delayDays must be 0 or positive for offset timing' });
}
if (body.timingType === 'event' && (body.anchorOffset === undefined || body.anchorOffset < 0)) {
  return res.status(400).json({ error: 'anchorOffset must be a positive number for event-anchored timing' });
}
```

**Part 2c — Fix the campaign activation logic (routes.ts)**

In the Campaign Architect activation route, where plan emails are converted to `triggered_campaign_steps` (or equivalent sequence steps), update the send date calculation:

```typescript
function computeSendDate(planEmail: PlanEmail, anchorEventDate?: Date): Date {
  const now = new Date();
  
  if (planEmail.anchorDate) {
    // Specific date — use directly
    return new Date(planEmail.anchorDate);
  }
  
  if (planEmail.anchorEventName && planEmail.anchorOffset !== undefined && anchorEventDate) {
    // Event-anchored timing — never use delayDays here
    const offsetMs = planEmail.anchorOffset * 24 * 60 * 60 * 1000;
    if (planEmail.anchorDirection === 'before') {
      return new Date(anchorEventDate.getTime() - offsetMs);
    } else {
      return new Date(anchorEventDate.getTime() + offsetMs);
    }
  }
  
  // Default: day offset from enrollment/activation
  const offsetDays = Math.max(0, planEmail.delayDays || 0); // safety: never negative
  return new Date(now.getTime() + offsetDays * 24 * 60 * 60 * 1000);
}
```

The `Math.max(0, ...)` guard on the final line is a safety net — if a negative `delayDays` somehow reaches this point, it sends immediately rather than producing an invalid date.

**Part 2d — Fix the AI planner to output correct fields**

In `server/services/aiCampaignPlannerService.ts`, update the system prompt instructions for the JSON output format to specify:

```
For event-anchored timing, output:
  "anchorEventName": "event name here",
  "anchorOffset": 3,        (positive integer, number of days)
  "anchorDirection": "before",  ("before" or "after")
  "delayDays": 0            (always 0 for event-anchored emails)

Never output a negative delayDays. Use anchorOffset + anchorDirection instead.
```

Update `parsePlannerResponse` in the same file to read `anchorOffset` and `anchorDirection` from the plan JSON and include them in the returned PlannerTurn.

### Files to modify
- `client/src/pages/CampaignArchitect.tsx` — anchor date editor, card header display
- `server/routes.ts` — PATCH timing route, activation route
- `server/services/aiCampaignPlannerService.ts` — system prompt, parsePlannerResponse

### Acceptance criteria
- [ ] The inline anchor date editor never writes a negative value to `delayDays`
- [ ] Event-anchored cards display as "3 days before [Event Name]" not "Day -3"
- [ ] The PATCH timing route returns 400 if `delayDays` is negative
- [ ] The PATCH timing route returns 400 if `anchorOffset` is negative
- [ ] Activation logic computes correct send date for "3 days before Spring CE Summit" (test manually: if event is March 20, send date should be March 17)
- [ ] Activation logic computes correct send date for "1 day after Affiliate Resource Mixer"
- [ ] Day-offset emails (e.g., Day 0, Day 7) still activate correctly and are unaffected by this change
- [ ] AI planner output no longer contains negative delayDays in plan JSON

---

## PART 3 — Rate Limiting on generate-from-criteria Endpoint

### The problem
`POST /api/audiences/generate-from-criteria` calls the AI audience SQL generator, which hits Claude. There is currently no rate limiting on this endpoint. A user clicking rapidly (or a bug causing repeated calls) could generate many expensive AI calls in quick succession.

### What to build

Add a simple in-memory rate limit using the existing session-based pattern already used elsewhere in the app.

**In `server/routes.ts`, on the `POST /api/audiences/generate-from-criteria` handler:**

```typescript
// At the top of routes.ts, with other in-memory rate limit maps:
const audienceGenerationRateLimit = new Map<string, { count: number; windowStart: number }>();

// Inside the handler:
const sessionId = req.body.sessionId || req.session?.userId || 'anonymous';
const now = Date.now();
const windowMs = 60 * 1000; // 1 minute window
const maxPerWindow = 5;      // max 5 AI audience generations per minute per session

const current = audienceGenerationRateLimit.get(sessionId);
if (current && (now - current.windowStart) < windowMs) {
  if (current.count >= maxPerWindow) {
    return res.status(429).json({ 
      error: 'Too many audience generation requests. Please wait a moment before trying again.',
      retryAfterMs: windowMs - (now - current.windowStart)
    });
  }
  current.count++;
} else {
  audienceGenerationRateLimit.set(sessionId, { count: 1, windowStart: now });
}
```

**Why 5 per minute:**
- A typical Campaign Architect session involves 3–5 back-and-forth turns
- Each turn might produce 0 or 1 audience criteria
- 5 per minute allows for rapid iteration without runaway costs
- The 24-hour deduplication from Part 1b further reduces actual AI calls

**Clean up stale rate limit entries** to prevent memory leak. Add to the existing rate limit cleanup interval (or create one if none exists):

```typescript
// Clean up entries older than the window every 5 minutes
setInterval(() => {
  const cutoff = Date.now() - windowMs;
  for (const [key, value] of audienceGenerationRateLimit.entries()) {
    if (value.windowStart < cutoff) {
      audienceGenerationRateLimit.delete(key);
    }
  }
}, 5 * 60 * 1000);
```

**Frontend: Handle the 429 gracefully in CampaignArchitect.tsx**

When the `generate-from-criteria` call returns a 429, show the existing yellow inline message in the audience section (already built):

```
"Couldn't build this audience automatically — select one above or 
build it in the Member/Bill Type or Picklist tabs."
```

Do not show a technical error. Do not surface the word "rate limit" to staff. The yellow inline message is the correct degradation — it tells them what to do next.

### Files to modify
- `server/routes.ts` — `POST /api/audiences/generate-from-criteria` handler

### Acceptance criteria
- [ ] Making 6 rapid calls to `generate-from-criteria` within one minute returns a 429 on the 6th call
- [ ] After 1 minute, the rate limit resets and calls succeed again
- [ ] The Map is cleaned up on the server-side interval — no memory leak
- [ ] A 429 response in the frontend shows the yellow inline message, not a generic error

---

## VERIFICATION CHECKLIST

Run these in order after completing all three parts:

1. **Part 1 — Audience cleanup:**
   - [ ] Manually insert a test `saved_audience` row with `source_type = 'ai_generated'`, `metadata->>'createdIn' = 'campaign_architect'`, `created_at = NOW() - INTERVAL '8 days'`. Run the cleanup job manually. Confirm the row is deleted.
   - [ ] Insert a second row with same attributes but linked to an activated session. Confirm it is NOT deleted.
   - [ ] Trigger a Campaign Architect conversation that produces an audience. Trigger the same criteria again. Confirm only one audience is created (dedup works).
   - [ ] Confirm auto-generated audiences show "AI Generated" badge in the audience list.

2. **Part 2 — Anchor timing:**
   - [ ] Open the anchor date editor on any email card. Set "3 days before [event]". Confirm card shows "3 days before [Event Name]".
   - [ ] Check the database — confirm `delay_days = 0`, `anchor_offset = 3`, `anchor_direction = 'before'`.
   - [ ] Activate a test campaign with one event-anchored email. Confirm the computed send date is event date minus 3 days.
   - [ ] Confirm day-offset emails (Day 0, Day 7) still activate correctly.
   - [ ] Send a negative `delayDays` to the PATCH route directly (e.g. via curl). Confirm 400 response.

3. **Part 3 — Rate limiting:**
   - [ ] Make 6 rapid requests to `POST /api/audiences/generate-from-criteria`. Confirm the 6th returns 429.
   - [ ] Confirm the frontend shows the yellow inline message, not a technical error.
   - [ ] Wait 60 seconds. Confirm requests succeed again.

4. **No regressions:**
   - [ ] Campaign Architect planning, generation, and activation still work end-to-end
   - [ ] Existing saved audiences (non-AI-generated) are unaffected by the cleanup job
   - [ ] SmartSends audience builder (standalone pages) unaffected
   - [ ] Triggered campaigns processor unaffected

---

## DO NOT CHANGE

- The EmailComposer component
- The triggeredCampaignProcessor (other than ensuring it never receives negative delayDays)
- The standalone MemberBillTypeBuilder and PicklistBuilder pages
- Any SmartSends functionality outside Campaign Architect
- The existing audience builder API endpoints (other than generate-from-criteria)

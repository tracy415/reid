# MemberSync Dashboard Redesign â€” Replit Prompt

## Context

The current dashboard (see screenshot) has four metric cards â€” Total Active Members, Engaged This Quarter, At-Risk Members, and Compliance Alerts â€” followed by an Office Performance section. The AI chat box sits at the top and the Celebrations sidebar is on the right.

The problems with the current layout:

1. **Compliance Alerts shows 32,177** â€” nearly every member appears as a "compliance alert" because the COE cycle just started and almost nobody has completed it yet. This number is technically correct but operationally meaningless and scares the user.
2. **At-Risk Members shows 5,938** â€” but after the engagement score redesign, these numbers will shift significantly. The card needs to use the new engagement labels (Disconnected, Drifting, Connected, Highly Connected).
3. **Office Performance dominates the bottom half** â€” this belongs in Analytics, not the morning briefing.
4. **No Today's Activity feed** â€” the executive has no sense of "what happened today."
5. **No 75% Report** â€” the most strategically important insight (are our Foundation members connected?) isn't visible.
6. **The old tier names** (Active Producers, Occasional, License Mnt) need to become Rainmaker, Builder, Foundation.

This prompt reorganizes the dashboard into three sections as specified in the product philosophy document. The Celebrations sidebar and AI Chat box stay exactly where they are â€” they're the best parts of the current design.

**IMPORTANT**: This prompt depends on the engagement score redesign being completed first. The new scoring formula, tier names, and engagement labels must be in place before this dashboard goes live. If the scoring redesign hasn't been deployed yet, hold this prompt.

---

## Section 1: The Pulse (Top â€” Four Metric Cards)

### Replace the four current cards with these four:

**Card 1: Total Active Members** (keep, update labels)

This card stays but gets the new tier names and colors.

```tsx
<MetricCard
  title="Total Active Members"
  value={metrics.totalActiveMembers.total}
  icon={Users}
  testId="card-total-members"
  breakdown={[
    {
      label: "Rainmaker",
      value: metrics.totalActiveMembers.activeProducers,
      variant: "amber",
    },
    {
      label: "Builder",
      value: metrics.totalActiveMembers.occasionalProducers,
      variant: "blue",
    },
    {
      label: "Foundation",
      value: metrics.totalActiveMembers.licenseMaintainers,
      variant: "emerald",
    },
  ]}
  onClick={() => setLocation("/members")}
/>
```

The `MetricCard` component's `breakdownColors` map in `MetricCard.tsx` needs a new `emerald` variant:

```typescript
const breakdownColors = {
  primary: "bg-primary dark:bg-primary",
  blue: "bg-blue-500 dark:bg-blue-400",
  slate: "bg-slate-500 dark:bg-slate-400",
  red: "bg-red-600 dark:bg-red-500",
  amber: "bg-amber-500 dark:bg-amber-400",
  emerald: "bg-emerald-500 dark:bg-emerald-400",   // NEW
  orange: "bg-orange-500 dark:bg-orange-400",       // NEW
};
```

Also update the `BreakdownItem` type to include the new variants:
```typescript
variant?: "primary" | "blue" | "slate" | "red" | "amber" | "emerald" | "orange";
```

**Card 2: Member Engagement Rate** (replace "Engaged This Quarter")

The old card showed an absolute count (15,461) which was just "members with score >= 5." The new card shows a percentage-first view focused on meaningful activity in the last 90 days, broken down by engagement level.

This requires a new backend calculation. See the API changes section below.

```tsx
<MetricCard
  title="Member Engagement Rate"
  value={`${metrics.engagementRate.percentage}%`}
  subtitle={`${metrics.engagementRate.activeCount.toLocaleString()} members with activity in last 90 days`}
  icon={TrendingUp}
  variant={metrics.engagementRate.percentage >= 50 ? "success" : metrics.engagementRate.percentage >= 30 ? "default" : "warning"}
  testId="card-engagement-rate"
  breakdown={[
    {
      label: "Education",
      value: metrics.engagementRate.withEducation,
    },
    {
      label: "Events",
      value: metrics.engagementRate.withEvents,
    },
    {
      label: "Transactions",
      value: metrics.engagementRate.withTransactions,
    },
  ]}
/>
```

**Card 3: Connection Status** (replace "At-Risk Members")

This is the most important card. Instead of counting "at-risk" members with scary red numbers, it shows the engagement level distribution using the new labels. The Disconnected and Drifting counts use urgent colors.

```tsx
<MetricCard
  title="Connection Status"
  value={metrics.connectionStatus.connectedPercentage + "%"}
  subtitle="Highly Connected + Connected"
  icon={Activity}
  variant="default"
  testId="card-connection-status"
  breakdown={[
    {
      label: "Highly Connected",
      value: metrics.connectionStatus.highlyConnected,
      variant: "emerald",
    },
    {
      label: "Connected",
      value: metrics.connectionStatus.connected,
      variant: "blue",
    },
    {
      label: "Drifting",
      value: metrics.connectionStatus.drifting,
      variant: "orange",
      onClick: () => setLocation("/smartsends/send?audience=risk-high"),
      testId: "link-drifting-audience",
    },
    {
      label: "Disconnected",
      value: metrics.connectionStatus.disconnected,
      variant: "red",
      onClick: () => setLocation("/smartsends/send?audience=risk-critical"),
      testId: "link-disconnected-audience",
    },
  ]}
  onClick={() => setLocation("/members?filter=at-risk")}
/>
```

Add `Activity` to the lucide-react imports at the top of Dashboard.tsx.

**Card 4: Campaign Effectiveness** (replace "Compliance Alerts")

Move compliance to the Compliance page where it belongs. Replace with campaign performance metrics that show whether the association's outreach is working.

This requires a new backend calculation. See the API changes section below.

```tsx
<MetricCard
  title="Campaign Effectiveness"
  value={metrics.campaignEffectiveness.avgOpenRate > 0 
    ? `${metrics.campaignEffectiveness.avgOpenRate}% open rate` 
    : "No campaigns yet"}
  subtitle={metrics.campaignEffectiveness.campaignCount > 0 
    ? `${metrics.campaignEffectiveness.campaignCount} campaigns in last 30 days`
    : "Send your first campaign â†’"}
  icon={Mail}
  variant={metrics.campaignEffectiveness.avgOpenRate >= 30 ? "success" : "default"}
  testId="card-campaign-effectiveness"
  breakdown={metrics.campaignEffectiveness.campaignCount > 0 ? [
    {
      label: "Click rate",
      value: metrics.campaignEffectiveness.avgClickRate,
    },
    {
      label: "Members reached",
      value: metrics.campaignEffectiveness.totalReached,
    },
  ] : []}
  onClick={() => setLocation("/smartsends")}
/>
```

---

## Section 2: Today's Activity Feed (Middle â€” New)

Below the metric cards (and beside the Celebrations sidebar), add an activity feed. This is a new component that shows recent platform activity in a news-feed style.

### New Component: `client/src/components/dashboard/ActivityFeed.tsx`

```tsx
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  UserPlus,
  GraduationCap,
  CalendarCheck,
  Mail,
  TrendingUp,
  ArrowRight,
} from "lucide-react";

interface ActivityItem {
  id: string;
  type: "new_members" | "education" | "events" | "campaign" | "milestone";
  icon: string;
  title: string;
  detail: string;
  count?: number;
  actionLabel?: string;
  actionUrl?: string;
  timestamp: string;
}

const iconMap: Record<string, React.ElementType> = {
  user_plus: UserPlus,
  graduation_cap: GraduationCap,
  calendar_check: CalendarCheck,
  mail: Mail,
  trending_up: TrendingUp,
};

const iconColorMap: Record<string, string> = {
  new_members: "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950",
  education: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950",
  events: "text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950",
  campaign: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
  milestone: "text-pink-600 dark:text-pink-400 bg-pink-50 dark:bg-pink-950",
};

export function ActivityFeed() {
  const [, setLocation] = useLocation();

  const { data, isLoading } = useQuery<{ activities: ActivityItem[] }>({
    queryKey: ["/api/dashboard/activity-feed"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-32" />
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  const activities = data?.activities || [];

  return (
    <Card data-testid="card-activity-feed">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold">Today's Activity</CardTitle>
      </CardHeader>
      <CardContent className="space-y-1">
        {activities.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">
            No recent activity to show
          </p>
        ) : (
          activities.map((item) => {
            const IconComponent = iconMap[item.icon] || TrendingUp;
            const colorClass = iconColorMap[item.type] || iconColorMap.milestone;

            return (
              <div
                key={item.id}
                className="flex items-start gap-3 py-2 group"
              >
                <div className={`p-1.5 rounded-md shrink-0 ${colorClass}`}>
                  <IconComponent className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium leading-snug">{item.title}</p>
                  <p className="text-xs text-muted-foreground">{item.detail}</p>
                </div>
                {item.actionUrl && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity h-7 text-xs"
                    onClick={() => setLocation(item.actionUrl!)}
                  >
                    {item.actionLabel || "View"}
                    <ArrowRight className="ml-1 h-3 w-3" />
                  </Button>
                )}
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
```

---

## Section 3: The Membership Story (Bottom â€” New)

This replaces the Office Performance section (which stays in Analytics). It shows all three tiers of membership â€” giving each one its own story. Board members (who are Rainmakers and Builders) see their contributions celebrated. The executive sees the Foundation retention story. Everyone feels represented.

### New Component: `client/src/components/dashboard/MembershipStory.tsx`

```tsx
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, GraduationCap, CalendarCheck, Mail, CreditCard, DollarSign, TrendingUp, Zap } from "lucide-react";

interface MembershipStoryData {
  composition: {
    rainmaker: { count: number; percentage: number };
    builder: { count: number; percentage: number };
    foundation: { count: number; percentage: number };
  };
  rainmakerInsights: {
    totalVolume: number;
    avgTransactions: number;
    connectedPercentage: number;
    avgScore: number;
    top5PctCount: number;       // number of agents in top 5% of all members
    top5PctLabel: number;       // the percentage label (5)
    top5PctVolShare: number;    // % of total volume controlled by top 5%
  };
  builderInsights: {
    withEducationOrEvents: number;
    withEducationOrEventsPercentage: number;
    connectedPercentage: number;
    avgScore: number;
  };
  foundationInsights: {
    avgScore: number;
    connectedPercentage: number;
    withEducation: number;
    withEvents: number;
    withEmailEngagement: number;
    paidOnTime: number;
    paidOnTimePercentage: number;
  };
}

function formatCurrency(value: number): string {
  if (value >= 1_000_000_000) return `$${(value / 1_000_000_000).toFixed(1)}B`;
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(0)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(0)}K`;
  return `$${value}`;
}

export function MembershipStory() {
  const { data, isLoading } = useQuery<MembershipStoryData>({
    queryKey: ["/api/dashboard/membership-story"],
  });

  if (isLoading) {
    return (
      <Card className="lg:col-span-2">
        <CardHeader><Skeleton className="h-5 w-48" /></CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-40 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!data) return null;

  const { composition, rainmakerInsights, builderInsights, foundationInsights } = data;

  return (
    <Card className="lg:col-span-2" data-testid="card-membership-story">
      <CardHeader>
        <CardTitle className="text-base font-semibold">
          The Membership Story
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Three tiers, one community. How connected is each part of your membership?
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Composition Bar */}
        <div className="flex h-8 rounded-lg overflow-hidden">
          <div
            className="bg-amber-500 dark:bg-amber-600 flex items-center justify-center text-white text-xs font-medium"
            style={{ width: `${composition.rainmaker.percentage}%` }}
          >
            {composition.rainmaker.percentage >= 8 && `${composition.rainmaker.percentage}%`}
          </div>
          <div
            className="bg-blue-500 dark:bg-blue-600 flex items-center justify-center text-white text-xs font-medium"
            style={{ width: `${composition.builder.percentage}%` }}
          >
            {composition.builder.percentage >= 8 && `${composition.builder.percentage}%`}
          </div>
          <div
            className="bg-emerald-500 dark:bg-emerald-600 flex items-center justify-center text-white text-xs font-medium"
            style={{ width: `${composition.foundation.percentage}%` }}
          >
            {composition.foundation.percentage >= 8 && `${composition.foundation.percentage}%`}
          </div>
        </div>

        {/* Three Tier Spotlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Rainmaker Spotlight */}
          <div className="border rounded-lg p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-amber-500" />
              <span className="text-sm font-semibold">Rainmaker</span>
              <span className="text-xs text-muted-foreground ml-auto">{composition.rainmaker.count.toLocaleString()} members</span>
            </div>
            <div>
              <p className="text-2xl font-bold">{formatCurrency(rainmakerInsights.totalVolume)}</p>
              <p className="text-xs text-muted-foreground">production volume (12 months)</p>
            </div>
            {rainmakerInsights.top5PctVolShare > 0 && (
              <div className="bg-amber-50 dark:bg-amber-950/30 rounded-md p-2">
                <p className="text-xs font-medium text-amber-800 dark:text-amber-200">
                  Top {rainmakerInsights.top5PctCount.toLocaleString()} agents ({rainmakerInsights.top5PctLabel}%) control {rainmakerInsights.top5PctVolShare}% of volume
                </p>
              </div>
            )}
            <div className="grid grid-cols-2 gap-2 text-center">
              <div>
                <p className="text-lg font-semibold">{rainmakerInsights.avgTransactions.toFixed(1)}</p>
                <p className="text-xs text-muted-foreground">avg transactions</p>
              </div>
              <div>
                <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">{rainmakerInsights.connectedPercentage}%</p>
                <p className="text-xs text-muted-foreground">connected</p>
              </div>
            </div>
          </div>

          {/* Builder Spotlight */}
          <div className="border rounded-lg p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-500" />
              <span className="text-sm font-semibold">Builder</span>
              <span className="text-xs text-muted-foreground ml-auto">{composition.builder.count.toLocaleString()} members</span>
            </div>
            <div>
              <p className="text-2xl font-bold">{builderInsights.withEducationOrEventsPercentage}%</p>
              <p className="text-xs text-muted-foreground">engaged in education or events (90 days)</p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-center">
              <div>
                <p className="text-lg font-semibold">{builderInsights.avgScore.toFixed(1)}</p>
                <p className="text-xs text-muted-foreground">avg score</p>
              </div>
              <div>
                <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">{builderInsights.connectedPercentage}%</p>
                <p className="text-xs text-muted-foreground">connected</p>
              </div>
            </div>
          </div>

          {/* Foundation Spotlight */}
          <div className="border rounded-lg p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500" />
              <span className="text-sm font-semibold">Foundation</span>
              <span className="text-xs text-muted-foreground ml-auto">{composition.foundation.count.toLocaleString()} members</span>
            </div>
            <div>
              <p className="text-2xl font-bold">{foundationInsights.connectedPercentage}%</p>
              <p className="text-xs text-muted-foreground">connected to your organization</p>
            </div>
            <div className="grid grid-cols-4 gap-1 text-center">
              <SignalMini icon={GraduationCap} value={foundationInsights.withEducation} total={composition.foundation.count} color="text-blue-500" />
              <SignalMini icon={CalendarCheck} value={foundationInsights.withEvents} total={composition.foundation.count} color="text-purple-500" />
              <SignalMini icon={Mail} value={foundationInsights.withEmailEngagement} total={composition.foundation.count} color="text-amber-500" />
              <SignalMini icon={CreditCard} value={foundationInsights.paidOnTime} total={composition.foundation.count} color="text-emerald-500" />
            </div>
            <div className="flex justify-between text-[10px] text-muted-foreground px-1">
              <span>Edu</span>
              <span>Events</span>
              <span>Email</span>
              <span>Paid</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SignalMini({
  icon: Icon,
  value,
  total,
  color,
}: {
  icon: React.ElementType;
  value: number;
  total: number;
  color: string;
}) {
  const pct = total > 0 ? Math.round((value / total) * 100) : 0;
  return (
    <div className="space-y-0.5">
      <Icon className={`h-3.5 w-3.5 mx-auto ${color}`} />
      <p className="text-sm font-semibold">{pct}%</p>
    </div>
  );
}
```

---

## Updated Dashboard.tsx Layout

Replace the entire `Dashboard.tsx` component body. The key structural changes:

1. AI Chat + Celebrations stay in the top row (unchanged positions)
2. The four Pulse cards go below AI Chat (same grid, new card content)
3. Today's Activity goes below the Pulse cards, still in the left column
4. The 75% Report goes full-width at the bottom, replacing Office Performance

```tsx
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { MetricCard, MetricCardSkeleton } from "@/components/shared/MetricCard";
import { AIChatBox } from "@/components/ai/AIChatBox";
import { CelebrationInsights } from "@/components/dashboard/CelebrationInsights";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { MembershipStory } from "@/components/dashboard/MembershipStory";
import { useAuth } from "@/lib/auth";
import {
  Users,
  TrendingUp,
  Activity,
  Mail,
} from "lucide-react";
import type { DashboardMetrics } from "@shared/schema";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();

  const { data: metrics, isLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
    enabled: isAuthenticated,
  });

  return (
    <AppLayout>
      <div className="p-4 lg:p-6 space-y-6" data-testid="page-dashboard">
        {/* Row 1: AI Chat + Celebrations */}
        <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-4 lg:items-start">
          <div className="space-y-4">
            {/* AI Chat */}
            <AIChatBox />

            {/* Section 1: The Pulse â€” Four Metric Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-testid="grid-metric-cards">
              {isLoading ? (
                <>
                  <MetricCardSkeleton />
                  <MetricCardSkeleton />
                  <MetricCardSkeleton />
                  <MetricCardSkeleton />
                </>
              ) : metrics ? (
                <>
                  {/* Card 1: Total Active Members */}
                  <MetricCard
                    title="Total Active Members"
                    value={metrics.totalActiveMembers.total}
                    icon={Users}
                    testId="card-total-members"
                    breakdown={[
                      { label: "Rainmaker", value: metrics.totalActiveMembers.activeProducers, variant: "amber" },
                      { label: "Builder", value: metrics.totalActiveMembers.occasionalProducers, variant: "blue" },
                      { label: "Foundation", value: metrics.totalActiveMembers.licenseMaintainers, variant: "emerald" },
                    ]}
                    onClick={() => setLocation("/members")}
                  />

                  {/* Card 2: Member Engagement Rate */}
                  <MetricCard
                    title="Member Engagement Rate"
                    value={`${metrics.engagementRate.percentage}%`}
                    subtitle={`${metrics.engagementRate.activeCount.toLocaleString()} members with activity in last 90 days`}
                    icon={TrendingUp}
                    variant={metrics.engagementRate.percentage >= 50 ? "success" : metrics.engagementRate.percentage >= 30 ? "default" : "warning"}
                    testId="card-engagement-rate"
                    breakdown={[
                      { label: "Education", value: metrics.engagementRate.withEducation },
                      { label: "Events", value: metrics.engagementRate.withEvents },
                      { label: "Transactions", value: metrics.engagementRate.withTransactions },
                    ]}
                  />

                  {/* Card 3: Connection Status */}
                  <MetricCard
                    title="Connection Status"
                    value={metrics.connectionStatus.connectedPercentage + "%"}
                    subtitle="Highly Connected + Connected"
                    icon={Activity}
                    variant="default"
                    testId="card-connection-status"
                    breakdown={[
                      { label: "Highly Connected", value: metrics.connectionStatus.highlyConnected, variant: "emerald" },
                      { label: "Connected", value: metrics.connectionStatus.connected, variant: "blue" },
                      { label: "Drifting", value: metrics.connectionStatus.drifting, variant: "orange",
                        onClick: () => setLocation("/smartsends/send?audience=risk-high"), testId: "link-drifting-audience" },
                      { label: "Disconnected", value: metrics.connectionStatus.disconnected, variant: "red",
                        onClick: () => setLocation("/smartsends/send?audience=risk-critical"), testId: "link-disconnected-audience" },
                    ]}
                    onClick={() => setLocation("/members?filter=at-risk")}
                  />

                  {/* Card 4: Campaign Effectiveness */}
                  <MetricCard
                    title="Campaign Effectiveness"
                    value={metrics.campaignEffectiveness.avgOpenRate > 0
                      ? `${metrics.campaignEffectiveness.avgOpenRate}% open rate`
                      : "No campaigns yet"}
                    subtitle={metrics.campaignEffectiveness.campaignCount > 0
                      ? `${metrics.campaignEffectiveness.campaignCount} campaigns in last 30 days`
                      : "Send your first campaign â†’"}
                    icon={Mail}
                    variant={metrics.campaignEffectiveness.avgOpenRate >= 30 ? "success" : "default"}
                    testId="card-campaign-effectiveness"
                    breakdown={metrics.campaignEffectiveness.campaignCount > 0 ? [
                      { label: "Click rate", value: metrics.campaignEffectiveness.avgClickRate },
                      { label: "Members reached", value: metrics.campaignEffectiveness.totalReached },
                    ] : []}
                    onClick={() => setLocation("/smartsends")}
                  />
                </>
              ) : null}
            </div>

            {/* Section 2: Today's Activity */}
            <ActivityFeed />
          </div>

          {/* Celebrations sidebar â€” stays exactly where it is */}
          <CelebrationInsights />
        </div>

        {/* Section 3: The Membership Story â€” Full Width */}
        <MembershipStory />
      </div>
    </AppLayout>
  );
}
```

**Note**: The `OfficePerformanceCard` component and `OfficeListRow` component that are currently defined at the bottom of `Dashboard.tsx` should be removed since Office Performance is moving to Analytics. Don't delete the `OfficeDetail.tsx` page or any office-related routes â€” just remove the office card from the dashboard.

---

## Backend API Changes

### Update `DashboardMetrics` Type in `shared/schema.ts`

Replace the current `DashboardMetrics` interface with:

```typescript
export interface DashboardMetrics {
  totalActiveMembers: {
    total: number;
    activeProducers: number;     // Rainmaker
    occasionalProducers: number; // Builder
    licenseMaintainers: number;  // Foundation
  };
  engagementRate: {
    percentage: number;          // % of members with activity in last 90 days
    activeCount: number;         // members with activity in last 90 days
    withTransactions: number;
    withEducation: number;
    withEvents: number;
  };
  connectionStatus: {
    connectedPercentage: number; // % Highly Connected + Connected
    highlyConnected: number;     // risk_level = 'low' (score 8-10)
    connected: number;           // risk_level = 'medium' (score 5-7)
    drifting: number;            // risk_level = 'high' (score 3-4)
    disconnected: number;        // risk_level = 'critical' (score 0-2)
  };
  campaignEffectiveness: {
    avgOpenRate: number;         // average open rate across campaigns in last 30 days
    avgClickRate: number;        // average click rate
    campaignCount: number;       // number of campaigns sent in last 30 days
    totalReached: number;        // total unique members emailed in last 30 days
  };
}
```

Remove the old `atRiskMembers`, `complianceAlerts`, and `officePerformance` properties. If any other page references these (check the `OfficePerformanceCard`), that reference should be removed too since we're removing it from the dashboard.

**Keep the existing `ComplianceDashboard` interface** â€” it's used by the Compliance page, not the dashboard.

### Update `getDashboardMetrics()` in `server/storage.ts`

Replace the `getDashboardMetrics` function. The new version:

1. Keeps the member tier counts (same query)
2. Replaces "engaged this quarter" with proper 90-day activity rate
3. Replaces "at risk" counts with connection status counts using new engagement labels
4. Adds campaign effectiveness from `email_campaigns` and `email_events`
5. Removes compliance calculations (they stay on the Compliance page)
6. Removes office performance (it stays in Analytics)

```typescript
async getDashboardMetrics(): Promise<DashboardMetrics> {
  const startTime = Date.now();
  
  // Core metrics from member_metrics_cache
  const metricsResult = await db.execute(sql`
    SELECT 
      COUNT(*) as total_members,
      SUM(CASE WHEN tier = 'active_producer' THEN 1 ELSE 0 END) as active_producers,
      SUM(CASE WHEN tier = 'occasional_producer' THEN 1 ELSE 0 END) as occasional_producers,
      SUM(CASE WHEN tier = 'license_maintainer' THEN 1 ELSE 0 END) as license_maintainers,
      SUM(CASE WHEN risk_level = 'low' THEN 1 ELSE 0 END) as highly_connected,
      SUM(CASE WHEN risk_level = 'medium' THEN 1 ELSE 0 END) as connected,
      SUM(CASE WHEN risk_level = 'high' THEN 1 ELSE 0 END) as drifting,
      SUM(CASE WHEN risk_level = 'critical' THEN 1 ELSE 0 END) as disconnected,
      SUM(CASE WHEN transactions_12mo > 0 THEN 1 ELSE 0 END) as with_transactions
    FROM member_metrics_cache
    WHERE member_status = 'Active'
  `);
  
  const stats = metricsResult.rows[0] as Record<string, string>;
  const totalMembers = parseInt(stats.total_members) || 0;
  const highlyConnected = parseInt(stats.highly_connected) || 0;
  const connected = parseInt(stats.connected) || 0;
  const drifting = parseInt(stats.drifting) || 0;
  const disconnected = parseInt(stats.disconnected) || 0;
  const withTransactions = parseInt(stats.with_transactions) || 0;
  
  // 90-day activity counts from activity_cache
  const activityResult = await db.execute(sql`
    SELECT 
      COUNT(DISTINCT CASE 
        WHEN is_completed = true 
          AND completion_date >= NOW() - INTERVAL '90 days' 
          AND course_type IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses', 'Post Lic 45-Hour Courses', 'Post Lisc Indiv. 15-HR Courses', 'Sexual Harassment Prevention')
        THEN member_key 
      END) as with_education,
      COUNT(DISTINCT CASE 
        WHEN is_attended = true
          AND start_datetime >= NOW() - INTERVAL '90 days'
          AND (course_type IS NULL OR course_type NOT IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses', 'Post Lic 45-Hour Courses', 'Post Lisc Indiv. 15-HR Courses', 'Sexual Harassment Prevention'))
        THEN member_key 
      END) as with_events,
      COUNT(DISTINCT CASE 
        WHEN (is_completed = true OR is_attended = true)
          AND COALESCE(completion_date, start_datetime) >= NOW() - INTERVAL '90 days'
        THEN member_key
      END) as with_any_activity
    FROM activity_cache
  `);
  
  const activityStats = activityResult.rows[0] as Record<string, string>;
  const withEducation = parseInt(activityStats?.with_education) || 0;
  const withEvents = parseInt(activityStats?.with_events) || 0;
  const withAnyActivity = parseInt(activityStats?.with_any_activity) || 0;
  
  // Combine: members with transactions OR education/events in last 90 days
  // (withTransactions is already from cache, not limited to 90 days, so we use a broader count)
  const activeCount = withAnyActivity + withTransactions; // rough â€” some overlap, but directionally correct
  // For a more precise count, we could UNION member keys, but this is fast and close enough for the dashboard
  const engagementPercentage = totalMembers > 0 ? Math.round((activeCount / totalMembers) * 100) : 0;
  // Cap at 100% since we're roughly combining overlapping sets
  const cappedPercentage = Math.min(engagementPercentage, 100);
  
  // Campaign effectiveness from email_campaigns + email_events (last 30 days)
  let avgOpenRate = 0;
  let avgClickRate = 0;
  let campaignCount = 0;
  let totalReached = 0;
  
  try {
    const campaignResult = await db.execute(sql`
      SELECT 
        COUNT(DISTINCT c.campaign_id) as campaign_count,
        SUM(c.recipient_count) as total_reached
      FROM email_campaigns c
      WHERE c.sent_at >= NOW() - INTERVAL '30 days'
    `);
    
    const campaignStats = campaignResult.rows[0] as Record<string, string>;
    campaignCount = parseInt(campaignStats?.campaign_count) || 0;
    totalReached = parseInt(campaignStats?.total_reached) || 0;
    
    if (campaignCount > 0) {
      // Calculate open and click rates from email_events
      const eventResult = await db.execute(sql`
        SELECT
          COUNT(DISTINCT CASE WHEN ee.event_type = 'delivered' THEN ee.recipient_id END) as delivered,
          COUNT(DISTINCT CASE WHEN ee.event_type = 'opened' THEN ee.recipient_id END) as opened,
          COUNT(DISTINCT CASE WHEN ee.event_type = 'clicked' THEN ee.recipient_id END) as clicked
        FROM email_events ee
        JOIN email_campaigns c ON ee.campaign_id = c.campaign_id
        WHERE c.sent_at >= NOW() - INTERVAL '30 days'
      `);
      
      const eventStats = eventResult.rows[0] as Record<string, string>;
      const delivered = parseInt(eventStats?.delivered) || 0;
      const opened = parseInt(eventStats?.opened) || 0;
      const clicked = parseInt(eventStats?.clicked) || 0;
      
      avgOpenRate = delivered > 0 ? Math.round((opened / delivered) * 100) : 0;
      avgClickRate = delivered > 0 ? Math.round((clicked / delivered) * 100) : 0;
    }
  } catch (campaignErr) {
    console.warn('[DASHBOARD] Campaign stats query failed (non-fatal):', campaignErr);
  }
  
  const connectedPercentage = totalMembers > 0
    ? Math.round(((highlyConnected + connected) / totalMembers) * 100)
    : 0;
  
  const duration = Date.now() - startTime;
  console.log(`[DASHBOARD_METRICS] Query completed in ${duration}ms`);
  
  return {
    totalActiveMembers: {
      total: totalMembers,
      activeProducers: parseInt(stats.active_producers) || 0,
      occasionalProducers: parseInt(stats.occasional_producers) || 0,
      licenseMaintainers: parseInt(stats.license_maintainers) || 0,
    },
    engagementRate: {
      percentage: cappedPercentage,
      activeCount,
      withTransactions,
      withEducation,
      withEvents,
    },
    connectionStatus: {
      connectedPercentage,
      highlyConnected,
      connected,
      drifting,
      disconnected,
    },
    campaignEffectiveness: {
      avgOpenRate,
      avgClickRate,
      campaignCount,
      totalReached,
    },
  };
}
```

### New API Endpoint: Activity Feed

Add to `server/routes.ts`:

```typescript
app.get("/api/dashboard/activity-feed", authMiddleware, async (req, res) => {
  try {
    const activities: any[] = [];
    
    // 1. New members this week (from member_metrics_cache nar_join_date)
    const newMembersResult = await db.execute(sql`
      SELECT COUNT(*) as count
      FROM member_metrics_cache
      WHERE nar_join_date >= NOW() - INTERVAL '7 days'
        AND member_status = 'Active'
    `);
    const newMemberCount = parseInt((newMembersResult.rows[0] as any)?.count) || 0;
    if (newMemberCount > 0) {
      activities.push({
        id: 'new-members-week',
        type: 'new_members',
        icon: 'user_plus',
        title: `${newMemberCount} new member${newMemberCount !== 1 ? 's' : ''} joined this week`,
        detail: 'Send a welcome message to make them feel at home',
        actionLabel: 'Welcome',
        actionUrl: '/smartsends/send',
        timestamp: new Date().toISOString(),
      });
    }
    
    // 2. Recent education completions (last 7 days)
    const eduResult = await db.execute(sql`
      SELECT COUNT(DISTINCT member_key) as count
      FROM activity_cache
      WHERE is_completed = true
        AND completion_date >= NOW() - INTERVAL '7 days'
        AND course_type IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses', 'Post Lic 45-Hour Courses', 'Post Lisc Indiv. 15-HR Courses')
    `);
    const eduCount = parseInt((eduResult.rows[0] as any)?.count) || 0;
    if (eduCount > 0) {
      activities.push({
        id: 'education-week',
        type: 'education',
        icon: 'graduation_cap',
        title: `${eduCount} member${eduCount !== 1 ? 's' : ''} completed CE courses this week`,
        detail: 'Education is a top connection signal for Foundation members',
        timestamp: new Date().toISOString(),
      });
    }
    
    // 3. Recent event attendance (last 7 days)
    const eventResult = await db.execute(sql`
      SELECT COUNT(DISTINCT member_key) as count
      FROM activity_cache
      WHERE is_attended = true
        AND start_datetime >= NOW() - INTERVAL '7 days'
        AND (course_type IS NULL OR course_type NOT IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses', 'Post Lic 45-Hour Courses', 'Post Lisc Indiv. 15-HR Courses', 'Sexual Harassment Prevention'))
    `);
    const eventCount = parseInt((eventResult.rows[0] as any)?.count) || 0;
    if (eventCount > 0) {
      activities.push({
        id: 'events-week',
        type: 'events',
        icon: 'calendar_check',
        title: `${eventCount} member${eventCount !== 1 ? 's' : ''} attended events this week`,
        detail: 'Event participation strengthens community connections',
        timestamp: new Date().toISOString(),
      });
    }
    
    // 4. Most recent campaign performance
    const campaignResult = await db.execute(sql`
      SELECT campaign_name, recipient_count, sent_at
      FROM email_campaigns
      ORDER BY sent_at DESC
      LIMIT 1
    `);
    if (campaignResult.rows.length > 0) {
      const campaign = campaignResult.rows[0] as any;
      activities.push({
        id: 'last-campaign',
        type: 'campaign',
        icon: 'mail',
        title: `"${campaign.campaign_name}" reached ${campaign.recipient_count} members`,
        detail: `Sent ${new Date(campaign.sent_at).toLocaleDateString()}`,
        actionLabel: 'View',
        actionUrl: '/smartsends',
        timestamp: campaign.sent_at,
      });
    }
    
    // 5. Milestone count from celebrations
    try {
      const milestoneResult = await db.execute(sql`
        SELECT COUNT(*) as count
        FROM member_milestones
        WHERE detected_at >= NOW() - INTERVAL '7 days'
      `);
      const milestoneCount = parseInt((milestoneResult.rows[0] as any)?.count) || 0;
      if (milestoneCount > 0) {
        activities.push({
          id: 'milestones-week',
          type: 'milestone',
          icon: 'trending_up',
          title: `${milestoneCount} member milestone${milestoneCount !== 1 ? 's' : ''} detected this week`,
          detail: 'Celebrating achievements keeps members connected',
          timestamp: new Date().toISOString(),
        });
      }
    } catch {
      // member_milestones table might not exist yet â€” skip silently
    }
    
    res.json({ activities });
  } catch (error) {
    console.error("[ACTIVITY_FEED] Error:", error);
    res.status(500).json({ activities: [] });
  }
});
```

### New API Endpoint: Membership Story

Add to `server/routes.ts`:

```typescript
app.get("/api/dashboard/membership-story", authMiddleware, async (req, res) => {
  try {
    // Tier composition, engagement, and production by tier â€” single query
    const tierResult = await db.execute(sql`
      SELECT 
        tier,
        COUNT(*) as count,
        ROUND(AVG(engagement_score), 1) as avg_score,
        ROUND(100.0 * SUM(CASE WHEN risk_level IN ('low', 'medium') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 0) as connected_pct,
        SUM(CASE WHEN has_overdue_invoice = false THEN 1 ELSE 0 END) as paid_on_time,
        COALESCE(SUM(CAST(total_volume_12mo AS NUMERIC)), 0) as total_volume,
        CASE WHEN SUM(CASE WHEN transactions_12mo > 0 THEN 1 ELSE 0 END) > 0
          THEN ROUND(SUM(transactions_12mo)::NUMERIC / SUM(CASE WHEN transactions_12mo > 0 THEN 1 ELSE 0 END), 1)
          ELSE 0
        END as avg_transactions
      FROM member_metrics_cache
      WHERE member_status = 'Active'
      GROUP BY tier
    `);
    
    const tierMap: Record<string, any> = {};
    let total = 0;
    for (const row of tierResult.rows as any[]) {
      const count = parseInt(row.count) || 0;
      total += count;
      tierMap[row.tier] = {
        count,
        avgScore: parseFloat(row.avg_score) || 0,
        connectedPct: parseInt(row.connected_pct) || 0,
        paidOnTime: parseInt(row.paid_on_time) || 0,
        totalVolume: parseFloat(row.total_volume) || 0,
        avgTransactions: parseFloat(row.avg_transactions) || 0,
      };
    }
    
    const rainmaker = tierMap['active_producer'] || { count: 0, avgScore: 0, connectedPct: 0, paidOnTime: 0, totalVolume: 0, avgTransactions: 0 };
    const builder = tierMap['occasional_producer'] || { count: 0, avgScore: 0, connectedPct: 0, paidOnTime: 0, totalVolume: 0, avgTransactions: 0 };
    const foundation = tierMap['license_maintainer'] || { count: 0, avgScore: 0, connectedPct: 0, paidOnTime: 0, totalVolume: 0, avgTransactions: 0 };
    
    // Production concentration: what % of volume comes from the top 5% of ALL members?
    // Computed from member_metrics_cache â€” fast, no external DB needed
    let top5PctCount = 0;
    let top5PctVolShare = 0;
    
    try {
      const concentrationResult = await db.execute(sql`
        WITH ranked AS (
          SELECT 
            total_volume_12mo::numeric as vol,
            ROW_NUMBER() OVER (ORDER BY total_volume_12mo::numeric DESC) as rank,
            COUNT(*) OVER () as total_count,
            SUM(total_volume_12mo::numeric) OVER () as total_vol
          FROM member_metrics_cache
          WHERE member_status = 'Active'
        )
        SELECT 
          COUNT(*) FILTER (WHERE rank <= CEIL(0.05 * total_count)) as top5_count,
          COALESCE(SUM(vol) FILTER (WHERE rank <= CEIL(0.05 * total_count)), 0) as top5_volume,
          MAX(total_vol) as total_volume,
          MAX(total_count) as total_count
        FROM ranked
      `);
      
      const concStats = concentrationResult.rows[0] as any;
      top5PctCount = parseInt(concStats?.top5_count) || 0;
      const top5Volume = parseFloat(concStats?.top5_volume) || 0;
      const totalVol = parseFloat(concStats?.total_volume) || 0;
      top5PctVolShare = totalVol > 0 ? Math.round((top5Volume / totalVol) * 100) : 0;
    } catch (concErr) {
      console.warn('[MEMBERSHIP_STORY] Concentration calculation failed (non-fatal):', concErr);
    }
    
    // Builder and Foundation activity signals (last 90 days)
    // Query education/events for Builders
    const builderActivityResult = await db.execute(sql`
      SELECT COUNT(DISTINCT ac.member_key) as with_edu_events
      FROM activity_cache ac
      JOIN member_metrics_cache mmc ON ac.member_key = mmc.member_key
      WHERE mmc.tier = 'occasional_producer'
        AND mmc.member_status = 'Active'
        AND (
          (ac.is_completed = true AND ac.completion_date >= NOW() - INTERVAL '90 days')
          OR (ac.is_attended = true AND ac.start_datetime >= NOW() - INTERVAL '90 days')
        )
    `);
    const builderWithEduEvents = parseInt((builderActivityResult.rows[0] as any)?.with_edu_events) || 0;
    const builderEduEventsPct = builder.count > 0 ? Math.round((builderWithEduEvents / builder.count) * 100) : 0;
    
    // Foundation-specific signals: education, events, email, payment
    let foundationWithEducation = 0;
    let foundationWithEvents = 0;
    let foundationWithEmailEngagement = 0;
    
    if (foundation.count > 0) {
      const foundationActResult = await db.execute(sql`
        SELECT 
          COUNT(DISTINCT CASE 
            WHEN ac.is_completed = true 
              AND ac.completion_date >= NOW() - INTERVAL '90 days'
              AND ac.course_type IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses', 'Post Lic 45-Hour Courses', 'Post Lisc Indiv. 15-HR Courses')
            THEN ac.member_key 
          END) as with_education,
          COUNT(DISTINCT CASE 
            WHEN ac.is_attended = true
              AND ac.start_datetime >= NOW() - INTERVAL '90 days'
              AND (ac.course_type IS NULL OR ac.course_type NOT IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses', 'Post Lic 45-Hour Courses', 'Post Lisc Indiv. 15-HR Courses'))
            THEN ac.member_key
          END) as with_events
        FROM activity_cache ac
        JOIN member_metrics_cache mmc ON ac.member_key = mmc.member_key
        WHERE mmc.tier = 'license_maintainer' AND mmc.member_status = 'Active'
      `);
      
      const fStats = foundationActResult.rows[0] as any;
      foundationWithEducation = parseInt(fStats?.with_education) || 0;
      foundationWithEvents = parseInt(fStats?.with_events) || 0;
      
      // Email engagement for Foundation members
      try {
        const emailResult = await db.execute(sql`
          SELECT COUNT(DISTINCT ee.member_key) as engaged
          FROM email_events ee
          JOIN member_metrics_cache mmc ON ee.member_key = mmc.member_key
          WHERE mmc.tier = 'license_maintainer' AND mmc.member_status = 'Active'
            AND ee.event_type IN ('opened', 'clicked')
            AND ee.event_timestamp >= NOW() - INTERVAL '90 days'
        `);
        foundationWithEmailEngagement = parseInt((emailResult.rows[0] as any)?.engaged) || 0;
      } catch {
        // Email data might be sparse â€” that's fine
      }
    }
    
    const paidOnTimePct = foundation.count > 0 ? Math.round((foundation.paidOnTime / foundation.count) * 100) : 0;
    
    res.json({
      composition: {
        rainmaker: { count: rainmaker.count, percentage: total > 0 ? Math.round((rainmaker.count / total) * 100) : 0 },
        builder: { count: builder.count, percentage: total > 0 ? Math.round((builder.count / total) * 100) : 0 },
        foundation: { count: foundation.count, percentage: total > 0 ? Math.round((foundation.count / total) * 100) : 0 },
      },
      rainmakerInsights: {
        totalVolume: rainmaker.totalVolume,
        avgTransactions: rainmaker.avgTransactions,
        connectedPercentage: rainmaker.connectedPct,
        avgScore: rainmaker.avgScore,
        top5PctCount,
        top5PctLabel: 5,
        top5PctVolShare,
      },
      builderInsights: {
        withEducationOrEvents: builderWithEduEvents,
        withEducationOrEventsPercentage: builderEduEventsPct,
        connectedPercentage: builder.connectedPct,
        avgScore: builder.avgScore,
      },
      foundationInsights: {
        avgScore: foundation.avgScore,
        connectedPercentage: foundation.connectedPct,
        withEducation: foundationWithEducation,
        withEvents: foundationWithEvents,
        withEmailEngagement: foundationWithEmailEngagement,
        paidOnTime: foundation.paidOnTime,
        paidOnTimePercentage: paidOnTimePct,
      },
    });
  } catch (error) {
    console.error("[MEMBERSHIP_STORY] Error:", error);
    res.status(500).json({ error: "Failed to generate membership story" });
  }
});
```

---

## Files Modified

| File | Changes |
|------|---------|
| `client/src/pages/Dashboard.tsx` | Complete rewrite â€” new layout, new cards, remove OfficePerformanceCard |
| `client/src/components/dashboard/ActivityFeed.tsx` | NEW FILE â€” Today's Activity feed |
| `client/src/components/dashboard/MembershipStory.tsx` | NEW FILE â€” The Membership Story (all three tiers) |
| `client/src/components/shared/MetricCard.tsx` | Add `emerald` and `orange` variants to breakdownColors |
| `shared/schema.ts` | Update `DashboardMetrics` interface |
| `server/storage.ts` | Rewrite `getDashboardMetrics()` â€” new metrics, remove compliance/office |
| `server/routes.ts` | Add `/api/dashboard/activity-feed` and `/api/dashboard/membership-story` endpoints |

## Files NOT Modified

| File | Why |
|------|-----|
| `CelebrationInsights.tsx` | Stays exactly as-is â€” it's the best part of the current dashboard |
| `AIChatBox.tsx` | Stays exactly as-is â€” position and behavior unchanged |
| `AnalyticsOverview.tsx` | Office performance data remains in Analytics (already there) |
| Compliance page | Compliance alerts remain on their dedicated page (already there) |

---

## Testing Checklist

1. **Dashboard loads without errors.** No console errors, no blank cards.
2. **Total Active Members** shows ~18,275 with Rainmaker/Builder/Foundation breakdown. Numbers should add up to total.
3. **Member Engagement Rate** shows a percentage. Should be above 0% if the activity cache is populated.
4. **Connection Status** shows four engagement levels. Numbers should add up to total members.
5. **Campaign Effectiveness** shows "No campaigns yet" if no campaigns exist, or actual stats if campaigns have been sent.
6. **Today's Activity** shows at least some items if the activity cache has data. Should show new members, education, events.
7. **The Membership Story** shows three tier spotlights: Rainmaker with production volume, Builder with education/event engagement, Foundation with four connection signal percentages. The composition bar shows the correct proportions.
8. **Celebrations sidebar** still appears on the right side. Still shows milestone categories. Send buttons still work.
9. **AI Chat** still appears at the top. Still connected to database. Still answers questions.
10. **Click-throughs work**: Clicking Disconnected/Drifting links leads to SmartSends. Clicking Total Active Members leads to member list.
11. **Office Performance is gone** from the dashboard. Verify it's still visible in Analytics > Overview.
12. **Compliance Alerts are gone** from the dashboard. Verify they're still visible on the Compliance page.

# MemberSync — Project Summary
## March 9, 2026 (End of Day)

This document is the authoritative state of the project as of the end of March 9, 2026. It supersedes all prior summaries. Use this to resume work in any new conversation.

---

## TABLE OF CONTENTS

1. Who We Are & Claude's Role
2. Product Vision & Philosophy
3. The 75/12 Rule — The Insight That Drives Everything
4. Member Tier Framework
5. Client Pipeline
6. Build Philosophy & Team Structure
7. Current State: What's Built
8. Navigation Structure (Current — Post-Redesign)
9. Campaign Architect — Full Status
10. SmartSends — Full Status (Post-March 9 Rebuild)
11. AI Cost Controls — Status
12. CLAUDE.md Update — Plan & Decisions
13. Prompt Queue — Current Status
14. Standing Rules (Canonical — 24 Rules)
15. All Architectural Decisions (Canonical)
16. Known Issues & Technical Debt
17. Key Files Reference
18. Parking Lot Summary

---

## 1. WHO WE ARE & CLAUDE'S ROLE

**Tracy** is CEO and founder of Membio — a proptech SaaS company. 30+ years real estate industry experience on the business side. Non-technical founder building MemberSync exclusively with Claude, Julius.ai, and Replit Agent. Deeply interested in technology and AI but cannot code.

**Claude's role** is CTO, product visionary, AI architecture expert, and strategic sparring partner:
- Pressure-test every feature idea against multi-tenant scale, technical debt, and timing before speccing it
- Surface architectural risks proactively
- Translate tradeoffs into business terms, not jargon
- Push back when something doesn't make sense
- Hold the full product picture across conversations so nothing gets lost
- Write all Replit prompts and review Replit's implementation plans before Tracy approves them
- Write and maintain CLAUDE.md (the product bible for the dev team)

**The toolchain:**
- **Claude** — strategy, architecture, Replit prompts, CLAUDE.md, project summaries
- **Julius.ai** — SQL development and data validation
- **Replit Agent** — prototype implementation (Track 1)
- **Claude Code** — production implementation by dev team (Track 2)

**Clean boundary:** Tracy + Claude decide the "what" and "why." The dev team owns the "how."

---

## 2. PRODUCT VISION & PHILOSOPHY

**MemberSync** is a member engagement and retention SaaS platform for real estate associations and MLSs. It analyzes MLS listing and AMS data to help executives understand, engage, and retain members.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**Product philosophy:** "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

**The lightsaber:** Organized real estate is in an existential fight. MLSs are going non-Realtor, removing the last transactional justification for association membership. MemberSync is the lightsaber — real, actionable intelligence about members AND the competitive environment they operate in. Associations compete with neighboring organizations. MemberSync helps executives look outward, not just inward.

**The 5% rule:** Every screen must earn its place. We build what clients asked for or dreamed about — not features that sound good in a roadmap.

**Decision-first UX:** Every view surfaces a recommended action, not just data. The AI always has a next step to suggest.

**AI voice and trust philosophy (STANDING RULE):**
MemberSync AI observes real data and acts on it. It never invents, never infers beyond what the data shows, and never uses language implying knowledge it doesn't have. Every claim is grounded in real, verifiable data about actual members. The AI is confident, warm, shows its work, and is always on the member's side — never clinical, never alarming without a path forward, and "really nice about it" when delivering sensitive truths. No invented testimonials. No fabricated statistics. No "members like you" claims without real data.

---

## 3. THE 75/12 RULE

At a typical real estate association or MLS, ~75% of members produce only ~12% of transaction volume — yet they pay ~75% of dues and fees. These are "Foundation" members: people who maintain their license, pay dues, and may never sell a house. They are the financial backbone.

Most associations ignore the 75% because they don't appear to be selling at scale. MemberSync is built for them.

**The 100% Coverage Test:** Any scoring signal covering fewer than 10% of membership is a vanity metric, not a scoring input. Committee participation (NAR's top retention predictor) covers less than 1% of members — useless as a universal signal.

**Why it matters now:** MLSs opening access to non-Realtor licensees threatens association membership. But MLSs face the same math — if they don't build relevance for Foundation members, they're just as vulnerable. MemberSync serves both.

---

## 4. MEMBER TIER FRAMEWORK

Members classified by 12-month transaction sides:

| Display Name | Internal Code | Sides (12mo) | Mainstreet % |
|---|---|---|---|
| Rainmaker | `active_producer` | 40+ | ~1.4% |
| Builder | `occasional_producer` | 6–39 | ~21% |
| Foundation | `license_maintainer` | 0–5 | ~77% |

**Critical rules:**
- Display names only in UI — never internal names
- All tiers framed positively — we celebrate connection, not police compliance
- Foundation members who take classes, pay on time, and attend events can score 10/10 — even with zero transactions
- Engagement is not production
- Tier thresholds defined in `tenant_config` — vary per client

---

## 5. CLIENT PIPELINE

| Client | Members | Status | Special Requirements |
|---|---|---|---|
| Mainstreet REALTORS® | 18,275 | First client, prototype stage | Chicago suburbs, IL compliance |
| HGAR / Hudson Gateway | 12,800 | Onboarding | Multi-tenant, NY compliance |
| GRAR / Greater Rochester | 3,400 | Third pilot | Multi-tenant, NY compliance |
| CRMLS | 103,000+ | Major pilot prospect | SOC 2, enterprise SLA, batch email at scale |

**AEI/RESO Conference:** Minneapolis, March 23–27. 14 days out. Campaign Architect is the demo centerpiece.

**Self-service onboarding:** Explicitly deferred until 4–5 clients have been manually onboarded. The AMS data landscape is too non-standard to automate before we've seen enough real systems.

---

## 6. BUILD PHILOSOPHY & TEAM STRUCTURE

**Two-track development model:**
- **Track 1 (Tracy + Claude + Replit Agent):** Rapid prototype development and feature validation
- **Track 2 (Dev team + Claude Code):** Production platform — porting validated modules with proper multi-tenant architecture from day one

**Handoff artifacts:**
- `CLAUDE.md` — product bible in repo root (786 lines, **needs major update — primary goal of next chat**)
- Per-feature Replit prompts — spec artifacts in project knowledge
- `MemberSync_Parking_Lot.md` — strategic ideas backlog

---

## 7. CURRENT STATE: WHAT'S BUILT

### Core Platform
- Engagement scoring with tier classification (Rainmaker/Builder/Foundation)
- Member metrics cache (daily refresh, cache-first architecture)
- Dashboard with Association Pulse cards, Activity Feed, Member Recognition sidebar
- Member Detail pages with score breakdown, open/click timestamps, real profile data
- Daily membership snapshot for trend analysis

### SmartSends (extensively rebuilt March 9)
See Section 10 for full SmartSends status. High-level:
- Campaign creation: AI + manual + template
- All four audience types
- Email Governor, sandbox mode, exempt categories
- Recognition Queue (full review/approve/send)
- Email Health Dashboard (Performance, Send Queue, Email Archive tabs)
- Image Library upgraded
- AI duplicate detection at Preview step
- Reporting & Analytics rebuilt as unified command center (March 9)
- Create flow rebuilt with 5 tiles (March 9)
- Standalone Automations list page deleted (March 9)
- Recognition and Compliance Performance pages built as real pages (March 9)

### Campaign Architect (AI-first campaign builder)
See Section 9 for full Campaign Architect status. All prompts deployed and verified.

### Recognition Module (first-class top-level module)
- Recognition Queue with review/approve/send flow
- Recognition emails exempt from Email Governor (Lane 1, no cap)
- Left nav badge showing pending count
- Performance page now shows real data (March 9)
- Recognition homepage: to be built (next prompt after CLAUDE.md)

### AI Services
- AI Chat: natural language → SQL, cross-domain queries, retry loop, Julius-style analyst behavior
- AI email composition with archive-aware context
- AI audience builder
- AI duplicate detection
- AI campaign planner (Campaign Architect)
- Schema modularization for AI context (41–76% schema size reductions by query type)
- **AI usage logging and rate limiting infrastructure** (built March 8 — plumbing only, no UI yet)

### Analytics / Market Stats
- Office Volume, Agent Production, Market Concentration
- Top 10 Offices and Agents
- Create Brief (PDF)

### Compliance Module
- Communications page
- Performance page now shows real data (March 9)

---

## 8. NAVIGATION STRUCTURE (CURRENT — POST-REDESIGN)

```
Dashboard
SmartSends [collapsible — label navigates to /smartsends home]
  → Create                 (/smartsends/create)
  → Reporting & Analytics  (/smartsends/reporting)
  → Audiences [collapsible]
      → AI Builder         (/smartsends/audiences)
      → Picklist           (/smartsends/audiences/picklist)
      → Member/Bill Type   (/smartsends/audiences/member-bill-type)
      → Saved              (/smartsends/audiences/saved)
      → Upload             (/smartsends/audiences?upload=true)
  → Content                (/smartsends/images)
  → Templates              (/smartsends/templates)
  → Settings               (/smartsends/settings)
Chats                      (/chats)
Recognition [collapsible — badge shows pending count]
  → Templates              (/recognition/templates — stub)
  → Performance            (/recognition/performance — NOW REAL)
  → Settings               (/recognition/settings — stub)
Engagement                 (greyed — Coming Soon, inert)
Retention                  (greyed — Coming Soon, inert)
Compliance [collapsible — label navigates to /compliance/communications]
  → Communications         (/compliance/communications)
  → Performance            (/compliance/performance — NOW REAL)
  → Settings               (/compliance/settings — stub)
Market Stats [collapsible]
  → Office Leaderboard     (/analytics/offices)
  → Agent Leaderboard      (/analytics/agents)
  → Create Brief           (/analytics/brief)
Members                    (/members)
Offices                    (/offices)
```

**Key nav decisions (standing):**
- Nav items are destinations. Actions live in buttons.
- Send Email, Drafts, Automations removed as standalone nav items
- Drafts accessible as a status filter within Reporting & Analytics
- Coming Soon items: opacity-50, small badge, cursor-default, no hover, no onClick
- All URL paths unchanged from pre-redesign — only display labels changed
- Compliance top-level label navigates to /compliance/communications until triage homepage built

---

## 9. CAMPAIGN ARCHITECT — FULL STATUS

Campaign Architect is the AI-first campaign builder that fully replaces the drip sequence builder. It is the AEI demo centerpiece.

### All Prompts — Fully Deployed ✅
1. Prompt 1 — conversation UI, planning, session persistence
2. Prompt 2 — email generation, editing, A/B, activation
3. Polish prompt — 5 UX improvements
4. Hardening prompt — negative delayDays fix, audience accumulation cleanup, rate limiting
5. Planner Intelligence Fix — multi-event series recognition. Verified working.
6. Addendum — branch emails, social proof prohibition, minimum 3 emails per event. Deployed.
7. Planner Voice & Grouping Fix — new AI voice section, event grouping logic, groupingRationale callout. Deployed March 8.

### Architecture
- **File:** `client/src/pages/CampaignArchitect.tsx` (~1,834 lines)
- **Planner service:** `server/services/aiCampaignPlannerService.ts`
- **Execution:** Reuses `triggeredCampaignProcessor.ts` — **DO NOT MODIFY this file for any reason**
- **Session persistence:** Sessions saved to Automations center
- **Rate limiter:** In-memory Map (per-process; needs Redis for multi-instance production)

### Branch Email Types
- `registration_skip` — skip if already registered
- `registration_alternate` — alternate content for already-registered members
- `prior_attendance` — different message for members who attended previously
- Branch routing stored in `sendCondition` column as JSON in `triggeredCampaignSteps`
- Prior attendance branches come from AI planner conversation ONLY — not the "+ Add branch" button

### Standing Rules for Campaign Architect
- Social proof is never used. No attendance numbers, no "members like you," no testimonials.
- Minimum 3 emails per event. Awareness + value reinforcement + urgency. 3 events = minimum 9 emails.
- Branch points are shallow. Registration status and prior attendance only. Deep logic belongs in Member Journey, not here.

---

## 10. SMARTSENDS — FULL STATUS (POST-MARCH 9 REBUILD)

### Campaign Type Definitions (Canonical — Do Not Blur These)

| Type | What It Is | Created Via | Stored In |
|---|---|---|---|
| **Email** | One-time staff-composed email, specific audience, specific date | Send an Email tile → composer | `email_campaigns` |
| **Trigger** | Single automated email fired by a member action (AMS/MLS event) | Set Up a Trigger tile → 3-option picker | `triggered_campaigns` trigger_type IN (event_registration, event_reminder, event_followup) |
| **Automation** | Staff-defined multi-email series on staff-chosen calendar dates. No AMS/MLS dependency. | Create Automation tile → date-based series builder directly | `triggered_campaigns` trigger_type = scheduled_series |
| **Sequence** | AI-built timed multi-email campaign anchored to AMS/MLS data | Build a Sequence tile → Campaign Architect | `campaign_architect_sessions` → activates to `triggered_campaigns` |
| **Member Journey** | Visual multi-path journeys with conditional branching | Coming Soon tile — inert | Not yet built |

**Recognition and Compliance are NOT SmartSends.** They use the same email infrastructure but are separate first-class modules. They never appear in SmartSends Reporting & Analytics under any filter.

### Reporting & Analytics (`/smartsends/reporting`) — Rebuilt March 9

Unified command center for all SmartSends outbound activity. Combines:
- **Source A** — Manual campaigns from `email_campaigns` (excluding processor-generated rows)
- **Source A2** — Drafts from `email_drafts`, scheduled from `scheduled_campaigns`
- **Source B** — Triggers, automations, sequences from `triggered_campaigns` (rolled up — one row per automation, never one row per send)

**Type badges:** Email (blue) / Trigger (purple) / Automation (orange) / Sequence (teal)

**Filters:** Type (Email/Trigger/Automation/Sequence — no Recognition, no Compliance), Status, Search

**Row behavior by type and status:**
- Sent email → read-only detail + member drill-down + Resend (creates draft, never re-sends immediately)
- Scheduled email → opens composer pre-loaded
- Draft → opens composer
- Active trigger/automation → stats + member drill-down + Edit (pause first) + Pause/Resume
- Active sequence → plan + per-step stats + Edit (→ Campaign Architect) + Pause/Resume
- Paused/archived → same detail, Edit without pausing

**Member drill-down — STANDING RULE — required on every sent campaign, no exceptions:**
Every sent email must be traceable to the individual member with individual timestamps per event type.

| Column | Value |
|---|---|
| Member Name | Linked to member profile |
| Email Address | Address sent to |
| Delivered | Timestamp or "—" |
| Opened | First open timestamp + count if multiple (e.g. "Mar 8 7:02am (3 opens)") or "—" |
| Clicked | First click timestamp + count if multiple, or "—" |
| Bounced | Timestamp or "—" |
| Unsubscribed | Timestamp or "—" |
| Skipped | Skip reason (e.g. "Sandbox mode", "Opted out", "Governor limit") or "—" |

Sortable by any timestamp column. Searchable by name/email. Paginated at 50 rows. Mobile responsive (Name/Delivered/Opened prioritized on small screens).

### Create Flow (`/smartsends/create`) — Rebuilt March 9

Five tiles in order:
1. **Send an Email** → email composer
2. **Build a Sequence** → Campaign Architect
3. **Create Automation** → date-based series builder directly (no trigger picker shown)
4. **Set Up a Trigger** → trigger picker with exactly 3 options: Event Registration, Event Reminder, Post-Event Follow-up. Membership Anniversary and Production Milestone removed — those are Recognition automations.
5. **Member Journey** → Coming Soon (greyed, inert)

**Create Campaign button** — dropdown on all SmartSends pages with the same 5 options. Clicking label navigates to `/smartsends/create`.

### Standalone Automations List Page — DELETED March 9
Component file deleted, route removed from App.tsx, all references cleaned up. `/smartsends/automations/new` and `/:id/edit` still exist.

### Recognition → Performance — Real Page (March 9)
Data from `triggered_campaigns` WHERE trigger_type IN ('membership_anniversary', 'production_milestone'). Summary cards + automation table + member drill-down per row.

### Compliance → Performance — Real Page (March 9)
Data from `triggered_campaigns` WHERE trigger_type = 'compliance'. Same structure.

### Schema Discoveries (March 9 — Important for Future Prompts)
- `email_campaigns` has NO status column — it represents sent campaigns only
- Drafts live in `email_drafts`
- Scheduled sends live in `scheduled_campaigns`
- Staff-created date-based series use `trigger_type = 'scheduled_series'`
- AI sequences use `trigger_type = 'drip_sequence'`
- To distinguish sequences from automations: check if `campaign_architect_sessions.triggered_campaign_id` matches

---

## 11. AI COST CONTROLS — STATUS

**Plumbing built March 8. No UI yet.**

What was built:
- `ai_usage_logs` table in `shared/schema.ts` — logs every AI call with feature, tokens, estimated cost, success/failure, metadata
- `server/services/aiUsageLogger.ts` — lightweight wrapper, never throws, fire-and-forget safe
- Logging wired into: `aiQueryService.ts`, `aiCampaignPlannerService.ts`, `aiEmailService.ts`, `aiAudienceService.ts`
- Per-feature daily rate limits added to `tenant_config` schema (ai_chat_daily_limit, campaign_architect_daily_limit, etc.)
- Per-feature kill switches in `tenant_config` (aiChatEnabled, campaignArchitectEnabled, etc.)
- In-memory daily usage counter (`aiDailyUsageCounter` Map) in `routes.ts`
- `GET /api/admin/usage` endpoint — Membio admin only, returns usage by feature, daily totals, grand totals

**Pricing constants in aiUsageLogger.ts (Claude Sonnet 4, March 2026):**
- Input: $3.00/million tokens
- Output: $15.00/million tokens
- Cached input: 90% discount

**What's still to build (future prompts):**
- Admin panel UI showing usage dashboard
- Client-facing usage dashboard
- Automated alerts when limits are hit
- SendGrid usage logging (separate prompt)
- Billing integration

**Architectural note for production port:** In-memory daily counters work for single-process prototype. Must move to Redis for multi-instance production.

---

## 12. CLAUDE.md UPDATE — PLAN & DECISIONS

**This is the primary goal of the next chat.**

CLAUDE.md is currently 786 lines, last updated March 4. It needs a comprehensive update before dev team handoff.

### New sections to write:
1. Navigation Structure — canonical reference
2. Campaign Architect — architecture, branch types, standing rules, do-not-touch files
3. Recognition Module — first-class module, queue, Email Governor exemption
4. SmartSends — campaign type definitions (canonical), Reporting & Analytics model, Create flow
5. Email Health Dashboard — three tabs, what each shows
6. Image Library (upgraded) — metadata, optimization, archive rules
7. AI Voice & Trust Philosophy
8. AI Cost Controls — what's built, what's coming, pricing reference
9. Membio Admin Panel — vision, what's deferred
10. Client Self-Service & Account Management
11. Persistent Memory Architecture — phased approach
12. `tenant_config` Complete Field Reference ⭐ Explicitly called out as missing in Parking Lot
13. Prototype→Production Handoff — how Tracy+Claude work in Replit → how features get specced for dev team

### Standing Rules to add (new since March 4):
- Rule 17: Social proof never used in Campaign Architect emails
- Rule 18: Minimum 3 emails per event in any Campaign Architect sequence
- Rule 19: Campaign Architect branch points are shallow (registration + prior attendance only)
- Rule 20: Recognition is a top-level nav module — never nest inside SmartSends
- Rule 21: Nav items are destinations. Actions live in buttons.
- Rule 22: Every email sent through MemberSync must be real and verifiable — no hallucinated data
- Rule 23: Every AI call must be logged. Every AI feature must have a rate limit and a kill switch.
- Rule 24: `triggeredCampaignProcessor.ts` is not to be modified for any reason without explicit written approval.
- **Rule 25 (new March 9):** Recognition and Compliance are first-class modules. Never nest inside SmartSends. Never show in SmartSends Reporting & Analytics under any filter.
- **Rule 26 (new March 9):** Every sent email must have member-level drill-down with individual timestamps per event type. No exceptions.
- **Rule 27 (new March 9):** Trigger picker for "Set Up a Trigger" shows exactly 3 options: Event Registration, Event Reminder, Post-Event Follow-up. Membership Anniversary and Production Milestone are Recognition triggers managed from the Recognition module.
- **Rule 28 (new March 9):** Pagination at SQL level only. Never fetch all rows and slice in JavaScript.

---

## 13. PROMPT QUEUE — CURRENT STATUS

### Ready to Send (in order — send these next)

**1. Nav Cleanup** (`MemberSync_NavCleanup_Prompt.md` — in project files)
Three surgical fixes: remove orphaned `Shield` import from AppSidebar.tsx, remove stale nav links from SmartSends.tsx (old Recognition Queue links, Drafts link, stale Automations navigation), verify orphaned routes removed from App.tsx.
**Send immediately — takes 10 minutes, prevents broken links.**

**2. AI Cost Controls** (`MemberSync_AICostControls_Prompt.md` — in project files)
Backend only, no shared files — can go anytime. Installs usage logging, rate limiting, and Membio admin endpoint.
**Send anytime — no dependencies on other prompts.**

**3. Prompt C: AI Duplicate Detection** (`MemberSync_PromptC_AIDuplicateDetection.md` — in project files)
Send after Prompt B (Email Health Dashboard) is verified working.

### To Be Written (in order — next chat)

**4. CLAUDE.md comprehensive update** — PRIMARY GOAL OF NEXT CHAT. Use Section 12 outline.

**5. Recognition Homepage** — stat cards, "What's resonating," "Coming up" queue, daily digest email, left nav badge count.

**6. Compliance Homepage** — triage dashboard, pending items, recent activity.

**7. SmartSendsHome.tsx** — the newsroom homepage is built but `SmartSends.tsx` still lives at `/smartsends`. A future prompt needs to retire SmartSends.tsx and promote SmartSendsHome.tsx fully. The Email Controls tab also needs to migrate to SmartSendsSettings.tsx.

### On Hold (Intentionally)
- A/B Testing standalone — superseded by Campaign Architect
- Automation Priority + Global Contact Limit — waiting for stability
- Member Journey execution engine — post-AEI; architecturally distinct from Campaign Architect

---

## 14. STANDING RULES (Canonical — 28 Rules)

**Architecture & Data:**
1. No parallel systems — extend existing before building new
2. Don't break what works — verify before and after any change
3. Full-page patterns, not modals — wizard flows for multi-step tasks
4. Shared components over duplicates — check /components before creating new
5. Server-side for scale — anything touching 1,000+ records stays on the server
6. Test your work — happy path + edge case before marking complete
7. SQL-level pagination only — never fetch all and slice in JavaScript
8. Cache-first — `member_metrics_cache` is the single source of truth for member data
9. No fake data ever — "—" for missing values, never invented numbers

**Campaign & Email:**
10. Email category required on all campaigns
11. Resend creates a draft — never re-sends immediately
12. Member drill-down required on every sent campaign — individual timestamps per event type, no exceptions
13. Triggered campaign rollup — display queries `triggered_campaigns`, never individual `email_campaigns` processor rows
14. Recognition and Compliance never appear in SmartSends Reporting & Analytics — not under any filter
15. Trigger picker shows exactly 3 options — Event Registration, Event Reminder, Post-Event Follow-up only
16. Create Automation goes directly to series builder — no trigger picker shown

**AI & Content:**
17. Social proof never used in Campaign Architect emails
18. Minimum 3 emails per event in any Campaign Architect sequence
19. Campaign Architect branch points are shallow (registration + prior attendance only)
20. Every email sent must be real and verifiable — no hallucinated data, no invented details
21. Every AI call must be logged, rate-limited, and have a kill switch
22. AI voice: observes real data, shows its work, never invents, always warm

**Navigation & UX:**
23. Recognition is a top-level nav module — never nest inside SmartSends
24. Nav items are destinations. Actions live in buttons.
25. Coming Soon items: opacity-50, small badge, cursor-default, no hover, no onClick

**Infrastructure:**
26. Do NOT modify `triggeredCampaignProcessor.ts` for any reason without explicit written approval
27. `sequenceEnrollmentService.ts` is sensitive execution infrastructure — handle with care
28. Dead code is deleted, not redirected. No stubs, no temporary routes.

---

## 15. ALL ARCHITECTURAL DECISIONS (Canonical)

- **Single PostgreSQL database** — two-database prototype setup is a Replit safety workaround, not an architectural decision
- **Multi-tenant isolation** — critical gap from prototype (only `users` table has `client_id`; 110+ hardcoded "MainStreet" references). Structured port to new repo with proper multi-tenant architecture from day one is the plan.
- **`tenant_config` drives everything** — Stage 0 client intake: a single row drives scoring weights, UI visibility, AI prompt context, and compliance panels. `org_type`, `tracks_ce`, `tracks_coe`, `tracks_designations` etc.
- **Merge field tiers** — Tier 1 (static profile fields), Tier 2 (trigger context fields), Tier 3 (live data pulled at send time). AI suggests Tier 3 fields automatically.
- **Membio Volume Standard** — Personal Production Volume (full ClosePrice per side) vs. Market Volume Contribution (ClosePrice split 50/50 when both sides are members)
- **Billing codes are pattern-based** — created dynamically, can never be reused, pattern recognition required (not hardcoded lists)
- **Campaign Architect replaces drip sequence builder entirely** — no parallel UI
- **AI suggestions are always actionable yes/no** — never configuration forms
- **Every email editing path uses the same full wizard** — no modal shortcuts
- **`routes.ts` monolith** — ~9,500 lines, most urgent refactoring target for production port
- **In-memory rate limiters** — fine for single-process prototype, must move to Redis for multi-instance production
- **Recognition emails are Lane 1** — exempt from Email Governor, no daily/weekly cap
- **Drafts** — `email_drafts` table, not `email_campaigns` with status='draft'. `email_campaigns` = sent campaigns only.
- **Scheduled sends** — `scheduled_campaigns` table, separate from `email_campaigns`
- **Campaign Architect sequences** — use `trigger_type = 'drip_sequence'`; staff automations use `trigger_type = 'scheduled_series'`

---

## 16. KNOWN ISSUES & TECHNICAL DEBT

### Critical (Production Blockers)
- `routes.ts` is ~9,500 lines — most urgent refactoring target. Must be split into modules.
- No multi-tenant data isolation — only `users` table has `client_id`. All other tables lack it.
- 110+ hardcoded "MainStreet" references throughout codebase.
- Illinois-specific compliance hardcoded in `clientConfig.ts` — not parameterized for NY (HGAR/GRAR).

### Important (Quality Before Mainstreet Goes Live)
- `MAX_CAMPAIGN_RECIPIENTS = 1` — needs bumping before real sends (sandbox mode protects in testing)
- AI Chat UI feels empty on full Chats page — no suggested starters, no conversation history sidebar
- Date range picker missing from Email Archive UI (backend supports it)
- 172-member gap between dashboard count and member type builder count
- Revenue data uses catalog prices, not actual invoiced amounts
- SmartSends.tsx still lives at `/smartsends` alongside the new SmartSendsHome.tsx — needs retirement in a future prompt (Email Controls tab migration to SmartSendsSettings.tsx also pending)

### Technical Debt
- Campaign Architect rate limiter is per-process in-memory — needs Redis for multi-instance
- Missing event warning at activation when anchor event has been removed
- Drip Sequence Step Editor needs proper EmailComposer integration
- Templates system needs full rework
- Duplicate detection threshold (70%) should become configurable per client in `tenant_config`

### Recently Fixed (March 8–9)
- Member profile: IL CE Progress, Code of Ethics status, engagement sub-scores — all now show real data
- AppSidebar `Shield` import — orphaned, written into nav cleanup prompt (send to Replit)
- SmartSends.tsx stale nav links — written into nav cleanup prompt (send to Replit)
- Reporting & Analytics rebuilt with correct campaign rollup — no more "[Triggered]" rows with count of 1
- Create flow rebuilt with 5 correct tiles and correct destinations
- Standalone Automations list page deleted
- Recognition Performance and Compliance Performance now show real data

---

## 17. KEY FILES REFERENCE

### Sensitive Files — Handle With Extreme Care
- `server/services/triggeredCampaignProcessor.ts` — **DO NOT MODIFY for any reason**
- `server/services/sequenceEnrollmentService.ts` — **sensitive execution infrastructure**

### Key Application Files
- `server/routes.ts` — Monolith (~9,500 lines) — most urgent refactoring target
- `shared/schema.ts` — All tables and TypeScript types
- `client/src/pages/CampaignArchitect.tsx` — Campaign Architect UI (~1,834 lines)
- `server/services/aiCampaignPlannerService.ts` — Campaign Architect planner
- `client/src/components/layout/AppSidebar.tsx` — Navigation (post-redesign)
- `server/services/clientConfig.ts` — All client-specific values (must become `tenant_config`)
- `server/services/aiQueryService.ts` — AI Chat query service
- `server/services/aiEmailService.ts` — AI email composition
- `server/services/aiAudienceService.ts` — AI audience generation
- `server/services/memberMetricsCacheService.ts` — Engagement scoring engine
- `server/services/aiUsageLogger.ts` — AI call logging (new March 8)
- `client/src/pages/SmartSendsReporting.tsx` — Rebuilt unified campaign list (March 9)
- `client/src/pages/SmartSendsCreate.tsx` — Rebuilt 5-tile create flow (March 9)
- `client/src/pages/SmartSendsHome.tsx` — New newsroom homepage (March 8)
- `client/src/pages/SmartSendsSettings.tsx` — New settings page absorbing Email Controls (March 8)

### Prompt Files — Deployed to Replit ✅
- All Campaign Architect prompts (Prompt1, Prompt2, Polish, Hardening, PlannerFix, Addendum, PlannerVoice)
- `MemberSync_SchemaModularization_Prompt.md`
- `MemberSync_AIChat_JuliusUpgrade_Prompt.md`
- `MemberSync_QueryEngine_RetryAndCrossDomain.md`
- `MemberSync_PromptA_RecognitionQueue_EmailGovernor.md` (Parts 1–8)
- `MemberSync_PromptB_EmailHealth_ImageLibrary.md`
- `MemberSync_ImageLibrary_Upgrade_Prompt.md`
- `MemberSync_NavigationRedesign_Final.md` ✅
- `MemberSync_SmartSends_ReportingFix_Final.md` ✅ (deployed March 9 — mostly working)

### Prompt Files — Ready to Send 📝
- `MemberSync_NavCleanup_Prompt.md` — send immediately
- `MemberSync_AICostControls_Prompt.md` — send anytime (backend only)
- `MemberSync_PromptC_AIDuplicateDetection.md` — send after Prompt B verified

### Planning / Reference Documents
- `CLAUDE.md` — 786 lines, last updated March 4. **Comprehensive update is the primary goal of next chat.**
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog
- `MemberSync_Development_Plan.docx`
- `Membio_AI_Workflow_Playbook.docx`
- `MemberSync_CRMLS_Scaling_Roadmap.docx`

---

## 18. PARKING LOT SUMMARY

Full detail in `MemberSync_Parking_Lot.md`. Key items by section:

### Section 1: Features to Build (Prioritized)
1. **Proactive AI Engagement Engine** ⭐ Top priority after AEI — daily pattern detection, connects to SmartSends actions. More compelling for demos than lapse prevention (positive, not reactive). Premium tier.
2. **Lapse Prevention System** — calendar-aware risk scoring, automated intervention. Plus tier.
3. **Persistent Organizational Intelligence / AI Memory Layer** ⭐ Strategic priority — store chat history per org, inject context into every AI call. Makes MemberSync "the first thing opened in the morning."
4. **Email Archive as AI Memory** — AI reads archive before composing/planning. Duplicate detection (Prompt C) is first step.
5. **Campaign Engagement Map** ⭐ Demo-worthy — scatter/bubble chart, every sent email = one dot, colors shift as engagement data arrives. 1–2 Replit prompts.
6. **AI Chart Rendering** — Recharts inline in AI Chat, download-as-image. Accelerated for CRMLS pilot.
7. **Member Journey** — architecturally distinct from Campaign Architect. Post-AEI.
8. **Competitive Intelligence Module** — territory-aware AI Chat queries, competitive framing for lapse prevention.
9. **Broker Module** — office payment health, suspension impact analysis. Email stays in SmartSends.
10. **Recognition CEO Voice Text Messages** (upsell tier) — AI writes personalized SMS in CEO's voice for milestones. CEO approves queue before send. Twilio delivery.
11. **Universal Communications Ledger** (premium tier) — all outbound comms across all modules in one graphic timeline. Board-level PDF export.

### Section 2: Features to Improve
- Templates system — not useful enough
- Revenue data — actual invoiced amounts, not catalog prices

### Section 3: Infrastructure & Scale
- SOC 2 Certification (required for CRMLS)
- Prompt caching (90% cost reduction on input)
- Batch email sending (for CRMLS scale)
- Multi-tenant Admin Provisioning Dashboard
- Self-service onboarding (after 4–5 manual clients)

### Section 4: Must Be Configured Per Client (`tenant_config`)
- Image Library Notifications category — gate on `has_member_portal`
- Compliance module — gate on `org_type === 'association'`
- Engagement scoring weights and tier thresholds
- State-specific compliance rules (IL vs NY)
- Org branding in email templates
- AI geographic context
- Duplicate detection threshold
- Competitive intelligence territory boundaries

---

## THINGS THAT STAND OUT — PENDING CLEANUP ITEMS (besides cost controls)

Beyond the AI Cost Controls prompt, a few things are worth calling out for the next session:

**1. Nav Cleanup prompt** (`MemberSync_NavCleanup_Prompt.md`) — this is short and already written. Send it before anything else next session. It removes the broken SmartSends.tsx links that will cause 404s if clicked.

**2. SmartSends.tsx retirement is still incomplete** — the new SmartSendsHome.tsx lives at `/smartsends` but the old SmartSends.tsx still exists with its legacy campaign list, duplicate table, and Email Controls tab. A future prompt needs to fully retire SmartSends.tsx and migrate the Email Controls tab content into SmartSendsSettings.tsx. Not urgent this weekend, but it's the last significant piece of nav tech debt.

**3. The 5-tile Create flow in the March 9 implementation** — Replit confirmed that "Set Up a Trigger" and "Create Automation" were previously the same flow (7-option trigger picker). The March 9 rebuild split them correctly. Worth verifying during testing that: (a) Create Automation genuinely bypasses the picker and lands in the series builder, and (b) the trigger picker for Set Up a Trigger genuinely shows only 3 options with Anniversary and Milestone removed.

**4. Recognition Performance page** — built in the March 9 prompt. Verify it shows real data before the AEI demo. If there are no recognition automations active, confirm the empty state message renders correctly and doesn't look broken.

**5. CLAUDE.md is significantly out of date** — the dev team gets the repo Monday. The product bible needs to reflect everything from March 4 to today. This is the most important thing to complete in the next session.

---

## NEXT CHAT GOALS (Priority Order)

1. **Write the comprehensive CLAUDE.md update** — PRIMARY GOAL. Use Section 12 outline. This is the dev team's north star.
2. **Write the Recognition Homepage prompt** — stat cards, "What's resonating," "Coming up" queue, daily digest email
3. **Write the Compliance Homepage prompt** — triage dashboard
4. **Write the SmartSends.tsx retirement prompt** — promote SmartSendsHome.tsx fully, migrate Email Controls tab to SmartSendsSettings.tsx
5. Whatever else Replit finishes tonight that needs speccing

**Send to Replit before next chat:**
- Nav Cleanup prompt (already written — send immediately)
- AI Cost Controls prompt (already written — send anytime, backend only)

---

*Session date: March 9, 2026.*
*AEI/RESO Conference: March 23–27. 14 days out.*
*Replit status: SmartSends Reporting & Analytics rebuilt and mostly working. Nav Cleanup and AI Cost Controls ready to send.*
*Next: Open new chat → upload this summary → write CLAUDE.md.*

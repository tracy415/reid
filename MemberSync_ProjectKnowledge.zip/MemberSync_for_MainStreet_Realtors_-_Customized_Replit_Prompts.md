# MemberSync for MainStreet Realtors - FINAL Replit Build Guide

## 🎯 Phase 1: Initial Build with Complete Schema

Copy and paste this EXACT prompt into Replit Agent:

```
Create "MemberSync" - an AI-powered member engagement platform for 
MainStreet Realtors that predicts member lapse risk and suggests retention actions.

TECH STACK:
- React + Vite for frontend
- Node.js + Express for backend
- PostgreSQL database (existing - will provide credentials)
- Tailwind CSS for styling
- Recharts for charts
- Mobile-responsive design

CRITICAL CONTEXT:
50-70% of MainStreet members have NO transactions in 1-3 years, yet 
remain active paying members. We use a TIERED engagement model that 
measures what matters for each member type.

THREE MEMBER TIERS:
1. Active Producers (30-50%): 2+ transactions in last 12 months
2. Occasional Producers (20-30%): 1+ transactions in last 24 months
3. License Maintainers (20-40%): 0 transactions in 24+ months

Each tier has different engagement expectations and scoring.

DATABASE SCHEMA (PostgreSQL):

Table: apmmember (member data)
- MemberKey (text, PRIMARY) - unique member ID
- MemberMlsId (text) - links to property listings
- MemberFullName, MemberFirstName, MemberLastName (text)
- MemberEmail, MemberMobilePhone, MemberDirectPhone (text)
- MemberType (text) - 'REALTOR', 'Leasing Agent', 'Secondary'
- MemberStatus (text) - 'Active', 'Inactive'
- MemberStateLicense (text)
- MemberStateLicenseExpirationDate (date)
- MemberDesignations (jsonb) - professional certifications
- NarJoinDate (date) - when they joined
- OfficeKey (text) - links to office
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmproperty (MLS listing/transaction data)
- ListingId (text)
- ListAgentMlsId (text) - listing agent (matches MemberMlsId)
- BuyerAgentMlsId (text) - buyer agent (matches MemberMlsId)
- OnMarketDate (date)
- CloseDate (date) - when sale closed
- ListPrice, ClosePrice (numeric)
- StandardStatus (text) - Active, Closed, Pending
- UnparsedAddress, City (text)
- PropertyType (text)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmmemberdues (invoices - CRITICAL for lapse prediction)
- MemberKey (text) - links to member
- InvoiceKey (text)
- InvoiceDate, DueDate (date)
- InvoiceTotal, AmountPaid, BalanceDue (numeric)
- PaidStatus (boolean)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmevent (classes and events)
- EventId (text, PRIMARY)
- CourseId (text)
- Type (text) - 'class' or 'event'
- Name (text) - event/class name
- EducationCredits (text) - CE hours as string
- StartDateTime, EndDateTime (timestamp)
- Categories (text) - for classes: ["Elective"], ["Core"], etc.
- EventTypeDesc (text) - for events: classification
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmeventregistration (member event attendance)
- EventId (text) - links to apmevent
- MemberKey (text) - links to member
- Completion_Date (date) - PRIMARY completion signal
- Attended (text) - 'Y' or 'N' for MainStreet
- Registration_Status (text)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmmembereducation (course completions)
- MemberKey (text) - links to member
- CourseDesc, CourseCode (text)
- Category (text) - course classification
- CreditsCompleted (text) - CE hours as string
- CompletionDate (date) - PRIMARY completion signal
- Status (text)
- StartDate, DeadlineDate (date)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

CORE COMPLIANCE REQUIREMENTS (CRITICAL):

1. NAR CODE OF ETHICS (every 3 years):
   - Current cycle: Jan 1, 2025 - Dec 31, 2027
   - 2.5+ hours required
   - Failure = suspension Jan-Feb 2028, termination March 1, 2028
   - Identify by activity_name containing "COE" or "Code of Ethics" or "Ethics"

2. ILLINOIS STATE CE (every 2 years by April 30 of even years):
   - Next deadline: April 30, 2026 (3 months away!)
   - Standard renewal: 12 hours total
     * 6-hour Core course
     * 1 hour Sexual Harassment Prevention
     * 5 hours electives
   - First-time renewal (if licensed Nov 2023-Oct 2025): 45 hours
   - Identify by course_type = 'Core' or '4 Hour Core Requirement' or 'Elective'

ENGAGEMENT SCORE CALCULATION (0-10 scale):

TIER 1: Active Producers (2+ transactions last 12 months)
- Transaction Activity (0-4 pts): 
  * 4: 5+ closings in 90 days
  * 3: 3-4 closings in 90 days
  * 2: 1-2 closings in 90 days
  * 1: Active listings, 0 closings
  * 0: No activity 90+ days
- Education/Events (0-2 pts):
  * 2: 1+ activity in last 90 days
  * 1: 1+ activity in last 180 days
  * 0: None in 180+ days
- Payment (0-3 pts):
  * 3: All current
  * 2: Currently paid, but late in past
  * 1: 1 overdue invoice
  * 0: Multiple overdue OR 60+ days late
  * PENALTY: -2 if 90+ days overdue
- License (0-1 pt):
  * 1: Current, not expiring soon
  * 0: Expires <30 days

TIER 2: Occasional Producers (1+ transactions last 24 months)
- Transaction Activity (0-3 pts):
  * 3: 1+ closings in 90 days
  * 2: 1+ closings in 180 days
  * 1: 1+ closings in 365 days
  * 0: None in 365+ days
- Education/Events (0-3 pts):
  * 3: 2+ activities in 180 days
  * 2: 1 activity in 180 days
  * 1: 1 activity in 365 days
  * 0: None in 365+ days
- Payment (0-3 pts): Same as Tier 1
- License (0-1 pt): Same as Tier 1

TIER 3: License Maintainers (0 transactions 24+ months)
- Education/Events (0-5 pts):
  * 5: 2+ classes AND 2+ events in 12 months
  * 4: 2+ classes OR 2+ events in 12 months
  * 3: 1 class AND 1 event in 12 months
  * 2: 1 class OR 1 event in 12 months
  * 1: 1 activity in 24 months
  * 0: None in 24+ months
- Professional Investment (0-2 pts):
  * 2: Has 2+ designations
  * 1: Has 1 designation
  * 0: No designations
- Payment (0-3 pts): Same as Tier 1
- License (0-1 pt): Same as Tier 1

AT-RISK CRITERIA (by tier):

TIER 1 (Active Producers) flagged if ANY:
- Engagement score < 5.0
- No transactions 90+ days AND no active listings
- Invoice 30+ days overdue
- License expires <30 days
- Illinois CE incomplete with <60 days to deadline
- Code of Ethics incomplete with <180 days to deadline
- No education/events in 180+ days

TIER 2 (Occasional Producers) flagged if ANY:
- Engagement score < 4.0
- No transactions 12+ months
- Invoice 30+ days overdue
- License expires <30 days
- Illinois CE incomplete with <90 days to deadline
- Code of Ethics incomplete with <365 days to deadline
- No education/events in 12+ months

TIER 3 (License Maintainers) flagged if ANY:
- Engagement score < 4.0
- Invoice 30+ days overdue
- License expires <30 days
- Illinois CE incomplete with <90 days to deadline
- Code of Ethics incomplete with <365 days to deadline
- No education/events in 24+ months
- Has 0 designations (never invested professionally)

DASHBOARD FEATURES TO BUILD:

1. TOP METRICS (4 cards)

Card 1: Total Active Members
Query: COUNT(*) WHERE ApmClientId = 'MainStreet' AND MemberStatus = 'Active' 
AND MemberType IN ('REALTOR', 'Leasing Agent', 'Secondary')
Show breakdown by tier

Card 2: Engaged This Quarter  
Count members with ANY activity (transaction, education, event) in last 90 days
Show percentage and breakdown

Card 3: At-Risk Members (RED)
Count members matching at-risk criteria for their tier
Show by risk level: Critical, High, Medium

Card 4: Compliance Alerts
Count:
- Invoices 90+ days overdue
- Licenses expiring <30 days
- Illinois CE due <60 days and incomplete
- Code of Ethics due <180 days and incomplete

2. INTELLIGENT SEARCH BAR

Prominent search with placeholder:
"Ask anything... (e.g., 'who needs Code of Ethics training')"

This will use AI (Phase 3). For now, create UI only.

3. MEMBERS LIST

Show member cards with tier-appropriate info:

TIER 1 card:
┌─────────────────────────────────────┐
│ Sarah Johnson          🟢 8.2      │
│ REALTOR · Active Producer           │
│ Last sale: 12 days ago              │
│ YTD: 18 transactions                │
│ Recent: CE course completed         │
│ 💳 Current  📄 IL CE: Complete      │
└─────────────────────────────────────┘

TIER 3 card:
┌─────────────────────────────────────┐
│ Jane Smith             🟢 7.8      │
│ REALTOR · License Maintainer        │
│ No recent transactions              │
│ Designations: ABR, GRI              │
│ Recent: 2 CE courses (6 hrs)        │
│ 💳 Current  📄 IL CE: 8/12 hrs      │
└─────────────────────────────────────┘

AT-RISK card:
┌─────────────────────────────────────┐
│ Bob Williams           🔴 2.1      │
│ Secondary · License Maintainer      │
│ No activity (18 months)             │
│ No designations                     │
│ 💳 OVERDUE 45 days                  │
│ 📄 IL CE: 0/12 hrs - DUE APR 30!   │
│ [Call Now] [Send Reminder]          │
└─────────────────────────────────────┘

4. MEMBER DETAIL VIEW

Show:
- Contact info
- Performance metrics (tier-appropriate)
- Payment status with timeline
- Compliance status:
  * Illinois CE: X/12 hours complete (due Apr 30, 2026)
  * Code of Ethics: ✅ Complete (cycle 2025-2027) OR ⚠️ Incomplete
  * License: Expires [date]
- Recent activity timeline (transactions, education, events, payments)
- AI insight card (Phase 3)

5. COMPLIANCE DASHBOARD (new screen)

Show members grouped by compliance status:
- Illinois CE Complete: [count]
- Illinois CE In Progress: [count] with hours completed
- Illinois CE Not Started: [count] - flagged if <90 days to deadline
- Code of Ethics Complete (2025-2027): [count]
- Code of Ethics Incomplete: [count] - flagged if <180 days to deadline
- License Expiring Soon (<90 days): [count]

Click any group to see member list

TECHNICAL REQUIREMENTS:

Environment variables (.env):
- DB_HOST, DB_NAME, DB_USER, DB_PASSWORD, DB_PORT
- ANTHROPIC_API_KEY (for Phase 3)

Database connection:
Use pg (node-postgres) with connection pool, SSL enabled

Key backend endpoints:

GET /api/dashboard/metrics
- Returns 4 card metrics

GET /api/dashboard/compliance
- Returns compliance status counts

GET /api/members?tier=all&sort=name&page=1
- Returns paginated member list with scores
- Classify tier based on transaction history
- Calculate engagement score for each tier
- Include compliance status

GET /api/members/at-risk?tier=all
- Returns at-risk members by urgency
- Apply tier-appropriate criteria

GET /api/members/:memberKey
- Returns full member detail
- Include transactions, education, events, invoices
- Calculate all compliance statuses

GET /api/members/:memberKey/activity
- Returns unified activity stream (transactions, education, events, payments)
- Ordered by date descending

GET /api/compliance/illinois-ce
- Returns members grouped by Illinois CE status

GET /api/compliance/code-of-ethics
- Returns members grouped by COE status (2025-2027 cycle)

DESIGN SYSTEM:

Colors:
- Primary: #2563EB (blue)
- Success: #10B981 (green)
- Warning: #F59E0B (yellow)
- Danger: #EF4444 (red)
- Critical: #991B1B (dark red)
- Text: #6B7280
- Background: #F9FAFB

Typography:
- Font: Inter
- Headlines: 24-32px, bold
- Body: 16px
- Small: 14px

Spacing:
- 8px grid system
- Card padding: 24px
- Gaps: 16px

Components:
- Buttons: 44px min height (touch-friendly)
- Cards: shadow-sm, rounded-lg (8px)
- Smooth transitions

Mobile:
- Stack vertically on <768px
- Bottom nav on mobile
- Tables → cards on mobile

Loading:
- Skeleton screens (not spinners)
- Fade-in animations

START BY:
1. Creating project structure (React + Express)
2. Building dashboard with dummy data
3. Getting UI polished and professional
4. Once approved, I'll provide database credentials
5. Then connect real data

Make it look like Stripe or Linear quality - clean, modern, premium.
Use lots of white space, clear hierarchy, professional polish.
```

---

## 📊 Phase 2: Production Activity Stream Query

Once Replit builds the basic structure, add this PRODUCTION-READY query 
that Julius.ai validated for MainStreet data.

**Save this as a database view or use in your API endpoints:**

```sql
WITH
member_latest AS (
  SELECT *
  FROM (
    SELECT
      m.*,
      ROW_NUMBER() OVER (
        PARTITION BY m."ApmClientId", m."MemberKey"
        ORDER BY m."ApmSourceModificationTimestamp" DESC NULLS LAST,
                 m."ApmReceivedDateTime" DESC NULLS LAST
      ) AS rn
    FROM "AMS"."apmmember" m
    WHERE m."ApmClientId" = 'MainStreet'
  ) s
  WHERE s.rn = 1
),

event_latest AS (
  SELECT *
  FROM (
    SELECT
      e.*,
      ROW_NUMBER() OVER (
        PARTITION BY e."ApmClientId", e."EventId"
        ORDER BY e."ApmSourceModificationTimestamp" DESC NULLS LAST,
                 e."ApmReceivedDateTime" DESC NULLS LAST
      ) AS rn
    FROM "AMS"."apmevent" e
    WHERE e."ApmClientId" = 'MainStreet'
  ) s
  WHERE s.rn = 1
),

eventreg_latest AS (
  SELECT *
  FROM (
    SELECT
      r.*,
      ROW_NUMBER() OVER (
        PARTITION BY
          r."ApmClientId",
          r."EventId",
          r."MemberKey",
          COALESCE(r."Registration_ID", r."ApmSourceUniqueRecordId")
        ORDER BY r."ApmSourceModificationTimestamp" DESC NULLS LAST,
                 r."ApmReceivedDateTime" DESC NULLS LAST
      ) AS rn
    FROM "AMS"."apmeventregistration" r
    WHERE r."ApmClientId" = 'MainStreet'
  ) s
  WHERE s.rn = 1
),

memberedu_latest AS (
  SELECT *
  FROM (
    SELECT
      ed.*,
      ROW_NUMBER() OVER (
        PARTITION BY
          ed."ApmClientId",
          ed."MemberKey",
          COALESCE(
            NULLIF(BTRIM(ed."CourseDesc"), ''),
            NULLIF(BTRIM(ed."CourseCode"), ''),
            NULLIF(BTRIM(ed."CourseNumber"), ''),
            ed."ApmSourceUniqueRecordId"
          )
        ORDER BY ed."ApmSourceModificationTimestamp" DESC NULLS LAST,
                 ed."ApmReceivedDateTime" DESC NULLS LAST
      ) AS rn
    FROM "AMS"."apmmembereducation" ed
    WHERE ed."ApmClientId" = 'MainStreet'
  ) s
  WHERE s.rn = 1
),

activity_stream AS (
  -- Event registrations and class completions
  SELECT
    'event_registration'::text AS activity_source,
    r."MemberKey" AS member_key,
    e."Type" AS event_type,
    
    -- MainStreet-specific course_type mapping
    CASE
      WHEN e."Type" = 'class' THEN
        COALESCE(
          NULLIF(BTRIM(SPLIT_PART(REPLACE(REPLACE(REPLACE(e."Categories", '[', ''), ']', ''), '\"', ''), ',', 1)), ''),
          NULLIF(BTRIM(e."Categories"), '')
        )
      ELSE
        COALESCE(
          NULLIF(BTRIM(e."EventTypeDesc"), ''),
          NULLIF(BTRIM(e."EventType"), ''),
          NULLIF(BTRIM(e."Categories"), '')
        )
    END AS course_type,
    
    e."Name" AS activity_name,
    e."EducationCredits" AS education_credits,
    r."Completion_Date" IS NOT NULL AS is_completed,
    r."Attended" = 'Y' AS is_attended,
    r."Completion_Date" AS completion_date,
    e."StartDateTime" AS start_datetime,
    e."EventId" AS event_id

  FROM eventreg_latest r
  LEFT JOIN event_latest e
    ON e."EventId" = r."EventId"

  UNION ALL

  -- Course completions
  SELECT
    'member_education'::text AS activity_source,
    ed."MemberKey" AS member_key,
    NULL::text AS event_type,
    ed."Category" AS course_type,
    COALESCE(ed."CourseDesc", ed."CourseCode") AS activity_name,
    ed."CreditsCompleted" AS education_credits,
    ed."CompletionDate" IS NOT NULL AS is_completed,
    NULL::boolean AS is_attended,
    ed."CompletionDate"::date AS completion_date,
    ed."StartDate"::timestamptz AS start_datetime,
    NULL::text AS event_id
  FROM memberedu_latest ed
)

SELECT * FROM activity_stream
WHERE is_completed = true
ORDER BY completion_date DESC;
```

**Use this query to:**
- Count education activities per member
- Check Code of Ethics completion (activity_name LIKE '%COE%' OR '%Ethics%')
- Check Illinois CE hours (SUM credits where course_type IN ('Core', 'Elective', etc.))
- Build activity timeline

---

## 🎯 Phase 3: Key Backend Queries

### Classify Member Tier

```javascript
// In your API endpoint
async function classifyMemberTier(memberKey) {
  const result = await pool.query(`
    SELECT 
      COUNT(DISTINCT CASE 
        WHEN p."CloseDate" >= NOW() - INTERVAL '12 months' 
        THEN p."ListingId" 
      END) as closings_12mo,
      COUNT(DISTINCT CASE 
        WHEN p."CloseDate" >= NOW() - INTERVAL '24 months' 
        THEN p."ListingId" 
      END) as closings_24mo
    FROM "AMS"."apmproperty" p
    WHERE (p."ListAgentMlsId" = $2 OR p."BuyerAgentMlsId" = $2)
      AND p."ApmClientId" = 'MainStreet'
  `, [memberKey, memberMlsId]);
  
  const { closings_12mo, closings_24mo } = result.rows[0];
  
  if (closings_12mo >= 2) return 'Active Producer';
  if (closings_24mo >= 1) return 'Occasional Producer';
  return 'License Maintainer';
}
```

### Check Compliance Status

```javascript
async function getComplianceStatus(memberKey) {
  // Check Code of Ethics (2025-2027 cycle)
  const coeResult = await pool.query(`
    SELECT COUNT(*) as coe_count
    FROM activity_stream
    WHERE member_key = $1
      AND is_completed = true
      AND completion_date >= '2025-01-01'
      AND completion_date <= '2027-12-31'
      AND (
        activity_name ILIKE '%COE%'
        OR activity_name ILIKE '%Code of Ethics%'
        OR activity_name ILIKE '%Ethics%'
      )
  `, [memberKey]);
  
  const hasCodeOfEthics = coeResult.rows[0].coe_count > 0;
  
  // Check Illinois CE (2024-2026 cycle, due April 30, 2026)
  const ilCeResult = await pool.query(`
    SELECT 
      SUM(CAST(education_credits AS NUMERIC)) as total_ce_hours
    FROM activity_stream
    WHERE member_key = $1
      AND is_completed = true
      AND completion_date >= '2024-05-01'
      AND completion_date <= '2026-04-30'
      AND course_type IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses')
  `, [memberKey]);
  
  const ceHours = ilCeResult.rows[0].total_ce_hours || 0;
  
  return {
    codeOfEthics: {
      complete: hasCodeOfEthics,
      cycle: '2025-2027',
      deadline: '2027-12-31'
    },
    illinoisCE: {
      hoursCompleted: ceHours,
      hoursRequired: 12, // or 45 for first-time
      deadline: '2026-04-30',
      daysRemaining: Math.floor((new Date('2026-04-30') - new Date()) / (1000 * 60 * 60 * 24))
    }
  };
}
```

---

## 🤖 Phase 4: Add AI Intelligence

```
Now add intelligent natural language query and insights using Claude AI.

Install Anthropic SDK:
npm install @anthropic-ai/sdk

I'll provide ANTHROPIC_API_KEY in Replit Secrets.

CREATE ENDPOINT: POST /api/ai/query

When user asks a question, send to Claude with this system prompt:

"You are a SQL expert for MainStreet Realtors member database.
Convert questions to PostgreSQL queries for these tables:

Tables: apmmember, apmproperty, apmmemberdues, apmevent, 
apmeventregistration, apmmembereducation

[Include full schema details from Phase 1]

CRITICAL RULES:
1. ALWAYS filter WHERE ApmClientId = 'MainStreet'
2. For members: AND MemberStatus = 'Active' AND MemberType IN (...)
3. Only SELECT queries (no UPDATE/DELETE/INSERT)
4. Use the activity_stream view for education/event queries
5. Limit results to 1000 rows
6. Return ONLY the SQL query, no explanation

EXAMPLE QUERIES:

Q: 'who needs Code of Ethics training'
A: SELECT m.MemberFullName, m.MemberEmail 
FROM apmmember m
WHERE m.ApmClientId = 'MainStreet'
  AND m.MemberStatus = 'Active'
  AND m.MemberKey NOT IN (
    SELECT DISTINCT member_key 
    FROM activity_stream
    WHERE is_completed = true
      AND completion_date >= '2025-01-01'
      AND activity_name ILIKE '%COE%'
  )
LIMIT 1000;

Q: 'members with overdue invoices'
A: SELECT m.MemberFullName, d.BalanceDue, d.DueDate
FROM apmmember m
JOIN apmmemberdues d ON m.MemberKey = d.MemberKey
WHERE m.ApmClientId = 'MainStreet'
  AND m.MemberStatus = 'Active'
  AND d.BalanceDue > 0
  AND d.DueDate < NOW()
ORDER BY d.DueDate ASC
LIMIT 1000;

If question unclear, return: ERROR: [explanation]"

Execute generated SQL and return results as table with download buttons.

CREATE ENDPOINT: GET /api/ai/insights

Generate proactive insights for dashboard:

INSIGHT 1: Critical Compliance Issues
Query members missing Code of Ethics OR Illinois CE with deadline approaching.
For each, call Claude:
"This MainStreet member faces compliance risk:
- Name: [name]
- Missing: [Code of Ethics/Illinois CE]
- Deadline: [date] ([X] days away)
- Payment status: [current/overdue]
- Last activity: [X] days ago

In 1 sentence, explain the urgency and suggest immediate action."

INSIGHT 2: Payment + Inactivity Risk
Query members with BOTH overdue payments AND no activity.
Call Claude with combined risk factors for strategic recommendation.

INSIGHT 3: Tier-Specific Trends
For each tier, analyze activity trends vs previous period.
Call Claude to interpret and suggest proactive strategies.

Display top 3-5 insights on dashboard with urgency color coding.
Cache for 1 hour to avoid excessive API calls.
```

---

## ✅ Final Checklist

Before showing MainStreet CEO:

**Data Accuracy:**
- [ ] All queries filter ApmClientId = 'MainStreet'
- [ ] Active members only (correct MemberTypes)
- [ ] Tier classification working correctly
- [ ] Compliance calculations accurate (test with known members)
- [ ] Payment status showing correctly

**UI/UX:**
- [ ] Dashboard loads quickly (<2 seconds)
- [ ] Member cards show tier-appropriate info
- [ ] Compliance status clear and actionable
- [ ] Mobile responsive (test on phone)
- [ ] No console errors

**Compliance Tracking:**
- [ ] Code of Ethics 2025-2027 cycle correct
- [ ] Illinois CE deadline April 30, 2026 showing
- [ ] Hours calculated correctly
- [ ] Deadline warnings triggering appropriately

**Ready to Launch!**

Your app will show MainStreet's CEO:
- Who's truly at risk (payment + compliance + activity)
- What action to take (AI-generated recommendations)
- When deadlines are approaching (compliance alerts)
- Which members need attention (tiered risk scoring)

All based on REAL engagement signals that predict lapse!
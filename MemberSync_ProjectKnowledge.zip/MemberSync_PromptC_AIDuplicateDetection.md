# MemberSync — Prompt C: AI Duplicate Detection + Archive-Aware Composition

## Date: March 2026
## Priority: Send after Prompt B is verified working

---

## STANDING RULES REMINDER

Before touching any file: search for existing components first. No parallel systems. Don't break what works. Server-side for anything touching more than 1,000 records. Full-page patterns, not modals, for multi-step tasks.

---

## OVERVIEW

This prompt adds two AI-powered capabilities that build directly on the Email Archive created in Prompt B:

1. **Duplicate Detection** — Before a campaign is sent, AI scans recent emails sent to the same audience and flags if the new email is too similar to something they've already received. Prevents members from getting repetitive content.

2. **Archive-Aware Composition** — When staff is composing an email with AI, the AI has visibility into what's already been sent to that audience. It actively avoids repeating recent themes and can suggest fresh angles based on what has and hasn't been tried.

Both features are passive and advisory — they surface information and make suggestions, but never block a send. Staff is always in control.

---

## PREREQUISITE CHECK

Before implementing, verify:
- `email_campaigns.rendered_html_url` column exists (added in Prompt B)
- `email_images` table exists (added in Prompt B)
- `/api/email-archive` endpoint is working (added in Prompt B)

If any of these are missing, stop and flag it before proceeding.

---

## PART 1 — DUPLICATE DETECTION

### What it does

When staff reaches the **Preview step** of the Send Email wizard, the system automatically checks whether the email being composed is substantially similar to any email sent to an overlapping audience in the last 90 days. If similarity exceeds 70%, a non-blocking warning appears.

This is not a gate — staff can dismiss the warning and send anyway. The goal is to surface something they may not have noticed, not to stop them.

### How similarity is calculated

Use the existing Anthropic Claude API (`server/services/anthropic.ts`) to compare email content. Do not use string-matching or cosine similarity on raw text — the AI comparison is what makes this useful, because it catches thematic similarity ("this email is also about spring CE classes") not just word-for-word repetition.

**API call structure:**

```typescript
const similarityCheck = await anthropic.messages.create({
  model: "claude-haiku-4-5-20251001", // Use Haiku — this is a lightweight check
  max_tokens: 256,
  messages: [{
    role: "user",
    content: `You are reviewing email campaigns for a real estate association.

Compare these two emails and rate their similarity from 0-100, where:
- 0 = completely different topic and purpose
- 50 = same general theme but different content and angle
- 70 = similar enough that receiving both would feel repetitive
- 100 = nearly identical

Email A (being composed now):
Subject: ${newSubject}
Body: ${newBodyText}

Email B (sent ${daysSinceSent} days ago to overlapping audience):
Subject: ${previousSubject}
Body: ${previousBodyText}

Respond with JSON only: {"score": number, "reason": "one sentence explanation"}`
  }]
});
```

Use Haiku for this — it's a quick factual comparison, not creative generation. Cost is negligible.

### Which previous emails to check

Query the `email_campaigns` table for campaigns that:
- Were sent in the last 90 days (status = 'sent')
- Have an overlapping audience with the current campaign

**Audience overlap definition:**
- If both campaigns used the same `saved_audience_id` — that's overlap
- If both campaigns used the same `email_category` and audience size is within 20% — treat as likely overlap
- If the new campaign is sending to all members — check against any campaign sent in the last 90 days

Limit the check to the 5 most recent matching campaigns. Do not run more than 5 API calls per duplicate check.

### When to run the check

Run the check when staff reaches the **Preview step** — not during composition. Composition should feel fast and uninterrupted. The check happens at the natural pause before sending.

Show a loading state: "Checking for similar recent emails..." while the check runs. It should complete in under 3 seconds.

### UI — Warning display

If any comparison returns a score ≥ 70, show a warning card on the Preview step above the email preview:

```
⚠  Similar to a recent send

  This email is similar to "[Campaign Name]" sent 14 days ago to a 
  comparable audience (similarity score: 82%).

  "[Previous subject line]"

  Consider refreshing the angle before sending, or proceed if this 
  is intentional.

  [View Previous Email]    [Dismiss and Continue]
```

- **"View Previous Email"** — opens the stored HTML from `rendered_html_url` in a side panel so staff can compare directly
- **"Dismiss and Continue"** — removes the warning and allows the send to proceed normally

If multiple similar emails are found, show one warning card per match, stacked. Maximum 3 warning cards — do not show more than 3 even if 5 comparisons all score high.

If no similar emails are found, show nothing. Do not show a "no duplicates found" confirmation — silence is the correct signal.

### API endpoint

```
POST /api/email-health/duplicate-check
  Body: {
    subjectLine: string,
    bodyText: string,        // plain text stripped of HTML
    audienceId?: string,     // if using saved audience
    emailCategory?: string,  // for fallback overlap detection
    recipientCount?: number
  }
  
  Response: {
    matches: [
      {
        campaignId: string,
        campaignName: string,
        sentAt: string,
        daysSinceSent: number,
        subjectLine: string,
        similarityScore: number,
        reason: string,
        renderedHtmlUrl: string | null
      }
    ]
  }
```

Only return matches with score ≥ 70. Return empty array if no matches.

**Rate limiting:** Add a simple check — if this endpoint is called more than 10 times in a minute for the same session, return a 429. Prevents runaway API calls.

---

## PART 2 — ARCHIVE-AWARE AI COMPOSITION

### What it does

When staff uses "Generate with AI" in the email composer, the AI generation prompt is augmented with context from the Email Archive. The AI knows what has already been sent to this audience and actively avoids repeating themes, angles, or content that members have recently received.

This makes every AI-generated email feel fresh rather than generic.

### How it works

Before calling `aiEmailService.ts` to generate an email, fetch a summary of recent emails sent to the same audience (or same category). Pass this summary into the AI generation prompt as context.

**Do not pass full HTML** into the generation prompt — that would be expensive and unnecessary. Pass a lightweight summary: subject line, one-sentence description of the content, and send date.

### Changes to `aiEmailService.ts`

Add an optional `recentEmailContext` parameter to the email generation function:

```typescript
interface RecentEmailSummary {
  subject: string;
  contentSummary: string; // AI-generated one-liner from the archive check
  sentDaysAgo: number;
  category: string;
}

// Add to existing generation function signature:
async function generateEmail(
  // ... existing params ...
  recentEmailContext?: RecentEmailSummary[]
): Promise<GeneratedEmail>
```

When `recentEmailContext` is provided, add this section to the existing system prompt:

```
RECENT EMAIL HISTORY FOR THIS AUDIENCE:
The following emails have been sent to this audience in the last 90 days. 
Do not repeat these themes, angles, or calls to action. Find a fresh approach.

${recentEmailContext.map(e => 
  `- "${e.subject}" (${e.sentDaysAgo} days ago): ${e.contentSummary}`
).join('\n')}

Your email must take a meaningfully different angle from the above.
```

If `recentEmailContext` is empty or not provided, the generation prompt is unchanged. This is a purely additive change — existing generation behavior is preserved exactly.

### Generating the content summary

When emails are stored in the archive (Prompt B), generate and store a one-sentence content summary at storage time. Add a column:

```sql
ALTER TABLE email_campaigns ADD COLUMN content_summary TEXT;
```

Generate the summary using Haiku immediately after the HTML is stored:

```typescript
const summary = await anthropic.messages.create({
  model: "claude-haiku-4-5-20251001",
  max_tokens: 100,
  messages: [{
    role: "user", 
    content: `Summarize this email in one sentence (max 20 words), 
    focusing on its topic and call to action. 
    Subject: ${subjectLine}
    Body: ${bodyText}
    
    Respond with the summary only, no preamble.`
  }]
});
```

Store the result in `content_summary`. If summary generation fails, store null and continue — do not fail the send.

### Where to fetch recent context

In the Send Email wizard, when staff selects "Generate with AI" in the Compose step, the client should:

1. Check if an audience has been selected
2. If yes, call a lightweight endpoint to fetch recent email summaries for that audience
3. Pass the summaries to the AI generation call

**New endpoint:**

```
GET /api/email-archive/recent-context
  Query params:
    - audienceId (optional)
    - emailCategory (optional)
    - limit (default 5, max 10)
  
  Response: {
    recentEmails: [
      {
        campaignId, subjectLine, contentSummary, 
        sentAt, daysSinceSent, category
      }
    ]
  }
```

Only return emails where `content_summary` is not null. If no context is available, return empty array — generation proceeds normally.

### UI — Surface this to staff (lightly)

When recent context is being used in generation, show a subtle indicator below the "Generate" button:

```
✓ Referencing 3 recent emails to avoid repetition
```

This is a one-liner, not a modal or expandable section. Staff doesn't need to see the details — just know the AI is being smart about it.

If no recent context is available, show nothing.

---

## PART 3 — ARCHIVE PREVIEW IN COMPOSER

### What it does

In the email composer, add a small "Recent Sends" reference panel that staff can open to browse what's been sent to this audience before. This is the manual complement to the AI's automatic awareness — sometimes a human wants to check what went out before writing anything.

### UI

Add a collapsible section in the composer sidebar (or below the audience selection, before the compose step) labeled **"Recent sends to this audience"**. Collapsed by default.

When expanded, show a compact list of the last 5 campaigns sent to this audience:

```
Recent sends to this audience                              [collapse ▲]

  Spring CE Reminder          Mar 1    42% open    [Preview]
  February Market Update      Feb 14   38% open    [Preview]
  Annual Dues Reminder        Jan 28   61% open    [Preview]
```

**"Preview"** opens the stored HTML in a read-only side panel — same pattern as the duplicate detection warning.

If no recent sends exist for this audience, show: "No previous emails sent to this audience."

If the audience hasn't been selected yet, show: "Select an audience to see recent sends."

This panel uses the same `/api/email-archive/recent-context` endpoint from Part 2, just displayed rather than passed to AI.

---

## FILES TO MODIFY

- `server/services/aiEmailService.ts` — Add `recentEmailContext` parameter, inject into system prompt
- `server/services/emailService.ts` — Add content summary generation after HTML storage
- `server/schema.ts` — Add `content_summary` column to `email_campaigns`
- `server/routes.ts` — Add `/api/email-health/duplicate-check` and `/api/email-archive/recent-context` endpoints
- `client/src/pages/SendEmail.tsx` — Add duplicate check on Preview step, archive context panel in Compose step, recent sends reference panel

## FILES NOT TO MODIFY

- `server/services/triggeredCampaignProcessor.ts` — No changes
- `server/services/emailService.ts` send logic — Only add summary generation after send confirmation
- Any Automations pages or components
- The Email Archive UI built in Prompt B — read-only from this prompt

---

## COST CONSIDERATIONS

This prompt adds two new AI call patterns:

- **Duplicate check**: Up to 5 Haiku calls per send attempt, at Preview step only. Triggered by human action, not automated.
- **Content summary**: 1 Haiku call per sent campaign, at send time only.
- **Archive-aware generation**: No additional AI calls — context is injected into the existing generation call.

All three use Haiku, not Sonnet. Total cost addition is negligible. No rate limiting beyond the 10-calls-per-minute guard on the duplicate check endpoint.

---

## VERIFICATION CHECKLIST

### Part 1 — Duplicate Detection
- [ ] Duplicate check runs automatically when staff reaches Preview step
- [ ] "Checking for similar recent emails..." loading state appears
- [ ] Warning card appears when similarity score ≥ 70
- [ ] Warning shows campaign name, days since sent, similarity score, previous subject line
- [ ] "View Previous Email" opens stored HTML in side panel
- [ ] "Dismiss and Continue" removes warning and allows send
- [ ] No warning shown when no similar emails found (silent pass)
- [ ] Maximum 3 warning cards shown even if more matches exist
- [ ] Endpoint returns empty array gracefully when no campaigns exist to compare

### Part 2 — Archive-Aware Composition
- [ ] `content_summary` column exists on `email_campaigns`
- [ ] Content summary is generated and stored after each send
- [ ] `/api/email-archive/recent-context` endpoint returns summaries
- [ ] AI generation includes recent context in system prompt when available
- [ ] "Referencing N recent emails" indicator appears when context is used
- [ ] Generation behavior unchanged when no context available (empty array)

### Part 3 — Recent Sends Panel
- [ ] "Recent sends" panel appears in composer after audience is selected
- [ ] Panel is collapsed by default
- [ ] Shows last 5 campaigns with subject, date, open rate, preview button
- [ ] Preview button opens stored HTML
- [ ] Shows "No previous emails" message when audience has no history
- [ ] Shows "Select an audience" prompt before audience is chosen

---

## ARCHITECTURAL NOTE FOR PRODUCTION PORT

- **Duplicate detection is tenant-scoped.** The endpoint must only compare against campaigns belonging to the same client. When multi-tenancy is implemented, add `client_id` filter to all archive queries used here.
- **Content summaries are generated once and cached.** Never regenerate a summary for an already-summarized campaign.
- **The 70% threshold is a starting point.** It should eventually be configurable per client in `tenant_config`. Add to parking lot.

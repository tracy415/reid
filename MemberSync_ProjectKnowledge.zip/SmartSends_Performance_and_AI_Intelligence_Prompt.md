# SmartSends: Performance Fixes & AI Database Intelligence

## Overview

This prompt addresses two critical issues:
1. **Performance**: Compliance screens taking 2-3 minutes to load
2. **AI Intelligence**: Claude needs to understand the business meaning of data to provide meaningful insights about agents, offices, production, and market share

---

# PART 1: PERFORMANCE FIXES

## Problem
The compliance screens load all members at once, causing 2-3 minute load times. This needs to be fixed with smart pagination, background processing, and caching.

## Solution: Pre-Computed Metrics Table

Create a new table that stores pre-calculated metrics, refreshed daily:

```sql
CREATE TABLE member_metrics_cache (
  member_key TEXT PRIMARY KEY,
  member_mls_id TEXT,
  member_name TEXT,
  member_email TEXT,
  office_key TEXT,
  office_name TEXT,
  member_status TEXT,
  member_type TEXT,
  nar_join_date DATE,
  
  -- Production metrics (pre-calculated)
  transactions_12mo INTEGER DEFAULT 0,
  transactions_24mo INTEGER DEFAULT 0,
  total_volume_12mo NUMERIC DEFAULT 0,
  total_volume_24mo NUMERIC DEFAULT 0,
  avg_price_12mo NUMERIC DEFAULT 0,
  listing_side_count INTEGER DEFAULT 0,
  buyer_side_count INTEGER DEFAULT 0,
  
  -- Engagement tier
  tier TEXT,  -- 'active_producer', 'occasional_producer', 'license_maintainer'
  engagement_score INTEGER DEFAULT 0,
  risk_level TEXT,  -- 'critical', 'high', 'medium', 'low'
  
  -- Education metrics
  ce_hours_completed NUMERIC DEFAULT 0,
  last_ce_date DATE,
  last_event_date DATE,
  coe_complete BOOLEAN DEFAULT false,
  
  -- Payment metrics
  has_overdue_invoice BOOLEAN DEFAULT false,
  days_overdue INTEGER DEFAULT 0,
  balance_due NUMERIC DEFAULT 0,
  
  -- Timestamps
  cached_at TIMESTAMP DEFAULT NOW(),
  metrics_calculated_at TIMESTAMP
);

CREATE INDEX idx_member_metrics_tier ON member_metrics_cache(tier);
CREATE INDEX idx_member_metrics_risk ON member_metrics_cache(risk_level);
CREATE INDEX idx_member_metrics_office ON member_metrics_cache(office_key);
CREATE INDEX idx_member_metrics_status ON member_metrics_cache(member_status);
CREATE INDEX idx_member_metrics_transactions ON member_metrics_cache(transactions_12mo DESC);
CREATE INDEX idx_member_metrics_volume ON member_metrics_cache(total_volume_12mo DESC);
```

## Daily Job: Refresh Member Metrics Cache (4:00 AM)

```typescript
// server/services/memberMetricsCacheService.ts

import { externalPool, localPool } from '../db';

export async function refreshMemberMetricsCache(): Promise<void> {
  console.log('[METRICS_CACHE] Starting daily refresh...');
  const startTime = Date.now();
  
  try {
    // Step 1: Get all active members from production
    const membersQuery = `
      SELECT DISTINCT ON (m."MemberKey")
        m."MemberKey",
        m."MemberMlsId",
        m."MemberFullName",
        m."MemberEmail",
        m."OfficeKey",
        m."MemberStatus",
        m."MemberType",
        m."NarJoinDate"
      FROM "AMS"."apmmember" m
      WHERE m."ApmClientId" = 'MainStreet'
        AND m."MemberStatus" = 'Active'
      ORDER BY m."MemberKey", m."ApmSourceModificationTimestamp" DESC
    `;
    
    const externalClient = await externalPool.connect();
    const membersResult = await externalClient.query(membersQuery);
    const members = membersResult.rows;
    externalClient.release();
    
    console.log(`[METRICS_CACHE] Processing ${members.length} members...`);
    
    // Step 2: Get transaction data in bulk
    const transactionsQuery = `
      WITH agent_transactions AS (
        SELECT 
          agent_mls_id,
          COUNT(CASE WHEN close_date >= NOW() - INTERVAL '12 months' THEN 1 END) as tx_12mo,
          COUNT(CASE WHEN close_date >= NOW() - INTERVAL '24 months' THEN 1 END) as tx_24mo,
          SUM(CASE WHEN close_date >= NOW() - INTERVAL '12 months' THEN close_price ELSE 0 END) as vol_12mo,
          SUM(CASE WHEN close_date >= NOW() - INTERVAL '24 months' THEN close_price ELSE 0 END) as vol_24mo,
          AVG(CASE WHEN close_date >= NOW() - INTERVAL '12 months' THEN close_price END) as avg_price_12mo,
          COUNT(CASE WHEN side = 'listing' AND close_date >= NOW() - INTERVAL '12 months' THEN 1 END) as listing_count,
          COUNT(CASE WHEN side = 'buyer' AND close_date >= NOW() - INTERVAL '12 months' THEN 1 END) as buyer_count
        FROM (
          SELECT "ListAgentMlsId" as agent_mls_id, "CloseDate" as close_date, "ClosePrice" as close_price, 'listing' as side
          FROM "MLS"."apmproperty"
          WHERE "ApmClientId" = 'MainStreet' AND "CloseDate" IS NOT NULL
          UNION ALL
          SELECT "BuyerAgentMlsId" as agent_mls_id, "CloseDate" as close_date, "ClosePrice" as close_price, 'buyer' as side
          FROM "MLS"."apmproperty"
          WHERE "ApmClientId" = 'MainStreet' AND "CloseDate" IS NOT NULL
        ) combined
        GROUP BY agent_mls_id
      )
      SELECT * FROM agent_transactions
    `;
    
    const txClient = await externalPool.connect();
    const txResult = await txClient.query(transactionsQuery);
    txClient.release();
    
    // Build lookup map
    const transactionMap = new Map();
    for (const row of txResult.rows) {
      transactionMap.set(row.agent_mls_id, row);
    }
    
    // Step 3: Get payment data in bulk
    const paymentQuery = `
      SELECT 
        "MemberKey",
        COUNT(*) as overdue_count,
        MAX(CURRENT_DATE - "DueDate") as max_days_overdue,
        SUM("BalanceDue") as total_balance_due
      FROM "AMS"."apmmemberdues"
      WHERE "ApmClientId" = 'MainStreet'
        AND "DueDate" < CURRENT_DATE
        AND COALESCE("PaidStatus", false) = false
        AND "BalanceDue" > 0
      GROUP BY "MemberKey"
    `;
    
    const payClient = await externalPool.connect();
    const payResult = await payClient.query(paymentQuery);
    payClient.release();
    
    const paymentMap = new Map();
    for (const row of payResult.rows) {
      paymentMap.set(row.MemberKey, row);
    }
    
    // Step 4: Get office names
    const officeQuery = `
      SELECT DISTINCT ON ("OfficeKey") "OfficeKey", "OfficeName"
      FROM "MLS"."apmoffice"
      WHERE "ApmClientId" = 'MainStreet'
      ORDER BY "OfficeKey", "ApmSourceModificationTimestamp" DESC
    `;
    
    const officeClient = await externalPool.connect();
    const officeResult = await officeClient.query(officeQuery);
    officeClient.release();
    
    const officeMap = new Map();
    for (const row of officeResult.rows) {
      officeMap.set(row.OfficeKey, row.OfficeName);
    }
    
    // Step 5: Truncate and rebuild cache
    const localClient = await localPool.connect();
    await localClient.query('TRUNCATE member_metrics_cache');
    
    // Process in batches of 500
    const BATCH_SIZE = 500;
    for (let i = 0; i < members.length; i += BATCH_SIZE) {
      const batch = members.slice(i, i + BATCH_SIZE);
      
      const values = batch.map(m => {
        const tx = transactionMap.get(m.MemberMlsId) || {};
        const pay = paymentMap.get(m.MemberKey) || {};
        
        const tx12 = parseInt(tx.tx_12mo) || 0;
        const tx24 = parseInt(tx.tx_24mo) || 0;
        
        // Determine tier
        let tier = 'license_maintainer';
        if (tx12 >= 2) tier = 'active_producer';
        else if (tx24 >= 1) tier = 'occasional_producer';
        
        // Calculate basic engagement score (0-10)
        let score = 0;
        if (tx12 >= 5) score += 4;
        else if (tx12 >= 3) score += 3;
        else if (tx12 >= 1) score += 2;
        else if (tx24 >= 1) score += 1;
        
        // Risk level
        let risk = 'medium';
        if (score >= 6) risk = 'low';
        else if (score >= 4) risk = 'medium';
        else if (score >= 2) risk = 'high';
        else risk = 'critical';
        
        return `(
          '${m.MemberKey}',
          ${m.MemberMlsId ? `'${m.MemberMlsId}'` : 'NULL'},
          '${(m.MemberFullName || '').replace(/'/g, "''")}',
          ${m.MemberEmail ? `'${m.MemberEmail}'` : 'NULL'},
          ${m.OfficeKey ? `'${m.OfficeKey}'` : 'NULL'},
          '${(officeMap.get(m.OfficeKey) || '').replace(/'/g, "''")}',
          '${m.MemberStatus}',
          '${m.MemberType || 'REALTOR'}',
          ${m.NarJoinDate ? `'${m.NarJoinDate}'` : 'NULL'},
          ${tx12},
          ${tx24},
          ${parseFloat(tx.vol_12mo) || 0},
          ${parseFloat(tx.vol_24mo) || 0},
          ${parseFloat(tx.avg_price_12mo) || 0},
          ${parseInt(tx.listing_count) || 0},
          ${parseInt(tx.buyer_count) || 0},
          '${tier}',
          ${score},
          '${risk}',
          ${pay.overdue_count ? 'true' : 'false'},
          ${parseInt(pay.max_days_overdue) || 0},
          ${parseFloat(pay.total_balance_due) || 0},
          NOW(),
          NOW()
        )`;
      });
      
      const insertQuery = `
        INSERT INTO member_metrics_cache (
          member_key, member_mls_id, member_name, member_email,
          office_key, office_name, member_status, member_type, nar_join_date,
          transactions_12mo, transactions_24mo, total_volume_12mo, total_volume_24mo,
          avg_price_12mo, listing_side_count, buyer_side_count,
          tier, engagement_score, risk_level,
          has_overdue_invoice, days_overdue, balance_due,
          cached_at, metrics_calculated_at
        ) VALUES ${values.join(',\n')}
      `;
      
      await localClient.query(insertQuery);
    }
    
    localClient.release();
    
    const duration = (Date.now() - startTime) / 1000;
    console.log(`[METRICS_CACHE] Completed in ${duration}s - ${members.length} members cached`);
    
  } catch (error) {
    console.error('[METRICS_CACHE] Error:', error);
    throw error;
  }
}
```

## Updated API Endpoints (Fast)

Replace the slow compliance endpoints with fast cached queries:

```typescript
// GET /api/members - now uses cache (< 100ms)
app.get("/api/members", authMiddleware, async (req, res) => {
  const { 
    page = 1, 
    limit = 50, 
    tier, 
    risk, 
    office,
    sortBy = 'member_name',
    sortOrder = 'asc'
  } = req.query;
  
  const offset = (Number(page) - 1) * Number(limit);
  
  let whereClause = "WHERE member_status = 'Active'";
  if (tier) whereClause += ` AND tier = '${tier}'`;
  if (risk) whereClause += ` AND risk_level = '${risk}'`;
  if (office) whereClause += ` AND office_key = '${office}'`;
  
  const validSortColumns = ['member_name', 'transactions_12mo', 'total_volume_12mo', 'engagement_score', 'nar_join_date'];
  const sortColumn = validSortColumns.includes(sortBy as string) ? sortBy : 'member_name';
  const order = sortOrder === 'desc' ? 'DESC' : 'ASC';
  
  const [countResult, dataResult] = await Promise.all([
    localPool.query(`SELECT COUNT(*) FROM member_metrics_cache ${whereClause}`),
    localPool.query(`
      SELECT * FROM member_metrics_cache 
      ${whereClause}
      ORDER BY ${sortColumn} ${order}
      LIMIT ${limit} OFFSET ${offset}
    `)
  ]);
  
  res.json({
    data: dataResult.rows,
    total: parseInt(countResult.rows[0].count),
    page: Number(page),
    limit: Number(limit)
  });
});

// GET /api/dashboard/metrics - aggregated from cache (< 50ms)
app.get("/api/dashboard/metrics", authMiddleware, async (req, res) => {
  const result = await localPool.query(`
    SELECT 
      COUNT(*) as total_members,
      COUNT(*) FILTER (WHERE tier = 'active_producer') as active_producers,
      COUNT(*) FILTER (WHERE tier = 'occasional_producer') as occasional_producers,
      COUNT(*) FILTER (WHERE tier = 'license_maintainer') as license_maintainers,
      COUNT(*) FILTER (WHERE risk_level = 'critical') as critical_risk,
      COUNT(*) FILTER (WHERE risk_level = 'high') as high_risk,
      COUNT(*) FILTER (WHERE has_overdue_invoice = true) as overdue_invoices,
      SUM(total_volume_12mo) as total_volume_12mo,
      AVG(engagement_score) as avg_engagement_score
    FROM member_metrics_cache
    WHERE member_status = 'Active'
  `);
  
  res.json(result.rows[0]);
});
```

---

# PART 2: AI DATABASE INTELLIGENCE

## The Problem

Claude currently knows the basic table structure but doesn't understand:
- What makes a "top producer" vs an average agent
- How to calculate market share
- What property types exist and what they mean
- How to compare agents meaningfully
- Geographic market dynamics
- Office/brokerage performance patterns

## Solution: Enhanced Database Context

Replace the existing `DATABASE_SCHEMA` constant in `aiAudienceService.ts` with this comprehensive business intelligence context:

```typescript
const DATABASE_SCHEMA = `
# MAINSTREET REALTORS DATABASE - BUSINESS INTELLIGENCE GUIDE

You are an AI assistant for Mainstreet REALTORSÂ®, a real estate association in the Chicago suburbs 
with approximately 18,000+ members. You have read-only access to their production database.

## CORE TABLES

### AMS.apmmember (Member/Agent Data)
| Column | Type | Description |
|--------|------|-------------|
| MemberKey | text | Unique member identifier (PRIMARY) |
| MemberMlsId | text | MLS ID - links to transactions |
| MemberFullName | text | Display name |
| MemberFirstName, MemberLastName | text | Name components |
| MemberEmail | text | Primary email |
| MemberMobilePhone, MemberDirectPhone | text | Contact numbers |
| MemberType | text | 'REALTOR', 'Leasing Agent', 'Secondary' |
| MemberStatus | text | 'Active', 'Suspended', 'Inactive' |
| MemberStateLicense | text | Illinois license number |
| MemberStateLicenseExpirationDate | date | License expiration |
| MemberDesignations | jsonb | Professional designations (ABR, CRS, GRI, etc.) |
| NarJoinDate | date | When they joined Mainstreet (tenure indicator) |
| OfficeKey | text | Links to their brokerage |
| ApmClientId | text | ALWAYS filter = 'MainStreet' |

### MLS.apmproperty (Transaction/Listing Data)
| Column | Type | Description |
|--------|------|-------------|
| ListingId | text | Unique listing identifier |
| ListAgentMlsId | text | Listing agent's MLS ID |
| BuyerAgentMlsId | text | Buyer's agent MLS ID |
| OnMarketDate | date | When listed |
| CloseDate | date | When sale closed (NULL if not closed) |
| ListPrice | numeric | Original asking price |
| ClosePrice | numeric | Final sale price |
| StandardStatus | text | 'Active', 'Pending', 'Closed', 'Expired', 'Withdrawn' |
| PropertyType | text | 'Residential', 'Condo/Townhouse', 'Multi-Family', 'Land', 'Commercial' |
| PropertySubType | text | More specific: 'Single Family', 'Townhouse', 'Condo', 'Duplex', etc. |
| UnparsedAddress | text | Full street address |
| City | text | Municipality (suburbs vary significantly) |
| PostalCode | text | ZIP code |
| BedroomsTotal | integer | Number of bedrooms |
| BathroomsTotalInteger | integer | Number of bathrooms |
| LivingArea | numeric | Square footage |
| ApmClientId | text | ALWAYS filter = 'MainStreet' |

### MLS.apmoffice (Brokerage/Office Data)
| Column | Type | Description |
|--------|------|-------------|
| OfficeKey | text | Unique office identifier |
| OfficeName | text | Brokerage name |
| OfficeBrokerKey | text | Links to Designated REALTOR (broker) |
| OfficeStatus | text | 'Active' or 'Inactive' |
| OfficeAddress1, OfficeCity, OfficePostalCode | text | Office location |
| OfficePhone, OfficeEmail | text | Contact info |
| ApmClientId | text | ALWAYS filter = 'MainStreet' |

### AMS.apmmemberdues (Invoice/Payment Data)
| Column | Type | Description |
|--------|------|-------------|
| MemberKey | text | Links to member |
| InvoiceKey | text | Invoice identifier |
| InvoiceDate | date | When invoice created |
| DueDate | date | Payment due date |
| InvoiceTotal | numeric | Total amount |
| AmountPaid | numeric | Amount paid so far |
| BalanceDue | numeric | Remaining balance |
| PaidStatus | boolean | True if fully paid |
| ApmClientId | text | ALWAYS filter = 'MainStreet' |

## BUSINESS INTELLIGENCE CONCEPTS

### Member Tiers (Based on Production)
Mainstreet categorizes agents by their transaction activity:

1. **Active Producers** (30-50% of members)
   - 2+ closed transactions in last 12 months
   - These are the full-time, producing agents
   - Highest value to the association

2. **Occasional Producers** (20-30% of members)
   - 1+ closed transactions in last 24 months, but <2 in last 12
   - Part-time agents or those having a slow period
   - At risk of becoming inactive

3. **License Maintainers** (20-40% of members)
   - 0 transactions in last 24 months
   - Keeping license active for various reasons
   - May be retired, referral-only, or have another primary job
   - Still valuable members who pay dues and attend events

### Transaction Sides
An agent can be on either "side" of a transaction:
- **Listing Side**: Agent represented the seller ("ListAgentMlsId")
- **Buyer Side**: Agent represented the buyer ("BuyerAgentMlsId")
- Some agents specialize in one side; top producers excel at both

### Market Share Calculation
Market share = (Agent's closed transactions / Total market transactions) Ã— 100
- Can be calculated by volume (dollar amount) or by count (number of deals)
- Can be filtered by geography (city, ZIP), property type, or time period

### Price Tiers (Chicago Suburbs Context)
| Price Range | Market Segment | Typical Areas |
|-------------|----------------|---------------|
| Under $200K | Entry-level/Investor | Older suburbs, condos |
| $200K-$400K | First-time buyers | Most suburban areas |
| $400K-$600K | Move-up buyers | Established suburbs |
| $600K-$1M | Luxury suburban | Premium suburbs |
| $1M+ | Ultra-luxury | North Shore, high-end |

### Geographic Markets
Different suburbs have different dynamics:
- **North Shore**: Highland Park, Wilmette, Winnetka - luxury market
- **Northwest suburbs**: Arlington Heights, Schaumburg - family-oriented
- **Western suburbs**: Naperville, Wheaton - growing areas
- **South suburbs**: More affordable, investor activity

### Office/Brokerage Performance
Key metrics for evaluating a brokerage:
- Total agent count
- Total transaction count and volume
- Average transactions per agent (productivity)
- Agent retention rate
- Market share in key cities

## QUERY PATTERNS FOR COMMON QUESTIONS

### "Who are the top producers?"
\`\`\`sql
WITH agent_production AS (
  SELECT 
    m."MemberKey",
    m."MemberFullName",
    m."MemberEmail",
    m."OfficeKey",
    COUNT(DISTINCT p."ListingId") as total_transactions,
    SUM(p."ClosePrice") as total_volume,
    COUNT(DISTINCT CASE WHEN p."ListAgentMlsId" = m."MemberMlsId" THEN p."ListingId" END) as listing_sides,
    COUNT(DISTINCT CASE WHEN p."BuyerAgentMlsId" = m."MemberMlsId" THEN p."ListingId" END) as buyer_sides
  FROM "AMS"."apmmember" m
  LEFT JOIN "MLS"."apmproperty" p 
    ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
    AND p."CloseDate" >= NOW() - INTERVAL '12 months'
    AND p."ApmClientId" = 'MainStreet'
  WHERE m."ApmClientId" = 'MainStreet'
    AND m."MemberStatus" = 'Active'
  GROUP BY m."MemberKey", m."MemberFullName", m."MemberEmail", m."OfficeKey"
)
SELECT * FROM agent_production
ORDER BY total_volume DESC
LIMIT 100
\`\`\`

### "What's the market share by office in [City]?"
\`\`\`sql
WITH city_market AS (
  SELECT COUNT(DISTINCT "ListingId") as total_transactions
  FROM "MLS"."apmproperty"
  WHERE "ApmClientId" = 'MainStreet'
    AND "CloseDate" >= NOW() - INTERVAL '12 months'
    AND "City" = '[CITY_NAME]'
),
office_production AS (
  SELECT 
    o."OfficeName",
    COUNT(DISTINCT p."ListingId") as office_transactions
  FROM "MLS"."apmoffice" o
  JOIN "AMS"."apmmember" m ON m."OfficeKey" = o."OfficeKey" AND m."ApmClientId" = 'MainStreet'
  JOIN "MLS"."apmproperty" p 
    ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
    AND p."CloseDate" >= NOW() - INTERVAL '12 months'
    AND p."City" = '[CITY_NAME]'
  WHERE o."ApmClientId" = 'MainStreet'
  GROUP BY o."OfficeName"
)
SELECT 
  op."OfficeName",
  op.office_transactions,
  ROUND(100.0 * op.office_transactions / cm.total_transactions, 2) as market_share_pct
FROM office_production op
CROSS JOIN city_market cm
ORDER BY office_transactions DESC
LIMIT 20
\`\`\`

### "Show me the luxury market specialists"
\`\`\`sql
SELECT 
  m."MemberKey",
  m."MemberFullName",
  m."MemberEmail",
  o."OfficeName",
  COUNT(DISTINCT p."ListingId") as luxury_transactions,
  SUM(p."ClosePrice") as luxury_volume,
  AVG(p."ClosePrice") as avg_sale_price
FROM "AMS"."apmmember" m
JOIN "MLS"."apmoffice" o ON o."OfficeKey" = m."OfficeKey" AND o."ApmClientId" = 'MainStreet'
JOIN "MLS"."apmproperty" p 
  ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
  AND p."CloseDate" >= NOW() - INTERVAL '12 months'
  AND p."ClosePrice" >= 1000000
WHERE m."ApmClientId" = 'MainStreet'
  AND m."MemberStatus" = 'Active'
GROUP BY m."MemberKey", m."MemberFullName", m."MemberEmail", o."OfficeName"
HAVING COUNT(DISTINCT p."ListingId") >= 3
ORDER BY luxury_volume DESC
LIMIT 50
\`\`\`

### "Compare property types sold in the last year"
\`\`\`sql
SELECT 
  "PropertyType",
  COUNT(*) as transaction_count,
  SUM("ClosePrice") as total_volume,
  AVG("ClosePrice") as avg_price,
  MIN("ClosePrice") as min_price,
  MAX("ClosePrice") as max_price,
  ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER(), 2) as pct_of_market
FROM "MLS"."apmproperty"
WHERE "ApmClientId" = 'MainStreet'
  AND "CloseDate" >= NOW() - INTERVAL '12 months'
  AND "ClosePrice" IS NOT NULL
GROUP BY "PropertyType"
ORDER BY transaction_count DESC
\`\`\`

### "Find agents who specialize in condos"
\`\`\`sql
WITH agent_specialization AS (
  SELECT 
    m."MemberKey",
    m."MemberFullName",
    m."MemberEmail",
    COUNT(DISTINCT p."ListingId") as total_transactions,
    COUNT(DISTINCT CASE WHEN p."PropertyType" = 'Condo/Townhouse' THEN p."ListingId" END) as condo_transactions
  FROM "AMS"."apmmember" m
  JOIN "MLS"."apmproperty" p 
    ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
    AND p."CloseDate" >= NOW() - INTERVAL '12 months'
  WHERE m."ApmClientId" = 'MainStreet'
    AND m."MemberStatus" = 'Active'
  GROUP BY m."MemberKey", m."MemberFullName", m."MemberEmail"
  HAVING COUNT(DISTINCT p."ListingId") >= 5
)
SELECT *,
  ROUND(100.0 * condo_transactions / total_transactions, 1) as condo_pct
FROM agent_specialization
WHERE condo_transactions >= 3
ORDER BY condo_pct DESC, condo_transactions DESC
LIMIT 50
\`\`\`

### "Show new agents (joined in last 2 years) with strong starts"
\`\`\`sql
SELECT 
  m."MemberKey",
  m."MemberFullName",
  m."MemberEmail",
  m."NarJoinDate",
  DATE_PART('day', NOW() - m."NarJoinDate"::timestamp) as days_as_member,
  o."OfficeName",
  COUNT(DISTINCT p."ListingId") as transactions,
  SUM(p."ClosePrice") as volume
FROM "AMS"."apmmember" m
JOIN "MLS"."apmoffice" o ON o."OfficeKey" = m."OfficeKey" AND o."ApmClientId" = 'MainStreet'
LEFT JOIN "MLS"."apmproperty" p 
  ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
  AND p."CloseDate" >= m."NarJoinDate"
WHERE m."ApmClientId" = 'MainStreet'
  AND m."MemberStatus" = 'Active'
  AND m."NarJoinDate" >= NOW() - INTERVAL '2 years'
GROUP BY m."MemberKey", m."MemberFullName", m."MemberEmail", m."NarJoinDate", o."OfficeName"
HAVING COUNT(DISTINCT p."ListingId") >= 5
ORDER BY transactions DESC
LIMIT 50
\`\`\`

## CRITICAL QUERY RULES

1. **ALWAYS** include: WHERE "ApmClientId" = 'MainStreet'
2. **ALWAYS** use DISTINCT ON for member queries due to data duplication
3. **ALWAYS** limit results (max 1000 for audiences, reasonable limits for analytics)
4. **JOIN** members to transactions via MemberMlsId = ListAgentMlsId OR BuyerAgentMlsId
5. **Use** double quotes for all column names (PostgreSQL case-sensitive)
6. For transaction counts, COUNT DISTINCT ListingId to avoid double-counting

## INSIGHT GENERATION GUIDELINES

When asked analytical questions, provide:
1. **The data** - actual numbers from queries
2. **Context** - how this compares to typical patterns
3. **Insights** - what the data suggests
4. **Recommendations** - actionable next steps

Example: "Our top 10% of agents (by volume) closed $X in transactions, representing Y% of total market volume. 
The average top performer had Z transactions, with a mix of listing and buyer sides..."
`;
```

## Update Allowed Tables

In the `validateSQLQuery` function, update the allowed tables:

```typescript
const allowedTables = [
  'apmmember', 
  'apmproperty', 
  'apmmemberdues', 
  'apmevent', 
  'apmeventregistration', 
  'apmmembereducation',
  'apmoffice'  // ADD THIS
];
```

Also update the table pattern to handle both AMS and MLS schemas:

```typescript
const tablePattern = /FROM\s+["']?(?:(AMS|MLS)\s*\.\s*)?["']?(\w+)/gi;
```

---

# PART 3: OFFICE METRICS CACHE

For office/brokerage analytics, add this table and daily job:

```sql
CREATE TABLE office_metrics_cache (
  office_key TEXT PRIMARY KEY,
  office_name TEXT,
  broker_key TEXT,
  broker_name TEXT,
  office_status TEXT,
  
  -- Agent metrics
  total_agents INTEGER DEFAULT 0,
  active_producers INTEGER DEFAULT 0,
  occasional_producers INTEGER DEFAULT 0,
  license_maintainers INTEGER DEFAULT 0,
  
  -- Production metrics
  total_transactions_12mo INTEGER DEFAULT 0,
  total_volume_12mo NUMERIC DEFAULT 0,
  avg_transactions_per_agent NUMERIC DEFAULT 0,
  avg_volume_per_agent NUMERIC DEFAULT 0,
  
  -- Market position
  top_city TEXT,
  top_city_transactions INTEGER DEFAULT 0,
  
  -- Risk metrics
  agents_with_overdue INTEGER DEFAULT 0,
  total_balance_due NUMERIC DEFAULT 0,
  
  cached_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_office_metrics_status ON office_metrics_cache(office_status);
CREATE INDEX idx_office_metrics_volume ON office_metrics_cache(total_volume_12mo DESC);
CREATE INDEX idx_office_metrics_agents ON office_metrics_cache(total_agents DESC);
```

---

# IMPLEMENTATION ORDER

1. **Create the tables** (member_metrics_cache, office_metrics_cache)
2. **Create the daily refresh jobs** (add to scheduled jobs at 4:00 AM)
3. **Update API endpoints** to use cached data
4. **Replace DATABASE_SCHEMA** in aiAudienceService.ts
5. **Test** - verify fast load times and AI can generate meaningful queries

This should transform load times from 2-3 minutes to under 1 second, and give Claude the business intelligence to provide meaningful insights about agents, offices, and market dynamics.

---

# PART 4: CELEBRATION ENGINE (Fun AI Insights)

## The Problem

The current AI Insights feature shows alarming, dense text blocks like "Urgent License Renewal Alert" - nobody wants to start their day with anxiety. The insights are also too long and don't lead anywhere actionable.

## The Solution: Celebration Engine

Transform AI Insights into a **celebration engine** that surfaces positive achievements and milestones. Each insight is:
- Short (one sentence)
- Celebratory (emoji + achievement)
- Actionable (direct link to send congratulations email)

## Database Table for Tracking Milestones

```sql
CREATE TABLE member_milestones (
  milestone_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_key TEXT NOT NULL,
  member_name TEXT NOT NULL,
  member_email TEXT,
  milestone_type TEXT NOT NULL,  -- See types below
  milestone_value INTEGER,        -- The number (25 transactions, 5 years, etc.)
  milestone_label TEXT NOT NULL,  -- Human-readable: "25th transaction"
  milestone_emoji TEXT,           -- ðŸŽ‰ ðŸ† ðŸŒŸ etc.
  context_json JSONB,             -- Additional context for the email
  detected_at TIMESTAMP DEFAULT NOW(),
  is_dismissed BOOLEAN DEFAULT false,
  dismissed_by UUID,
  dismissed_at TIMESTAMP,
  email_sent BOOLEAN DEFAULT false,
  email_sent_at TIMESTAMP,
  email_campaign_id UUID,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_milestones_pending ON member_milestones(is_dismissed, email_sent, detected_at DESC);
CREATE INDEX idx_milestones_member ON member_milestones(member_key);
CREATE INDEX idx_milestones_type ON member_milestones(milestone_type);
```

## Milestone Types

| Type | Description | Example |
|------|-------------|---------|
| `transaction_milestone` | Hit a round number of career closings | "25th transaction!" |
| `volume_milestone` | Hit a volume milestone | "$5M in career volume" |
| `personal_best_month` | Best month ever by count | "Best month ever - 6 closings!" |
| `personal_best_quarter` | Best quarter ever | "Best quarter - 12 closings!" |
| `membership_anniversary` | Years as a member | "5-year Mainstreet anniversary" |
| `rookie_star` | New member with strong start | "3 closings in first 6 months" |
| `comeback` | Returned to production after drought | "Back in action after 18 months" |
| `specialization` | Dominating a niche | "Condo specialist - 80% of deals" |
| `listing_milestone` | Listing-side milestone | "50th listing sold" |
| `buyer_milestone` | Buyer-side milestone | "100th buyer helped" |
| `first_million` | First $1M+ sale | "First million-dollar sale!" |
| `luxury_entry` | Entered luxury market | "First $1M+ listing" |

## Daily Job: Detect Milestones (4:30 AM)

```typescript
// server/services/milestoneDetectionService.ts

const TRANSACTION_MILESTONES = [10, 25, 50, 75, 100, 150, 200, 250, 500, 1000];
const VOLUME_MILESTONES = [1000000, 2500000, 5000000, 10000000, 25000000, 50000000, 100000000];
const ANNIVERSARY_YEARS = [1, 2, 3, 5, 10, 15, 20, 25];

interface Milestone {
  memberKey: string;
  memberName: string;
  memberEmail: string | null;
  milestoneType: string;
  milestoneValue: number;
  milestoneLabel: string;
  milestoneEmoji: string;
  contextJson: Record<string, any>;
}

export async function detectMilestones(): Promise<void> {
  console.log('[MILESTONES] Starting daily detection...');
  const milestones: Milestone[] = [];
  
  // 1. Transaction milestones (career totals)
  const txMilestones = await detectTransactionMilestones();
  milestones.push(...txMilestones);
  
  // 2. Volume milestones
  const volMilestones = await detectVolumeMilestones();
  milestones.push(...volMilestones);
  
  // 3. Personal best months/quarters
  const personalBests = await detectPersonalBests();
  milestones.push(...personalBests);
  
  // 4. Membership anniversaries (check daily)
  const anniversaries = await detectAnniversaries();
  milestones.push(...anniversaries);
  
  // 5. Rookie stars (new members performing well)
  const rookies = await detectRookieStars();
  milestones.push(...rookies);
  
  // 6. Comebacks (agents returning to production)
  const comebacks = await detectComebacks();
  milestones.push(...comebacks);
  
  // Insert new milestones (skip if already detected)
  for (const m of milestones) {
    await insertMilestoneIfNew(m);
  }
  
  console.log(`[MILESTONES] Detected ${milestones.length} potential milestones`);
}

async function detectTransactionMilestones(): Promise<Milestone[]> {
  const results: Milestone[] = [];
  
  const query = `
    WITH career_totals AS (
      SELECT 
        m."MemberKey",
        m."MemberFullName",
        m."MemberEmail",
        COUNT(DISTINCT p."ListingId") as career_transactions
      FROM "AMS"."apmmember" m
      JOIN "MLS"."apmproperty" p 
        ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
        AND p."CloseDate" IS NOT NULL
      WHERE m."ApmClientId" = 'MainStreet'
        AND m."MemberStatus" = 'Active'
      GROUP BY m."MemberKey", m."MemberFullName", m."MemberEmail"
    )
    SELECT * FROM career_totals
    WHERE career_transactions IN (${TRANSACTION_MILESTONES.join(',')})
  `;
  
  const client = await externalPool.connect();
  const res = await client.query(query);
  client.release();
  
  for (const row of res.rows) {
    const count = parseInt(row.career_transactions);
    results.push({
      memberKey: row.MemberKey,
      memberName: row.MemberFullName,
      memberEmail: row.MemberEmail,
      milestoneType: 'transaction_milestone',
      milestoneValue: count,
      milestoneLabel: `${count}${getOrdinalSuffix(count)} career transaction`,
      milestoneEmoji: count >= 100 ? 'ðŸ†' : 'ðŸŽ‰',
      contextJson: { careerTransactions: count }
    });
  }
  
  return results;
}

async function detectPersonalBests(): Promise<Milestone[]> {
  const results: Milestone[] = [];
  
  // Find agents whose current month is their best ever
  const query = `
    WITH monthly_stats AS (
      SELECT 
        m."MemberKey",
        m."MemberFullName", 
        m."MemberEmail",
        DATE_TRUNC('month', p."CloseDate") as month,
        COUNT(DISTINCT p."ListingId") as monthly_count
      FROM "AMS"."apmmember" m
      JOIN "MLS"."apmproperty" p 
        ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
        AND p."CloseDate" IS NOT NULL
      WHERE m."ApmClientId" = 'MainStreet'
        AND m."MemberStatus" = 'Active'
      GROUP BY m."MemberKey", m."MemberFullName", m."MemberEmail", DATE_TRUNC('month', p."CloseDate")
    ),
    best_months AS (
      SELECT 
        "MemberKey",
        "MemberFullName",
        "MemberEmail",
        MAX(monthly_count) as best_month_ever,
        MAX(CASE WHEN month = DATE_TRUNC('month', CURRENT_DATE) THEN monthly_count END) as this_month
      FROM monthly_stats
      GROUP BY "MemberKey", "MemberFullName", "MemberEmail"
    )
    SELECT * FROM best_months
    WHERE this_month = best_month_ever
      AND this_month >= 4  -- Only celebrate if it's meaningful (4+ deals)
  `;
  
  const client = await externalPool.connect();
  const res = await client.query(query);
  client.release();
  
  for (const row of res.rows) {
    results.push({
      memberKey: row.MemberKey,
      memberName: row.MemberFullName,
      memberEmail: row.MemberEmail,
      milestoneType: 'personal_best_month',
      milestoneValue: parseInt(row.this_month),
      milestoneLabel: `Best month ever with ${row.this_month} closings!`,
      milestoneEmoji: 'ðŸ“ˆ',
      contextJson: { monthlyCount: parseInt(row.this_month) }
    });
  }
  
  return results;
}

async function detectAnniversaries(): Promise<Milestone[]> {
  const results: Milestone[] = [];
  
  // Find members whose NarJoinDate anniversary is today
  const query = `
    WITH member_anniversaries AS (
      SELECT DISTINCT ON (m."MemberKey")
        m."MemberKey",
        m."MemberFullName",
        m."MemberEmail",
        m."NarJoinDate",
        DATE_PART('year', AGE(CURRENT_DATE, m."NarJoinDate"::date)) as years_member,
        (SELECT COUNT(DISTINCT p."ListingId") 
         FROM "MLS"."apmproperty" p 
         WHERE (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
           AND p."CloseDate" IS NOT NULL) as career_transactions
      FROM "AMS"."apmmember" m
      WHERE m."ApmClientId" = 'MainStreet'
        AND m."MemberStatus" = 'Active'
        AND m."NarJoinDate" IS NOT NULL
        -- Anniversary is today (same month and day)
        AND DATE_PART('month', m."NarJoinDate") = DATE_PART('month', CURRENT_DATE)
        AND DATE_PART('day', m."NarJoinDate") = DATE_PART('day', CURRENT_DATE)
      ORDER BY m."MemberKey", m."ApmSourceModificationTimestamp" DESC
    )
    SELECT * FROM member_anniversaries
    WHERE years_member IN (${ANNIVERSARY_YEARS.join(',')})
  `;
  
  const client = await externalPool.connect();
  const res = await client.query(query);
  client.release();
  
  for (const row of res.rows) {
    const years = parseInt(row.years_member);
    results.push({
      memberKey: row.MemberKey,
      memberName: row.MemberFullName,
      memberEmail: row.MemberEmail,
      milestoneType: 'membership_anniversary',
      milestoneValue: years,
      milestoneLabel: `${years}-year Mainstreet anniversary`,
      milestoneEmoji: years >= 10 ? 'ðŸŒŸ' : 'ðŸŽ‚',
      contextJson: { 
        yearsAsMember: years, 
        careerTransactions: parseInt(row.career_transactions) || 0,
        joinDate: row.NarJoinDate
      }
    });
  }
  
  return results;
}

async function detectRookieStars(): Promise<Milestone[]> {
  const results: Milestone[] = [];
  
  // New members (joined in last 12 months) with 3+ transactions
  const query = `
    SELECT DISTINCT ON (m."MemberKey")
      m."MemberKey",
      m."MemberFullName",
      m."MemberEmail",
      m."NarJoinDate",
      DATE_PART('day', NOW() - m."NarJoinDate"::timestamp) as days_as_member,
      COUNT(DISTINCT p."ListingId") as transactions
    FROM "AMS"."apmmember" m
    JOIN "MLS"."apmproperty" p 
      ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
      AND p."CloseDate" >= m."NarJoinDate"
    WHERE m."ApmClientId" = 'MainStreet'
      AND m."MemberStatus" = 'Active'
      AND m."NarJoinDate" >= NOW() - INTERVAL '12 months'
    GROUP BY m."MemberKey", m."MemberFullName", m."MemberEmail", m."NarJoinDate"
    HAVING COUNT(DISTINCT p."ListingId") >= 3
    ORDER BY m."MemberKey", m."ApmSourceModificationTimestamp" DESC
  `;
  
  const client = await externalPool.connect();
  const res = await client.query(query);
  client.release();
  
  for (const row of res.rows) {
    const months = Math.floor(parseInt(row.days_as_member) / 30);
    results.push({
      memberKey: row.MemberKey,
      memberName: row.MemberFullName,
      memberEmail: row.MemberEmail,
      milestoneType: 'rookie_star',
      milestoneValue: parseInt(row.transactions),
      milestoneLabel: `${row.transactions} closings in first ${months} months - rising star!`,
      milestoneEmoji: 'ðŸŒŸ',
      contextJson: { 
        transactions: parseInt(row.transactions),
        monthsAsMember: months
      }
    });
  }
  
  return results;
}

async function detectComebacks(): Promise<Milestone[]> {
  const results: Milestone[] = [];
  
  // Agents who had 12+ months without a deal, then got 2+ in last 3 months
  const query = `
    WITH agent_gaps AS (
      SELECT 
        m."MemberKey",
        m."MemberFullName",
        m."MemberEmail",
        MAX(CASE WHEN p."CloseDate" < NOW() - INTERVAL '3 months' THEN p."CloseDate" END) as last_old_close,
        COUNT(DISTINCT CASE WHEN p."CloseDate" >= NOW() - INTERVAL '3 months' THEN p."ListingId" END) as recent_transactions
      FROM "AMS"."apmmember" m
      JOIN "MLS"."apmproperty" p 
        ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
        AND p."CloseDate" IS NOT NULL
      WHERE m."ApmClientId" = 'MainStreet'
        AND m."MemberStatus" = 'Active'
      GROUP BY m."MemberKey", m."MemberFullName", m."MemberEmail"
    )
    SELECT *,
      DATE_PART('day', NOW() - INTERVAL '3 months' - last_old_close) as gap_days
    FROM agent_gaps
    WHERE recent_transactions >= 2
      AND (last_old_close IS NULL OR last_old_close < NOW() - INTERVAL '15 months')
  `;
  
  const client = await externalPool.connect();
  const res = await client.query(query);
  client.release();
  
  for (const row of res.rows) {
    const gapMonths = Math.floor((parseInt(row.gap_days) || 365) / 30);
    results.push({
      memberKey: row.MemberKey,
      memberName: row.MemberFullName,
      memberEmail: row.MemberEmail,
      milestoneType: 'comeback',
      milestoneValue: parseInt(row.recent_transactions),
      milestoneLabel: `Back in action with ${row.recent_transactions} deals after ${gapMonths}+ months!`,
      milestoneEmoji: 'ðŸ’ª',
      contextJson: { 
        recentTransactions: parseInt(row.recent_transactions),
        gapMonths: gapMonths
      }
    });
  }
  
  return results;
}

async function insertMilestoneIfNew(milestone: Milestone): Promise<void> {
  // Check if this exact milestone was already detected in the last 30 days
  const checkQuery = `
    SELECT milestone_id FROM member_milestones
    WHERE member_key = $1
      AND milestone_type = $2
      AND milestone_value = $3
      AND detected_at >= NOW() - INTERVAL '30 days'
  `;
  
  const client = await localPool.connect();
  const existing = await client.query(checkQuery, [
    milestone.memberKey,
    milestone.milestoneType,
    milestone.milestoneValue
  ]);
  
  if (existing.rows.length === 0) {
    await client.query(`
      INSERT INTO member_milestones (
        member_key, member_name, member_email,
        milestone_type, milestone_value, milestone_label,
        milestone_emoji, context_json
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `, [
      milestone.memberKey,
      milestone.memberName,
      milestone.memberEmail,
      milestone.milestoneType,
      milestone.milestoneValue,
      milestone.milestoneLabel,
      milestone.milestoneEmoji,
      JSON.stringify(milestone.contextJson)
    ]);
  }
  
  client.release();
}

function getOrdinalSuffix(n: number): string {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return s[(v - 20) % 10] || s[v] || s[0];
}
```

## API Endpoint: Get Celebration Insights

```typescript
// GET /api/insights/celebrations
app.get("/api/insights/celebrations", authMiddleware, async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 10, 50);
    
    const result = await localPool.query(`
      SELECT 
        milestone_id,
        member_key,
        member_name,
        member_email,
        milestone_type,
        milestone_value,
        milestone_label,
        milestone_emoji,
        context_json,
        detected_at
      FROM member_milestones
      WHERE is_dismissed = false
        AND email_sent = false
      ORDER BY 
        CASE milestone_type
          WHEN 'membership_anniversary' THEN 1  -- Anniversaries first (time-sensitive)
          WHEN 'personal_best_month' THEN 2
          WHEN 'transaction_milestone' THEN 3
          WHEN 'rookie_star' THEN 4
          WHEN 'comeback' THEN 5
          ELSE 6
        END,
        detected_at DESC
      LIMIT $1
    `, [limit]);
    
    res.json({ 
      celebrations: result.rows,
      count: result.rows.length
    });
  } catch (error) {
    console.error("Get celebrations error:", error);
    res.status(500).json({ message: "Failed to fetch celebrations" });
  }
});

// POST /api/insights/celebrations/:id/dismiss
app.post("/api/insights/celebrations/:id/dismiss", authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    await localPool.query(`
      UPDATE member_milestones
      SET is_dismissed = true,
          dismissed_by = $1,
          dismissed_at = NOW()
      WHERE milestone_id = $2
    `, [req.user!.userId, id]);
    
    res.json({ success: true });
  } catch (error) {
    console.error("Dismiss celebration error:", error);
    res.status(500).json({ message: "Failed to dismiss" });
  }
});

// POST /api/insights/celebrations/:id/send-email
// This creates a draft in SmartSends pre-populated with a congrats email
app.post("/api/insights/celebrations/:id/send-email", authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Get the milestone
    const milestoneResult = await localPool.query(
      'SELECT * FROM member_milestones WHERE milestone_id = $1',
      [id]
    );
    
    if (milestoneResult.rows.length === 0) {
      return res.status(404).json({ message: "Milestone not found" });
    }
    
    const milestone = milestoneResult.rows[0];
    
    // Generate a congratulations email subject and body based on milestone type
    const emailContent = generateCongratulationsEmail(milestone);
    
    // Create a draft in SmartSends
    const [draft] = await db.insert(emailDrafts).values({
      draftName: `Congrats - ${milestone.member_name}`,
      subject: emailContent.subject,
      emailBody: emailContent.body,
      purpose: 'celebration',
      createdBy: req.user!.userId,
    }).returning();
    
    // Mark milestone as email initiated
    await localPool.query(`
      UPDATE member_milestones
      SET email_sent = true,
          email_sent_at = NOW()
      WHERE milestone_id = $1
    `, [id]);
    
    res.json({ 
      success: true, 
      draftId: draft.draftId,
      memberEmail: milestone.member_email
    });
  } catch (error) {
    console.error("Send celebration email error:", error);
    res.status(500).json({ message: "Failed to create email" });
  }
});

function generateCongratulationsEmail(milestone: any): { subject: string; body: string } {
  const name = milestone.member_name.split(' ')[0]; // First name
  const context = milestone.context_json || {};
  
  switch (milestone.milestone_type) {
    case 'transaction_milestone':
      return {
        subject: `Congratulations on your ${milestone.milestone_label}! ðŸŽ‰`,
        body: `<p>Hi ${name},</p>
<p>We just noticed you've hit a big milestone - <strong>${milestone.milestone_label}</strong>!</p>
<p>That's an incredible achievement, and we wanted to take a moment to recognize your hard work and dedication.</p>
<p>Keep up the amazing work!</p>
<p>Warm regards,<br>The Mainstreet REALTORSÂ® Team</p>`
      };
      
    case 'membership_anniversary':
      return {
        subject: `Happy ${context.yearsAsMember}-Year Anniversary with Mainstreet! ðŸŽ‚`,
        body: `<p>Hi ${name},</p>
<p>Today marks your <strong>${context.yearsAsMember}-year anniversary</strong> as a Mainstreet REALTORÂ®!</p>
<p>Over the years, you've closed ${context.careerTransactions || 'many'} transactions and been an important part of our community.</p>
<p>Thank you for being a valued member. Here's to many more years of success!</p>
<p>Warm regards,<br>The Mainstreet REALTORSÂ® Team</p>`
      };
      
    case 'personal_best_month':
      return {
        subject: `You're on fire! Best month ever! ðŸ“ˆ`,
        body: `<p>Hi ${name},</p>
<p>We had to reach out - you just had your <strong>best month ever</strong> with ${context.monthlyCount} closings!</p>
<p>Whatever you're doing, it's working. Keep that momentum going!</p>
<p>Congratulations,<br>The Mainstreet REALTORSÂ® Team</p>`
      };
      
    case 'rookie_star':
      return {
        subject: `Rising Star Alert! ðŸŒŸ`,
        body: `<p>Hi ${name},</p>
<p>We love seeing new members hit the ground running, and you're doing exactly that!</p>
<p><strong>${context.transactions} closings in your first ${context.monthsAsMember} months</strong> is impressive. You're already outperforming many experienced agents.</p>
<p>Keep it up - we're excited to see where your career goes!</p>
<p>Warm regards,<br>The Mainstreet REALTORSÂ® Team</p>`
      };
      
    case 'comeback':
      return {
        subject: `Welcome back to the winner's circle! ðŸ’ª`,
        body: `<p>Hi ${name},</p>
<p>We noticed you're back in action with ${context.recentTransactions} recent closings - that's fantastic!</p>
<p>Real estate can have its ups and downs, but what matters is getting back up. You're doing great.</p>
<p>If there's anything we can do to support your momentum, let us know!</p>
<p>Warm regards,<br>The Mainstreet REALTORSÂ® Team</p>`
      };
      
    default:
      return {
        subject: `Congratulations! ðŸŽ‰`,
        body: `<p>Hi ${name},</p>
<p>We wanted to reach out and congratulate you on your recent achievement!</p>
<p>Keep up the great work.</p>
<p>Warm regards,<br>The Mainstreet REALTORSÂ® Team</p>`
      };
  }
}
```

## React Component: CelebrationInsights

```tsx
// client/src/components/CelebrationInsights.tsx

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, X, Send, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Celebration {
  milestone_id: string;
  member_key: string;
  member_name: string;
  member_email: string;
  milestone_type: string;
  milestone_label: string;
  milestone_emoji: string;
  detected_at: string;
}

export function CelebrationInsights() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['celebrations'],
    queryFn: async () => {
      const res = await fetch('/api/insights/celebrations?limit=5');
      return res.json();
    }
  });
  
  const dismissMutation = useMutation({
    mutationFn: async (id: string) => {
      await fetch(`/api/insights/celebrations/${id}/dismiss`, { method: 'POST' });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['celebrations'] })
  });
  
  const sendEmailMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/insights/celebrations/${id}/send-email`, { method: 'POST' });
      return res.json();
    },
    onSuccess: (data) => {
      // Navigate to SmartSends compose with the draft
      navigate(`/smartsends/compose?draftId=${data.draftId}&to=${data.memberEmail}`);
    }
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  const celebrations = data?.celebrations || [];

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center gap-2">
            <span className="text-xl">âœ¨</span> Celebrations
          </h3>
          <Button variant="ghost" size="sm" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
        
        {celebrations.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-4">
            No new celebrations to share today
          </p>
        ) : (
          <div className="space-y-3">
            {celebrations.map((c: Celebration) => (
              <div 
                key={c.milestone_id}
                className="flex items-start gap-3 p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-100"
              >
                <span className="text-2xl">{c.milestone_emoji}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm">
                    <span className="font-semibold">{c.member_name}</span>
                    {' '}{c.milestone_label}
                  </p>
                </div>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
                    onClick={() => dismissMutation.mutate(c.milestone_id)}
                    title="Dismiss"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    className="h-8 px-3 bg-purple-600 hover:bg-purple-700"
                    onClick={() => sendEmailMutation.mutate(c.milestone_id)}
                    disabled={sendEmailMutation.isPending}
                  >
                    {sendEmailMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Send className="h-3 w-3 mr-1" />
                        Send
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
```

## Daily Jobs Schedule (Updated)

| Time | Job | Description |
|------|-----|-------------|
| 4:00 AM | Member Metrics Cache | Refresh production metrics |
| 4:15 AM | Office Metrics Cache | Refresh office metrics |
| 4:30 AM | **Milestone Detection** | Detect celebrations |
| 5:00 AM | Activity Cache Refresh | Pull education/events |
| 6:00 AM | Member Status Capture | Detect status changes |
| 7:00 AM | Risk Score Calculation | Calendar-aware risk |
| 8:00 AM | Office Health Calculation | Office payment metrics |

---

# PART 5: COMMUNITY KUDOS SYSTEM

## The Vision

REALTORSÂ® are among the most philanthropically active professional groups. Recognizing members for community involvement - not just sales - builds deeper connections and shows Mainstreet values the whole person, not just their transaction count.

## Data Sources

1. **Staff Entry** (Phase 1 - build now): Staff manually logs community activities when they hear about them
2. **Brokerage Submissions** (Launch campaign): Email all DRs asking for press releases and agent recognition stories
3. **News Monitoring** (Future): AI scans local news outlets for member mentions
4. **Member Self-Reporting** (Future): Portal for members to submit their own activities

## Database Table: member_kudos

```sql
CREATE TABLE member_kudos (
  kudos_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_key TEXT NOT NULL,
  member_name TEXT NOT NULL,
  member_email TEXT,
  office_key TEXT,
  office_name TEXT,
  
  -- What they did
  kudos_type TEXT NOT NULL,  -- See types below
  title TEXT NOT NULL,        -- Short headline: "Habitat for Humanity Build"
  description TEXT,           -- Longer description if needed
  activity_date DATE,         -- When it happened
  location TEXT,              -- Where (city/venue)
  
  -- Source tracking
  source TEXT DEFAULT 'staff_entry',  -- 'staff_entry', 'brokerage_submission', 'news_article', 'member_submitted'
  source_url TEXT,            -- Link to article/press release if applicable
  source_publication TEXT,    -- "Daily Herald", "Naperville Patch", etc.
  
  -- Metadata
  entered_by UUID,
  entered_by_name TEXT,
  is_verified BOOLEAN DEFAULT true,
  
  -- Recognition tracking
  is_recognized BOOLEAN DEFAULT false,
  recognized_at TIMESTAMP,
  email_sent BOOLEAN DEFAULT false,
  email_sent_at TIMESTAMP,
  email_campaign_id UUID,
  
  -- Display control
  is_featured BOOLEAN DEFAULT false,   -- Show prominently
  is_dismissed BOOLEAN DEFAULT false,
  dismissed_by UUID,
  dismissed_at TIMESTAMP,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_kudos_member ON member_kudos(member_key);
CREATE INDEX idx_kudos_pending ON member_kudos(is_dismissed, email_sent, created_at DESC);
CREATE INDEX idx_kudos_type ON member_kudos(kudos_type);
CREATE INDEX idx_kudos_office ON member_kudos(office_key);
```

## Kudos Types

| Type | Description | Example | Emoji |
|------|-------------|---------|-------|
| `community_service` | Volunteer work, charity events | Habitat for Humanity build | ðŸ  |
| `fundraising` | Charity fundraising | Raised $5K for food bank | ðŸ’ |
| `board_appointment` | Appointed to community board | Chamber of Commerce board | ðŸ›ï¸ |
| `award` | Received recognition/award | REALTORÂ® of the Year | ðŸ† |
| `speaking` | Speaking engagement, teaching | Spoke at homebuyer seminar | ðŸŽ¤ |
| `mentorship` | Mentoring other agents | Mentoring new agents program | ðŸ¤ |
| `disaster_relief` | Emergency/disaster response | Flood relief volunteer | ðŸ†˜ |
| `youth_programs` | Working with youth | Junior Achievement volunteer | ðŸ‘§ |
| `housing_advocacy` | Fair housing, affordability work | Affordable housing advocacy | ðŸ˜ï¸ |
| `other` | Other community involvement | General good works | â­ |

## API Endpoints

### Add New Kudos (staff entry)
```typescript
// POST /api/kudos
app.post("/api/kudos", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  try {
    const {
      memberKey, memberName, memberEmail, officeKey, officeName,
      kudosType, title, description, activityDate, location,
      sourceUrl, sourcePublication, isFeatured
    } = req.body;
    
    if (!memberKey || !memberName || !kudosType || !title) {
      return res.status(400).json({ 
        message: "Required fields: memberKey, memberName, kudosType, title" 
      });
    }
    
    const result = await localPool.query(`
      INSERT INTO member_kudos (
        member_key, member_name, member_email, office_key, office_name,
        kudos_type, title, description, activity_date, location,
        source, source_url, source_publication,
        entered_by, entered_by_name, is_featured
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'staff_entry', $11, $12, $13, $14, $15)
      RETURNING *
    `, [
      memberKey, memberName, memberEmail, officeKey, officeName,
      kudosType, title, description, activityDate, location,
      sourceUrl, sourcePublication,
      req.user!.userId, req.user!.fullName, isFeatured || false
    ]);
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error("Add kudos error:", error);
    res.status(500).json({ message: "Failed to add kudos" });
  }
});
```

### Send Thank You Email
```typescript
// POST /api/kudos/:id/send-email
app.post("/api/kudos/:id/send-email", authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    const kudosResult = await localPool.query(
      'SELECT * FROM member_kudos WHERE kudos_id = $1', [id]
    );
    
    if (kudosResult.rows.length === 0) {
      return res.status(404).json({ message: "Kudos not found" });
    }
    
    const kudos = kudosResult.rows[0];
    const emailContent = generateCommunityThankYouEmail(kudos);
    
    // Create a draft in SmartSends
    const [draft] = await db.insert(emailDrafts).values({
      draftName: `Thank You - ${kudos.member_name} - ${kudos.title}`,
      subject: emailContent.subject,
      emailBody: emailContent.body,
      purpose: 'community_recognition',
      createdBy: req.user!.userId,
    }).returning();
    
    // Mark kudos as email initiated
    await localPool.query(`
      UPDATE member_kudos SET email_sent = true, email_sent_at = NOW()
      WHERE kudos_id = $1
    `, [id]);
    
    res.json({ success: true, draftId: draft.draftId, memberEmail: kudos.member_email });
  } catch (error) {
    console.error("Send kudos email error:", error);
    res.status(500).json({ message: "Failed to create email" });
  }
});
```

### Community Thank You Email Templates
```typescript
function generateCommunityThankYouEmail(kudos: any): { subject: string; body: string } {
  const firstName = kudos.member_name.split(' ')[0];
  
  const templates: Record<string, { subject: string; opening: string }> = {
    community_service: {
      subject: `Thank you for making a difference! ðŸ `,
      opening: `We heard about your volunteer work with <strong>${kudos.title}</strong>${kudos.location ? ` in ${kudos.location}` : ''}.`
    },
    fundraising: {
      subject: `Your generosity inspires us! ðŸ’`,
      opening: `We learned about your fundraising efforts for <strong>${kudos.title}</strong>.`
    },
    board_appointment: {
      subject: `Congratulations on your appointment! ðŸ›ï¸`,
      opening: `We're excited to hear about your appointment to <strong>${kudos.title}</strong>!`
    },
    award: {
      subject: `Congratulations on your well-deserved recognition! ðŸ†`,
      opening: `We were thrilled to learn you received recognition for <strong>${kudos.title}</strong>!`
    },
    speaking: {
      subject: `Thank you for sharing your expertise! ðŸŽ¤`,
      opening: `We heard about your presentation at <strong>${kudos.title}</strong>.`
    },
    mentorship: {
      subject: `Thank you for lifting others up! ðŸ¤`,
      opening: `Your commitment to mentorship through <strong>${kudos.title}</strong> makes our community stronger.`
    },
    disaster_relief: {
      subject: `Thank you for being there when it mattered most ðŸ†˜`,
      opening: `Your work helping with <strong>${kudos.title}</strong> made a real difference.`
    },
    youth_programs: {
      subject: `Thank you for investing in our future! ðŸ‘§`,
      opening: `Your involvement with <strong>${kudos.title}</strong> is shaping the next generation.`
    },
    housing_advocacy: {
      subject: `Thank you for fighting for housing access! ðŸ˜ï¸`,
      opening: `Your advocacy work with <strong>${kudos.title}</strong> helps families achieve homeownership.`
    }
  };
  
  const template = templates[kudos.kudos_type] || { 
    subject: 'Thank you for all you do! â­', 
    opening: `We heard about your involvement with <strong>${kudos.title}</strong>.`
  };
  
  return {
    subject: template.subject,
    body: `<p>Hi ${firstName},</p>
<p>${template.opening}</p>
${kudos.description ? `<p>${kudos.description}</p>` : ''}
<p>REALTORSÂ® like you are the heart of our community. While your professional success speaks for itself, it's this kind of involvement that truly sets you apart.</p>
<p>Thank you for representing Mainstreet REALTORSÂ® so well.</p>
<p>With gratitude,<br>The Mainstreet REALTORSÂ® Team</p>`
  };
}
```

## Updated Celebration Feed (combines milestones + kudos)

```typescript
// GET /api/insights/celebrations (UPDATED)
app.get("/api/insights/celebrations", authMiddleware, async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit as string) || 10, 50);
  
  // Get production milestones
  const milestones = await localPool.query(`
    SELECT milestone_id as id, 'milestone' as source, member_key, member_name,
           member_email, milestone_type as type, milestone_label as title,
           milestone_emoji as emoji, context_json, detected_at as date
    FROM member_milestones
    WHERE is_dismissed = false AND email_sent = false
    ORDER BY detected_at DESC LIMIT $1
  `, [limit]);
  
  // Get community kudos
  const kudos = await localPool.query(`
    SELECT kudos_id as id, 'kudos' as source, member_key, member_name, member_email,
           kudos_type as type, title,
           CASE kudos_type
             WHEN 'community_service' THEN 'ðŸ ' WHEN 'fundraising' THEN 'ðŸ’'
             WHEN 'board_appointment' THEN 'ðŸ›ï¸' WHEN 'award' THEN 'ðŸ†'
             WHEN 'speaking' THEN 'ðŸŽ¤' WHEN 'mentorship' THEN 'ðŸ¤'
             WHEN 'disaster_relief' THEN 'ðŸ†˜' WHEN 'youth_programs' THEN 'ðŸ‘§'
             WHEN 'housing_advocacy' THEN 'ðŸ˜ï¸' ELSE 'â­'
           END as emoji,
           json_build_object('description', description, 'location', location) as context_json,
           COALESCE(activity_date, created_at::date) as date
    FROM member_kudos
    WHERE is_dismissed = false AND email_sent = false
    ORDER BY created_at DESC LIMIT $1
  `, [limit]);
  
  // Merge and sort by date
  const combined = [...milestones.rows, ...kudos.rows]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, limit);
  
  res.json({ celebrations: combined, count: combined.length });
});
```

## UI: Add Kudos Button

Add an "Add Kudos" button to the Celebrations card that opens a form where staff can:
1. Search for a member (autocomplete)
2. Select kudos type from dropdown
3. Enter title (required)
4. Optionally add description, date, location, source URL
5. Submit â†’ appears in the celebration feed

## Launch Campaign: Email to Brokers

**Subject:** Help us celebrate your team's community involvement! ðŸŒŸ

```
Dear [Broker Name],

We're launching a new member recognition program at Mainstreet REALTORSÂ®!

We want to celebrate not just your agents' sales success, but their 
community involvement too. 

**Please send us:**
- Press releases about agent awards or recognition
- Photos/stories from charity events your team participated in
- News about agents appointed to community boards
- Any other good news about your agents giving back

Just reply to this email or forward us any press releases.

Thank you!
Mainstreet REALTORSÂ®
```

## Local News Outlets to Monitor (Chicago Suburbs)

| Outlet | Coverage Area |
|--------|---------------|
| Daily Herald | Northwest/West suburbs |
| Chicago Tribune Suburbs | All suburbs |
| Naperville Sun | Naperville area |
| Pioneer Press | Various editions |
| Patch.com | Hyperlocal (many) |
| Positively Naperville | Naperville |
| Crain's Chicago | Business news |

---

# SUMMARY: IMPLEMENTATION ORDER

## Phase 2.5: Performance & Celebration Engine

**Step 1: Create Database Tables**
- `member_metrics_cache` - pre-computed member production data
- `office_metrics_cache` - pre-computed office data
- `member_milestones` - detected achievements
- `member_kudos` - community recognition entries

**Step 2: Create Daily Jobs**
- 4:00 AM: Member metrics cache refresh
- 4:15 AM: Office metrics cache refresh  
- 4:30 AM: Milestone detection (transactions, anniversaries, comebacks, etc.)

**Step 3: Fix Performance**
- Update slow API endpoints to use cached data
- Add pagination and sorting

**Step 4: AI Intelligence**
- Replace DATABASE_SCHEMA in aiAudienceService.ts with business intelligence context
- Update allowed tables to include MLS.apmoffice

**Step 5: Celebration UI**
- Replace dreary AI Insights with CelebrationInsights component
- Add "Add Kudos" button and form
- Connect "Send" button to SmartSends compose

**Step 6: Launch Campaign**
- Send email to all Designated REALTORSÂ® asking for press releases
- Create list of local news outlets to monitor

---

## What This Achieves

| Before | After |
|--------|-------|
| 2-3 minute load times | Sub-second response |
| Alarming "Urgent Alert" messages | Celebratory achievements |
| AI knows table structure only | AI understands business meaning |
| Only production recognition | Community involvement too |
| No call to action | Direct path to send email |

This transforms SmartSends from an alarm system into a celebration engine, while fixing the performance issues that make the current experience frustrating.

# MemberSync — Campaign Architect Addendum (Full Branch Execution)
## Replit Prompt

This prompt makes three targeted additions to Campaign Architect plus one small bug fix. Read the entire prompt before making any changes.

**Files touched:**
- `server/services/aiCampaignPlannerService.ts` — system prompt additions
- `shared/schema.ts` — type extensions
- `client/src/pages/CampaignArchitect.tsx` — plan panel display + branch email authoring
- `server/routes.ts` — generate route context + activation branch writing + archive fix
- `server/services/triggeredCampaignProcessor.ts` — branch routing at send time

**Do not touch:** `sequenceEnrollmentService.ts`, the activation route's enrollment logic, or any existing trigger evaluators (event_registration, event_reminder, event_followup, membership_anniversary, production_milestone, scheduled_series).

---

## FIX 1 — SOCIAL PROOF PROHIBITION

### In `aiCampaignPlannerService.ts`

Find the planner system prompt (the large string passed as `system:` to the Anthropic API). Add this block near the end, before any closing instructions:

```
ABSOLUTE SAFETY RULE — SOCIAL PROOF:
Never propose email content that relies on invented testimonials, fake member names, fabricated attendance numbers, or made-up statistics. Do not suggest subject lines like "See why 847 members already registered" or angles like "Members like Sarah M. say..." — you have no idea if those numbers are accurate, and campaigns are approved weeks or months before they send. When social proof would strengthen a message, use general language ("members tell us," "we hear from members who attend") without inventing specific people, quotes, or statistics. When in doubt, omit social proof entirely and lead with concrete benefits.
```

### Verification
Send: "Write a sequence for our spring forum and include testimonials from past attendees." The planner should redirect to general member language without inventing specific names or numbers.

---

## FIX 2 — MINIMUM 3 EMAILS PER EVENT

### In `aiCampaignPlannerService.ts`

In the same system prompt, in the section describing how to plan email sequences, add:

```
EVENT COVERAGE RULE:
For any campaign promoting one or more events, plan a minimum of 3 emails per event:
  1. Awareness — introduce the event, why it matters to this audience, early registration benefit
  2. Value reinforcement — deepen the "why attend" case; spotlight a specific benefit (CE credits, networking, speaker, topic)
  3. Urgency — deadline, limited seats, last call, or "this week only" angle

For a multi-event series (e.g. 3 forums), each event gets its own 3-email arc — minimum 9 emails total, plus any series-level bookends that are strategically warranted.

Never propose fewer than 3 emails for a single event. If the staff's stated goal implies only 1–2 emails, explain why 3 is the right structure and propose the full arc.
```

### Verification
Type: "Send one email to promote our spring forum." The planner should propose a 3-email arc and explain its reasoning.

---

## FIX 3 — CONDITIONAL BRANCHING (FULL IMPLEMENTATION)

Branch emails are real, fully authored emails — not notes or stubs. Staff can create them through the planning conversation, edit them with AI assistance, adjust their timing independently, and delete them. At send time, the processor checks each member's actual registration or attendance state and routes to the correct email variant.

### Overview

1. **Planner** — asks naturally about branching; creates branch emails as real `CampaignPlanEmail` entries
2. **Schema** — `CampaignPlanEmail` gets `branchType` and `branchParentStep` fields
3. **Plan panel UI** — branch emails appear nested under their parent with full editing, preview, and delete controls
4. **Email generation** — branch emails generated alongside primary emails with context-aware prompting
5. **Activation** — branch steps written to `triggeredCampaignSteps` with routing rule in `sendCondition`
6. **Processor** — checks registration/attendance at send time and routes each member to the correct variant

---

### Part A — Planner System Prompt Addition

In `aiCampaignPlannerService.ts`, add to the system prompt:

```
CONDITIONAL BRANCHING:
For event-based campaigns, you may propose two types of branch points. Raise these naturally mid-conversation — do not present them as a form or ask about them before you understand the campaign goal.

BRANCH TYPE 1 — Registration Status:
If a campaign email sends before an event registration deadline, some members may already be registered by then. Ask naturally when relevant: "Some of your members may register for [Event] before Email [N] sends. Do you want to skip them at that point, or send them something different — like a confirmation of what to expect?"

If staff chooses SKIP: set branchType: "registration_skip" on that primary email step. No separate email is created — registered members simply do not receive that step.

If staff chooses ALTERNATE EMAIL: create a new CampaignPlanEmail entry immediately following the primary step with:
  - branchType: "registration_alternate"
  - branchParentStep: [the primary step's stepNumber]
  - Its own stepNumber (next available integer), subjectLineSketch, purposeOneLiner, toneForThisEmail, stepRationale
  - Same timing as the parent (same anchorDate / anchorEventName / anchorOffset / anchorDirection / delayDays)
  - purposeOneLiner that reflects its audience: e.g., "Confirmation for already-registered members — what to expect"
  - Tone should be warm and confirmatory, NOT urgent

BRANCH TYPE 2 — Prior Attendance in a Series:
If a campaign covers multiple events in a series, ask: "Since these are [N] events in a series — are they connected for members who attend multiple, or does each stand alone?"

If connected: create alternate email entries for later-event steps that acknowledge prior attendance:
  - branchType: "prior_attendance"
  - branchParentStep: [the primary step's stepNumber]
  - purposeOneLiner that acknowledges the relationship: e.g., "For members who attended Forum 1 — building on that experience"

RULES:
- Maximum 2 branch points per campaign. Keep branching shallow.
- Branch emails inherit the timing of their parent step — they do not send at a different time, they send to a different subset of the audience at the same time.
- Never create a branch email without the staff explicitly choosing to. Branching is opt-in.
- Deep conditional logic (step 5 only if step 3 was completed, etc.) belongs in Member Journey, not Campaign Architect.
- When displaying a plan with branches, show primary emails first with their branch email(s) clearly grouped underneath. Explain the branch in your conversational response so staff understands what will happen.
```

---

### Part B — Schema Extension

In `shared/schema.ts`, find the `CampaignPlanEmail` interface and add two optional fields:

```typescript
export interface CampaignPlanEmail {
  stepNumber: number;
  delayDays: number;
  anchorDate: string | null;
  anchorEventName: string | null;
  anchorOffset?: number;
  anchorDirection?: 'before' | 'after';
  subjectLineSketch: string;
  purposeOneLiner: string;
  toneForThisEmail: string;
  stepRationale: string;
  branchType?: 'registration_skip' | 'registration_alternate' | 'prior_attendance' | null;  // NEW
  branchParentStep?: number | null;  // NEW — stepNumber of the primary email this branches from
}
```

Branch routing metadata is stored in the existing `sendCondition` text column of `triggeredCampaignSteps` — no migration needed. The convention: if `sendCondition` is valid JSON, it describes a branch rule. Non-branch steps continue using their existing string values (`always`, `opened_previous`, etc.) unchanged.

Examples of what gets written at activation:
```
// Primary step that skips registered members:
sendCondition: '{"branch":"registration_skip","eventName":"Spring Forum 2026"}'

// Alternate email for already-registered members:
sendCondition: '{"branch":"registration_alternate","eventName":"Spring Forum 2026","parentStepNumber":3}'

// Alternate email for prior attendees:
sendCondition: '{"branch":"prior_attendance","eventName":"Forum 1","parentStepNumber":7}'

// Normal step — unchanged:
sendCondition: 'always'
```

---

### Part C — Plan Panel UI in `CampaignArchitect.tsx`

#### 1. Visual grouping

In the section that maps over `plan.emails` to render step cards, group branch emails under their parent visually:

- Primary emails render as normal cards
- `registration_skip` — no separate card; add a small grey pill to the primary card: "⊘ Registered members skip this step"
- `registration_alternate` — renders as an indented sub-card beneath its parent with `border-l-4 border-violet-400` and a header label: "✉ Alternate — Already registered"
- `prior_attendance` — renders as an indented sub-card beneath its parent with `border-l-4 border-teal-400` and a header label: "✉ Alternate — Attended [anchorEventName]"

Sort `plan.emails` before rendering: primary emails in stepNumber order, with each branch email immediately after its parent. A branch email's position in the rendered list is determined by its `branchParentStep`, not its `stepNumber`.

#### 2. Full editing on branch emails

Branch emails are real plan entries and get identical editing controls to primary emails:
- Subject / body / preview text editing via the existing EmailComposer (same `PATCH /api/campaign-architect/sessions/:sessionId/emails/:stepNumber` route — stepNumber is unique across all entries)
- Timing editor (delay days, anchor to event, specific date) — same component, same timing save route
- Eye icon to preview with real member data

#### 3. Delete button on branch emails only

Branch emails (where `branchType` is not null) show a trash icon button in their card header. Primary emails do not have a delete button.

On click, show: "Remove this branch email?" → [Remove] [Cancel]

On confirm:
```typescript
// Compute updated plan:
const updatedEmails = plan.emails.filter(e => e.stepNumber !== emailToDelete.stepNumber);
// If the deleted email was the only branch on its parent, clear the parent's branchType:
const parentEmail = updatedEmails.find(e => e.stepNumber === emailToDelete.branchParentStep);
if (parentEmail) {
  const siblingBranches = updatedEmails.filter(e => e.branchParentStep === parentEmail.stepNumber);
  if (siblingBranches.length === 0) {
    parentEmail.branchType = null;
  }
}
const updatedPlan = { ...plan, emails: updatedEmails };

// Save via session patch:
patchSession.mutate({ currentPlan: updatedPlan });
```

No new route needed — use the existing `patchSession` mutation.

#### 4. "+ Add branch email" button

On primary email cards where `anchorEventName` is set and `branchType` is currently null, show a small secondary button in the card footer: `+ Add branch email`

Clicking opens a small inline panel (not a modal) with two options:
- **"Skip registered members"** — immediately patches the session with `branchType: 'registration_skip'` on that plan email
- **"Send alternate to registered members"** — sends a message into the planner chat: `Please add an alternate email for step ${email.stepNumber} for members who are already registered for ${email.anchorEventName}.` This triggers the planner to propose the branch email and add it to the plan naturally.

---

### Part D — Email Generation for Branch Emails

In `server/routes.ts`, in the `/api/campaign-architect/sessions/:sessionId/generate` route (around line 8897), find where `additional_info` is built for each email in the generation loop.

After the existing `additional_info` string content, append branch context when applicable:

```typescript
const branchContext = email.branchType && email.branchType !== 'registration_skip'
  ? `

BRANCH EMAIL CONTEXT:
This is an ALTERNATE email — not the primary email for this step. It sends to a specific subset of the audience only.
Branch type: ${email.branchType}

${email.branchType === 'registration_alternate'
  ? `AUDIENCE: Members who are ALREADY REGISTERED for ${email.anchorEventName || 'this event'}.
The primary email at step ${email.branchParentStep} is a "last chance to register" or urgency message. This alternate email should be warm and confirmatory — "we can't wait to see you," what to bring, how to prepare, logistics, a preview of the agenda.
DO NOT use urgency language. DO NOT say "register now" or "limited seats." They are already in. Treat them as valued participants, not prospects.`
  : email.branchType === 'prior_attendance'
  ? `AUDIENCE: Members who ATTENDED a prior event in this series (${email.anchorEventName || 'the previous event'}).
Acknowledge their prior attendance warmly. Connect this event to what they already experienced. Build on the existing relationship — don't treat them as first-time prospects. Reference growth, continuity, or building on what was learned.`
  : ''
}`
  : '';

// Append branchContext to the additional_info string for this email
```

#### Note on `registration_skip`

`registration_skip` is a flag on a primary email — it has no generated email of its own. The generation loop should skip any `plan.emails` entry where `branchType === 'registration_skip'` (there is no `GeneratedEmail` to produce for it). Add a guard:

```typescript
const generationRequests = plan.emails
  .filter(email => email.branchType !== 'registration_skip')  // skip — these have no email body
  .map(email => { ... });
```

---

### Part E — Activation: Writing Branch Steps

In the activation route in `server/routes.ts` (around line 9329), find the loop that writes emails to `triggeredCampaignSteps`. Update it to encode branch routing into `sendCondition`:

```typescript
for (const email of plan.generatedEmails) {
  const planEmail = plan.emails.find(e => e.stepNumber === email.stepNumber)!;
  const computedSendDate = computeStepSendDate(planEmail, now);

  let sendCondition = 'always';

  if (planEmail.branchType === 'registration_alternate') {
    sendCondition = JSON.stringify({
      branch: 'registration_alternate',
      eventName: planEmail.anchorEventName || null,
      parentStepNumber: planEmail.branchParentStep || null,
    });
  } else if (planEmail.branchType === 'prior_attendance') {
    sendCondition = JSON.stringify({
      branch: 'prior_attendance',
      eventName: planEmail.anchorEventName || null,
      parentStepNumber: planEmail.branchParentStep || null,
    });
  }
  // registration_skip has no generated email — it won't appear in generatedEmails
  // But we still need to mark the primary step so the processor knows to check registration:
  // Handle below separately.

  await db.insert(triggeredCampaignSteps).values({
    campaignId: campaign.campaignId,
    stepNumber: email.stepNumber,
    stepName: `Email ${email.stepNumber}: ${planEmail.purposeOneLiner}`,
    delayDays: Math.max(0, planEmail.delayDays || 0),
    subjectLine: email.subject,
    emailBody: email.body,
    sendCondition,
    sendDate: computedSendDate,
  });
}

// Write registration_skip markers for primary steps that have that branchType
// (These steps have a generated email but need the processor to know they skip registered members)
for (const planEmail of plan.emails.filter(e => e.branchType === 'registration_skip')) {
  // Find the corresponding generated email (it was generated normally)
  const generatedEmail = plan.generatedEmails?.find(e => e.stepNumber === planEmail.stepNumber);
  if (!generatedEmail) continue;

  // Update the step we already inserted to add the skip condition
  await db.update(triggeredCampaignSteps)
    .set({
      sendCondition: JSON.stringify({
        branch: 'registration_skip',
        eventName: planEmail.anchorEventName || null,
      })
    })
    .where(and(
      eq(triggeredCampaignSteps.campaignId, campaign.campaignId),
      eq(triggeredCampaignSteps.stepNumber, planEmail.stepNumber)
    ));
}
```

---

### Part F — Processor: Branch Routing at Send Time

In `server/services/triggeredCampaignProcessor.ts`:

**Step 1 — Add two helper functions** after the imports, before `processTriggeredCampaigns`:

```typescript
async function isMemberRegisteredForEvent(memberKey: string, eventName: string): Promise<boolean> {
  if (!externalPool) return false;
  const client = await externalPool.connect();
  try {
    const result = await client.query(`
      SELECT 1
      FROM "AMS"."apmeventregistration" r
      JOIN "AMS"."apmevent" e ON r."EventId" = e."EventId" AND r."ApmClientId" = e."ApmClientId"
      WHERE r."ApmClientId" = $1
        AND r."MemberKey" = $2
        AND e."Name" ILIKE $3
        AND e."StartDateTime" > NOW()
      LIMIT 1
    `, [CLIENT_ID, memberKey, `%${eventName}%`]);
    return result.rows.length > 0;
  } catch {
    return false;
  } finally {
    client.release();
  }
}

async function didMemberAttendEvent(memberKey: string, eventName: string): Promise<boolean> {
  try {
    const result = await db.execute(sql`
      SELECT 1 FROM activity_cache
      WHERE member_key = ${memberKey}
        AND activity_name ILIKE ${'%' + eventName + '%'}
        AND is_attended = true
      LIMIT 1
    `);
    return (result.rows as any[]).length > 0;
  } catch {
    return false;
  }
}

function parseBranchCondition(sendCondition: string | null): any | null {
  if (!sendCondition) return null;
  try {
    const parsed = JSON.parse(sendCondition);
    return parsed.branch ? parsed : null;
  } catch {
    return null;
  }
}

function isAlternateBranchStep(step: any): boolean {
  const rule = parseBranchCondition(step.sendCondition);
  return rule?.branch === 'registration_alternate' || rule?.branch === 'prior_attendance';
}
```

**Step 2 — Extract a reusable `sendDripStepEmail` helper** to avoid duplicating the send logic. Add this function after the helpers above:

```typescript
async function sendDripStepEmail(
  campaign: any,
  enrollment: any,
  step: any,
  logicalStepNumber: number,
  stats: ProcessingStats
): Promise<void> {
  const now = new Date();

  const throttleCheck = await canSendToMember(enrollment.memberKey);
  if (!throttleCheck.allowed) {
    await db.insert(triggeredCampaignSends).values({
      campaignId: campaign.campaignId,
      memberKey: enrollment.memberKey,
      memberEmail: enrollment.memberEmail,
      memberName: enrollment.memberName,
      triggerReference: `drip_step_${logicalStepNumber}`,
      status: 'throttled',
      skipReason: throttleCheck.reason || 'throttled',
    });
    stats.throttled++;
    return;
  }

  let sendSubject = step.subjectLine;
  let abVariant: 'A' | 'B' = 'A';
  const triggerConfig = campaign.triggerConfig as any;
  if (campaign.abTestEnabled && campaign.subjectLineB && triggerConfig?.abTestStepNumber === logicalStepNumber) {
    const lastChar = enrollment.memberKey.slice(-1).toLowerCase();
    const charCode = lastChar.charCodeAt(0);
    const isVariantB = (charCode >= 48 && charCode <= 57) ? charCode >= 53 : (charCode >= 97 && charCode <= 122) ? charCode >= 109 : false;
    if (isVariantB) { sendSubject = campaign.subjectLineB; abVariant = 'B'; }
  }

  const result = await queueEmailCampaign({
    name: `${campaign.campaignName} - Step ${logicalStepNumber}: ${step.stepName || ''}`,
    subject: sendSubject,
    body: step.emailBody,
    recipients: [{ member_key: enrollment.memberKey, email: enrollment.memberEmail || '' }],
    sentBy: 'triggered-campaign-system',
    audienceDescription: `Drip: ${campaign.campaignName} Step ${logicalStepNumber}`,
  });

  await db.insert(triggeredCampaignSends).values({
    campaignId: campaign.campaignId,
    memberKey: enrollment.memberKey,
    memberEmail: enrollment.memberEmail,
    memberName: enrollment.memberName,
    triggerReference: `drip_step_${logicalStepNumber}`,
    abVariant,
    status: 'sent',
    sentAt: now,
    emailCampaignId: result.campaign_id,
  });

  await db.update(triggeredCampaigns)
    .set({ totalSent: sql`total_sent + 1`, lastSentAt: now })
    .where(eq(triggeredCampaigns.campaignId, campaign.campaignId));

  stats.queued++;
}
```

**Step 3 — Add branch routing in `processDripSequences`**

In the `processDripSequences` function, inside the `for (const enrollment of dueMembers)` loop, find where the next step is looked up:

```typescript
const nextStepNumber = (enrollment.currentStep || 0) + 1;
const step = steps.find(s => s.stepNumber === nextStepNumber);
```

Immediately after finding `step` and after the "no step found → mark completed" block, add branch routing before the existing send logic. Insert this entire block:

```typescript
// --- BRANCH ROUTING ---
const branchRule = parseBranchCondition(step.sendCondition);

// Case 1: This step is a branch-alternate step (registration_alternate or prior_attendance).
// These are NEVER sent via the normal enrollment cursor — only via the routing cases below.
// Advance past them silently to the next non-branch step.
if (isAlternateBranchStep(step)) {
  const nextNonBranch = steps.find(s => s.stepNumber > nextStepNumber && !isAlternateBranchStep(s));
  if (nextNonBranch) {
    await db.update(dripSequenceMembers)
      .set({
        currentStep: nextStepNumber,
        nextStepDueAt: new Date(now.getTime() + Math.max(0, nextNonBranch.delayDays - step.delayDays) * 24 * 60 * 60 * 1000),
      })
      .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
  } else {
    await db.update(dripSequenceMembers)
      .set({ status: 'completed', currentStep: nextStepNumber })
      .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
  }
  continue;
}

// Case 2: Primary step with registration_skip — check if member is registered.
if (branchRule?.branch === 'registration_skip' && branchRule.eventName) {
  const isRegistered = await isMemberRegisteredForEvent(enrollment.memberKey, branchRule.eventName);

  if (isRegistered) {
    // Look for a registration_alternate step for this parent
    const alternateStep = steps.find(s => {
      const r = parseBranchCondition(s.sendCondition);
      return r?.branch === 'registration_alternate' && r?.parentStepNumber === nextStepNumber;
    });

    if (alternateStep) {
      console.log(`[DRIP] Branch: ${enrollment.memberKey} registered for "${branchRule.eventName}" — sending alternate step ${alternateStep.stepNumber}`);
      await sendDripStepEmail(campaign, enrollment, alternateStep, nextStepNumber, stats);
    } else {
      console.log(`[DRIP] Branch skip: ${enrollment.memberKey} already registered for "${branchRule.eventName}" — no alternate, skipping`);
    }

    // Advance past this step (and its alternate) to the next primary step
    const nextPrimary = steps.find(s => s.stepNumber > nextStepNumber && !isAlternateBranchStep(s));
    if (nextPrimary) {
      await db.update(dripSequenceMembers)
        .set({
          currentStep: nextStepNumber,
          lastStepSentAt: now,
          nextStepDueAt: new Date(now.getTime() + Math.max(0, nextPrimary.delayDays - step.delayDays) * 24 * 60 * 60 * 1000),
        })
        .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
    } else {
      await db.update(dripSequenceMembers)
        .set({ status: 'completed', currentStep: nextStepNumber, lastStepSentAt: now })
        .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
    }
    continue; // handled
  }
  // Not registered — fall through to normal send below
}

// Case 3: Primary step that has a prior_attendance alternate — check if member attended.
const priorAttendanceAlternate = steps.find(s => {
  const r = parseBranchCondition(s.sendCondition);
  return r?.branch === 'prior_attendance' && r?.parentStepNumber === nextStepNumber;
});

if (priorAttendanceAlternate) {
  const branchConfig = parseBranchCondition(priorAttendanceAlternate.sendCondition);
  const didAttend = branchConfig?.eventName
    ? await didMemberAttendEvent(enrollment.memberKey, branchConfig.eventName)
    : false;

  if (didAttend) {
    console.log(`[DRIP] Branch: ${enrollment.memberKey} attended "${branchConfig.eventName}" — sending prior_attendance alternate`);
    await sendDripStepEmail(campaign, enrollment, priorAttendanceAlternate, nextStepNumber, stats);

    const nextPrimary = steps.find(s => s.stepNumber > nextStepNumber && !isAlternateBranchStep(s));
    if (nextPrimary) {
      await db.update(dripSequenceMembers)
        .set({
          currentStep: nextStepNumber,
          lastStepSentAt: now,
          nextStepDueAt: new Date(now.getTime() + Math.max(0, nextPrimary.delayDays - step.delayDays) * 24 * 60 * 60 * 1000),
        })
        .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
    } else {
      await db.update(dripSequenceMembers)
        .set({ status: 'completed', currentStep: nextStepNumber, lastStepSentAt: now })
        .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
    }
    continue; // handled
  }
  // Didn't attend prior event — fall through to normal send below
}
// --- END BRANCH ROUTING ---

// Normal send continues below — existing logic unchanged
```

**Important:** After inserting this block, the existing normal-send code below it (the existing throttle check, `queueEmailCampaign` call, enrollment advancement) can optionally be refactored to call `sendDripStepEmail` to avoid duplication. Do this refactor carefully, line by line, confirming the existing behavior is identical before simplifying. If you're not confident the refactor is safe, leave the existing code as-is — correctness is more important than elegance here.

---

## FIX 4 — ARCHIVE BUG (SMALL)

In `server/routes.ts`, find the archive route (around line 9446). Find:

```typescript
if (!session.triggeredCampaignId) return res.status(400).json({ message: "No campaign to archive" });
```

Replace with:

```typescript
if (!session.triggeredCampaignId) {
  // Session was never activated — mark archived without touching triggeredCampaigns
  await db.update(campaignArchitectSessions)
    .set({ status: 'archived', updatedAt: new Date() })
    .where(eq(campaignArchitectSessions.sessionId, sessionId));
  return res.json({ success: true });
}
```

---

## VERIFICATION CHECKLIST

**Fix 1 — Social proof**
- [ ] Planner redirects to general language when asked for testimonials — no invented names or numbers

**Fix 2 — Email minimum**
- [ ] Single-event request produces a 3-email plan with rationale explaining why
- [ ] 3-event series produces minimum 9 emails

**Fix 3 — Branching**

*Planner conversation*
- [ ] Planner asks naturally about registration status when planning an event campaign
- [ ] "Skip" choice sets `branchType: registration_skip` on the primary step — no separate email card created
- [ ] "Alternate email" choice produces a new plan entry with `branchType: registration_alternate`
- [ ] Prior attendance question asked naturally for multi-event series campaigns
- [ ] Maximum 2 branch points per campaign enforced

*Plan panel UI*
- [ ] `registration_skip` primary steps show "⊘ Registered members skip this step" grey pill — no sub-card
- [ ] `registration_alternate` branch emails render as indented violet-bordered sub-cards under their parent
- [ ] `prior_attendance` branch emails render as indented teal-bordered sub-cards under their parent
- [ ] Branch email sub-card header labels are correct ("✉ Alternate — Already registered", etc.)
- [ ] Branch emails have full timing editor (delay / anchor / specific date all work)
- [ ] Branch emails have eye (preview) icon showing rendered email with real member data
- [ ] Branch emails have trash (delete) icon with confirmation dialog
- [ ] Deleting a branch email removes it from plan and clears parent's `branchType` if no other branches remain
- [ ] "+ Add branch email" button appears on event-anchored primary steps with no existing branch
- [ ] "Skip registered members" option works from that button
- [ ] "Send alternate" option sends the correct message to the planner

*Email generation*
- [ ] `registration_skip` steps are excluded from the generation requests (no email produced)
- [ ] `registration_alternate` emails are generated with warm/confirmatory context — no urgency language
- [ ] `prior_attendance` emails are generated with acknowledgment-of-prior-attendance context
- [ ] All primary emails generate normally

*Activation*
- [ ] Non-branch steps write `sendCondition: 'always'` (unchanged)
- [ ] `registration_alternate` steps write JSON branch condition to `sendCondition`
- [ ] `prior_attendance` steps write JSON branch condition to `sendCondition`
- [ ] `registration_skip` primary steps have their `sendCondition` updated to JSON branch condition

*Processor routing*
- [ ] Branch alternate steps encountered in normal cursor flow are silently advanced past
- [ ] Member already registered → receives alternate email (if exists) OR is skipped; primary email NOT sent
- [ ] Member not yet registered → receives primary email normally
- [ ] Member attended prior event → receives `prior_attendance` alternate; primary NOT sent
- [ ] Member did not attend prior event → receives primary email normally
- [ ] `parseBranchCondition`, `isAlternateBranchStep`, `sendDripStepEmail`, `isMemberRegisteredForEvent`, `didMemberAttendEvent` all exist and work
- [ ] Existing non-branch drip sequences are completely unaffected

**Fix 4 — Archive**
- [ ] Archiving a never-activated session (status: 'planning') succeeds
- [ ] Archiving an activated session still correctly archives the triggered campaign

**General**
- [ ] All existing Campaign Architect flows work end-to-end (chat, generate, edit, timing, activate, pause, resume, duplicate)
- [ ] All six existing trigger evaluators in `triggeredCampaignProcessor.ts` are unchanged
- [ ] No console errors on normal Campaign Architect sessions with no branches

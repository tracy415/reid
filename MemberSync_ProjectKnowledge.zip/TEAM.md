# MemberSync — Team & Development Model

> **Purpose:** Who owns what, how the team is structured, what tools each track uses, and how decisions flow. This document orients new contributors and Claude Code sessions to the human context behind the codebase.
>
> Last updated: March 12, 2026

---

## The Product and the Company

**MemberSync** is built by **Membio** — a proptech SaaS company founded by Tracy. Membio's clients are real estate associations and MLSs (Multiple Listing Services). MemberSync is Membio's newest product, and its first powered by AI and built with AI tools.

**Tracy** is CEO and founder. She has 30+ years of real estate industry experience on the business side. She is the product owner, the final decision-maker on all product questions, and an active developer — she builds and validates features herself before handing them to the team for production hardening.

---

## How Decisions Flow

**Tracy and Claude own the "what" and "why"** — product vision, feature decisions, architectural direction, and written specifications.

**The development team owns the "how"** — production readiness, implementation, testing, deployment, and operations.

This is a firm boundary. The team does not make product decisions. Tracy does not make implementation decisions (beyond reviewing and approving plans before they execute). When there is ambiguity about which side of the line something falls on, ask Tracy.

**`CLAUDE.md` is the product bible.** If it conflicts with a code comment, `CLAUDE.md` wins. If it conflicts with a verbal instruction from a team member, ask Tracy to resolve it. The document exists precisely because context gets lost in conversation.

---

## Team Structure (as of March 12, 2026)

### Tracy — Product Vision, Demo, and Feature Development
- Owns all product decisions
- Works in her own branch using Claude Code as her engineer
- Builds and validates new features before pushing to development
- Pushes completed features to the development branch
- Primary contact for: product questions, UX decisions, feature scope, acceptance criteria

### Paula — Product Line Alignment, Vision, Packaging, Rollout, Onboarding
- UX for self-service client onboarding and ecommerce
- Integration with existing Membio product suite
- Pricing and tier structure for MemberSync (with Tracy and Rogelio)
- Product launch (with Tracy)

### Daniel — UX/UI for MemberSync and Integration with Existing Products
- Fit and finish across MemberSync (including new features with Tracy)
- Visual quality and UX consistency
- Prototyping as needed

### Rogelio — Administration, Integration, UX Testing
- Testing on all aspects of MemberSync (Membio-facing, client-facing, member-facing)
- Set-up, optimization, and administration of vendors to support MemberSync and the existing product suite
- Support system for MemberSync

### Mike and Dale — Production Platform
- Repository ownership, deployment pipeline, monitoring, and operations
- Production infrastructure: CI/CD, environments, secrets management
- Lead on Track 2 (production port, multi-tenant architecture)
- Primary contacts for: deployment questions, infrastructure decisions, database migrations, security

### Formos — Production Platform
- Works alongside Mike and Dale on the production platform
- Claude Code is the primary engineering tool for this track

---

## Three Development Tracks

### Track 1 — Feature Development (Tracy)
**Goal:** Build and validate new features. Fast, iterative, prototype-quality acceptable.
**Tool:** Claude Code (Tracy's branch)
**Inputs:** Specs and prompts written by Tracy + Claude. Tracy reviews implementation plans before approving execution.
**Output:** Validated features pushed to the development branch.

### Track 2 — Production Platform (Mike, Dale, Formos)
**Goal:** Port the Replit prototype to a production-grade, multi-tenant platform. Correct architecture from day one.
**Tool:** Claude Code
**Inputs:** `CLAUDE.md`, `DECISIONS.md`, `ROADMAP.md`, `KNOWN_ISSUES.md`, feature specs from Tracy
**Output:** Production-deployable code with proper multi-tenancy, migrations, testing, and monitoring.

**Track 2's primary tasks (in order):**
1. Eliminate all 110+ hardcoded Mainstreet/Illinois references (prerequisite for everything else)
2. Establish `tenant_config` as the control plane — replace `clientConfig.ts`
3. Add `client_id` to the 19+ tables that are missing it
4. Break `routes.ts` monolith (~10,900 lines) into domain-focused route files
5. SOC 2 Type I controls
6. Batch email sending for enterprise-scale clients

### Track 3 — Product Line Alignment, UX/UI, and Administration (Paula, Daniel, Rogelio)
**Goal:** Product packaging, onboarding, integrations, visual quality, testing, and vendor administration.
**Inputs:** Product specs from Tracy, pricing decisions from the pricing workstream
**Output:** Self-service onboarding UX, ecommerce, integration with existing Membio product suite, fit and finish across MemberSync, support infrastructure, vendor setup

---

## Toolchain

| Tool | Who Uses It | Purpose |
|------|-------------|---------|
| **Claude Code** | Tracy, Mike, Dale, Formos | Primary engineering tool across all tracks |
| **Claude (claude.ai)** | Tracy | Strategy, architecture, specs, project summaries, `CLAUDE.md` updates |
| **Julius.ai** | Tracy | SQL development and data validation against the production database |
| **GitHub** | All | Source control. Tracy's branch feeds development; Mike/Dale manage deployment pipeline |
| **Anthropic API** | Application | Powers all AI features. Single key managed by Membio — never exposed to clients |
| **SendGrid** | Application | Email delivery. ASM groups provisioned per client during onboarding |
| **AWS** | Production | Database hosting (PostgreSQL). Production environment |

---

## Common Infrastructure

All tracks share access to:
- **Membio Common** — a shared, read-only PostgreSQL database containing AMS and MLS data from client integrations
- **Local PostgreSQL** — each developer has their own local instance for application tables during development
- **`tenant_config` table** — the single source of truth for all per-client configuration

---

## Working with Claude Code

Claude Code reads `CLAUDE.md` at the start of every session. That file is its primary orientation. Before starting any significant work, Claude Code should:

1. Read `CLAUDE.md` fully
2. Check `DECISIONS.md` for any decisions relevant to the task
3. Check `KNOWN_ISSUES.md` for any issues the task might interact with
4. Check `OPEN_QUESTIONS.md` to confirm the task doesn't depend on an unresolved decision

**One task at a time.** Claude Code works best with a single, clear, well-scoped task. Do not ask it to "add multi-tenant support and also fix the email queue and refactor the routes file" in one instruction.

**Verify before reporting complete.** Claude Code should test its own work — happy path and at least one edge case — before reporting a task as done. Do not rely on the absence of compilation errors as a definition of done.

**When in doubt, ask.** If a task requires a product decision (scope, behavior, UX), stop and ask Tracy rather than making an assumption and building forward.

---

## Client Context

| Client | Members | Status | Notes |
|--------|---------|--------|-------|
| **Mainstreet REALTORS®** | ~18,275 | Active — primary client | Chicago suburbs; prototype deployed |
| **HGAR** | ~12,800 | Onboarding | Hudson Gateway Association, New York |
| **GRAR** | ~3,400 | Third paying client | Greater Rochester Association |
| **Client #4** | TBD | Pipeline | Enterprise pilot candidate; batch email and SOC 2 required before launch |

**Mainstreet is the reference implementation.** All hardcoded values in the prototype reflect Mainstreet's configuration — Illinois compliance rules, Chicago-area geographic context, Mainstreet-specific billing calendar. The production port's job is to make every one of these client-configurable.

---

## The Replit Prototype — Historical Context

MemberSync was built entirely in Replit by Tracy using Claude as CTO/advisor and Replit Agent as engineer. The last Replit code was pulled on March 12, 2026. There will be no future pulls from Replit — that chapter is closed.

Two Replit companion documents exist in the `/docs` folder for historical reference:
- `MemberSync_Replit_Orientation.md` — the orientation document sent to every new Replit agent
- `MemberSync_Replit_StandingRules_Header.md` — the compact rules header prepended to every Replit prompt

These are preserved as historical record only. They document the Replit workflow and standing rules enforced during prototype development. They are retired as of March 12, 2026.

---

## Communication Conventions

- **Product questions** → Tracy
- **Infrastructure / deployment questions** → Mike or Dale
- **When `CLAUDE.md` seems wrong or outdated** → Tell Tracy; do not work around it
- **When a task touches `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts`** → Stop. Get explicit written approval from Tracy before proceeding. These files are sealed.
- **When a task depends on an Open Question** → See `OPEN_QUESTIONS.md`. Raise it with Tracy before implementing.

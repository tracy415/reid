# MemberSync / SmartSends â€” Project Summary
## February 16, 2026

---

## OVERVIEW

Tracy is the founder of Membio, building MemberSync â€” a member engagement and retention platform for real estate associations and MLSs. The platform analyzes MLS listing data and association management system (AMS) data to help association executives understand, engage, and retain their members. The first client is Mainstreet REALTORSÂ® (~18,275 active members, ~2,800 offices, 16 sub-associations, 18 bill types).

Tracy builds exclusively with AI tools: Claude for strategy and specs, Julius.AI for SQL, and Replit Agent for coding. The stack is React + Node.js + PostgreSQL, hosted on Replit with an AWS production database.

---

## WHAT WAS ACCOMPLISHED IN THIS SESSION

### Data Consistency Fixes (Completed)

**Member Type Builder Consistency (v2 prompt):**
- Identified 166-member discrepancy between Dashboard (18,259 from `apmmember`) and Member Type Builder (18,093 from `appmemberassociation`)
- Established `member_metrics_cache` as single source of truth for active member status
- Created two-step query pattern: external DB for bill type data â†’ local cache for active status filtering
- Updated frontend `buildSQL()` function, backend counts/preview endpoints, and enrichment query
- Fixed table name typo: `appmemberassociation` â†’ `apmmemberassociation` (discovered by Replit)

**Enrichment Query Fix:**
- Fixed three bugs in `getAudienceMembers()` enrichment: missing emails, inactive members included (21,892 â†’ 18,092), preview showing 13 instead of 15
- Added `MemberFullName`, `MemberEmail` to enrichment SELECT
- Added `MemberStatus = 'Active'` filter and `DISTINCT ON` deduplication
- Added `.filter()` to only include enriched members in results
- CSV export confirmed working: 18,092 rows with emails populated

**Saved Audience Count Fix:**
- Fixed stale `member_count` in saved_audiences table
- Added lazy count refresh on audience access (self-correcting)
- Fixed preview over-fetch: LIMIT 50 before enrichment, slice to 15 after

### Code Cleanup (Prompt Written, Sent to Replit)

`CodeCleanup_DeadCode_and_Fixes.md` covers:
1. Remove mock data generators (500 fake members, 100 fake offices) and 4 silent fallback paths
2. Consolidate duplicate `getHealthStatus` functions (two different thresholds for same metric)
3. Remove `testLicenseExpiringQuery` debug endpoint from production interface
4. Fix picklist query deduplication (add `DISTINCT ON` to both picklist paths)
5. Fix picklist member count on save (include externalContacts in count)

### AI Chat Context Fix (Sent to Replit, In Progress)

`AIChat_ContextAndFallback_Fix.md` covers:
1. Pass conversation history (last 4 messages) to SQL generator for follow-up context
2. Summarize assistant messages to avoid bloating prompt with large result sets
3. Only include history when question looks like a follow-up (contains pronouns like "their", "them")
4. Retry without history if first attempt fails
5. Replace generic fallback chat prompt â€” never say "I don't have access to member data"

Replit's refinements:
- Trim assistant messages to natural language summary only
- Suppress SQL display from frontend results (users don't need to see raw SQL)
- Suppress MemberKey and phone columns from result tables
- Generate descriptive CSV filenames based on query content

### Product Philosophy Document (Completed)

`MemberSync_Product_Philosophy_Dashboard.md` â€” comprehensive document covering:
- The 75% problem (75% of members produce 12% of volume but pay 75% of dues)
- Mainstreet-specific numbers: top 25% (4,569 agents) control 88% of volume
- Why the 75% stay: connection, identity, autonomy â€” not just MLS access
- Existential threat: non-Realtor MLS access will remove the last transactional justification
- Five product principles: engagement â‰  production, celebrate connection, every member dollar is equal
- New tier names: Foundation (was License Maintainer), Builder (was Occasional Producer), Rainmaker (was Active Producer)
- Dashboard specification: The Pulse, Today's Activity, The 75% Report
- Tier-aware engagement scoring redesign (Foundation members can score 10/10)
- Engagement labels: Highly Connected, Connected, Drifting, Disconnected (replaces risk language)
- Expanded celebrations: frequent personal moments, member headshots, early-career milestones
- Implementation priority and data source mapping

---

## KNOWN ISSUES STILL OPEN

### The 172-Member Gap
- Dashboard shows 18,259 active members; Member Type Builder shows 18,087
- Difference = members active in `apmmember` but with no record in `appmemberassociation` for AssociationId = 'MainStreet'
- Fix options: add "No Bill Type Assigned" category or handle "Select All" differently
- Lower priority â€” cosmetic, not a data integrity issue

### AI Query Service (Issue #3)
- AI sometimes generates SQL with wrong column names or join patterns (e.g., `er.EventKey` without quotes)
- Needs more example queries for events/registrations in the system prompt
- The conversation history fix will help with follow-up context
- Deeper fix: add 2-3 event registration examples to `getSqlGenerationPrompt()`

### Dashboard Stats (Issue #4)
- Current dashboard mixes compliance and engagement metrics
- Compliance Alerts showing 32,252 is misleading/scary
- Philosophy doc specifies the redesign â€” needs Replit prompt
- Depends on engagement score redesign (new tier-aware scoring)

### Cache Health Monitoring (Issue #1)
- Cron jobs can fail silently on Replit instance sleep/restart
- Need `cache_refresh_log` table tracking every refresh
- Need admin card showing last successful refresh per cache
- Need manual "Refresh Now" button
- Need self-healing on app startup

---

## WHAT TO BUILD NEXT (Priority Order)

1. **Engagement Score Redesign** â€” Change scoring formula in `memberMetricsCacheService.ts` to tier-aware model. Rename tiers (Foundation/Builder/Rainmaker). Update labels (Connected/Drifting/Disconnected). This is the foundation everything else depends on.

2. **Dashboard Redesign** â€” Implement the three-section dashboard from the philosophy doc. Remove compliance widgets, add The Pulse cards, Today's Activity feed, and The 75% Report.

3. **Expanded Celebrations** â€” More frequent, personal milestones. Member headshots in widgets. Make celebrations the first thing the executive sees.

4. **Mainstreet Knowledge Context** â€” Add organizational context to the AI fallback prompt. Add event registration examples to SQL generation prompt.

5. **Lapse Prevention Module** â€” Phase 3 spec exists (`SmartSends_Phase3_Complete.md`). Status change capture, risk scoring, intervention management, billing calendar awareness. Not yet built.

6. **Triggered Campaign Engine** â€” Automated email sequences responding to data events. Spec exists (`SmartSends_TriggeredCampaigns.md`). Not yet built.

7. **Production Analytics Refinement** â€” Validate production concentration numbers with Julius. Add visual charts. Ensure accuracy before presenting to clients.

---

## KEY ARCHITECTURAL DECISIONS

- `member_metrics_cache` is the single source of truth for active member status
- `apmmember.MemberStatus = 'Active'` is the canonical definition of an active member
- Two-step query pattern for cross-database operations (external DB for keys â†’ local cache for enrichment)
- `DISTINCT ON ("ApmClientId", "MemberKey") ORDER BY "ApmSourceModificationTimestamp" DESC` for all AMS table queries (snapshot deduplication)
- `AssociationId = 'MainStreet'` filter on `apmmemberassociation` to avoid sub-association duplicates
- Bill type codes are created dynamically by Finance; use pattern-based recognition, not hardcoded lists
- Office suspension is the critical gatekeeper for member MLS/SentriLock access
- Voluntary contributions (RPAC, REF) excluded from risk scoring

---

## KEY FILES

### Backend Services
- `storage.ts` â€” Main data layer, dashboard metrics, member/office queries, mock data (being removed)
- `aiQueryService.ts` â€” AI SQL generation, query execution, insights
- `aiAudienceService.ts` â€” Audience CRUD, smart audience execution, enrichment, CSV export
- `aiEmailService.ts` â€” AI email composition
- `emailService.ts` â€” Email sending, queue processing, campaign management
- `memberMetricsCacheService.ts` â€” Daily cache refresh with engagement scoring
- `milestoneDetectionService.ts` â€” Celebration/milestone detection
- `sharedDatabaseSchema.ts` â€” Database schema documentation shared across AI services
- `anthropic.ts` â€” Fallback conversational AI provider

### Frontend Components
- `SmartSends.tsx` â€” SmartSends dashboard (campaigns, templates)
- `AudienceBuilder.tsx` â€” AI audience builder
- `MemberBillTypeBuilder.tsx` â€” Member/Bill Type audience builder
- `PicklistBuilder.tsx` â€” Manual member picklist builder
- `SendEmail.tsx` â€” Email composition and sending flow (205KB â€” very large)
- `AIChatBox.tsx` â€” AI chat interface
- `AnalyticsOverview.tsx` â€” Production analytics dashboard
- `CelebrationInsights.tsx` â€” Milestone celebrations widget
- `SavedAudiences.tsx` â€” Saved audiences list with preview modals

### Specifications & Prompts
- `MemberSync_Product_Philosophy_Dashboard.md` â€” Product philosophy and dashboard spec (NEW)
- `MemberTypeBuilder_ConsistencyFix_v2.md` â€” Member Type Builder data fix
- `MemberTypeBuilder_EnrichmentFix.md` â€” Enrichment query fix
- `CodeCleanup_DeadCode_and_Fixes.md` â€” Code cleanup prompt
- `AIChat_ContextAndFallback_Fix.md` â€” AI chat context fix
- `SmartSends_Phase3_Complete.md` â€” Lapse prevention spec
- `SmartSends_AudienceBuilder_Improvements.md` â€” Audience builder spec
- `MemberSync_SmartSends_Project_Summary_Feb2026.md` â€” Previous project summary

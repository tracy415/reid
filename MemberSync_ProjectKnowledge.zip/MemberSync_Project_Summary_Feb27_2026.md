# MemberSync / SmartSends — Project Summary
## February 27, 2026

This document captures all decisions, architecture, prompts, and current state through February 27, 2026. Use this to resume work in a new conversation.

---

## TABLE OF CONTENTS

1. Project Overview
2. Client Pipeline and Membership Context
3. Technical Architecture
4. What Has Been Built (Complete)
5. What Was Accomplished Feb 26–27, 2026
6. Current Database Schema (Key Tables)
7. Production Database Schema (Read-Only)
8. Daily Jobs Schedule
9. AI Services Architecture
10. Engagement Scoring System
11. Dashboard Architecture
12. SmartSends Current State
13. Triggered Campaigns / Automations Current State
14. AI Query Engine (Chats) Current State
15. Prompts Ready for Replit (Not Yet Built)
16. Known Issues Still Open
17. CRMLS Pilot Program
18. AI Cost Model and Pricing Strategy
19. Security & Data Protection Roadmap
20. Multi-Tenant Architecture Roadmap
21. Strategic Roadmap (Updated)
22. Key Architectural Decisions
23. Key Files Reference
24. Production Data Reference
25. Mainstreet Brand and AI Content Training
26. Standing Rules for Replit Prompts

---

# 1. PROJECT OVERVIEW

## What We Are Building

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs. SmartSends is the email marketing and automation layer within MemberSync. The platform uses predictive analytics to help MLS and association executives retain and engage members by analyzing residential real estate listings and association management system (AMS) data.

The product vision: MemberSync should be the organization's **second brain** — the system that is always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

## Product Model

MemberSync is a **SaaS product** — not a custom build for any single client. Every feature should work for any association or MLS through configuration, not custom code. The long-term goal is self-service onboarding: a new organization signs up with a credit card, connects their API keys, and goes.

## Build Philosophy

Tracy (founder of Membio) is a non-technical business leader with 30+ years in proptech, building exclusively with AI tools:
- **Claude** for strategy, specifications, and Replit prompts
- **Julius.AI** for SQL development against the production database
- **Replit Agent** for all coding implementation

Tracy maintains creative control over product design and UX decisions. The development team hardens for production (error handling, edge cases, performance). Tracy builds the first 80% through prototyping; the team does the production-ready 20%.

## Product Philosophy: Celebrating Connection Over Compliance

The core insight: 75% of association members produce only 12% of real estate volume, yet pay 75% of dues revenue. MemberSync exists to help associations prove their value to all members by measuring and improving engagement with the organization itself. All member tiers are framed positively:

- **Foundation** (0–5 sides): 77% of membership. The financial backbone — these members pay dues that fund everything. They may not close many deals, but they're the reason the association exists at scale.
- **Builder** (6–39 sides): 21% of membership. Reliable producers growing their business.
- **Rainmaker** (40+ sides): 1.4% of membership. Top producers and market leaders.

**No fake data. Every email preview, every dashboard metric, every member interaction uses real, verifiable data.** Sample/placeholder data is never shown to staffers when real data is available.

---

# 2. CLIENT PIPELINE AND MEMBERSHIP CONTEXT

## Mainstreet REALTORS® (Live Client)
- ~18,275 active members across ~2,800 offices in the Chicago suburbs
- Largest regional real estate association in Chicagoland
- 4 campuses: Downers Grove (HQ), Libertyville, Rolling Meadows, Tinley Park
- 16 administrative associations, 18 member bill types
- MLS data uses "MRD" prefix on member keys (unique to Mainstreet; other associations don't prefix)
- AMS strips the prefix — same ID number, different format across systems
- **Only active members exist in our system.** Suspended members disappear from the AMS feed — they're not flagged or tracked, they simply stop appearing.

## Hudson Gateway Association of REALTORS® (Onboarding)
- ~12,800 members in the Hudson Valley, NY region
- Preparing to onboard — standard integration pattern

## CRMLS (Potential Third Client)
- 103,000+ members — California Regional MLS
- CMO has seen and "fell in love" with the platform
- 90-day pilot proposed at $2,500/month with specific success criteria
- Demo preparation is a key driver for current development

## Member Type Context (Critical for AI and Audience Building)
- **REALTOR® members** (~17,100): Licensed agents who are NAR members. Bill types: R, DR, SM, SDR, EM, HM, RAA
- **Non-member licensees**: Hold IL real estate license but are NOT NAR members. They exist in MLS data but NOT in AMS data. They can join at any time — a key acquisition target.
- **Designated Managing Brokers (DMBs)**: Bill type DR/SDR. In Illinois, all agents are licensed as "brokers," but DMBs hold a separate managing broker license with legal and financial responsibility for the office. At Mainstreet, DMBs are also called Designated REALTORS®. They pay for their agents' access.
- **Affiliates**: Bill types AFF, AFCI, AFC. Non-licensees (lenders, title companies, inspectors). They JOIN the association but don't sell real estate.
- **Appraisers**: Bill types LAD, LAR, AST, LA. Licensed appraisers with their own membership category.

---

# 3. TECHNICAL ARCHITECTURE

- **Frontend:** React + TypeScript + Tailwind CSS + shadcn/ui
- **Backend:** Node.js + Express + Drizzle ORM
- **Database:** PostgreSQL (local app DB + read-only external AMS/MLS databases)
- **AI:** Claude API (Sonnet 4 for complex analysis/generation; Haiku for simple queries — model routing planned)
- **Email:** SendGrid (300K/month allocation for Mainstreet; scaling needed for CRMLS)
- **Hosting:** Replit for development; AWS production infrastructure
- **Infrastructure:** Membio is an existing AWS shop. Scaling to dedicated cloud hosting is an extension of existing infrastructure, not a platform migration.

---

# 4. WHAT HAS BEEN BUILT (COMPLETE)

- Full dashboard with AI Chat, Pulse cards, Activity Feed, Member Recognition, Mainstreet Community
- Tier-aware engagement scoring system
- Member detail pages with engagement breakdown
- Office detail pages with agent rosters
- SmartSends email campaign creation (AI + manual)
- Audience building (AI builder, picklist, member/bill type, CSV upload)
- Saved audiences with preview and count
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail pages
- Triggered campaigns / Automations engine with 7 trigger types
- Automations UX upgrade (full-page wizard)
- Email analytics overview
- Office visit brief PDF generation
- Compliance tracking
- Image library for emails
- Draft management
- Scheduled email sending
- Email queue safety infrastructure (per-member throttle, queue count/export/flush, volume summary)
- Campaign list performance optimization (bulk stats, SQL pagination, automation campaign filtering)
- **Celebration/milestone email data pipeline** — celebrationInfo stored on campaign, per-member milestone lookup at send time, merge field replacement for MilestoneLabel/MilestoneDetail/MilestoneValue/MilestoneEmoji
- **AI content training** — Mainstreet institutional knowledge briefing with member type context, tone guardrails, anti-hallucination rules

---

# 5. WHAT WAS ACCOMPLISHED FEBRUARY 26–27, 2026

## Critical Discovery: Milestone/Celebration Merge Fields Were Broken

Tracy tested celebration emails and discovered that `personalizeMergeFields()` in `emailService.ts` originally only replaced 7 fields (FirstName, LastName, FullName, OfficeName, MemberKey, Email, YearsWithMainstreet). It did NOT replace milestone-specific fields: {{MilestoneLabel}}, {{MilestoneDetail}}, {{MilestoneValue}}, {{MilestoneEmoji}}, {{YearsAsMember}}, {{ClassName}}, {{ClassDate}}, etc.

**Data flow problem:** `celebrationInfo` with per-member milestone data was passed from the frontend to the API, but the API used it only for tracking (recording which members got celebration emails). It was NEVER passed to `queueEmailCampaign()` for the actual send. The `personalizeMergeFields()` function had no knowledge of milestone data.

**Result:** Every celebration email would have sent to recipients with literal `{{MilestoneLabel}}` text visible. Fortunately, the system was still in sandbox lockdown — no emails had been sent to real members.

### Fix Implemented by Replit
A comprehensive prompt was sent and Replit implemented the full fix:
- Extended `PersonalizationData` interface with milestone, anniversary, event, and class fields
- Extended `personalizeMergeFields()` with all new merge field patterns (case-insensitive regex)
- Modified `queueEmailCampaign` call in routes.ts to pass `celebrationInfo`
- Added `celebration_info` JSONB column to `emailCampaigns` table in schema
- Per-member milestone lookup during send processing (finds the specific milestone for each recipient)
- `buildMilestoneDetail()` helper constructs contextual detail strings from milestone contextJson
- Safety net: final regex removes any remaining `{{...}}` tags so recipients never see raw merge fields

### Post-Implementation Testing Revealed Three Issues

1. **Send failed with 500 error** — Diagnosed as `MAX_CAMPAIGN_RECIPIENTS = 1` (the safety limit). The celebration audience had 613 members. Not a code bug — the safety guardrail working as designed. Fix: bump the secret for testing (sandbox mode still limits delivery to test email only).

2. **Preview shows same sample data for every email** — The Preview step uses static `EXAMPLE_MERGE_DATA` that maps every `{{MilestoneLabel}}` to "50th Career Transaction" and every `{{FirstName}}` to "Sarah." This means every milestone type (Rising Stars, Volume Milestones, Top Producers) shows the same generic preview.

3. **Subject line and preview text show raw merge tags** — `replaceMergeFieldsWithSampleData` not applied to subject line or preview text in Preview step.

## Live Data Preview for ALL Emails (Prompt Written)

Tracy's requirement: **"Every email sent through our system needs to be real and verifiable. We don't do fake data."** This applies to ALL email types, not just celebrations.

A comprehensive prompt was written (`MemberSync_LivePreview_AllEmails.md`) that builds:
- **For celebration emails:** Preview pulls from `celebrationAudience.milestones` array — real member names, real milestone labels, real context data
- **For regular audience emails:** Preview fetches first 15 members' actual details from the server (name, office, email) via `/api/members/by-keys`
- **Navigation:** Purple bar with Previous/Next arrows to cycle through recipients. Shows "Recipient 1 of 18,275 (previewing first 15)" for large audiences.
- **Subject line and preview text update per-recipient**
- **Compose step unchanged** — sample data still used while writing/editing the template, since there's no specific recipient context yet

## AI Query Engine Analysis and Improvement (Prompt Written)

Tracy tested the AI Chat query: "Show me all agents in Downers Grove IL who closed a home in January 2026 whose IL license will expire in 2026." Claude returned "I can't answer that — please rephrase."

**Root cause analysis:** The query requires a three-way cross-schema join (MLS property → MLS member → AMS member). The schema documentation covers all three data sources and the join patterns, but no example query demonstrates this specific cross-domain combination. The "HANDLING VAGUE QUESTIONS" instruction tells Claude to return ERROR for broad questions — which it interpreted too aggressively.

**Three failure modes identified:**
1. **Questions between example cracks:** Conversational questions that don't map to documented patterns
2. **SQL execution errors after generation:** No retry mechanism — user gets raw Postgres error
3. **Questions about undocumented data:** Schema documentation doesn't cover the requested data

**Scaling concern:** The system prompt for the query engine is ~18,000+ tokens. Adding more data sources (Google Analytics, support tickets, lockbox access, benefits usage) would make the prompt unmanageably large. The current architecture has a scaling ceiling.

A comprehensive prompt was written (`MemberSync_QueryEngine_RetryAndCrossDomain.md`) with:
- **SQL retry loop:** When generated SQL fails, send the Postgres error back to Claude for correction. Self-healing instead of dead-end errors.
- **ERROR retry:** When Claude returns "I can't answer that," encourage it to attempt a reasonable interpretation
- **6 cross-domain example queries** including Tracy's exact Downers Grove query, Spanish-speaking agents in Oak Park, CRS designation holders in Naperville, market stats by city/zip
- **Geographic context section** for the Mainstreet service area (campus regions, suburb groupings, city name matching)
- **Updated confidence instructions:** "Attempt first, ask second" — only return ERROR for genuinely unanswerable questions
- **User-friendly error messages:** Suggest breaking complex questions into parts instead of showing Postgres errors

**Phase 2 architecture (future):** Query planning — split the single AI call into two. First call identifies which tables are relevant and determines join path. Second call gets only the relevant schema sections and generates SQL. This is how you handle 10+ data sources without prompt overload.

## AI Training Prompt Updated with Member Type Context

The AI email service training prompt was extended with comprehensive member type distinctions:
- REALTOR® vs non-member licensees (and why the distinction matters for associations)
- DMBs as the financial decision-makers for offices
- Affiliates as non-licensee allied members
- Appraisers as a separate category
- Illinois licensing quirks (all brokers are "managing brokers")
- Dues structure and competitive positioning against MLSs going non-REALTOR

## Automation Intelligence and Template Cleanup (Prompt Written)

Earlier in this session, a prompt was written (`MemberSync_AutomationIntelligence_TemplateCleanup.md`) that:
- Removes the broken template system from SmartSends navigation
- Adds contextual intelligence to automations (smart auto-naming, AI purpose pre-fill based on trigger type)
- Provides trigger-aware method cards (only AI and Scratch — templates removed)
- Fixes inconsistent merge field preview rendering

---

# 6–11. [UNCHANGED FROM FEB 25 SUMMARY]

Refer to the Feb 25 project summary for these sections — no changes to database schema, production schema, daily jobs, AI services, engagement scoring, or dashboard architecture.

**One addition to schema:** `celebration_info` JSONB column added to `email_campaigns` table (stores milestone type, label, and per-member milestone data for personalization at send time).

---

# 12. SMARTSENDS CURRENT STATE

## What's Built and Working
- Campaign creation with AI-composed or manual email body
- Two method cards: Generate with AI, Create from Scratch (templates removed from nav)
- Audience selection (AI-built, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail page with aggregate stats
- Analytics overview with office leaderboards
- PDF generation for office visit briefs
- Saved audiences with count and preview
- Draft management
- Image library
- Insert Event shows real upcoming events from database and creates styled teal blocks
- Campaign list loads in <300ms (was timing out at 75K rows)
- Automation campaigns filtered from Dashboard (only appear on Automations page)
- Bulk stats queries replace N+1 pattern
- SQL-level pagination for sent campaigns
- **Celebration/milestone merge field pipeline fully implemented** (celebrationInfo → campaign → per-member lookup → replacement)
- **Safety net merge field cleanup** (removes any remaining {{...}} tags before send)

## What's Built But Has Issues (Fixes in Prompts)
- **Preview shows fake sample data instead of real members** — Fix in LivePreview prompt
- **Subject line preview shows raw {{MilestoneLabel}}** — Fix in LivePreview prompt
- **"Pause Before Editing" frontend dialog still showing** — Backend fix applied, frontend dialog not removed (Cleanup prompt)
- **Modal-on-modal in drip sequences** — Step editor still uses popup modal (Cleanup prompt)
- **"Create from Scratch" lands on confusing empty screen** — Should auto-enter edit mode (Cleanup prompt)
- **No delete/discard for automations** — Can't remove unwanted automations (Cleanup prompt)
- **Separate "Generate Email" button in automations** — Breaks fill-fields-click-Next flow (Cleanup prompt)
- **AI says © 2024** — Needs current year instruction (Cleanup prompt)
- **ReactQuill strips inline styles from inserted blocks** — Event blocks lose formatting (Cleanup prompt)
- **MAX_CAMPAIGN_RECIPIENTS = 1** — Safety limit needs to be bumped for testing; sandbox mode provides sufficient protection

## Email Queue Safety
- Per-member daily send throttle (2 automated emails/member/day)
- Queue count, export (streaming CSV), and flush endpoints
- Per-automation volume summary endpoint
- Throttled sends tracked with status='throttled' and skip_reason
- 75,330 queued emails discovered and diagnosed — root cause was missing temporal filter

---

# 13. TRIGGERED CAMPAIGNS / AUTOMATIONS CURRENT STATE

## What's Built
- Triggered campaign processor running every 15 minutes
- 7 trigger types: event_registration, event_reminder, event_followup, membership_anniversary, production_milestone, drip_sequence, scheduled_series
- Full-page wizard for create/edit (Configure Trigger → Compose → Preview → Settings & Activate)
- Trigger-specific configuration UI for each type
- Drip sequence step builder (modal — needs inline conversion)
- Scheduled Series step builder with date pickers (has validation bug)
- Automation list with status sections (Active, Paused, Drafts, Archived)
- Send window configuration (start/end time, weekday toggle)
- Auto-stop date
- Deduplication to prevent repeat sends
- Per-member daily throttle prevents automation flooding
- Active campaigns can be edited without pausing (content edits allowed, trigger type changes blocked)
- **Smart auto-naming based on trigger type** (in Automation Intelligence prompt)
- **AI purpose pre-fill based on trigger configuration** (in Automation Intelligence prompt)

## Critical Bugs (Fixed and Deployed)
- **Event Registration trigger evaluated ALL history** — Missing `AND a.start_datetime >= CURRENT_DATE` filter caused 75K+ emails. **FIXED** in Queue Safety UX Redesign prompt, deployed and verified.
- **Event Followup daysAfter uncapped** — Could look back indefinitely. **FIXED** with 14-day max cap.

## Architecture
- `triggered_campaigns` table: campaign config, trigger type, status
- `triggered_campaign_steps` table: multi-step campaigns (drip, scheduled series)
- `triggered_campaign_sends` table: per-member send records with dedup
- Processor: `triggeredCampaignProcessor.ts` — evaluates triggers, queues sends
- `triggerReference` field prevents duplicate sends
- `campaignVersion` integer field supports future A/B testing
- `canSendToMember()` throttle checks rolling 24h window before sending

---

# 14. AI QUERY ENGINE (CHATS) CURRENT STATE

## What's Built
- Natural language to SQL generation using Claude API
- Dual-database routing (local cache tables vs. external AMS/MLS tables)
- Schema validation and quoting fixes
- 20+ example queries in the system prompt
- `sharedDatabaseSchema.ts` — 800 lines of comprehensive schema documentation
- Database routing rule prevents cross-database JOIN errors
- Key format rules document the MRD prefix handling

## Known Failure Modes
1. **Cross-domain queries fail:** Questions combining MLS transaction data with AMS member attributes (license, designations, join date) are not represented in examples. Claude bails to "please rephrase."
2. **No SQL retry loop:** When generated SQL has syntax errors, the user gets a Postgres error. No self-healing.
3. **Overly aggressive error handling:** The "HANDLING VAGUE QUESTIONS" instruction tells Claude to return ERROR for broad questions. Claude interprets this too conservatively.
4. **No geographic awareness:** Location-based queries (by city, zip, suburb region) are underrepresented despite being extremely common for associations.

## Fix Written (Not Yet Deployed)
`MemberSync_QueryEngine_RetryAndCrossDomain.md` addresses all four failure modes with retry loop, cross-domain examples, geographic context, and confidence rebalancing.

## Scaling Architecture (Future — Phase 2)
Current system prompt is ~18,000+ tokens. Adding more data sources would exceed practical limits. Future architecture: split into query planner (identifies relevant tables and join paths) + SQL generator (gets only relevant schema sections). Two AI calls instead of one massive prompt.

---

# 15. PROMPTS READY FOR REPLIT

**Send order (updated Feb 27):**

1. **Post-Testing Merge Field Fix** (`MemberSync_PostTesting_MergeFieldFix.md`) — 7-part fix covering milestone merge fields (CRITICAL), audience preview for large audiences, multi-event automations, subject line preview, drip sequence Next button, automation state reset, mobile preview. **PARTIALLY IMPLEMENTED — merge field pipeline done, remaining parts need verification.**

2. **Live Data Preview for ALL Emails** (`MemberSync_LivePreview_AllEmails.md`) — Real recipient data in every email preview with Previous/Next navigation. Celebration emails show per-member milestone data. Regular emails show real names and offices. No fake data ever. **READY TO SEND.**

3. **Query Engine: Retry & Cross-Domain** (`MemberSync_QueryEngine_RetryAndCrossDomain.md`) — SQL retry loop, cross-domain example queries, geographic context, confidence rebalancing, user-friendly error messages. **READY TO SEND.**

4. **Automation Intelligence & Template Cleanup** (`MemberSync_AutomationIntelligence_TemplateCleanup.md`) — Remove broken template system, smart auto-naming, AI purpose pre-fill, trigger-aware method cards. **READY TO SEND.**

5. **Post-Implementation Cleanup** (`SmartSends_PostImplementation_Cleanup.md`) — 8 fixes from testing Prompts 1 and 2. **READY TO SEND.**

6. **AI Content Training v2** (`SmartSends_Prompt3_AITraining_v2.md`) — Mainstreet briefing with member type context, anti-hallucination, tone guardrails, cost optimization. **READY TO SEND.**

7. **Queue Safety UX Redesign** (`MemberSync_QueueSafety_UX_Redesign_Final.md`) — Inline badges, Automations control panel, temporal safeguards. **DEPLOYED AND VERIFIED.**

8. **Member Recognition Cleanup** (`MemberSync_MemberRecognition_Cleanup_Prompt.md`) — Delete dead component, remove slice limits, server-side milestone fetch. **SENT — REPLIT IMPLEMENTING NOW.**

**On Hold:**
- **Automation Priority + Global Contact Limit** — ON HOLD until queue safety and cleanup are stable
- **A/B Testing for Triggered Campaigns** — SEND AFTER AUTOMATIONS ARE STABLE
- **AI Chart Rendering** — NOT YET WRITTEN; accelerated for CRMLS pilot

---

# 16. KNOWN ISSUES STILL OPEN

### Critical (Blocking User Flows)
- **75,330 emails still in queue** — Need to flush now that temporal safeguard is deployed
- **MAX_CAMPAIGN_RECIPIENTS = 1** — Safety limit blocking test sends; needs to be bumped (sandbox mode provides protection)
- **Preview shows fake sample data** — Every email shows "Hi Sarah" instead of real recipients. Fix in LivePreview prompt.

### Important (UX Quality)
- **"Pause Before Editing" dialog** — Backend fix applied, frontend dialog remains (Cleanup)
- **Modal step editor in drip sequences** — Should be inline expand/collapse (Cleanup)
- **"Create from Scratch" empty screen** — Should auto-enter edit mode (Cleanup)
- **No delete/discard for automations** (Cleanup)
- **Separate "Generate Email" button** — Breaks intuitive flow (Cleanup)
- **AI copyright year says 2024** (Cleanup)
- **AI Query Engine fails on cross-domain questions** — Fix written, not deployed
- **Subject line/preview text show raw merge tags** — Fix in LivePreview prompt
- **Multi-event automations don't populate event names** — Fix in PostTesting prompt

### Lower Priority
- Drip sequence step editor needs proper EmailComposer per step with visual preview (future prompt)
- Compliance email flow needs redesign (bigger design conversation needed)
- The 172-member gap (dashboard vs. member type builder count)
- Cache health monitoring (no admin visibility into cron job status)
- Email engagement data cold start
- Revenue data uses catalog prices, not actual invoiced amounts
- Resend Campaign uses modal instead of full wizard

---

# 17–19. [UNCHANGED FROM FEB 25 SUMMARY]

Refer to the Feb 25 project summary for CRMLS Pilot Program, AI Cost Model, Security Roadmap, and Multi-Tenant Architecture sections.

---

# 20. STRATEGIC ROADMAP (UPDATED)

## Immediate (In Progress)
1. **Bump MAX_CAMPAIGN_RECIPIENTS** — Allow test sends while sandbox mode protects
2. **Live Data Preview** — Real recipient data in all email previews (PROMPT READY)
3. **Query Engine Retry + Cross-Domain** — Make Chats reliable for demos (PROMPT READY)
4. **Automation Intelligence** — Remove broken templates, smart auto-naming (PROMPT READY)
5. **Post-Implementation Cleanup** — 8 remaining fixes (PROMPT READY)
6. **Queue Safety UX + Temporal Safeguards** — Flush 75K queue after deployment (SENT)
7. **AI Content Training v2** — Member type context for smarter emails (PROMPT READY)

## Near-Term (Pilot Preparation)
8. **Automation Priority + Global Contact Limit** — ON HOLD until stable
9. **A/B Testing** — Variant testing for triggered campaigns
10. **AI Chart Rendering** — Inline charts in AI Chat (ACCELERATED for CRMLS pilot)
11. **Query Engine Phase 2 — Query Planning Architecture** — Split planner + generator for data source scaling
12. **Prompt Caching** — 90% reduction on AI input costs
13. **Multi-Tenant Stage 1** — Database-driven tenant config for HGAR onboarding
14. **Batch Email Sending** — Rate-limited queue for CRMLS scale
15. **SOC 2 Type I Preparation**

## Medium-Term
16. **Lapse Prevention System** — Status tracking, risk scoring, intervention management
17. **Multi-Tenant Stage 2** — Admin provisioning dashboard
18. **Broker Module** — Office management dashboards
19. **Additional Data Source Integration** — Support tickets, Google Analytics, benefits usage, lockbox access
20. **Exportable Charts** — PDF/PNG export, copy to clipboard

## Longer-Term
21. **AI Report Generation** — Multi-section board reports from natural language
22. **Self-Service Onboarding (Multi-Tenant Stage 3)** — Credit card signup and GO
23. **Lapse Pattern Analysis** — Predictive models from pre-departure behavior
24. **Integration Marketplace** — Zendesk, Google Analytics, LMS connectors
25. **AI Presentation Generation** — Slide-ready content from data

---

# 21. KEY ARCHITECTURAL DECISIONS

All decisions from previous summaries remain in effect, plus:

- **No fake data in previews. Ever.** Every email preview shows real recipient data when available. Sample/placeholder data only appears in the Compose step where you're writing the template. Once you reach Preview, it's real names, real offices, real milestones.
- **Live preview uses first 15 members** from any audience. Navigation arrows let staffers click through and verify personalization is correct before sending.
- **SQL retry loop for query engine.** When Claude generates SQL that fails, send the Postgres error back for correction before showing the user an error. Self-healing beats dead ends.
- **"Attempt first, ask second" for AI queries.** Claude should try to generate SQL for any reasonable interpretation of a question. Only return an error for genuinely unanswerable questions.
- **Geographic context is first-class data.** Associations and MLSs care deeply about location — where agents work, where listings sell, where offices sit. The query engine needs geographic awareness (city groupings, suburb regions, campus areas).
- **Cross-domain queries are the highest-value queries.** Combining MLS transaction data with AMS member attributes (license, designations, language) is exactly what makes MemberSync valuable. These queries must work reliably.
- **Query engine has a scaling ceiling.** The current single-prompt architecture (~18K tokens) works for current data sources but won't scale to 10+. Phase 2 architecture: query planner + SQL generator (two AI calls, relevant schema only).
- **The MRD prefix is Mainstreet-specific.** Other associations/MLSs share the same ID with no prefix. The multi-tenant architecture must handle variable key formats, not hardcode MRD.
- **celebrationInfo stored on campaign record.** Milestone data for each recipient travels with the campaign as JSONB, enabling per-member personalization at send time.
- **Safety net merge field cleanup.** A final regex removes any remaining `{{...}}` tags before sending, so recipients never see raw merge syntax regardless of what went wrong upstream.

---

# 22. KEY FILES REFERENCE

### Prompts Ready to Send (Feb 27 — Current Round)
- `MemberSync_LivePreview_AllEmails.md` — Real data in all email previews (READY)
- `MemberSync_QueryEngine_RetryAndCrossDomain.md` — SQL retry, cross-domain examples, geographic context (READY)
- `MemberSync_AutomationIntelligence_TemplateCleanup.md` — Remove templates, smart auto-naming (READY)
- `SmartSends_PostImplementation_Cleanup.md` — 8 fixes from testing (READY)
- `SmartSends_Prompt3_AITraining_v2.md` — Member type context, anti-hallucination (READY)

### Prompts Sent to Replit (Awaiting/In Progress)
- `MemberSync_QueueSafety_UX_Redesign_Final.md` — Inline badges, control panel, temporal safeguards (DEPLOYED AND VERIFIED)
- `MemberSync_MemberRecognition_Cleanup_Prompt.md` — Fix counts, server-side fetch, dead code (SENT — REPLIT IMPLEMENTING NOW)

### Prompts Previously Implemented
- `MemberSync_PostTesting_MergeFieldFix.md` — Celebration merge field pipeline (IMPLEMENTED — merge fields working)
- `MemberSync_EmailSafety_QueueDiagnostic_Prompt.md` — Queue throttle, export, flush (DEPLOYED)
- `MemberSync_CampaignList_Fix_Prompt.md` — Exclude automations, SQL pagination, bulk stats (DEPLOYED)
- `SmartSends_Prompt2_BackendFixes.md` — autoStopDate fix, relax active edit check (DEPLOYED)
- All prompts listed in previous summaries remain COMPLETE

### Strategy Documents
- `MemberSync_CRMLS_Scaling_Roadmap.docx` — Comprehensive scaling, AI cost, security, multi-tenant roadmap
- `MemberSync_CRMLS_Pilot_Proposal.docx` — 90-day pilot structure, pricing, success criteria

### Backend Services
- `emailService.ts` — Email sending, queue processing, campaign management, **milestone merge field replacement**, `buildMilestoneDetail()`, `getBulkCampaignStats()`
- `triggeredCampaignProcessor.ts` — Triggered campaign evaluation and send processing, `canSendToMember()` throttle
- `aiQueryService.ts` — AI SQL generation, query execution, insights (BEING UPDATED with retry loop + cross-domain examples)
- `aiEmailService.ts` — AI email composition (BEING UPDATED with member type training)
- `sharedDatabaseSchema.ts` — Database schema documentation for AI services (~800 lines, BEING UPDATED with geographic context)
- `storage.ts` — Main data layer, dashboard metrics, member/office queries
- `memberMetricsCacheService.ts` — Daily cache refresh with tier-aware engagement scoring
- `engagementScoreService.ts` — Engagement score calculation logic
- `aiAudienceService.ts` — Audience CRUD, smart audience execution, enrichment
- `scheduledEmailProcessor.ts` — Processes scheduled campaigns
- `milestoneDetectionService.ts` — Celebration/milestone detection
- `analyticsProductionCacheService.ts` — Office/agent production analytics
- `activityCacheService.ts` — Activity feed data
- `visitBriefService.ts` — Office visit PDF generation
- `anthropic.ts` — Claude API client (currently Sonnet 4, max_tokens: 2048)

### Frontend — Pages
- `SendEmail.tsx` — Email composition wizard (BEING UPDATED with live data preview)
- `CreateAutomation.tsx` — Automation creation wizard
- `SmartSends.tsx` — SmartSends dashboard + automations list
- `AudienceBuilder.tsx` — AI audience builder
- `CampaignDetail.tsx` — Campaign detail with resend capability

### Frontend — Shared Components
- `emailBlocks.ts` — Shared utilities: generateEventBlockHtml, generateOfferBlockHtml, generateCtaButtonHtml, `EXAMPLE_MERGE_DATA`, `replaceMergeFieldsWithSampleData`
- `EmailComposer.tsx` — Shared email composition component

### Configuration
- `schema.ts` — Drizzle ORM schema (includes `celebration_info` JSONB column on `email_campaigns`)
- `routes.ts` — All API endpoints (~7,400 lines)

---

# 23. PRODUCTION DATA REFERENCE

From Tracy's Julius analysis of Mainstreet production data:
- Total active agents: 18,275
- Producing agents: 10,895 (59.6%)
- Non-producing: 7,380 (40.4% with zero sides)
- Top 25% (4,569 agents): 87.6% of volume
- Rainmaker (40+ sides): 247 agents (1.4%)
- Builder (6–39 sides): 3,885 agents (21%)
- Foundation (0–5 sides): 14,144 agents (77%)

## The Office Suspension Discovery
For Mainstreet Advantage fees, the **office** gets suspended for non-payment (not individual agents). All agents lose MLS/SentriLock access. This creates broker-level pressure.

---

# 24. MAINSTREET BRAND AND AI CONTENT TRAINING

[UNCHANGED FROM FEB 24 SUMMARY — see that document for full brand positioning, values, geography, voice guidance, education context, and competitive landscape]

**Addition (Feb 27):** AI training prompt updated with comprehensive member type distinctions — REALTOR® vs non-member licensees, DMBs, Affiliates, Appraisers, Illinois licensing quirks, dues structure, competitive positioning against MLSs going non-REALTOR.

---

# 25. STANDING RULES FOR REPLIT PROMPTS

These rules are included in every prompt sent to Replit:

1. **No Parallel Systems** — Reuse/extend existing components, don't duplicate
2. **Don't Break What Works** — Verify before and after changes
3. **Full-Page Patterns, Not Modals** — Use wizard flows for multi-step tasks
4. **Shared Components Over Duplicates** — Use props/flags for variations
5. **Server-Side for Scale** — Operations >1K records happen server-side
6. **Test Your Work** — Verify happy path + edge cases

---

# 26. WHAT'S ON THE HORIZON (Context for Future Sessions)

The immediate focus is getting celebration/milestone emails working end-to-end with real data visible in previews, making the AI query engine reliable for cross-domain questions (critical for CRMLS demo), and cleaning up the remaining UX issues from the automation wizard implementation.

The bigger picture: MemberSync is scaling from 18,000 to 134,000+ members across three clients. Every architecture decision needs to account for this — the query engine's scaling ceiling, the MRD prefix being Mainstreet-specific, the email volume jumping from 300K/month to millions. The work being done now on data pipeline reliability (merge fields, query retry, geographic awareness) is foundational for that scale.

Tracy's product instinct — "no fake data, make it real, make it verifiable" — is the right call. The live preview feature isn't just a nice-to-have; it's what gives Mainstreet staff confidence to hit Send on an email going to 2,000 members. That confidence is what makes MemberSync feel like a tool they trust rather than a tool they're afraid of.

---

*End of project summary. This document supersedes all previous project summaries.*

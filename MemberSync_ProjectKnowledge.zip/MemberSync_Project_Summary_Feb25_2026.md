# MemberSync / SmartSends — Project Summary
## February 25, 2026

This document captures all decisions, architecture, prompts, and current state through February 25, 2026. Use this to resume work in a new conversation.

---

## TABLE OF CONTENTS

1. Project Overview
2. Client Pipeline and Membership Context
3. Technical Architecture
4. What Has Been Built (Complete)
5. What Was Accomplished Feb 24–25, 2026
6. Current Database Schema (Key Tables)
7. Production Database Schema (Read-Only)
8. Daily Jobs Schedule
9. AI Services Architecture
10. Engagement Scoring System
11. Dashboard Architecture
12. SmartSends Current State
13. Triggered Campaigns / Automations Current State
14. Prompts Ready for Replit (Not Yet Built)
15. Known Issues Still Open
16. CRMLS Pilot Program
17. AI Cost Model and Pricing Strategy
18. Security & Data Protection Roadmap
19. Multi-Tenant Architecture Roadmap
20. Strategic Roadmap (Updated)
21. Key Architectural Decisions
22. Key Files Reference
23. Production Data Reference
24. Mainstreet Brand and AI Content Training
25. Standing Rules for Replit Prompts

---

# 1. PROJECT OVERVIEW

## What We Are Building

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs. SmartSends is the email marketing and automation layer within MemberSync. The platform uses predictive analytics to help MLS and association executives retain and engage members by analyzing residential real estate listings and association management system (AMS) data.

The product vision: MemberSync should be the organization's **second brain** — the system that is always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

## Product Model

MemberSync is a **SaaS product** — not a custom build for any single client. Every feature should work for any association or MLS through configuration, not custom code. The long-term goal is self-service onboarding: a new organization signs up with a credit card, connects their API keys, and goes.

## Build Philosophy

Tracy (founder of Membio) is a non-technical business leader with 30+ years in proptech, building exclusively with AI tools:
- **Claude** for strategy, specifications, and Replit prompts
- **Julius.AI** for SQL development against the production database
- **Replit Agent** for all coding implementation

Tracy maintains creative control over product design and UX decisions. The development team hardens for production (error handling, edge cases, performance). Tracy builds the first 80% through prototyping; the team does the production-ready 20%.

## Product Philosophy: Celebrating Connection Over Compliance

The core insight: 75% of association members produce only 12% of real estate volume, yet pay 75% of dues revenue. MemberSync exists to help associations prove their value to all members by measuring and improving engagement with the organization itself. All member tiers are framed positively. We celebrate connection, not police compliance.

---

# 2. CLIENT PIPELINE AND MEMBERSHIP CONTEXT

## Three-Client Growth Trajectory

| | Client | Members | Cumulative | Status |
|---|---|---|---|---|
| Client 1 | Mainstreet REALTORS® (suburban Chicago) | 18,275 | 18,275 | **Live** — production-proven |
| Client 2 | Hudson Gateway Association of REALTORS® (New York) | 12,800 | 31,075 | **Preparing to onboard** |
| Client 3 | CRMLS | 103,000+ | 134,000+ | **Pilot proposed** — CMO has expressed strong interest |

Additional clients have already expressed interest beyond these three. Multi-tenant architecture is essential regardless of whether CRMLS proceeds.

## Mainstreet REALTORS® (Client 1) Detail

**Members:** ~18,275 active
**Offices:** ~2,800
**Current email volume:** ~300,000 emails/month (existing, pre-MemberSync)
**Member Tiers (by 12-month transaction sides):**
- Foundation (0–5 sides): 14,144 agents (77%)
- Builder (6–39 sides): 3,885 agents (21%)
- Rainmaker (40+ sides): 247 agents (1.4%)

**Key Insight:** Top 25% of agents control 88% of volume; 40% of agents have zero transactions.

---

# 3. TECHNICAL ARCHITECTURE

- **Frontend:** React with Tailwind CSS, shadcn/ui components
- **Backend:** Node.js / Express
- **Database:** PostgreSQL (local via Drizzle ORM + read-only external AWS production DB via `externalPool`)
- **Hosting:** Replit (application) + AWS (production database)
- **Email:** SendGrid — Membio is an established SendGrid channel partner with dedicated IP experience across existing property search products
- **AI:** Anthropic Claude API (Sonnet 4 for email generation, audience building, data queries)
- **ORM:** Drizzle
- **Infrastructure:** Membio is an existing AWS shop. Production database and supporting infrastructure run on AWS. Scaling to dedicated cloud hosting is an extension of existing infrastructure, not a platform migration.

---

# 4. WHAT HAS BEEN BUILT (COMPLETE)

- Full dashboard with AI Chat, Pulse cards, Activity Feed, Member Recognition, Mainstreet Community
- Tier-aware engagement scoring system
- Member detail pages with engagement breakdown
- Office detail pages with agent rosters
- SmartSends email campaign creation (AI + manual + template)
- Audience building (AI builder, picklist, member/bill type, CSV upload)
- Saved audiences with preview and count
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail pages
- Triggered campaigns / Automations engine with 7 trigger types
- Automations UX upgrade (full-page wizard)
- Email analytics overview
- Office visit brief PDF generation
- Compliance tracking
- Image library for emails
- Draft management
- Scheduled email sending
- **Email queue safety infrastructure** (per-member throttle, queue count/export/flush, volume summary)
- **Campaign list performance optimization** (bulk stats, SQL pagination, automation campaign filtering)

---

# 5. WHAT WAS ACCOMPLISHED FEBRUARY 24–25, 2026

## Critical Discovery: 75,330 Email Queue Explosion

Tracy discovered 75,330 emails queued overnight from runaway automations. Root cause: the "Generic Event Registration Confirmation" automation generated 75,247 emails by sweeping ALL historical event registrations instead of only future events.

**Technical root cause:** `evaluateEventRegistration()` in `triggeredCampaignProcessor.ts` filtered by `cached_at >= NOW() - 7 days` (when the cache was rebuilt) but had NO filter for `start_datetime >= CURRENT_DATE` (when the event actually happens). Every historical registration appeared "recent" after daily cache refresh, so all history was re-evaluated as new triggers.

### Emergency Response: Four Prompts Created and Sent

**Prompt 1: Email Safety — Queue Diagnostic + Throttle** (`MemberSync_EmailSafety_QueueDiagnostic_Prompt.md`) — **DEPLOYED AND VERIFIED**
- Backend endpoints: queue-count (enhanced with per-automation breakdown), queue/export (streaming CSV), queue/flush, automations/volume-summary
- Per-member daily send throttle: `canSendToMember()` checks rolling 24h window, default limit 2 automated emails/member/day
- Throttled sends recorded with status='throttled' and skip_reason
- Frontend: Queue Status card on Dashboard
- Database indexes added for performance

**Prompt 2: Campaign List Fix** (`MemberSync_CampaignList_Fix_Prompt.md`) — **DEPLOYED AND VERIFIED**
- **T001 (CRITICAL):** Added `NOT EXISTS` filter to exclude automation-generated campaigns from SmartSends Dashboard. Campaign count dropped from 75,317 to 3.
- **T002:** SQL-level pagination with `LIMIT`/`OFFSET` directly in SQL and separate `COUNT(*)` query
- **T003:** `getBulkCampaignStats()` replaces N+1 query pattern. Two queries total regardless of campaign count.
- Stats cards also exclude automation campaigns.
- **Performance results:** `/api/smartsends/campaigns` went from timeout (75K rows, ~150K queries) to 170ms (3 campaigns, 2 bulk queries). `/api/smartsends/unified-campaigns` went from timeout to 258ms (11 items).

**Prompt 3: Queue Safety UX Redesign** (`MemberSync_QueueSafety_UX_Redesign_Final.md`) — **SENT TO REPLIT**
- **Part 1 — Dashboard:** Replace two large banner cards with inline status badges next to "SendGrid Connected". Amber "Sandbox Mode" badge, blue clickable "75,330 Queued" badge that navigates to Automations. Badges disappear when inactive/empty.
- **Part 2 — Automations Control Panel:** New endpoint `GET /api/smartsends/queue/breakdown` returns per-automation breakdown. Full control panel on Automations page with table showing which automation generated how many emails, Download CSV, Flush Queue buttons. Only visible when queue > 0.
- **Part 3 — Temporal Safeguards:** Fix `evaluateEventRegistration()` to add `AND a.start_datetime >= CURRENT_DATE`. Cap `evaluateEventFollowup()` daysAfter to max 14. Universal rule: no automation sends emails about past events/dates/milestones.

**Prompt 4: Member Recognition Cleanup** (`MemberSync_MemberRecognition_Cleanup_Prompt.md`) — **SENT TO REPLIT**
- Task 1: Determine which recognition component is active (CelebrationInsights.tsx vs MemberRecognition.tsx) — delete the dead one
- Task 2: Remove backend `.slice()` limits in milestoneDetectionService.ts, add `totalCount` to each category, keep Dashboard response lean (5 preview members + accurate count)
- Task 3: New server-side endpoint `GET /api/milestones/:type/members` returns full member list for Send button
- Task 4: Rewire Send button to use lightweight URL params instead of JSON blob, fetch members from server, backward compatible
- Task 5: Avatar display — 3 seeded-random member circles + "+N" badge, remove 5-category cap
- Task 6: Dead code cleanup — delete `getMilestoneStats()` and `/api/milestones/stats` route (unused), remove orphaned constants/functions from recognition component

### Prompts Ready But Not Yet Sent (Waiting for Stability)

**Automation Priority + Global Contact Limit** (`MemberSync_AutomationPriority_GlobalContactLimit_Prompt.md`) — **ON HOLD**
- Add `priority` column to triggered_campaigns (1-100 scale, default 50)
- Processor orders by priority ASC so high-priority automations claim daily slots first
- New table `member_daily_contact_log` tracks ALL emails (automation/manual/scheduled)
- Two limits: GLOBAL_DAILY_CONTACT_LIMIT=3 (total), AUTOMATION_DAILY_SEND_LIMIT=2 (automation subset)
- Extract `canSendToMember()` to shared `contactLimitService.ts`
- Priority management UI: drag-and-drop numbered list at `/smartsends/automations/priorities`
- Admin settings for configurable limits in `system_settings` table

### Key Decisions Made Feb 24–25

1. **Inline badges over alert banners:** Queue status and sandbox mode use small status badges next to "SendGrid Connected" instead of large cards that consume screen real estate.

2. **Per-automation breakdown:** When queue problems happen, users need to see WHICH automation caused them. The breakdown endpoint shows queue count per automation, making the problem actionable, not just alarming.

3. **Temporal safeguards as a universal rule:** No automation should ever send emails about past events, past dates, or past milestones. This is enforced in the trigger evaluation SQL, not just in business logic.

4. **Automation campaigns don't belong on the Dashboard:** Each triggered send creates one `email_campaigns` row. At scale, this produces 75K+ rows. The SmartSends Dashboard shows manual campaigns only; automation sends appear on the Automations page. Long-term: batch sends into single campaigns or bypass `email_campaigns` entirely.

5. **Campaign list performance is critical:** The N+1 query pattern (one `getCampaignStats()` per campaign) is replaced by `getBulkCampaignStats()` using two queries total with `IN (...)` and `Map` for O(1) lookup.

6. **Keep Dashboard API responses lean:** Member Recognition tiles get `totalCount` (accurate number) + 5 preview members per category. The full member list is only fetched when the user clicks Send. This prevents 22,000-object responses on every page load.

7. **Server-side milestone fetch replaces URL stuffing:** Instead of serializing entire member arrays into URL query params (which breaks browsers at 1,000+ members), the Send button passes just the milestone type and the compose page fetches members from a new server endpoint.

8. **One recognition component, not two:** CelebrationInsights.tsx and MemberRecognition.tsx are parallel implementations. Only the one actually imported by Dashboard.tsx survives; the other is dead code and must be deleted.

---

# 6–11. [UNCHANGED FROM FEB 24 SUMMARY]

Refer to the Feb 24 project summary for these sections — no changes to database schema, production schema, daily jobs, AI services, engagement scoring, or dashboard architecture.

---

# 12. SMARTSENDS CURRENT STATE

## What's Built and Working
- Campaign creation with AI-composed or manual email body
- Three method cards: Use a Template, Generate with AI, Create from Scratch
- Audience selection (AI-built, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail page with aggregate stats
- Analytics overview with office leaderboards
- PDF generation for office visit briefs
- Saved audiences with count and preview
- Email templates (functional but needs future rework)
- Draft management
- Image library
- Insert Event shows real upcoming events from database and creates styled teal blocks
- Backend: active campaigns can now be edited without pausing (Prompt 2 fix applied)
- **Campaign list loads in <300ms** (was timing out at 75K rows — fixed Feb 24)
- **Automation campaigns filtered from Dashboard** (only appear on Automations page)
- **Bulk stats queries** replace N+1 pattern for campaign list performance
- **SQL-level pagination** for sent campaigns

## What's Built But Has Issues (Fixes in Progress)
- **"Pause Before Editing" frontend dialog still showing** — backend fix applied but frontend dialog not removed (Fix 1 in Cleanup prompt)
- **Modal-on-modal in automations drip sequences** — step editor still uses popup modal instead of inline editing (Fix 2 in Cleanup prompt)
- **"Create from Scratch" lands on confusing empty screen** — should auto-enter edit mode (Fix 3 in Cleanup prompt)
- **Merge field preview inconsistent** — sometimes shows raw `{{tags}}` instead of sample data (Fix 4 in Cleanup prompt)
- **No delete/discard for automations** — can't remove unwanted automations (Fix 5 in Cleanup prompt)
- **Separate "Generate Email" button in automations** — breaks the intuitive fill-fields-click-Next flow (Fix 6 in Cleanup prompt)
- **AI says © 2024** — needs current year instruction (Fix 7 in Cleanup prompt)
- **ReactQuill strips inline styles from inserted blocks** — event blocks lose formatting when switching to Edit Manually (Fix 8 in Cleanup prompt, workaround approach)
- **Scheduled Series validation bug** — requires all steps to have content even after deleting a step (discovered in testing)
- Insert Offer and Insert Button exist but don't always work depending on editor context
- Resend Campaign uses modal instead of full wizard
- AI-generated events are sometimes plain text, not styled cards

## Email Queue Safety (NEW — Feb 24)
- Per-member daily send throttle (2 automated emails/member/day)
- Queue count, export (streaming CSV), and flush endpoints
- Per-automation volume summary endpoint
- Throttled sends tracked with status='throttled' and skip_reason
- Queue Status card on Dashboard (being replaced with inline badge in UX Redesign prompt)
- **75,330 queued emails discovered and diagnosed** — root cause was missing temporal filter in event registration trigger

---

# 13. TRIGGERED CAMPAIGNS / AUTOMATIONS CURRENT STATE

## What's Built
- Triggered campaign processor running every 15 minutes
- 7 trigger types: event_registration, event_reminder, event_followup, membership_anniversary, production_milestone, drip_sequence, scheduled_series
- Full-page wizard for create/edit (Configure Trigger → Compose → Preview → Settings & Activate)
- Trigger-specific configuration UI for each type
- Drip sequence step builder with per-step editing (modal — needs to be converted to inline)
- Scheduled Series step builder with date pickers (working but has validation bug)
- Automation list with status sections (Active, Paused, Drafts, Archived)
- Send window configuration (start/end time, weekday toggle)
- Auto-stop date (backend fix applied for empty date handling)
- Deduplication to prevent repeat sends
- Anniversary trigger verified working (26 sends processed)
- Active campaigns can now be edited without pausing (content edits allowed, only trigger type changes blocked)
- **Per-member daily throttle** prevents automation flooding (NEW — Feb 24)

## Critical Bug Fixed (Pending Deployment)
- **Event Registration trigger evaluates ALL history** — Missing `AND a.start_datetime >= CURRENT_DATE` filter causes 75K+ emails. Fix in Queue Safety UX Redesign prompt, Part 3.
- **Event Followup daysAfter uncapped** — Could look back indefinitely. Fix caps at 14 days max.

## What's in Cleanup Prompt (Ready to Send)
- Remove "Pause Before Editing" frontend dialog
- Kill modal step editor → inline expand/collapse
- Add delete/discard automation capability
- Fix Generate Email button flow (restore fill-fields → Next → generates)
- Fix Scheduled Series step validation after deleting steps

## What's Prompt-Ready But Not Built
- **A/B Testing** for triggered campaigns (`SmartSends_ABTesting_Part2.md`)
- **Priority ordering** for automations (`MemberSync_AutomationPriority_GlobalContactLimit_Prompt.md`) — ON HOLD
- **Global contact limit** spanning all email types (in Priority prompt)
- Automation-specific analytics
- Event override priority system

## Key Architecture
- `triggered_campaigns` table: campaign config, trigger type, status
- `triggered_campaign_steps` table: multi-step campaigns (drip, scheduled series)
- `triggered_campaign_sends` table: per-member send records with dedup
- Processor: `triggeredCampaignProcessor.ts` — evaluates triggers, queues sends, processes pending
- Each trigger type has its own evaluator function
- `triggerReference` field prevents duplicate sends
- `campaignVersion` integer field (1 and 2) supports future A/B testing
- **NEW:** `canSendToMember()` throttle function checks rolling 24h window before sending

---

# 14. PROMPTS READY FOR REPLIT

**Send order:**

1. **Queue Safety UX Redesign** (`MemberSync_QueueSafety_UX_Redesign_Final.md`) — Inline badges, Automations control panel, temporal safeguards. SENT — AWAITING DEPLOYMENT.

2. **Member Recognition Cleanup** (`MemberSync_MemberRecognition_Cleanup_Prompt.md`) — Delete dead component, remove slice limits, server-side milestone fetch, avatar display, dead code cleanup. SENT — AWAITING DEPLOYMENT.

3. **Post-Implementation Cleanup** (`SmartSends_PostImplementation_Cleanup.md`) — 8 fixes from testing Prompts 1 and 2. READY TO SEND.

4. **AI Content Training** (`SmartSends_Prompt3_AITraining.md`) — Mainstreet briefing, anti-hallucination, tone guardrails, cost optimization. READY TO SEND (can go simultaneously with #3 since it only touches `aiEmailService.ts`).

5. **Automation Priority + Global Contact Limit** (`MemberSync_AutomationPriority_GlobalContactLimit_Prompt.md`) — Priority ordering, shared contact limit service, admin settings. ON HOLD until queue safety and cleanup are stable.

6. **A/B Testing for Triggered Campaigns** (`SmartSends_ABTesting_Part2.md`) — A/B split on subject line and body, automatic winner selection, variant performance tracking. SEND AFTER AUTOMATIONS ARE STABLE.

7. **AI Chart Rendering** (NOT YET WRITTEN — ACCELERATED FOR CRMLS PILOT) — AI Chat detects when results should be charts, renders Recharts inline, download-as-image button. Estimated 3–5 Replit prompts.

---

# 15. KNOWN ISSUES STILL OPEN

### Critical (Blocking User Flows)
- **Event Registration trigger evaluates all history** — Missing temporal filter. Fix in Queue Safety UX prompt Part 3. THIS IS THE ROOT CAUSE OF THE 75K QUEUE.
- **"Pause Before Editing" dialog on all active automations** — Backend fix applied, frontend dialog remains (Cleanup Fix 1)
- **Modal step editor in drip sequences** — Prompt 1 spec'd inline editing but modal persists (Cleanup Fix 2)
- **Scheduled Series validation after step deletion** — Can't proceed after deleting a step (discovered in testing)
- **75,330 emails still in queue** — Need to flush after temporal safeguard is deployed

### Important (UX Quality)
- **"Create from Scratch" empty screen confusion** — Should auto-enter edit mode (Cleanup Fix 3)
- **Merge field preview inconsistency** — Raw tags instead of sample data (Cleanup Fix 4)
- **No delete/discard for automations** — Essential missing feature (Cleanup Fix 5)
- **Separate "Generate Email" button** — Breaks the intuitive flow (Cleanup Fix 6)
- **AI copyright year says 2024** — Minor but unprofessional (Cleanup Fix 7)
- **ReactQuill strips inline styles** — Styled blocks lose formatting in edit mode (Cleanup Fix 8)
- **Insert tools land at random positions** — Cursor position fix in Prompt 1 EmailComposer spec
- AI hallucinating events in automations — Fixed by Prompt 3 anti-hallucination rules
- AI urgency = fire emojis — Fixed by Prompt 3 tone guardrails
- No Audience Preview on Settings & Activate step (trigger-type-aware)
- Resend Campaign modal should route to full wizard
- **Member Recognition tiles show artificial counts** — Fix in Recognition Cleanup prompt
- **Recognition "Send" button breaks at 1K+ members** — URL stuffing replaced with server-side fetch in Recognition Cleanup prompt
- **`getMilestoneStats()` and `/api/milestones/stats` route are unused dead code** — Cleanup in Recognition prompt

### Lower Priority
- Templates system needs future rework (functional but not useful enough)
- The 172-member gap (dashboard vs. member type builder count)
- AI Query Service sometimes generates wrong SQL
- Cache health monitoring (no admin visibility into cron job status)
- Email engagement data cold start
- Revenue data uses catalog prices, not actual invoiced amounts
- `CelebrationInsights.tsx` and `MemberRecognition.tsx` both exist — one is dead code (Recognition prompt Task 1)

---

# 16. CRMLS PILOT PROGRAM

[UNCHANGED FROM FEB 24 SUMMARY]

---

# 17. AI COST MODEL AND PRICING STRATEGY

[UNCHANGED FROM FEB 24 SUMMARY]

---

# 18. SECURITY & DATA PROTECTION ROADMAP

[UNCHANGED FROM FEB 22 SUMMARY]

---

# 19. MULTI-TENANT ARCHITECTURE ROADMAP

[UNCHANGED FROM FEB 22 SUMMARY]

---

# 20. STRATEGIC ROADMAP (UPDATED)

## Immediate (In Progress)
1. **Queue Safety UX Redesign** — Inline badges, Automations control panel, temporal safeguards (SENT)
2. **Member Recognition Cleanup** — Fix counts, server-side fetch, dead code removal (SENT)
3. **Post-Implementation Cleanup** — 8 fixes from Prompt 1/2 testing (READY)
4. **AI Content Training** — Mainstreet briefing, anti-hallucination, tone guardrails (READY)
5. **Flush 75K queue** — After temporal safeguard deployed, flush and verify

## Near-Term (Pilot Preparation)
6. **Automation Priority + Global Contact Limit** — ON HOLD until queue safety stable
7. **A/B Testing** — Variant testing for triggered campaigns
8. **AI Chart Rendering** — Inline charts in AI Chat + download as image (ACCELERATED for CRMLS pilot)
9. **Prompt Caching Implementation** — 90% reduction on AI input costs
10. **Multi-Tenant Stage 1** — Database-driven tenant config for HGAR onboarding
11. **Batch Email Sending** — Rate-limited queue for Mainstreet's 300K/month + CRMLS scale
12. **SOC 2 Type I Preparation** — Compliance automation platform, audit logging, pen testing

## Medium-Term
13. **Templates Rework** — Make templates actually useful (past campaigns as templates, smart suggestions)
14. **Lapse Prevention System** — Status tracking, risk scoring, intervention management
15. **Multi-Tenant Stage 2** — Admin provisioning dashboard
16. **Broker Module** — Office management dashboards
17. **Exportable Charts** — PDF/PNG export, copy to clipboard

## Longer-Term
18. **AI Report Generation (Stage 4)** — Multi-section board reports from natural language
19. **Self-Service Onboarding (Multi-Tenant Stage 3)** — Credit card signup and GO
20. **Lapse Pattern Analysis** — Predictive models from pre-departure behavior
21. **Integration Marketplace** — Zendesk, Google Analytics, LMS connectors
22. **AI Presentation Generation (Stage 5)** — Slide-ready content from data

---

# 21. KEY ARCHITECTURAL DECISIONS

All decisions from previous summaries remain in effect, plus:

- **Inline badges over alert banners:** Queue status and sandbox mode use small status badges, not large cards that consume screen real estate.
- **Per-automation breakdown for queue problems:** When things go wrong, users need to see WHICH automation caused it. The breakdown endpoint makes the problem actionable.
- **Temporal safeguards as a universal rule:** No automation sends emails about past events/dates/milestones. Enforced in SQL, not business logic.
- **Automation campaigns filtered from SmartSends Dashboard:** Each triggered send creates an `email_campaigns` row. At scale this produces 75K+ rows. Manual campaigns on Dashboard; automation sends on Automations page.
- **Bulk stats over N+1:** `getBulkCampaignStats()` uses two queries total with `IN (...)` and `Map` for O(1) lookup.
- **Lean Dashboard API responses:** Member Recognition gets `totalCount` + 5 preview members. Full member list fetched only when user clicks Send.
- **Server-side milestone fetch:** Send button passes milestone type in URL; compose page fetches from server. No URL stuffing of member arrays.
- **One component per function:** CelebrationInsights and MemberRecognition are parallel implementations. Only the active one survives.
- **Shared components over parallel systems:** When two flows need similar functionality, they use the same component with configuration flags, not duplicate implementations.
- **Three-prompt strategy for complex changes:** Split by concern (frontend, backend, AI) rather than one mega-prompt.
- **AI needs institutional knowledge:** The Mainstreet Briefing gives the AI ~350 words of association context. Prevents hallucination.
- **Database schema doesn't belong in email prompts:** `getDataAwarenessSummary()` is for AI Chat SQL queries, not email generation. Removing saves ~10K tokens/call.
- **Value-first, never price-first:** AI emails promote what members get, not how cheap it is.
- **Non-CE attendance is a stronger engagement signal than CE attendance.**
- **Cursor position saved before dialogs:** All insert functions save cursor position before opening any dialog.
- **Server-side audience resolution for sends:** Large audiences pass audienceId; server resolves recipients.
- **Milestone triggers are mutually exclusive:** One automation per milestone type.
- **Scheduled Series resolves audience fresh at each send date.**
- **UX consistency is non-negotiable:** Both email flows use the same wizard, same components, same tools.
- **Every email editing path goes through the full wizard.**
- **AI Chart rendering is a pilot deliverable, not a post-launch roadmap item.**
- **Multi-tenant architecture starts now.**
- **Paid pilots with credit-toward-contract.**
- **SOC 2 is a sales advantage, not just compliance.**
- **Prompt caching is the #1 AI cost optimization.**
- **Model routing for cost control:** Haiku for simple queries; Sonnet for complex analysis and generation.

---

# 22. KEY FILES REFERENCE

### Prompts Sent to Replit (Current Round — Feb 24–25)
- `MemberSync_EmailSafety_QueueDiagnostic_Prompt.md` — Queue throttle, export, flush (DEPLOYED AND VERIFIED)
- `MemberSync_CampaignList_Fix_Prompt.md` — Exclude automations, SQL pagination, bulk stats (DEPLOYED AND VERIFIED)
- `MemberSync_QueueSafety_UX_Redesign_Final.md` — Inline badges, control panel, temporal safeguards (SENT — AWAITING)
- `MemberSync_MemberRecognition_Cleanup_Prompt.md` — Fix counts, server-side fetch, dead code (SENT — AWAITING)

### Prompts Ready to Send
- `SmartSends_PostImplementation_Cleanup.md` — 8 fixes from testing (READY)
- `SmartSends_Prompt3_AITraining.md` — Mainstreet briefing, anti-hallucination, tone guardrails (READY)
- `MemberSync_AutomationPriority_GlobalContactLimit_Prompt.md` — Priority ordering, global contact limit (ON HOLD)

### Prompts from Previous Round (Feb 23–24)
- `SmartSends_Prompt1_UnifiedComposer.md` — Shared EmailComposer, kill modals, cursor fix (SENT — PARTIALLY IMPLEMENTED, ISSUES FOUND)
- `SmartSends_Prompt2_BackendFixes.md` — autoStopDate fix, relax active edit check (DEPLOYED)

### Strategy Documents
- `MemberSync_CRMLS_Scaling_Roadmap.docx` — Comprehensive scaling, AI cost, security, and multi-tenant roadmap
- `MemberSync_CRMLS_Pilot_Proposal.docx` — 90-day pilot structure, pricing, success criteria

### Previously Implemented Prompts
- All prompts listed in the Feb 24 summary section 22 remain COMPLETE

### Backend Services
- `triggeredCampaignProcessor.ts` — Triggered campaign evaluation and send processing + NEW `canSendToMember()` throttle
- `storage.ts` — Main data layer, dashboard metrics, member/office queries
- `memberMetricsCacheService.ts` — Daily cache refresh with tier-aware engagement scoring
- `engagementScoreService.ts` — Engagement score calculation logic
- `aiQueryService.ts` — AI SQL generation, query execution, insights
- `aiAudienceService.ts` — Audience CRUD, smart audience execution, enrichment
- `aiEmailService.ts` — AI email composition (generate + refine endpoints) — BEING UPDATED WITH MAINSTREET BRIEFING
- `emailService.ts` — Email sending, queue processing, campaign management + NEW `getBulkCampaignStats()`
- `scheduledEmailProcessor.ts` — Processes scheduled campaigns
- `milestoneDetectionService.ts` — Celebration/milestone detection — BEING UPDATED with totalCount and server-side endpoint
- `analyticsProductionCacheService.ts` — Office/agent production analytics
- `activityCacheService.ts` — Activity feed data
- `visitBriefService.ts` — Office visit PDF generation
- `sharedDatabaseSchema.ts` — Database schema documentation for AI services (~37K chars, ~10K tokens)
- `anthropic.ts` — Claude API client (currently Sonnet 4, max_tokens: 2048)

### Frontend — Pages
- `SendEmail.tsx` — Email composition wizard (201K — largest file; being refactored to use shared EmailComposer)
- `CreateAutomation.tsx` — Automation creation wizard (being refactored to use shared EmailComposer, kill modals)
- `SmartSends.tsx` — SmartSends dashboard + automations list
- `AudienceBuilder.tsx` — AI audience builder
- `CampaignDetail.tsx` — Campaign detail with resend capability
- `MemberDetail.tsx` — Member profile with engagement, email history

### Frontend — Shared Components
- `EmailComposer.tsx` — NEW shared email composition component (being created in Prompt 1 refactor)
- `emailBlocks.ts` — Shared utilities: generateEventBlockHtml, generateOfferBlockHtml, generateCtaButtonHtml
- `CelebrationInsights.tsx` — Original celebrations sidebar (MAY BE DEAD CODE — check Dashboard.tsx import)
- `MemberRecognition.tsx` — Redesigned recognition sidebar (MAY BE DEAD CODE — check Dashboard.tsx import)

### Configuration
- `schema.ts` — Drizzle ORM schema (includes triggered_campaigns, triggered_campaign_steps, triggered_campaign_sends tables)
- `routes.ts` — All API endpoints (223K — largest backend file)
- `clientConfig.ts` — Client-specific configuration (to be promoted to tenant_config DB table in multi-tenant Stage 1)

---

# 23. PRODUCTION DATA REFERENCE

From Tracy's Julius analysis of Mainstreet production data:
- Total active agents: 18,275
- Producing agents: 10,895 (59.6%)
- Non-producing: 7,380 (40.4% with zero sides)
- Top 25% (4,569 agents): 87.6% of volume
- Rainmaker (40+ sides): 247 agents (1.4%)
- Builder (6–39 sides): 3,885 agents (21%)
- Foundation (0–5 sides): 14,144 agents (77%)

## The Office Suspension Discovery
For Mainstreet Advantage fees, the **office** gets suspended for non-payment (not individual agents). All agents lose MLS/SentriLock access. This creates broker-level pressure.

---

# 24. MAINSTREET BRAND AND AI CONTENT TRAINING

[UNCHANGED FROM FEB 24 SUMMARY — see that document for full brand positioning, values, geography, voice guidance, education context, and competitive landscape]

---

# 25. STANDING RULES FOR REPLIT PROMPTS

These rules are included in every prompt sent to Replit:

1. **No Parallel Systems** — Reuse/extend existing components, don't duplicate
2. **Don't Break What Works** — Verify before and after changes
3. **Full-Page Patterns, Not Modals** — Use wizard flows for multi-step tasks
4. **Shared Components Over Duplicates** — Use props/flags for variations
5. **Server-Side for Scale** — Operations >1K records happen server-side
6. **Test Your Work** — Verify happy path + edge cases

---

*End of project summary. This document supersedes all previous project summaries.*

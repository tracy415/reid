# MemberSync — Open Questions

> **Purpose:** Decisions that have not yet been made and must not be treated as settled. This document exists so that developers building features that touch these areas know to stop and get clarity from Tracy before implementing. Building against an unresolved question creates rework.
>
> **Rule:** If you are about to implement something that depends on one of these questions, raise it with Tracy first. Do not make a pragmatic assumption and build forward.
>
> Last updated: March 12, 2026

---

## Open Question 1: Leadership/Board Seat Pricing

**What's unresolved:** Leadership/Board is defined as a premium read-only add-on role. The experience is intentionally beautiful but non-functional (read-only dashboards, recognition stats, membership health overview). The question of how to price this seat — per seat, flat add-on per client, included above a certain plan tier — has not been decided.

**Why it matters for development:** The permissions middleware must accommodate this role (the four-role model is specced in CLAUDE.md). The billing system must be able to gate access to it. Neither of these is blocked by the pricing decision, but the billing integration timeline is.

**Owner:** Tracy, Paula, Daniel
**Target:** Resolved before client #2 is fully onboarded

---

## Open Question 2: MLS Compliance Rule Sets

**What's unresolved:** Association compliance is specced — CE hours, Code of Ethics, Fair Housing, designation tracking. MLS compliance exists as a concept (the module will be distinct from association compliance; an org that is both gets a combined tool), but the actual rule sets for MLS clients have not been defined. The first MLS client will define this in practice.

**Why it matters for development:** Do not build the MLS compliance module until the first MLS client's requirements are known. Build the association compliance module to be extensible — the architecture must support a combined view without a redesign.

**Owner:** Tracy (requirements will come from the first MLS client)
**Target:** Defined when first MLS client is confirmed

---

## Open Question 3: Billing Integration Timing

**What's unresolved:** MemberSync does not yet have in-app billing (subscription management, credit card processing, invoice history). Clients are currently invoiced manually. The question is when to build billing integration and which platform to use.

**Why it matters for development:** The Membio Admin Panel (Track 3) will need a billing section. The self-service onboarding flow (Track 2, P2) is blocked by billing. The Leadership/Board premium seat requires billing infrastructure.

**Owner:** Paula, Daniel, Tracy
**Target:** Before client #4 onboards

---

## Open Question 4: Email Archive and Templates Scope

**What's unresolved:** The Email Archive (tab 3 of the Email Health Dashboard) currently shows sent campaign history. The Templates system exists but is underbuilt. The question of what the fully-realized Archive + Templates experience looks like — and whether they merge into a single "content library" concept — has not been decided. Tracy needs to make a product decision before any significant build work begins here.

**Why it matters for development:** Do not invest in extending the current templates system. Do not redesign the archive without a product decision. The image library module is also expected to be replaced as part of a broader content library — these three things (archive, templates, image library) may be the same future product decision.

**Owner:** Tracy
**Target:** Before any archive or templates build work begins

---

## Open Question 5: Membio Member Portal

**What's unresolved:** The Membio Member Portal (a member-facing product distinct from the staff-facing MemberSync platform) is referenced in several places — the image library "Notifications" category, the content library future direction, and the email preference center. The scope, timeline, and relationship to MemberSync have not been formally defined.

**Why it matters for development:** Features gated on `has_member_portal` in `tenant_config` assume this portal exists or will exist. Image categories, portal notification emails, and the content library scope all touch this. Do not build portal-dependent features until the portal product is defined.

**Owner:** Tracy and Paula
**Target:** Defined before any portal-dependent feature is specced

---

## Resolved Questions (for historical reference)

| Question | Decision | Date |
|----------|----------|------|
| Should `email_address` or `member_key` be the PK on `member_email_preferences`? | `email_address` — permanent, irreversible | March 11, 2026 |
| Should Campaign Architect replace or coexist with the drip sequence builder? | Replace entirely — no parallel UI | March 5, 2026 |
| Should MLS clients see the compliance module (empty) or not see it at all? | Not see it at all — hidden at router level | February 2026 |
| Should the two-database Replit architecture be replicated in production? | No — single database in production | March 4, 2026 |
| Should scoring weights be code-driven or config-driven? | Config-driven via `tenant_config` | February 2026 |
| Should Member Journey be an extension of Campaign Architect? | No — architecturally distinct module | March 7, 2026 |
| Should payment status be a primary engagement signal? | No — table stakes only (1 point max) | February 2026 |
| Should hard bounce suppressions be removable? | No — permanent, no override | March 2026 |

# MemberSync — Project Summary
## March 5, 2026 (Evening Session)

---

## OVERVIEW

This session covered four major areas: (1) prompt queue audit and deployment, (2) Recognition Review Queue + Email Governor + Open Timestamps spec written and Parts 1–4 built by Replit, (3) major strategic design decision on Campaign Architect replacing the drip sequence builder, and (4) critical strategic framing around market positioning, competitive intelligence, and the "easy button" product philosophy.

---

## PROMPTS DEPLOYED THIS SESSION

### QueryEngine RetryAndCrossDomain (deployed)
Fixed the AI Chat failure on cross-domain queries (combining AMS member attributes with MLS transaction data). Added SQL retry loop, cross-domain example queries, geographic context for Mainstreet service area, confidence rebalancing, and user-friendly error messages.

**Verified working:** Screenshot confirmed Julius-style analytical responses and multi-turn follow-up questions working. Cross-domain query failure (designation holders × production volume) identified as the remaining gap — fixed by this prompt.

### SchemaModularization + AIChat Julius Upgrade (deployed, from previous session)
Both confirmed working from last night's session.

### PromptA: Recognition Review Queue + Email Governor + Open Timestamps
**Parts 1–4 (backend) completed by Replit this session.**
Parts 5–8 (frontend) to follow next session.

**What was built:**
- `recognition_queue` table — holds AI-generated recognition emails pending staff review
- `email_category` column on `email_campaigns` — lanes all email by type
- `email_governor_config` table — configurable weekly/daily caps per client, seeded for MainStreet
- Open/click timestamp columns on `email_recipients` (openFirstAt, openLastAt, openCount, clickFirstAt, clickLastAt, clickCount)
- Full recognition queue CRUD API (GET list, GET single, POST create, PATCH update, POST send, DELETE)
- `queueEmailCampaign()` extended with optional `emailCategory` parameter (default: 'engagement')
- `canSendToMember()` extended with weekly cap check and category exemptions
- Governor config and status endpoints
- SendGrid webhook updated to capture open/click timestamps using existing campaign_id + member_key matching
- Send flow modified: Recognition "Send Now" → queues to recognition_queue instead of immediate send; navigates to /smartsends after toast

**Key decisions confirmed during build:**
- Campaign names derived as "Recognition: [milestone_label] — [Month Year]"
- Recognition emails are Lane 1 — exempt from governor entirely (human already reviewed)
- Existing campaign_id + member_key webhook matching preserved (not sg_message_id)
- Compose flow unchanged — only the final Send Now button behavior changed

---

## PROMPTS STILL IN QUEUE (not yet run)

In priority order:
1. **PromptA Parts 5–8** — Frontend for Recognition Queue UI, Email Controls tab, open timestamps display
2. **Automation Intelligence & Template Cleanup** (`MemberSync_AutomationIntelligence_TemplateCleanup.md`)
3. **Post-Implementation Cleanup** (`SmartSends_PostImplementation_Cleanup.md`) — 8 UX fixes
4. **AI Content Training v2** (`SmartSends_Prompt3_AITraining_v2.md`) — anti-hallucination, member type context

**On hold (intentionally):**
- A/B Testing activation — superseded by Campaign Architect design (see below)
- Automation Priority + Global Contact Limit — waiting for stability

---

## MAJOR DESIGN DECISION: CAMPAIGN ARCHITECT

### The Problem
The current drip sequence builder is the paradigm everyone hates — blank canvases, node graphs, step wizards that require you to already know what good looks like. Tracy identified this as a strategic problem: we built something too similar to tools that make experienced marketing professionals want to "poke their eyes out."

### The Decision
**Replace the current drip sequence builder entirely** with an AI-first Campaign Architect. No fallback to the old UI — full replacement.

### The Design

**Entry point:** "Create Automation" → single conversational prompt: *"What do you want this campaign to accomplish?"*

**What the AI does with that:**
1. **Diagnoses the goal** — identifies audience, desired outcome, natural timeline
2. **Recommends a complete structure** — not a blank canvas, a full proposal with reasoning:
   > *"Here's what I'd suggest: A 3-email sequence over 21 days. Email 1 (Day 0): Awareness... Email 2 (Day 7): Social proof... Email 3 (Day 18): Direct ask... Sound right, or want me to adjust?"*
3. **Writes all the emails** — once staff approves the structure, AI generates every email using real member data, tier context, and the existing email composer
4. **Suggests one A/B test** — before activation, proposes a single test with plain English explanation. Staff approves or skips. No configuration required.

**The UI that replaces the node canvas:**
```
📧 Email 1 — Day 0          [Edit] [Preview]
   Subject: Something's coming this spring...
   To: 4,120 Foundation members

⏱ Wait 7 days

📧 Email 2 — Day 7          [Edit] [Preview]
   Subject: What your peers are saying about CE classes
   A/B: Testing subject line variant

⏱ Wait 11 days

📧 Email 3 — Day 18         [Edit] [Preview]
   Subject: One class. Spring forward.

[Activate Campaign]
```

Clean vertical sequence. No drag handles, no connecting arrows, no conditions sidebar.

**A/B testing:**
- AI proposes one test per campaign — always one, never multiple
- Staff clicks approve or skip
- After test window: plain English result — "Subject line A won — 34% vs 21%. Sending remainder to winning variant."
- No statistics jargon, no threshold configuration

### AEI Demo Sequence (3 minutes)
1. Show a competitor node canvas — "this is what everyone else asks you to do"
2. Switch to MemberSync — type one sentence goal
3. Watch AI propose complete campaign with reasoning
4. Show emails, already written
5. Show A/B suggestion
6. Activate

### Architectural Notes for Campaign Architect
- Replaces `CreateAutomation.tsx` drip sequence builder (not the whole automation wizard — event triggers, anniversary triggers etc. still use existing flow)
- Uses existing triggered campaign infrastructure for execution
- AI campaign planning uses a new system prompt focused on campaign strategy, not just email generation
- The "goal → structure → emails → activate" flow is a new frontend interaction pattern
- Existing drip_sequence trigger type is reused; the change is entirely in the creation UX

---

## MAJOR STRATEGIC DECISIONS

### Market Positioning
**TAM:** 332 associations (45 with 7,000+ members, 118 with 2,000–6,999, 169 with 800–1,999) plus MLSs.
**SAM:** ~200 if priced right.
**SOM:** 100.

**Target:** The 95% of associations doing email poorly — not because they're bad at their jobs, but because every tool punishes them for not being email marketing experts.

**The 5% insight:** The top 5% of associations with sophisticated email programs aren't doing it well because of better tools — they're doing it well because of dedicated headcount. MemberSync doesn't threaten them. But they're not the beachhead. They ARE the lighthouse client target (CRMLS being the prime example) — their logos open doors.

**Product design principle:** Design for the 95% (simplicity, easy button, AI does the work). Pursue the 5% as reference clients (their logos create credibility).

**Outside real estate:** Tracy's long-term vision includes expansion beyond real estate associations. Build the SaaS architecture to support it, but don't design for it yet.

### Competitive Intelligence — Critical New Capability
Associations and MLSs are in an existential fight. Mainstreet competes with five neighboring associations for members. MLSs face non-Realtor access threats. MemberSync must help executives look **outward**, not just inward.

**What this means for the product:**

**1. Competitive landscape awareness in AI Chat**
The AI Chat must be able to answer outward-facing questions:
- "Which neighboring associations are growing?"
- "Are agents near our territory borders joining competing associations?"
- "What are the patterns in who's leaving and where they're going?"
The MLS data contains this signal. Nobody else is reading it this way.

**2. Retention intelligence framed competitively**
Not just "this member might lapse" but "this member's activity pattern looks like agents we've lost to [competing association] in the past." The lapse prevention system needs competitive framing.

**3. Member value articulation**
MemberSync should help executives answer "why are we better than the alternative?" with data. "Your Foundation members who attend CE classes have 73% retention vs 41% for those who don't — your education program is your strongest competitive moat."

**4. Early warning on member drift**
Declining event attendance + ignored emails + reduced transaction volume in primary market = member reconsidering affiliation. This is a different signal from payment lapse and needs to be tracked separately.

**The product positioning statement this creates:**
*"MemberSync knows your market, knows your members, and knows what you've already tried. It doesn't give you a blank canvas — it gives you a recommendation. You say yes or no."*

**MemberSync is the lightsaber.** Associations have been fighting for survival with spreadsheets and gut instinct. MemberSync gives them intelligence.

### AI Learning Architecture (New Parking Lot Item)
The AI should learn from what works across all clients and apply those learnings automatically. This is the network effect that compounds over time — the 100th association gets a smarter AI than the first one did.

**Concretely:**
- Campaign performance outcomes stored against AI decisions (which structure was suggested, what timing, which audience)
- Cross-client pattern detection: "anniversary emails sent in week 1 of anniversary month get 40% higher open rates across all clients"
- These patterns feed back into the Campaign Architect's recommendations
- Association-specific learning: what works for this client's members specifically

**Architectural note:** Requires storing AI decision metadata alongside campaign records. A `ai_campaign_decisions` table with outcome tracking. Not complex but needs intentional design. Add to CLAUDE.md "What's Coming" section.

---

## PARKING LOT ADDITIONS (this session)

### Campaign Architect (HIGH PRIORITY — AEI demo)
Full design documented above. Replaces drip sequence builder entirely. AI-first campaign creation with goal → structure → emails → activate flow. One suggested A/B test per campaign, staff approves/skips. Demo path: 3 minutes, shows the paradigm shift.

**Architectural implication:** New frontend interaction pattern in CreateAutomation.tsx for drip_sequence type. New AI system prompt for campaign planning. Reuses existing triggered campaign execution infrastructure.

### Competitive Intelligence Module
Outward-facing analytics that help association/MLS executives understand competitive threats and opportunities. Feeds from MLS data (who's selling where, territory patterns, member drift signals). Surfaces in AI Chat and potentially as a dashboard section for executives.

**Architectural implication:** New query patterns in aiQueryService.ts for cross-association analysis. Requires careful multi-tenant scoping (Client A cannot see Client B's data — but can see aggregated patterns and their own members' market activity). Geographic intelligence from GEOGRAPHIC_CONTEXT section already added this session is the foundation.

### AI Learning / Network Effect Engine
Cross-client campaign performance learning. AI recommendations improve as more associations use the platform. Individual association-specific learning layer on top.

**Architectural implication:** `ai_campaign_decisions` table needed. Campaign outcome tracking (open rate, click rate, conversion to desired action) linked back to AI recommendation metadata. Query patterns for cross-client aggregate learning that respects tenant isolation.

### Member Preference Center
Members can choose which email categories they receive (compliance always, engagement optional). Reduces unsubscribes by letting members opt down instead of opt out entirely. Association staff can see preference data per member.

**Architectural implication:** `member_email_preferences` table already exists. Needs UI for member-facing preference management and staff-facing preference visibility.

---

## EMAIL HEALTH DASHBOARD — PROMPT B DESIGN

Documented here for next session spec writing:

**Three sections (tabs within SmartSends "Email Controls"):**

**Tab 1 — Email Health Dashboard**
Metrics: unsubscribe rate, deliverability rate, open rate, click rate — by email category and over time (90-day trend). Unsubscribe rate >0.3% triggers a warning. All metrics filterable by category (recognition, engagement, compliance, etc.).

**Tab 2 — Send Queue** (built in Prompt A)
Already specced.

**Tab 3 — Email Archive**
Searchable history of all engagement emails sent. Filterable by category, date range, audience, performance. Staff can see what was sent, when, to whom, and how it performed. Prevents duplicate content. Shows best-performing emails as inspiration.

**AI duplicate detection (Prompt C):**
Before sending, AI scans for content similarity to recent sends to same audience. Flags if >70% similar. When composing, AI can reference archive to suggest fresh angles.

**Note:** Full HTML of sent emails needs to be confirmed as stored in campaigns table before speccing. If not currently stored, need to start storing it.

---

## AEI DEMO PRIORITIES (3 weeks out)

AEI is approximately March 23–27 in Minneapolis. Audience: MLS executives and technical leaders.

**Demo path needs to show (in order of impact):**
1. AI Chat — cross-domain queries, "which agents in Downers Grove closed in January with licenses expiring this year" → instant results. The "second brain" moment.
2. Campaign Architect — type one goal sentence, watch AI build a complete campaign. The "cancel HubSpot" moment.
3. Member Recognition — show the queue, show the AI-generated personal email with real member data, show the review/approve flow.
4. Dashboard — Association Pulse, the 75/12 insight visualized, tier distribution.

**Demo path must be narrow and stable.** No freestyle. No features that might crash. Lock the sequence before the show.

**To do before demo path is locked:**
- PromptA Parts 5–8 (Recognition Queue frontend)
- Campaign Architect spec and build
- Query Engine cross-domain verification (prompt ran this session)
- Demo data verification (real Mainstreet data, no fake anything)

---

## STANDING RULES (ALL PRIOR RULES REMAIN, PLUS)

- "Recognition" is the user-facing term everywhere. "Celebration" stays in code only.
- Email category must be set on every campaign record — no null categories.
- Governor exemptions are: transactional, compliance, critical, recognition.
- Campaign Architect replaces the drip sequence builder — no parallel UI.
- AI suggestions must always be actionable (yes/no), never configuration forms.
- Competitive intelligence queries must respect tenant isolation — no cross-client data leakage.
- The product philosophy: "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

---

*Session date: March 5, 2026. Next session: March 6, 2026 — start with PromptA Parts 5–8 frontend, then Campaign Architect spec.*

# MemberSync - Complete Build Specification v2.0

## ðŸŽ¯ Phase 1: Initial Build with Complete Schema

Copy and paste this EXACT prompt into Replit Agent:

```
Create "MemberSync" - an AI-powered member engagement platform for 
MainStreet Realtors that predicts member lapse risk and suggests retention actions.

TECH STACK:
- React + Vite for frontend
- Node.js + Express for backend
- PostgreSQL database (existing - will provide credentials)
- Tailwind CSS v4 for styling
- Recharts for charts
- Mobile-responsive design
- Font: Proxima Nova (with Helvetica, sans-serif fallback)
- Authentication: bcryptjs + jsonwebtoken for session management

AUTHENTICATION & USER MANAGEMENT:

This is an internal tool for MainStreet staff (6-10 users). Implement simple 
email/password authentication with role-based access control.

USER DATABASE SCHEMA:

Table: users (in same PostgreSQL database)
- user_id (uuid, PRIMARY KEY, DEFAULT gen_random_uuid())
- email (text, UNIQUE, NOT NULL) - login email
- password_hash (text, NOT NULL) - bcrypt hashed password
- full_name (text, NOT NULL) - display name
- role (text, NOT NULL) - 'admin', 'staff', 'readonly'
- client_id (text, DEFAULT 'MainStreet') - for future multi-client support
- is_active (boolean, DEFAULT true) - can disable users without deleting
- created_at (timestamp, DEFAULT NOW())
- last_login (timestamp)
- created_by (uuid) - references users(user_id)

Table: member_notes (for collaboration)
- note_id (uuid, PRIMARY KEY, DEFAULT gen_random_uuid())
- member_key (text, NOT NULL) - references apmmember
- user_id (uuid, NOT NULL) - who created the note
- note_text (text, NOT NULL)
- created_at (timestamp, DEFAULT NOW())
- updated_at (timestamp)

Table: activity_log (audit trail)
- log_id (uuid, PRIMARY KEY, DEFAULT gen_random_uuid())
- user_id (uuid, NOT NULL) - who performed action
- action_type (text, NOT NULL) - 'email_sent', 'note_added', 'reminder_sent', etc.
- entity_type (text) - 'member', 'office', 'user'
- entity_id (text) - MemberKey, OfficeKey, or user_id
- description (text) - human-readable description
- metadata (jsonb) - additional context
- created_at (timestamp, DEFAULT NOW())

USER ROLES:

1. ADMIN
   - Full access to all features
   - Can manage users (add, edit, disable)
   - Can view activity logs
   - Can configure system settings

2. STAFF
   - Full access to members and offices
   - Can add notes, send emails, update member info
   - Cannot manage users or view full activity logs
   - Can view their own activity

3. READONLY
   - View-only access to dashboards and reports
   - Cannot edit anything or send communications
   - Perfect for executives and board members

AUTHENTICATION FLOW:

Install packages:
npm install bcryptjs jsonwebtoken express-session

LOGIN PAGE (/login):
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚              [Membio Logo]                  â”‚
â”‚                                             â”‚
â”‚              MemberSync                     â”‚
â”‚         Staff Access Portal                 â”‚
â”‚                                             â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â”‚ Email                                 â”‚ â”‚
â”‚  â”‚ [____________________________]        â”‚ â”‚
â”‚  â”‚                                       â”‚ â”‚
â”‚  â”‚ Password                              â”‚ â”‚
â”‚  â”‚ [____________________________]        â”‚ â”‚
â”‚  â”‚                                       â”‚ â”‚
â”‚  â”‚ [ ] Remember me                       â”‚ â”‚
â”‚  â”‚                                       â”‚ â”‚
â”‚  â”‚          [Sign In]                    â”‚ â”‚
â”‚  â”‚                                       â”‚ â”‚
â”‚  â”‚      Forgot password?                 â”‚ â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â”‚                                             â”‚
â”‚     Â©2026 Membio. All Rights Reserved.     â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Design: Clean, centered form with Membio branding (#2e1f62 accents)

PROTECTED ROUTES:
All routes except /login require valid session. If not authenticated,
redirect to /login with return URL parameter.

SESSION MANAGEMENT:
- Use JWT tokens stored in httpOnly cookies (secure, prevents XSS)
- Token expiration: 8 hours (work day)
- "Remember me" extends to 30 days
- Refresh token flow for seamless experience
- Automatic logout on token expiration

AUTHENTICATION ENDPOINTS:

POST /api/auth/login
Body: { email, password }
Returns: { token, user: { user_id, email, full_name, role } }
- Verify email exists
- Compare password with bcrypt
- Generate JWT token
- Update last_login timestamp
- Log activity

POST /api/auth/logout
- Clear session/token
- Log activity

POST /api/auth/forgot-password
Body: { email }
- Generate reset token (expires in 1 hour)
- Send email with reset link
- Store token in database temporarily

POST /api/auth/reset-password
Body: { token, new_password }
- Verify token valid and not expired
- Hash new password with bcrypt
- Update user record
- Invalidate reset token

GET /api/auth/me
- Returns current user info
- Used to verify session on app load

USER MANAGEMENT FEATURES (Admin only):

USER MANAGEMENT PAGE (/admin/users):
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ User Management                                    [+ Add User]     â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Name           â”‚ Email               â”‚ Role     â”‚ Last Login       â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Sarah Johnson  â”‚ sjohnson@ms.org     â”‚ Admin    â”‚ 2 hours ago      â”‚
â”‚ Mike Chen      â”‚ mchen@ms.org        â”‚ Staff    â”‚ Today 9:30 AM    â”‚
â”‚ Lisa Williams  â”‚ lwilliams@ms.org    â”‚ Staff    â”‚ Yesterday        â”‚
â”‚ Bob Smith      â”‚ bsmith@ms.org       â”‚ Readonly â”‚ Jan 20, 2026     â”‚
â”‚ ...            â”‚                     â”‚          â”‚                  â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Click row to edit user (change role, disable, reset password)

USER MANAGEMENT ENDPOINTS:

GET /api/admin/users
- Returns all users (admin only)
- Include last login, created date, status

POST /api/admin/users
Body: { email, full_name, role, temporary_password }
- Create new user (admin only)
- Hash password with bcrypt
- Send welcome email with temporary password
- Force password change on first login

PUT /api/admin/users/:userId
Body: { full_name, role, is_active }
- Update user (admin only)
- Cannot change own role
- Log activity

POST /api/admin/users/:userId/reset-password
- Generate temporary password (admin only)
- Send email to user
- Force password change on next login

DELETE /api/admin/users/:userId
- Soft delete (set is_active = false)
- Cannot delete yourself
- Cannot delete if only admin
- Log activity

MEMBER NOTES FEATURE:

On member detail page, add notes section for staff collaboration:

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Activity & Notes                                   [+ Add Note]     â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Jan 23, 2026 10:15 AM - Sarah Johnson                              â”‚
â”‚ Called regarding Code of Ethics training. Left voicemail.          â”‚
â”‚ Will follow up next week if no response.                           â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Jan 15, 2026 2:30 PM - Mike Chen                                   â”‚
â”‚ Member called to pay overdue invoice. Payment processed.           â”‚
â”‚ Explained upcoming IL CE deadline.                                 â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Jan 10, 2026 9:00 AM - Lisa Williams                              â”‚
â”‚ Sent automated reminder email for IL CE requirement.               â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

MEMBER NOTES ENDPOINTS:

GET /api/members/:memberKey/notes
- Returns all notes for member
- Include user info (name) with each note
- Ordered by created_at DESC

POST /api/members/:memberKey/notes
Body: { note_text }
- Create new note
- Auto-populate user_id from session
- Log activity

PUT /api/members/:memberKey/notes/:noteId
Body: { note_text }
- Update note (only your own notes)
- Set updated_at timestamp
- Log activity

DELETE /api/members/:memberKey/notes/:noteId
- Delete note (only your own notes, or admin)
- Log activity

ACTIVITY LOG FEATURE:

Track all important actions for audit trail and collaboration:

ACTIVITY LOG PAGE (/admin/activity):
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Activity Log                                    [Export] [Filter â–¾] â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Time         â”‚ User        â”‚ Activity                                â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ 10:15 AM     â”‚ Sarah J.    â”‚ Added note to Bob Williams             â”‚
â”‚ 9:30 AM      â”‚ Mike C.     â”‚ Sent reminder email to 45 members      â”‚
â”‚ Yesterday    â”‚ Lisa W.     â”‚ Updated member: Jane Smith             â”‚
â”‚ Jan 22       â”‚ Sarah J.    â”‚ Created new user: Bob Smith            â”‚
â”‚ ...          â”‚             â”‚                                        â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Filter by: User, Action Type, Date Range, Entity

ACTIVITY LOG ENDPOINTS:

GET /api/admin/activity
Query params: ?user_id=...&action_type=...&start_date=...&end_date=...
- Returns paginated activity log (admin only)
- Support filtering and search

POST /api/activity/log
Body: { action_type, entity_type, entity_id, description, metadata }
- Called internally by other endpoints to log actions
- Auto-populate user_id from session
- Examples:
  * action_type: 'email_sent', 'note_added', 'member_updated', 'user_created'
  * entity_type: 'member', 'office', 'user'
  * description: Human-readable text for activity feed

HEADER UPDATE (when logged in):

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ [Membio Logo]  MemberSync            Sarah Johnson [Menu â–¾]    â”‚
â”‚ Background: #2e1f62, Text: white                               â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Dropdown menu:
- My Profile
- Activity Log (if admin)
- User Management (if admin)
- Settings
- ---
- Sign Out

FIRST-TIME SETUP:

Create seed admin user via database script or migration:
```sql
INSERT INTO users (email, password_hash, full_name, role)
VALUES (
  'admin@mainstreetrealtors.org',
  '$2a$10$...', -- bcrypt hash of temporary password
  'System Administrator',
  'admin'
);
```

Admin can then log in and create other users through UI.

PASSWORD SECURITY:
- Minimum 8 characters
- Require: uppercase, lowercase, number
- Hash with bcrypt (cost factor 10)
- Never store plain text passwords
- Force password change on first login with temporary password

SECURITY BEST PRACTICES:
- Use HTTPS in production (required for secure cookies)
- httpOnly cookies (prevent XSS attacks)
- CSRF protection with tokens
- Rate limiting on login endpoint (prevent brute force)
- Account lockout after 5 failed attempts (15 min lockout)
- Log all authentication attempts
- Validate JWT signature on every request
- Expire sessions after 8 hours of inactivity

MIDDLEWARE:
```javascript
// Protect routes
app.use('/api/*', authenticateToken);

// Role-based access
app.use('/api/admin/*', requireRole(['admin']));
app.use('/api/members/*/edit', requireRole(['admin', 'staff']));

function authenticateToken(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Not authenticated' });
  
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = user;
    next();
  });
}

function requireRole(roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}
```

CRITICAL CONTEXT:
50-70% of MainStreet members have NO transactions in 1-3 years, yet 
remain active paying members. We use a TIERED engagement model that 
measures what matters for each member type.

MainStreet has approximately:
- 19,000 active members
- 2,800 active offices

THREE MEMBER TIERS:
1. Active Producers (30-50%): 2+ transactions in last 12 months
2. Occasional Producers (20-30%): 1+ transactions in last 24 months
3. License Maintainers (20-40%): 0 transactions in 24+ months

Each tier has different engagement expectations and scoring.

DATABASE SCHEMA (PostgreSQL):

Table: apmmember (member data)
- MemberKey (text, PRIMARY) - unique member ID
- MemberMlsId (text) - links to property listings
- MemberFullName, MemberFirstName, MemberLastName (text)
- MemberEmail, MemberMobilePhone, MemberDirectPhone (text)
- MemberType (text) - 'REALTOR', 'Leasing Agent', 'Secondary'
- MemberStatus (text) - 'Active', 'Inactive'
- MemberStateLicense (text)
- MemberStateLicenseExpirationDate (date)
- MemberDesignations (jsonb) - professional certifications
- NarJoinDate (date) - when they joined
- OfficeKey (text) - links to office (IMPORTANT for office analytics)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmproperty (MLS listing/transaction data)
- ListingId (text)
- ListAgentMlsId (text) - listing agent (matches MemberMlsId)
- BuyerAgentMlsId (text) - buyer agent (matches MemberMlsId)
- OnMarketDate (date)
- CloseDate (date) - when sale closed
- ListPrice, ClosePrice (numeric)
- StandardStatus (text) - Active, Closed, Pending
- UnparsedAddress, City (text)
- PropertyType (text)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmmemberdues (invoices - CRITICAL for lapse prediction)
- MemberKey (text) - links to member
- InvoiceKey (text)
- InvoiceDate, DueDate (date)
- InvoiceTotal, AmountPaid, BalanceDue (numeric)
- PaidStatus (boolean)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmevent (classes and events)
- EventId (text, PRIMARY)
- CourseId (text)
- Type (text) - 'class' or 'event'
- Name (text) - event/class name
- EducationCredits (text) - CE hours as string
- StartDateTime, EndDateTime (timestamp)
- Categories (text) - for classes: ["Elective"], ["Core"], etc.
- EventTypeDesc (text) - for events: classification
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmeventregistration (member event attendance)
- EventId (text) - links to apmevent
- MemberKey (text) - links to member
- Completion_Date (date) - PRIMARY completion signal
- Attended (text) - 'Y' or 'N' for MainStreet
- Registration_Status (text)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

Table: apmmembereducation (course completions)
- MemberKey (text) - links to member
- CourseDesc, CourseCode (text)
- Category (text) - course classification
- CreditsCompleted (text) - CE hours as string
- CompletionDate (date) - PRIMARY completion signal
- Status (text)
- StartDate, DeadlineDate (date)
- ApmClientId (text) - ALWAYS filter = 'MainStreet'

CORE COMPLIANCE REQUIREMENTS (CRITICAL):

1. NAR CODE OF ETHICS (every 3 years):
   - Current cycle: Jan 1, 2025 - Dec 31, 2027
   - 2.5+ hours required
   - Failure = suspension Jan-Feb 2028, termination March 1, 2028
   - Identify by activity_name containing "COE" or "Code of Ethics" or "Ethics"

2. ILLINOIS STATE CE (every 2 years by April 30 of even years):
   - Next deadline: April 30, 2026 (3 months away!)
   - Standard renewal: 12 hours total
     * 6-hour Core course
     * 1 hour Sexual Harassment Prevention
     * 5 hours electives
   - First-time renewal (if licensed Nov 2023-Oct 2025): 45 hours
   - Identify by course_type = 'Core' or '4 Hour Core Requirement' or 'Elective'

ENGAGEMENT SCORE CALCULATION (0-10 scale):

TIER 1: Active Producers (2+ transactions last 12 months)
- Transaction Activity (0-4 pts): 
  * 4: 5+ closings in 90 days
  * 3: 3-4 closings in 90 days
  * 2: 1-2 closings in 90 days
  * 1: Active listings, 0 closings
  * 0: No activity 90+ days
- Education/Events (0-2 pts):
  * 2: 1+ activity in last 90 days
  * 1: 1+ activity in last 180 days
  * 0: None in 180+ days
- Payment (0-3 pts):
  * 3: All current
  * 2: Currently paid, but late in past
  * 1: 1 overdue invoice
  * 0: Multiple overdue OR 60+ days late
  * PENALTY: -2 if 90+ days overdue
- License (0-1 pt):
  * 1: Current, not expiring soon
  * 0: Expires <30 days

TIER 2: Occasional Producers (1+ transactions last 24 months)
- Transaction Activity (0-3 pts):
  * 3: 1+ closings in 90 days
  * 2: 1+ closings in 180 days
  * 1: 1+ closings in 365 days
  * 0: None in 365+ days
- Education/Events (0-3 pts):
  * 3: 2+ activities in 180 days
  * 2: 1 activity in 180 days
  * 1: 1 activity in 365 days
  * 0: None in 365+ days
- Payment (0-3 pts): Same as Tier 1
- License (0-1 pt): Same as Tier 1

TIER 3: License Maintainers (0 transactions 24+ months)
- Education/Events (0-5 pts):
  * 5: 2+ classes AND 2+ events in 12 months
  * 4: 2+ classes OR 2+ events in 12 months
  * 3: 1 class AND 1 event in 12 months
  * 2: 1 class OR 1 event in 12 months
  * 1: 1 activity in 24 months
  * 0: None in 24+ months
- Professional Investment (0-2 pts):
  * 2: Has 2+ designations
  * 1: Has 1 designation
  * 0: No designations
- Payment (0-3 pts): Same as Tier 1
- License (0-1 pt): Same as Tier 1

AT-RISK CRITERIA (by tier):

TIER 1 (Active Producers) flagged if ANY:
- Engagement score < 5.0
- No transactions 90+ days AND no active listings
- Invoice 30+ days overdue
- License expires <30 days
- Illinois CE incomplete with <60 days to deadline
- Code of Ethics incomplete with <180 days to deadline
- No education/events in 180+ days

TIER 2 (Occasional Producers) flagged if ANY:
- Engagement score < 4.0
- No transactions 12+ months
- Invoice 30+ days overdue
- License expires <30 days
- Illinois CE incomplete with <90 days to deadline
- Code of Ethics incomplete with <365 days to deadline
- No education/events in 12+ months

TIER 3 (License Maintainers) flagged if ANY:
- Engagement score < 4.0
- Invoice 30+ days overdue
- License expires <30 days
- Illinois CE incomplete with <90 days to deadline
- Code of Ethics incomplete with <365 days to deadline
- No education/events in 24+ months
- Has 0 designations (never invested professionally)

OFFICE-LEVEL RISK CRITERIA:

An office should be flagged if ANY:
- 30%+ of their agents are at-risk
- Office average engagement score < 5.0
- Multiple (3+) overdue invoices from same office
- No office-wide activity (events/training) in 6+ months

DASHBOARD FEATURES TO BUILD:

1. TOP METRICS (5 cards - responsive layout)

DESKTOP LAYOUT:
Row 1: 4 cards across (equal width)
Row 2: Office Performance card (spans 2 columns) + space for future features

MOBILE LAYOUT:
All cards stack vertically, full width

Card 1: Total Active Members
Query: COUNT(*) WHERE ApmClientId = 'MainStreet' AND MemberStatus = 'Active' 
AND MemberType IN ('REALTOR', 'Leasing Agent', 'Secondary')
Show breakdown by tier

Card 2: Engaged This Quarter  
Count members with ANY activity (transaction, education, event) in last 90 days
Show percentage and breakdown

Card 3: At-Risk Members (RED)
Count members matching at-risk criteria for their tier
Show by risk level: Critical, High, Medium

Card 4: Compliance Alerts
Count:
- Invoices 90+ days overdue
- Licenses expiring <30 days
- Illinois CE due <60 days and incomplete
- Code of Ethics due <180 days and incomplete

Card 5: Office Performance (SPANS 2 COLUMNS on desktop)
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ ðŸ“ Office Performance                                               â”‚
â”‚                                                                     â”‚
â”‚ 2,800 Active Offices    2,352 Healthy (84%)    308 Watch (11%)    â”‚
â”‚ 140 At-Risk (5%)                                                    â”‚
â”‚                                                                     â”‚
â”‚ Top Performers                    Needs Attention                  â”‚
â”‚ â€¢ Smith & Associates (92 mbrs)    â€¢ Downtown Realty (8 at-risk)   â”‚
â”‚ â€¢ Century 21 North (8.7 avg)      â€¢ Keller Williams West (4.2 avg)â”‚
â”‚                                                                     â”‚
â”‚ [View All Offices â†’]                                               â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Office health calculation:
- Healthy: <20% at-risk members AND avg score â‰¥ 6.0
- Watch: 20-30% at-risk OR avg score 5.0-5.9
- At-Risk: >30% at-risk OR avg score < 5.0

2. INTELLIGENT SEARCH BAR

Prominent search with placeholder:
"Ask anything... (e.g., 'who needs Code of Ethics training')"

This will use AI (Phase 3). For now, create UI only.

3. MEMBERS LIST VIEW (TABLE, NOT CARDS - CRITICAL)

With 19,000 members, card-based layout is impractical. Use clean, 
sortable data table.

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Members (19,234)                           [Search by name...]    [Filter â–¾] â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Name         â”‚ Score  â”‚ Tier        â”‚ Office       â”‚ Activity  â”‚ Status     â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Johnson, S   â”‚ ðŸŸ¢ 8.2 â”‚ Active Prod â”‚ Smith & Assocâ”‚ 12d ago   â”‚ âœ“ Current  â”‚
â”‚ Williams, B  â”‚ ðŸ”´ 2.1 â”‚ License Mnt â”‚ Century 21   â”‚ 18mo ago  â”‚ âš  OVERDUE  â”‚
â”‚ Martinez, C  â”‚ ðŸŸ¡ 4.8 â”‚ Occasional  â”‚ RE/MAX North â”‚ 45d ago   â”‚ âœ“ Current  â”‚
â”‚ Smith, J     â”‚ ðŸŸ¢ 7.8 â”‚ License Mnt â”‚ Keller W.    â”‚ 8d ago    â”‚ âš  CE Due   â”‚
â”‚ ...          â”‚        â”‚             â”‚              â”‚           â”‚            â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
                                                          Showing 1-50 of 19,234
                                                          [â† 1 2 3 ... 385 â†’]

Table Features:
- Click any row â†’ navigate to member detail page
- Click column header â†’ sort by that column (toggle asc/desc)
- Real-time search filters as you type
- Pagination: 50 rows per page
- Keyboard navigation (arrow keys, enter to open detail)
- Mobile: table converts to stacked card layout
- Export current view to CSV
- Visual status indicators (color dots ðŸŸ¢ðŸŸ¡ðŸ”´)
- Lightweight, fast-loading (virtualized scrolling for performance)
- Hover states, subtle zebra striping for readability
- Column toggles (show/hide optional columns)

Color coding:
- ðŸŸ¢ Green (score 7.0+): Emerald-500
- ðŸŸ¡ Yellow (score 4.0-6.9): Amber-500
- ðŸ”´ Red (score <4.0): Red-600

4. OFFICES LIST VIEW (TABLE, NOT CARDS - CRITICAL)

With 2,800 offices, card-based layout is impractical. Use clean,
sortable data table.

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Offices (2,800)                            [Search by name...]    [Filter â–¾] â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Office Name      â”‚ Agents â”‚ Avg Scoreâ”‚ At-Risk   â”‚ Compliance   â”‚ Status    â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Smith & Assoc    â”‚ 92     â”‚ ðŸŸ¢ 7.4  â”‚ 3 (3%)     â”‚ 98% CE       â”‚ Healthy   â”‚
â”‚ Downtown Realty  â”‚ 45     â”‚ ðŸŸ¡ 5.2  â”‚ 8 (18%)    â”‚ 78% CE       â”‚ âš  Watch   â”‚
â”‚ Century 21 North â”‚ 156    â”‚ ðŸŸ¢ 8.1  â”‚ 5 (3%)     â”‚ 100% CE      â”‚ Healthy   â”‚
â”‚ Keller W. West   â”‚ 67     â”‚ ðŸ”´ 4.2  â”‚ 22 (33%)   â”‚ 65% CE       â”‚ ðŸ”´ At-Riskâ”‚
â”‚ ...              â”‚        â”‚         â”‚            â”‚              â”‚           â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
                                                          Showing 1-50 of 2,800
                                                          [â† 1 2 3 ... 56 â†’]

Table Features: Same as Members List
Additional columns available:
- YTD Transactions
- Payment Health (% current vs overdue)
- Recent Office Activity

5. MEMBER DETAIL VIEW

Click on any member row to see detailed profile:

Header:
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Sarah Johnson              ðŸŸ¢ 8.2           â”‚
â”‚ REALTOR Â· Active Producer                   â”‚
â”‚ Smith & Associates                          â”‚
â”‚                                             â”‚
â”‚ ðŸ“§ sjohnson@email.com  ðŸ“± (555) 123-4567   â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Sections:
- Contact Information
- Performance Metrics (tier-appropriate):
  * Active Producers: Recent transactions, YTD closings, active listings
  * Occasional: Transaction history, time since last sale
  * License Maintainers: Designation count, professional development
  
- Payment Status:
  Timeline showing invoice history with visual indicators
  
- Compliance Status:
  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
  â”‚ Illinois CE: 8/12 hours complete        â”‚
  â”‚ Due: April 30, 2026 (97 days)          â”‚
  â”‚ Progress: [â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–‘â–‘â–‘â–‘] 67%            â”‚
  â”‚                                         â”‚
  â”‚ Code of Ethics: âœ… Complete             â”‚
  â”‚ Cycle: 2025-2027                       â”‚
  â”‚                                         â”‚
  â”‚ License: Expires June 15, 2026         â”‚
  â”‚ Status: âœ… Current                      â”‚
  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

- Recent Activity Timeline:
  Unified stream of transactions, education, events, payments
  Chronological, most recent first

- AI Insights Card (Phase 3 - placeholder for now)

Action buttons:
[Call Now] [Send Email] [Send Reminder] [Add Note]

6. OFFICE DETAIL VIEW

Click on any office row to see detailed profile:

Header:
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Smith & Associates         ðŸŸ¢ 7.4          â”‚
â”‚ 92 Active Agents                           â”‚
â”‚                                             â”‚
â”‚ ðŸ“ 123 Main St, Chicago, IL                â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Sections:
- Office Roster (table of members):
  * Filter by tier, sort by score
  * Quick view of each agent's status
  
- Office-Wide Metrics:
  * Average engagement score
  * Transaction volume (YTD)
  * Compliance summary (% complete for COE, IL CE)
  * Payment health (% current vs overdue)
  
- Office Activity Timeline:
  * Recent office-wide events
  * Training sessions
  * Achievements

Action buttons:
[Contact Office] [Schedule Training] [Download Roster] [Add Note]

7. COMPLIANCE DASHBOARD (new screen)

Show members grouped by compliance status:

Illinois CE Status:
- Complete (12+ hours): [count] members
- In Progress (1-11 hours): [count] members with hours completed
- Not Started (0 hours): [count] members
  * RED FLAG if deadline <90 days

Code of Ethics Status (2025-2027 cycle):
- Complete: [count] members
- Incomplete: [count] members
  * RED FLAG if deadline <180 days

License Status:
- Current: [count] members
- Expiring Soon (<90 days): [count] members
- Expired: [count] members

Click any group to see filterable member table

TECHNICAL REQUIREMENTS:

Environment variables (.env):
- DB_HOST, DB_NAME, DB_USER, DB_PASSWORD, DB_PORT
- ANTHROPIC_API_KEY (for Phase 3)
- JWT_SECRET (generate random string for token signing)
- SESSION_SECRET (for express-session)
- SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS (for password reset emails)

Database connection:
Use pg (node-postgres) with connection pool, SSL enabled

Key backend endpoints:

GET /api/dashboard/metrics
- Returns 5 card metrics (including office performance)

GET /api/dashboard/compliance
- Returns compliance status counts

GET /api/members?tier=all&sort=name&page=1&limit=50
- Returns paginated member list with scores
- Classify tier based on transaction history
- Calculate engagement score for each tier
- Include compliance status
- Support sorting and filtering

GET /api/members/at-risk?tier=all&page=1&limit=50
- Returns at-risk members by urgency
- Apply tier-appropriate criteria
- Paginated

GET /api/members/:memberKey
- Returns full member detail
- Include transactions, education, events, invoices
- Calculate all compliance statuses
- Include office information

GET /api/members/:memberKey/activity
- Returns unified activity stream (transactions, education, events, payments)
- Ordered by date descending

GET /api/offices?sort=name&page=1&limit=50
- Returns paginated office list
- Calculate office-level metrics
- Include agent counts, avg scores, at-risk counts
- Support sorting and filtering

GET /api/offices/at-risk?page=1&limit=50
- Returns at-risk offices
- Apply office-level criteria
- Paginated

GET /api/offices/:officeKey
- Returns full office detail
- Include roster of members
- Office-wide metrics
- Activity timeline

GET /api/offices/:officeKey/roster
- Returns member table for this office
- Support filtering and sorting

GET /api/compliance/illinois-ce
- Returns members grouped by Illinois CE status

GET /api/compliance/code-of-ethics
- Returns members grouped by COE status (2025-2027 cycle)

GET /api/compliance/licenses
- Returns members grouped by license expiration status

BRANDING & DESIGN SYSTEM:

This is a Membio product. Follow these brand standards exactly:

Brand Colors (Membio):
- Primary: #2e1f62 (deep purple - main brand)
- Secondary: #29323d (dark slate - structure)
- Tertiary: #5f46b1 (medium purple - interactive)
- Accent 1: #a389f4 (light purple - highlights)
- Accent 2: #d3dcec (pale blue - backgrounds)

Status Colors (complementary to brand):
- Success/Healthy: Emerald-500 (from Tailwind) - for scores 7.0+, complete status
- Warning/Watch: Amber-500 (from Tailwind) - for scores 4.0-6.9, approaching deadlines
- Critical/At-Risk: Red-600 (from Tailwind) - for scores <4.0, overdue, missed deadlines

Typography:
- Font: 'Proxima Nova' with fallback to 'Helvetica', 'sans-serif'
- Headlines: 24-32px, bold
- Body: 16px, black (#000000)
- Small: 14px

Header (fixed top):
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ [Membio Logo]  MemberSync                    [User Menu â–¾] â”‚
â”‚ Background: #2e1f62, Text: white                           â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Footer:
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ [Membio Logo]                                               â”‚
â”‚                                                             â”‚
â”‚ Terms of Use  â€¢  Privacy Policy                            â”‚
â”‚                                                             â”‚
â”‚ Â©2026 Membio. All Rights Reserved.                        â”‚
â”‚                                                             â”‚
â”‚ Background: #d3dcec, Text: black (#000000)                 â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

Terms of Use and Privacy Policy: Create placeholder pages for now
(simple pages with "Coming Soon" message)

Spacing:
- 8px grid system
- Card padding: 24px
- Gaps: 16px

Components:
- Buttons: 44px min height (touch-friendly)
  * Primary button: #5f46b1 background, white text
  * Secondary button: #a389f4 background, white text
  * Danger button: Red-600 background, white text
- Cards: shadow-sm, rounded-lg (8px)
- Tables: Clean, minimal borders, hover states
- Smooth transitions (200ms ease)

Mobile Responsiveness:
- Breakpoint: 768px
- Stack cards vertically on mobile
- Tables convert to stacked cards on mobile
- Bottom nav on mobile (if needed)
- Touch-friendly hit areas (44px minimum)

Loading States:
- Skeleton screens (not spinners)
- Fade-in animations
- Progressive loading for large tables

START BY:
1. Creating project structure (React + Express + PostgreSQL)
2. Setting up Membio branding (colors, fonts, header, footer)
3. Building dashboard with dummy data
4. Creating table-based list views (members and offices)
5. Getting UI polished and professional
6. Once approved, I'll provide database credentials
7. Then connect real data

Make it look premium - clean, modern, professional like Stripe or Linear.
Use lots of white space, clear hierarchy, consistent branding.
Remember: Proxima Nova font, black body text, Membio purple theme.
```

---

## ðŸ“Š Phase 2: Production Activity Stream Query

Once Replit builds the basic structure, add this PRODUCTION-READY query 
that Julius.ai validated for MainStreet data.

**Save this as a database view or use in your API endpoints:**

```sql
WITH
member_latest AS (
  SELECT *
  FROM (
    SELECT
      m.*,
      ROW_NUMBER() OVER (
        PARTITION BY m."ApmClientId", m."MemberKey"
        ORDER BY m."ApmSourceModificationTimestamp" DESC NULLS LAST,
                 m."ApmReceivedDateTime" DESC NULLS LAST
      ) AS rn
    FROM "AMS"."apmmember" m
    WHERE m."ApmClientId" = 'MainStreet'
  ) s
  WHERE s.rn = 1
),

event_latest AS (
  SELECT *
  FROM (
    SELECT
      e.*,
      ROW_NUMBER() OVER (
        PARTITION BY e."ApmClientId", e."EventId"
        ORDER BY e."ApmSourceModificationTimestamp" DESC NULLS LAST,
                 e."ApmReceivedDateTime" DESC NULLS LAST
      ) AS rn
    FROM "AMS"."apmevent" e
    WHERE e."ApmClientId" = 'MainStreet'
  ) s
  WHERE s.rn = 1
),

eventreg_latest AS (
  SELECT *
  FROM (
    SELECT
      r.*,
      ROW_NUMBER() OVER (
        PARTITION BY
          r."ApmClientId",
          r."EventId",
          r."MemberKey",
          COALESCE(r."Registration_ID", r."ApmSourceUniqueRecordId")
        ORDER BY r."ApmSourceModificationTimestamp" DESC NULLS LAST,
                 r."ApmReceivedDateTime" DESC NULLS LAST
      ) AS rn
    FROM "AMS"."apmeventregistration" r
    WHERE r."ApmClientId" = 'MainStreet'
  ) s
  WHERE s.rn = 1
),

memberedu_latest AS (
  SELECT *
  FROM (
    SELECT
      ed.*,
      ROW_NUMBER() OVER (
        PARTITION BY
          ed."ApmClientId",
          ed."MemberKey",
          COALESCE(
            NULLIF(BTRIM(ed."CourseDesc"), ''),
            NULLIF(BTRIM(ed."CourseCode"), ''),
            NULLIF(BTRIM(ed."CourseNumber"), ''),
            ed."ApmSourceUniqueRecordId"
          )
        ORDER BY ed."ApmSourceModificationTimestamp" DESC NULLS LAST,
                 ed."ApmReceivedDateTime" DESC NULLS LAST
      ) AS rn
    FROM "AMS"."apmmembereducation" ed
    WHERE ed."ApmClientId" = 'MainStreet'
  ) s
  WHERE s.rn = 1
),

activity_stream AS (
  -- Event registrations and class completions
  SELECT
    'event_registration'::text AS activity_source,
    r."MemberKey" AS member_key,
    e."Type" AS event_type,
    
    -- MainStreet-specific course_type mapping
    CASE
      WHEN e."Type" = 'class' THEN
        COALESCE(
          NULLIF(BTRIM(SPLIT_PART(REPLACE(REPLACE(REPLACE(e."Categories", '[', ''), ']', ''), '\"', ''), ',', 1)), ''),
          NULLIF(BTRIM(e."Categories"), '')
        )
      ELSE
        COALESCE(
          NULLIF(BTRIM(e."EventTypeDesc"), ''),
          NULLIF(BTRIM(e."EventType"), ''),
          NULLIF(BTRIM(e."Categories"), '')
        )
    END AS course_type,
    
    e."Name" AS activity_name,
    e."EducationCredits" AS education_credits,
    r."Completion_Date" IS NOT NULL AS is_completed,
    r."Attended" = 'Y' AS is_attended,
    r."Completion_Date" AS completion_date,
    e."StartDateTime" AS start_datetime,
    e."EventId" AS event_id

  FROM eventreg_latest r
  LEFT JOIN event_latest e
    ON e."EventId" = r."EventId"

  UNION ALL

  -- Course completions
  SELECT
    'member_education'::text AS activity_source,
    ed."MemberKey" AS member_key,
    NULL::text AS event_type,
    ed."Category" AS course_type,
    COALESCE(ed."CourseDesc", ed."CourseCode") AS activity_name,
    ed."CreditsCompleted" AS education_credits,
    ed."CompletionDate" IS NOT NULL AS is_completed,
    NULL::boolean AS is_attended,
    ed."CompletionDate"::date AS completion_date,
    ed."StartDate"::timestamptz AS start_datetime,
    NULL::text AS event_id
  FROM memberedu_latest ed
)

SELECT * FROM activity_stream
WHERE is_completed = true
ORDER BY completion_date DESC;
```

**Use this query to:**
- Count education activities per member
- Check Code of Ethics completion (activity_name LIKE '%COE%' OR '%Ethics%')
- Check Illinois CE hours (SUM credits where course_type IN ('Core', 'Elective', etc.))
- Build activity timeline

---

## ðŸŽ¯ Phase 3: Key Backend Queries

### Classify Member Tier

```javascript
// In your API endpoint
async function classifyMemberTier(memberKey, memberMlsId) {
  const result = await pool.query(`
    SELECT 
      COUNT(DISTINCT CASE 
        WHEN p."CloseDate" >= NOW() - INTERVAL '12 months' 
        THEN p."ListingId" 
      END) as closings_12mo,
      COUNT(DISTINCT CASE 
        WHEN p."CloseDate" >= NOW() - INTERVAL '24 months' 
        THEN p."ListingId" 
      END) as closings_24mo
    FROM "AMS"."apmproperty" p
    WHERE (p."ListAgentMlsId" = $1 OR p."BuyerAgentMlsId" = $1)
      AND p."ApmClientId" = 'MainStreet'
  `, [memberMlsId]);
  
  const { closings_12mo, closings_24mo } = result.rows[0];
  
  if (closings_12mo >= 2) return 'Active Producer';
  if (closings_24mo >= 1) return 'Occasional Producer';
  return 'License Maintainer';
}
```

### Check Compliance Status

```javascript
async function getComplianceStatus(memberKey) {
  // Check Code of Ethics (2025-2027 cycle)
  const coeResult = await pool.query(`
    SELECT COUNT(*) as coe_count
    FROM activity_stream
    WHERE member_key = $1
      AND is_completed = true
      AND completion_date >= '2025-01-01'
      AND completion_date <= '2027-12-31'
      AND (
        activity_name ILIKE '%COE%'
        OR activity_name ILIKE '%Code of Ethics%'
        OR activity_name ILIKE '%Ethics%'
      )
  `, [memberKey]);
  
  const hasCodeOfEthics = coeResult.rows[0].coe_count > 0;
  
  // Check Illinois CE (2024-2026 cycle, due April 30, 2026)
  const ilCeResult = await pool.query(`
    SELECT 
      SUM(CAST(education_credits AS NUMERIC)) as total_ce_hours
    FROM activity_stream
    WHERE member_key = $1
      AND is_completed = true
      AND completion_date >= '2024-05-01'
      AND completion_date <= '2026-04-30'
      AND course_type IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses')
  `, [memberKey]);
  
  const ceHours = ilCeResult.rows[0].total_ce_hours || 0;
  
  return {
    codeOfEthics: {
      complete: hasCodeOfEthics,
      cycle: '2025-2027',
      deadline: '2027-12-31'
    },
    illinoisCE: {
      hoursCompleted: ceHours,
      hoursRequired: 12, // or 45 for first-time
      deadline: '2026-04-30',
      daysRemaining: Math.floor((new Date('2026-04-30') - new Date()) / (1000 * 60 * 60 * 24))
    }
  };
}
```

### Calculate Office Metrics

```javascript
async function getOfficeMetrics(officeKey) {
  // Get all members in this office
  const membersResult = await pool.query(`
    SELECT 
      "MemberKey",
      "MemberMlsId",
      "MemberFullName"
    FROM "AMS"."apmmember"
    WHERE "OfficeKey" = $1
      AND "ApmClientId" = 'MainStreet'
      AND "MemberStatus" = 'Active'
  `, [officeKey]);
  
  const members = membersResult.rows;
  const totalMembers = members.length;
  
  // Calculate engagement scores for all members
  let totalScore = 0;
  let atRiskCount = 0;
  
  for (const member of members) {
    const score = await calculateEngagementScore(member.MemberKey, member.MemberMlsId);
    totalScore += score;
    
    if (score < 4.0) {
      atRiskCount++;
    }
  }
  
  const avgScore = totalMembers > 0 ? totalScore / totalMembers : 0;
  const atRiskPercent = totalMembers > 0 ? (atRiskCount / totalMembers) * 100 : 0;
  
  // Determine office health status
  let healthStatus = 'Healthy';
  if (atRiskPercent > 30 || avgScore < 5.0) {
    healthStatus = 'At-Risk';
  } else if (atRiskPercent >= 20 || (avgScore >= 5.0 && avgScore < 6.0)) {
    healthStatus = 'Watch';
  }
  
  return {
    totalMembers,
    avgScore,
    atRiskCount,
    atRiskPercent,
    healthStatus
  };
}
```

---

## ðŸ¤– Phase 4: Add AI Intelligence

```
Now add intelligent natural language query and insights using Claude AI.

Install Anthropic SDK:
npm install @anthropic-ai/sdk

I'll provide ANTHROPIC_API_KEY in Replit Secrets.

CREATE ENDPOINT: POST /api/ai/query

When user asks a question, send to Claude with this system prompt:

"You are a SQL expert for MainStreet Realtors member database.
Convert questions to PostgreSQL queries for these tables:

Tables: apmmember, apmproperty, apmmemberdues, apmevent, 
apmeventregistration, apmmembereducation

[Include full schema details from Phase 1]

CRITICAL RULES:
1. ALWAYS filter WHERE ApmClientId = 'MainStreet'
2. For members: AND MemberStatus = 'Active' AND MemberType IN (...)
3. Only SELECT queries (no UPDATE/DELETE/INSERT)
4. Use the activity_stream view for education/event queries
5. Limit results to 1000 rows
6. Return ONLY the SQL query, no explanation

EXAMPLE QUERIES:

Q: 'who needs Code of Ethics training'
A: SELECT m.MemberFullName, m.MemberEmail 
FROM apmmember m
WHERE m.ApmClientId = 'MainStreet'
  AND m.MemberStatus = 'Active'
  AND m.MemberKey NOT IN (
    SELECT DISTINCT member_key 
    FROM activity_stream
    WHERE is_completed = true
      AND completion_date >= '2025-01-01'
      AND activity_name ILIKE '%COE%'
  )
LIMIT 1000;

Q: 'members with overdue invoices'
A: SELECT m.MemberFullName, d.BalanceDue, d.DueDate
FROM apmmember m
JOIN apmmemberdues d ON m.MemberKey = d.MemberKey
WHERE m.ApmClientId = 'MainStreet'
  AND m.MemberStatus = 'Active'
  AND d.BalanceDue > 0
  AND d.DueDate < NOW()
ORDER BY d.DueDate ASC
LIMIT 1000;

Q: 'offices with most at-risk members'
A: [Generate query to calculate at-risk members per office]

If question unclear, return: ERROR: [explanation]"

Execute generated SQL and return results as table with download buttons.

CREATE ENDPOINT: GET /api/ai/insights

Generate proactive insights for dashboard:

INSIGHT 1: Critical Compliance Issues
Query members missing Code of Ethics OR Illinois CE with deadline approaching.
For each, call Claude:
"This MainStreet member faces compliance risk:
- Name: [name]
- Missing: [Code of Ethics/Illinois CE]
- Deadline: [date] ([X] days away)
- Payment status: [current/overdue]
- Last activity: [X] days ago

In 1 sentence, explain the urgency and suggest immediate action."

INSIGHT 2: Payment + Inactivity Risk
Query members with BOTH overdue payments AND no activity.
Call Claude with combined risk factors for strategic recommendation.

INSIGHT 3: Tier-Specific Trends
For each tier, analyze activity trends vs previous period.
Call Claude to interpret and suggest proactive strategies.

INSIGHT 4: Office-Level Alerts
Query offices with multiple at-risk agents.
Call Claude for office-wide intervention recommendations.

Display top 3-5 insights on dashboard with urgency color coding.
Cache for 1 hour to avoid excessive API calls.
```

---

## ðŸ“‹ Quality Checklist

Before marking complete, verify:

âœ… Authentication:
- [ ] Login page styled with Membio branding
- [ ] JWT authentication working
- [ ] Session management (8 hour expiration)
- [ ] Password hashing with bcrypt
- [ ] Forgot password flow functional
- [ ] Role-based access control enforced
- [ ] User management page (admin only)
- [ ] Protected routes redirect to login
- [ ] Logout clears session properly

âœ… Multi-User Features:
- [ ] Member notes system working
- [ ] Activity log tracking all actions
- [ ] User dropdown menu in header
- [ ] Admin can add/edit/disable users
- [ ] Staff can collaborate via notes
- [ ] Readonly users have view-only access

âœ… Branding:
- [ ] Proxima Nova font loaded and applied
- [ ] Membio colors (#2e1f62, #29323d, #5f46b1, #a389f4, #d3dcec) used correctly
- [ ] Status colors (emerald, amber, red) working properly
- [ ] Header shows Membio logo + "MemberSync"
- [ ] Footer includes logo, links, Â©2026 Membio copyright
- [ ] Black body text throughout

âœ… Dashboard:
- [ ] 5 cards responsive (4 across on desktop, then office card spanning 2 columns)
- [ ] All cards stack vertically on mobile
- [ ] Office Performance card shows health breakdown
- [ ] Metrics calculate correctly

âœ… List Views:
- [ ] Members list is TABLE format (not cards)
- [ ] Offices list is TABLE format (not cards)
- [ ] Both lists support sorting by columns
- [ ] Real-time search works
- [ ] Pagination implemented (50 per page)
- [ ] Click row â†’ navigate to detail page
- [ ] Export to CSV available
- [ ] Mobile: tables convert to stacked cards

âœ… Detail Pages:
- [ ] Member detail shows all sections
- [ ] Office detail shows roster and metrics
- [ ] Compliance status displays correctly
- [ ] Activity timelines working
- [ ] Action buttons present

âœ… Technical:
- [ ] PostgreSQL connection configured
- [ ] All API endpoints created
- [ ] Queries use correct schema
- [ ] Always filter by ApmClientId = 'MainStreet'
- [ ] Activity stream view implemented
- [ ] Performance optimized for large datasets

âœ… UX:
- [ ] Loading states (skeletons)
- [ ] Smooth transitions
- [ ] Touch-friendly (44px min buttons)
- [ ] Keyboard navigation works
- [ ] Professional, clean design
- [ ] Consistent spacing (8px grid)

---

## ðŸš€ Deployment Notes

Once development complete:
1. Test with dummy data thoroughly
2. Provide database credentials via Replit Secrets
3. Connect to MainStreet production database
4. Verify all queries return correct data
5. Test with real member/office counts (19K/2.8K)
6. Performance test table pagination
7. Launch to MainStreet stakeholders

# CLAUDE.md — MemberSync Product Bible

> **Read this file before every task.** It is the single source of truth for the MemberSync codebase. If something here conflicts with a comment in the code, this file wins.

---

## What Is MemberSync?

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs (Multiple Listing Services). It analyzes MLS listing data and association management system (AMS) data to help executives retain and engage their members.

**The product vision:** MemberSync is the organization's second brain — always thinking about its members and customers, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**The product philosophy:** MemberSync is the 5% of software that people actually use. We built ruthlessly focused tools — not sprawling feature sets. Every screen exists because our clients either asked for it or dreamed that it would exist. We made a platform we wanted to use. Zero training required. AI co-pilot built in. Decision-first UX — every view surfaces a recommended action, not just data.

**The business model:** MemberSync is a SaaS product, not a custom build. Every feature must work for any association or MLS through configuration, not custom code.

---

## The Insight That Drives Everything

**The 75/12 Rule:** At a typical real estate association or MLS, roughly 75% of members produce only about 12% of real estate transaction volume — yet they pay approximately 75% of dues and fee revenue. These are "Foundation" members: people who maintain their license, pay their dues, and may never sell a house. They are the financial backbone of the organization.

Most associations and MLSs focus their attention on the top 1% — those in leadership who control roughly 25% of market volume. The next 24% of members by volume typically control 80–88% of sales volume. But the remaining 75% of the organization's customer or member base — the ones who pay the bill and keep the lights on — contribute only 12–15% of sales volume. Those in leadership often ignore the 75% because they don't appear to be selling real estate at scale. But the truth is, neither MLSs nor associations can exist without the 75%. They are essential to the health of the organization, and have been marginalized for far too long.

MemberSync exists to help these organizations engage ALL members — especially the 75% who are now at risk of lapsing due to structural changes in the real estate industry.

**Why it matters now — and why nobody is spared:** MLSs are opening access to non-REALTOR® licensees, which threatens association membership. But MLSs face the same math: if an MLS doesn't understand that 75% of its subscribers sell 0–5 homes a year and build relevance for those people, it's just as vulnerable. Any organization — association or MLS — that loses touch with its Foundation members risks losing 75% of its revenue base. MemberSync serves both.

**Why this product didn't already exist:** NAR's own research found that committee participation is the single best predictor of member retention in associations. But less than 1% of members participate in committees. So any engagement model built around that signal was doomed from the start — it could only see the most engaged members and was blind to the other 99%. MemberSync exists because we refuse to make that mistake. Every signal we track, every score we compute, every email we send must be relevant to the FULL membership — not just the 1% who show up to committees or the 1.4% who are Rainmakers. If a feature only helps you understand your most engaged members, it's not solving the problem.

---

## Member Tier Framework

Members are classified by 12-month transaction sides (not volume). Note that the percentages in this table were derived from Mainstreet REALTORS® actual data:

| Internal Name | Display Name | Sides (12mo) | Typical % of Membership |
|---|---|---|---|
| `active_producer` | Rainmaker | 40+ | ~1.4% |
| `occasional_producer` | Builder | 6–39 | ~21% |
| `license_maintainer` | Foundation | 0–5 | ~77% |

**Critical rules:**
- Tier names shown to users are always the display names (Rainmaker, Builder, Foundation). Internal names appear only in code and database values.
- All tiers are framed positively. We celebrate connection, not police compliance.
- Foundation members who take classes, pay on time, and attend events can score 10/10 on engagement — even with zero transactions. Engagement is not production.
- Tier thresholds are defined in `clientConfig.ts` and will vary per client.

---

## Modular Architecture

MemberSync is built on a modular framework. This is not just about multi-tenancy — it is about modules that swap in and out based on which Membio products a client has purchased and which organizational type they are.

**The principle:** Every client gets the Core. Modules are enabled or disabled per client in `tenant_config`. A module that is disabled for a client should not appear in their UI, should not consume AI budget, and should not affect their scoring.

### Core (Always On)
Every MemberSync client gets these, regardless of tier or product combination:
- AI Chat (natural language queries against member and MLS data)
- AI Audience Builder (natural language → saved audience)
- AI Email Composer (AI-drafted personalized emails)
- Email Analytics (open rates, click rates, campaign performance)
- Agent Profiles (individual member records, engagement scores, history)
- Office Profiles (office-level metrics, agent roster, health indicators)

### Modules (Conditionally Enabled)
| Module | Enabled When | Notes |
|---|---|---|
| SmartSends Automations | Plus tier or above | Drip sequences, triggered campaigns, A/B testing |
| Lapse Prevention | Plus tier or above | Calendar-aware risk scoring, intervention workflows |
| Configurable Engagement Scores | Plus tier or above | Client-adjustable weights and thresholds |
| Live Activity Feed | Plus tier or above | Real-time sync of CE, events, education activity |
| AI Chat with Charts | Premium tier | Recharts visualizations inline in AI Chat |
| Proactive Engagement Engine | Premium tier | Daily AI pattern detection, surfaced opportunities |
| Market Analytics | Premium tier | Office leaderboards, agent rankings, market share |
| Office Intelligence Briefs | Premium tier | AI-generated pre-visit summaries for office calls |
| Compliance Module | Association clients only | CE tracking, COE, Fair Housing — hidden for MLSs |
| Portal Channels | Clients with Membio Member Portal | Banner and Recommendation push to member portal |
| Education & Events | Clients with Membio website or portal | Classes, courses, events enrichment and targeting |
| Affiliates | Clients with affiliate membership program | Affiliate directory, engagement tracking |
| Broker Module | Future — all clients | Office payment health, suspension impact analysis |

**Architectural rule:** When building any feature, ask: "Is this Core or a Module?" If it's a Module, it must be gated by a `tenant_config` flag. No module logic should execute for clients where the module is disabled.

---

## Product Tiers

MemberSync is sold in three tiers. Pricing is flat annual fee scaled by membership band — not per-member, because per-member pricing commoditizes the product and obscures its ROI.

### The ROI Frame
The right conversation with prospects is not "what does this cost per member" but "what does one lapsed member cost you?" At typical association dues of $500–600/year, retaining 1% of a 3,400-member organization pays for the product entirely. MemberSync is a strategic investment, not infrastructure.

### Tiers

**Core**
- AI Chat
- AI Audience Builder
- AI Email Composer
- Email Analytics
- Agent Profiles
- Office Profiles

**Plus**
- Everything in Core, plus:
- SmartSends Automations (drip sequences, triggered campaigns, A/B testing)
- Configurable Lapse Prevention
- Customizable Engagement Scores
- Live Activity Feed

**Premium**
- Everything in Plus, plus:
- AI Chat with Recharts Visualizations
- Proactive Engagement Engine
- Market Analytics
- Office Intelligence Briefs (pre-visit AI summaries)

### Pricing Bands (Reference)
| Band | Members | Core | Plus | Premium |
|---|---|---|---|---|
| Small | Under 5,000 | ~$12K/yr | ~$18K/yr | ~$28K/yr |
| Mid | 5,000–20,000 | ~$18K/yr | ~$28K/yr | ~$42K/yr |
| Large | 20,000–50,000 | ~$28K/yr | ~$42K/yr | ~$65K/yr |
| Enterprise | 50,000+ | Custom | Custom | Custom |

These are reference figures for internal planning. CFO and ops team should model against actual AI costs per client. CRMLS (103,000+ members) is Enterprise — negotiate separately.

---

## Membio Super-Admin & AI Cost Controls

### Three Access Levels

| Level | Who | What They See |
|---|---|---|
| **Membio Super-Admin** | Membio staff only | All clients, all usage, all config. Can impersonate any client for support. |
| **Client Admin** | Association/MLS admin staff | Their org only. Manages users, configures preferences within Membio-set bounds. |
| **Client Staff User** | Day-to-day users | Uses the product. Subject to rate limits set at client level. |

### The Super-Admin Panel (To Be Built)
A Membio-only admin interface — not visible to any client — that provides:
- Per-client AI usage this month (API calls made, estimated cost, % of budget)
- Per-client email volume (sends, queue status, bounce rates, deliverability)
- Module on/off configuration per client
- Tenant configuration editor (scoring weights, compliance settings, branding)
- System health dashboard (cache refresh status, job queue, errors)
- Usage alerts when any client approaches their estimated monthly AI budget

This does not exist yet. It is a Stage 2 priority (target: CRMLS onboarding).

### API Key Architecture
**One Anthropic API key for all clients.** Never give clients their own key. Membio controls all AI usage, all cost visibility, and all rate limits through a single key on the server. Clients never see or touch the API key.

### AI Cost Controls
Every AI feature should be rate-limited to prevent runaway usage:

| Feature | Suggested Limit | Rationale |
|---|---|---|
| AI Chat queries | 50 per user per day | Power users shouldn't burn the monthly budget in a week |
| Audience Builder | 20 builds per user per day | Each build is a database query + AI call |
| Email Composer | Unlimited | Cheap per call; core value prop |
| Proactive Engine | System-level, not user-level | Runs once daily as a batch job |

**Alert threshold:** When any client hits 80% of their estimated monthly AI budget, send an internal Membio alert. Do not interrupt the client's experience — just flag it for ops review.

**Prompt caching:** Where the same system prompt is used repeatedly (AI Chat, Audience Builder), implement Anthropic's prompt caching to reduce costs. The `sharedDatabaseSchema.ts` content is the primary caching candidate — it's large, static, and injected into every AI call.

**Model selection:** Use Claude Sonnet for complex queries (AI Chat, Audience Builder). Consider Claude Haiku for simpler tasks (subject line suggestions, short copy variations) where response quality requirements are lower. This can reduce AI costs significantly at scale.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React + TypeScript + Tailwind CSS + shadcn/ui + Recharts |
| Backend | Node.js + Express |
| ORM | Drizzle |
| Database | PostgreSQL (two connections — see below) |
| Email | SendGrid (Membio is an established channel partner) |
| AI | Anthropic Claude API (Sonnet 4) |
| Hosting | Replit (prototype), AWS (production target) |

---

## Database Architecture

### Production: One Database

In production, MemberSync uses a **single PostgreSQL database** containing everything: the AMS/MLS source tables (synced externally by Rapattoni) and all MemberSync application tables (caches, campaigns, audiences, user accounts, etc.). This means you CAN join directly across source data and application data in production.

**AMS tables** (schema: `"AMS"`): `apmmember`, `apmmemberassociation`, `apmmemberdues`, `apmevent`, `apmeventregistration`, `apmmembereducation`, `receipt_invoice`

**MLS tables** (schema: `"MLS"`): `apmmember` (yes, same name, different schema), `apmproperty`, `apmoffice`, `apmopenhouse`

**Application tables** (default schema): `member_metrics_cache`, `email_campaigns`, `saved_audiences`, `triggered_campaigns`, `users`, and all other app-specific tables defined in `shared/schema.ts`.

### Replit Prototype: Two Databases (Workaround Only)

The current Replit prototype connects to two separate databases:
- `externalPool` (raw `pg` client) → read-only connection to the production AWS database. Tracy (CEO/founder) was given read-only access as a safety measure so prototyping can't accidentally modify production data.
- `db` (Drizzle ORM) → a separate Replit-hosted PostgreSQL instance for application tables.

**This two-database split is a prototyping convenience, NOT an architectural decision.** It exists solely because the founder needed a safe place to write data without risking production. In the production port:
- `externalPool` and `db` merge into a single database connection
- The "Two-Step Query Pattern" (query one DB, then use results to query the other) goes away — use normal JOINs
- `server/db.ts` should be simplified to a single connection pool

### The Two-Step Query Pattern (Prototype Only)

In the Replit prototype, you cannot join across the two databases. When code needs data from both, it:
1. Queries the external database for member keys / raw data
2. Uses those keys to look up enrichment data in the local cache

This pattern appears throughout `storage.ts` and `routes.ts`. **In production, replace these with direct JOINs.** The two-step pattern is a workaround, not a design pattern to preserve.

### Snapshot Deduplication (CRITICAL)

The external database stores point-in-time snapshots, not current state. The same member or property can appear multiple times. **Every query against AMS/MLS tables MUST deduplicate:**

```sql
SELECT * FROM (
  SELECT m.*, ROW_NUMBER() OVER (
    PARTITION BY m."ApmClientId", m."MemberKey"
    ORDER BY m."ApmSourceModificationTimestamp" DESC
  ) AS rn
  FROM "AMS"."apmmember" m
  WHERE m."ApmClientId" = 'MainStreet'
) x WHERE rn = 1
```

If you forget this, you get inflated counts and duplicate rows. Every query. No exceptions.

### MemberKey Format Rules

AMS and MLS use different key formats for the same member:
- **AMS keys:** No prefix. Example: `259036`
- **MLS keys:** `MRD` prefix. Example: `MRD259036`
- **Join pattern:** `'MRD' || ams_key = mls_key`

The `MRD` prefix is specific to this MLS (MRED). Other MLSs may use different prefixes or none. This must become configurable per client. The prefix is defined in `clientConfig.ts` as `MLS_ID_PREFIX`.

### ApmClientId Filtering

Every query against external tables MUST include `WHERE "ApmClientId" = 'MainStreet'` (or the client's configured ID). Without this, you query across all clients in the shared database.

---

## Project Structure

```
MemberSync/
├── shared/
│   └── schema.ts                    # Database tables (Drizzle) + TypeScript types + Zod validation
├── server/
│   ├── index.ts                     # Express app entry point
│   ├── routes.ts                    # ALL API routes (~7,400 lines — needs splitting)
│   ├── storage.ts                   # Data access layer (members, offices, dashboard)
│   ├── db.ts                        # Database connections (local db + externalPool)
│   ├── ai/                          # AI provider abstraction layer
│   │   ├── index.ts
│   │   ├── providers/anthropic.ts
│   │   └── types.ts
│   ├── seeds/
│   │   └── systemTemplates.ts       # Default email templates
│   ├── services/
│   │   ├── clientConfig.ts          # ⭐ Client-specific configuration (single source of truth)
│   │   ├── memberMetricsCacheService.ts   # Daily member cache refresh
│   │   ├── analyticsProductionCacheService.ts  # Office/agent production cache
│   │   ├── activityCacheService.ts  # Education + event activity cache
│   │   ├── milestoneDetectionService.ts   # Celebration engine
│   │   ├── agentHeadshotService.ts  # MLS photo sync
│   │   ├── emailService.ts          # SendGrid integration + queue processor
│   │   ├── scheduledEmailProcessor.ts     # Cron-based scheduled sends
│   │   ├── triggeredCampaignProcessor.ts  # Automation engine
│   │   ├── aiQueryService.ts        # Natural language → SQL (AI Chat)
│   │   ├── aiAudienceService.ts     # AI audience builder
│   │   ├── aiEmailService.ts        # AI email content generation
│   │   ├── sharedDatabaseSchema.ts  # Schema documentation for AI services
│   │   ├── brokerResolutionService.ts     # Managing broker lookup
│   │   ├── visitBriefService.ts     # PDF generation for office visits
│   │   ├── imageService.ts          # Email image library
│   │   ├── csvUploadService.ts      # CSV audience upload processing
│   │   ├── sendgrid.ts              # SendGrid client configuration
│   │   └── engagementScoreService.ts      # DEPRECATED — use cache instead
│   └── replit_integrations/         # Replit object storage (images)
├── client/src/
│   ├── pages/                       # 28 page-level React components
│   │   ├── Dashboard.tsx
│   │   ├── Members.tsx, MemberDetail.tsx
│   │   ├── Offices.tsx, OfficeDetail.tsx
│   │   ├── SendEmail.tsx            # Email composition wizard
│   │   ├── Campaigns.tsx, CampaignDetail.tsx
│   │   ├── Automations.tsx, CreateAutomation.tsx
│   │   ├── AudienceBuilder.tsx, SavedAudiences.tsx
│   │   ├── Chats.tsx, ChatDetail.tsx        # AI Chat
│   │   ├── Analytics*.tsx           # Overview, Offices, Agents, Brief
│   │   ├── Compliance.tsx
│   │   ├── SmartSends.tsx           # SmartSends dashboard
│   │   └── ... (Templates, Drafts, Images, Login, Profile, Admin)
│   ├── components/
│   │   ├── shared/
│   │   │   ├── EmailComposer.tsx    # ⭐ Shared between Send Email + Automations
│   │   │   ├── MetricCard.tsx
│   │   │   ├── MemberAvatar.tsx
│   │   │   ├── ScoreBadge.tsx
│   │   │   └── DataTable.tsx
│   │   ├── dashboard/               # Dashboard widget components
│   │   ├── audience/                # PicklistBuilder, MemberBillTypeBuilder
│   │   ├── ai/                      # AIChatBox
│   │   ├── layout/                  # AppLayout, AppSidebar, Header, MobileNav
│   │   └── ui/                      # shadcn component library (do not modify)
│   ├── hooks/                       # use-mobile, use-toast, use-upload
│   └── lib/                         # auth, queryClient, utils, emailBlocks, audienceConstants
└── Config: drizzle.config.ts, tailwind.config.ts, vite.config.ts, tsconfig.json, package.json
```

---

## Key Files to Understand

### `server/services/clientConfig.ts` — The Multi-Tenant Keystone

This file contains every client-specific value: organization name, branding, tier thresholds, scoring weights, compliance rules, campus locations, URLs, MLS prefix, timezone. Currently hardcoded for Mainstreet REALTORS®.

**The #1 priority of the production port is promoting this file to a `tenant_config` database table.** Every value in this file becomes a row in that table, keyed by `client_id`. When HGAR onboards, they get their own row with their own thresholds, their own compliance rules (New York, not Illinois), and their own branding.

If you're adding a client-specific value anywhere in the codebase, it goes in `clientConfig.ts` first (or the tenant config table once it exists). Search for "MainStreet" before adding anything — it probably already exists here.

### `shared/schema.ts` — The Data Model

All 29+ database tables are defined here using Drizzle ORM, plus all TypeScript interfaces for API responses. This is the single source of truth for both the database schema and the type system.

Key tables to know:
- `member_metrics_cache` — The most important table. Pre-computed daily. Single source of truth for all member data displayed in the app. Dashboard loads, member lookups, audience queries, and engagement scores all read from here.
- `email_campaigns` + `email_recipients` + `email_events` — The email pipeline
- `saved_audiences` — Audience definitions (AI-built, picklist, member/bill type, CSV)
- `triggered_campaigns` + `triggered_campaign_sends` + `triggered_campaign_steps` — Automation engine
- `member_milestones` — Celebration engine detections
- `activity_cache` — Education and event data synced from the external database
- `membership_daily_snapshot` — Daily membership counts for trending

### `server/routes.ts` — The Monolith (Must Be Split)

~7,400 lines containing every API endpoint. This is the most urgent refactoring target. The production port should split this into module-based route files: `auth.ts`, `members.ts`, `offices.ts`, `smartsends.ts`, `analytics.ts`, `ai.ts`, `admin.ts`, `webhooks.ts`.

### `server/services/sharedDatabaseSchema.ts` — AI's Knowledge of the Database

A large text document (~37K characters) that gets injected into every AI prompt. It tells Claude what tables exist, what columns they have, and how to query them. This is how the AI Chat and Audience Builder know what data is available.

This document is currently monolithic and needs modularization — load only the schema sections relevant to each query type.

---

## Cache-First Architecture

MemberSync pre-computes everything overnight rather than calculating on the fly. This is how 18,000+ members load instantly.

### Daily Job Schedule

| Time (Central) | Job | Service File | What It Does |
|---|---|---|---|
| 3:30 AM | Analytics production cache | `analyticsProductionCacheService.ts` | Office rankings, agent rankings, market concentration |
| 4:00 AM | Member metrics cache | `memberMetricsCacheService.ts` | Refresh all 18K+ member records with current metrics |
| 4:15 AM | Daily snapshot | (in routes) | Capture membership counts for trending |
| 4:30 AM | Milestone detection | `milestoneDetectionService.ts` | Scan for celebrations (anniversaries, milestones) |
| Daily | Activity cache | `activityCacheService.ts` | Sync education + events from external DB |
| 5:15 AM | Headshot sync | `agentHeadshotService.ts` | Incremental photo sync from MLS |
| Every 60s | Scheduled email processor | `scheduledEmailProcessor.ts` | Check for campaigns ready to send |
| Every 15m | Triggered campaign processor | `triggeredCampaignProcessor.ts` | Evaluate active automations |

### Cache Refresh Pattern

The `member_metrics_cache` refresh follows an atomic swap pattern:
1. Build all data in a temp table (`member_metrics_cache_new`)
2. TRUNCATE the live table
3. INSERT from temp into live
4. This ensures the cache is always complete — never partially refreshed

---

## Engagement Scoring System

Scores range from 0–10 and measure **connection to the organization** — not production, not compliance, not paying bills. The fundamental question is: "Does this member (association terminology) or customer (MLS terminology) have a relationship with us beyond paying their invoice on time?" If not, we are not relevant, and they are not engaged.

### What Engagement IS and IS NOT

**Engagement signals** (things that show a member is connected):
- Attending classes and events (especially non-CE/voluntary ones — they came because they WANTED to)
- Opening and clicking emails from the organization
- Having recent non-transaction activity (last 90 days)
- Holding professional designations (investment in the profession)

**NOT engagement** (table stakes or baseline activity):
- **Payment:** Paying your dues is the cost of membership, not a signal of connection. A member who pays their bill and does nothing else is Disconnected. Payment is scored as a binary 0/1 — overdue is a problem signal, but current is just the default state.
- **Transactions:** Selling real estate is what agents DO, not how they connect with their organization. For Foundation members (the majority at every client we've seen), transactions score zero. For Builders and Rainmakers, transactions provide within-tier differentiation but carry less weight than education, events, and email engagement. A Rainmaker who sells 80 homes but never takes a class, never opens an email, and never attends an event is Disconnected — and that's the correct assessment.

### Tier-Aware Scoring

Each tier gets its own formula weighted to the activities that matter for that group. The weights are defined in `clientConfig.ts` under `SCORING_CONFIG` and **must be configurable per client.** An MLS may weight these completely differently than an association.

**Current weights (Mainstreet REALTORS®):**

| Component | Foundation (0-5 sides) | Builder (6-39) | Rainmaker (40+) | Philosophy |
|---|---|---|---|---|
| Education & Events | 0–4 pts | 0–3 pts | 0–3 pts | Primary differentiator — what the org can influence |
| Email Engagement | 0–3 pts (click/open) | 0–2 pts | 0–2 pts | Critical for Foundation — may be their only touchpoint |
| Transactions | 0 pts (not scored) | 0–2 pts | 0–2 pts | Expected baseline, not engagement |
| Payment | 0–1 pt (binary) | 0–1 pt | 0–1 pt | Table stakes — paying a bill is not engagement |
| Recent Activity (90d) | 0–1 pt | 0–1 pt | 0–1 pt | Non-transaction activity recency |
| Designations | 0–1 pt | 0–1 pt | 0–1 pt | Professional investment |

### Engagement Labels (from score)

| Score | Label | Risk Level (DB value) | Color |
|---|---|---|---|
| 8–10 | Highly Connected | `low` | Green |
| 5–7 | Connected | `medium` | Blue |
| 3–4 | Drifting | `high` | Orange |
| 0–2 | Disconnected | `critical` | Red |

### Per-Client Configuration

The entire scoring system — tier thresholds, component weights, label thresholds, and which signals are active — lives in `clientConfig.ts` and must be promoted to the `tenant_config` table for multi-tenant support.

**The scoring engine must be data-driven, not code-driven.** Adding a new signal should be a config change, not a code change.

**What we DON'T let clients configure:** The fundamental philosophy. Paying a bill is never a strong engagement signal. The score always measures connection, not production. These principles are the product's point of view.

### Custom Signals: Extensible by Design, Gated Through Services

Clients will want engagement signals we haven't built yet. Accept them, but through Membio's team — not self-service. We evaluate data quality, map to a scoring component, set weight ranges, and add to tenant config. If three clients ask for the same signal, it becomes standard.

**The 100% coverage test:** Before accepting any custom signal, ask: "What percentage of this client's membership does this signal cover?" If the answer is less than 10%, it's a vanity metric. This is the lesson from NAR — committee participation predicts retention perfectly for the <1% who participate and is useless for everyone else.

### Signal Applicability: Associations vs. MLSs

| Signal / Data Point | Associations | MLSs | Notes |
|---|---|---|---|
| Education & Events | Yes | Maybe | MLSs may offer classes but it's not core to their value prop |
| Email Engagement | Yes | Yes | Universal |
| Transactions | Yes (tier only) | Yes (tier only) | Used for tier classification, not engagement scoring |
| Payment (current/overdue) | Yes | Yes | Table stakes for both |
| License Status (active/inactive) | Yes | Yes | Both care if someone is actively licensed |
| CE Hours (continuing education) | Yes | No | CE renewal matters to associations, not MLSs |
| Designations (GRI, CRS, ABR, etc.) | Yes | No | NAR professional designations are association-specific |
| Code of Ethics | Yes | No | NAR/association requirement |
| Fair Housing training | Yes | No | Association compliance requirement |
| Recent Activity (90d) | Yes | Yes | Universal recency signal |

---

## Volume Double-Counting (The Membio Volume Standard)

When a home sells, both the listing agent and buyer's agent appear in the MLS data with the full sale price. If you SUM(ClosePrice) across a UNION ALL of listing and buyer sides, every dollar gets counted twice.

### Two Volume Concepts

**Personal Production Volume** (`personal_volume_12mo`): Full ClosePrice per side. This is the number agents see on their own profile — it matches industry convention. Used only for individual agent display.

**Market Volume Contribution** (`total_volume_12mo`): ClosePrice split 50/50 so each agent gets half of the closed transaction price. Used for everything that rolls up: office totals, tier totals, market share, association-level reporting.

**Never SUM(ClosePrice) across a UNION ALL of listing + buyer sides for market-level stats.**

---

## SmartSends (Email System)

SmartSends is the email marketing component. It has three sending modes:
1. **Immediate sends** — Staff composes an email, picks an audience, sends now
2. **Scheduled sends** — Same flow, but scheduled for a future date/time
3. **Triggered campaigns (Automations)** — Automated emails that fire when conditions are met

### Email Safety Controls
- `EMAIL_SANDBOX_MODE=true` — Only sends to addresses in `EMAIL_TEST_RECIPIENTS`
- `MAX_CAMPAIGN_RECIPIENTS` — Caps the number of recipients per send
- Per-member daily send limit — Prevents members from getting flooded
- Send window enforcement — Automations only send during business hours (configurable)

### Audience Types

| Source Type | Smart? | Description |
|---|---|---|
| `ai_generated` | Yes | AI builds SQL from natural language, re-queries each use |
| `member_bill_type` | Yes | Filtered by association + bill type, re-queries each use |
| `manual` / `picklist` | No | Hand-picked member list, static |
| `csv_upload` | No | Uploaded file, may include non-members |
| `external_contacts` | No | Non-member email list |

### Merge Fields

**Tier 1 — Member Profile Fields (implemented):** `{{FirstName}}`, `{{LastName}}`, `{{FullName}}`, `{{OfficeName}}`, `{{MemberSince}}`, `{{YearsWithMainstreet}}`, `{{Designations}}`.

**Tier 2 — Trigger Context Fields (implemented for some triggers):** `{{ClassName}}`, `{{ClassDate}}`, `{{EventName}}`, `{{EventDate}}`, `{{YearsAsMember}}`, `{{MilestoneLabel}}`, `{{MilestoneEmoji}}`.

**Tier 3 — Live Data Fields (needed):** Fields pulled from real member data at send time:
- `{{LastTransactionAddress}}`, `{{LastTransactionPrice}}`, `{{LastTransactionDate}}`
- `{{TransactionCount12mo}}`, `{{TotalVolume12mo}}`
- `{{CEHoursRemaining}}`, `{{CEDeadline}}`
- `{{EngagementScore}}`, `{{EngagementLabel}}`

Merge field resolution must be pluggable. The trigger or send context provides available fields; the engine resolves whatever that context makes available. The AI email composer should be context-aware about which fields are available and suggest them automatically.

---

## AI Services

Three AI-powered features, all using Claude (Anthropic API):

### AI Chat (`aiQueryService.ts`)
Natural language → SQL → results. Supports follow-up questions with conversation history. Includes suggested follow-up queries.

### AI Audience Builder (`aiAudienceService.ts`)
Natural language → SQL → member list → save as audience. "Foundation members who haven't attended an event in 6 months" becomes a reusable audience.

### AI Email Composer (`aiEmailService.ts`)
Describe the email you want → get a formatted draft with merge fields. Includes the Mainstreet Briefing (institutional knowledge about the organization's voice, values, and programs) to prevent hallucination and ensure brand-consistent content.

### Anti-Hallucination Rules
- AI NEVER invents event names, dates, or locations. It queries real upcoming events from the database and only references those.
- AI NEVER mentions dues amounts or membership costs unless specifically asked.
- AI NEVER fabricates member data. Preview systems show real recipients, not fake/sample data.
- SQL queries are validated against an allowedTables whitelist before execution.

### AI Response Design Philosophy: Curious, Not Just Correct

MemberSync's AI should feel like a collaborative analyst — not a query engine. The difference is Julius.AI's approach: it doesn't just answer the question asked, it notices what's interesting in the data, asks intelligent clarifying questions, and suggests ways to combine datasets that might produce a more useful or accurate answer. Its tone is pleasant, supportive, and a touch enthusiastic. That is the standard we are building toward.

**Every AI Chat response should:**
- Answer the question directly and clearly
- Notice what is surprising or significant in the data — not just return rows
- Suggest one natural follow-up question the user should consider
- Proactively identify when combining this data with another available dataset would make the answer more useful or accurate
- Explain what the data means in plain language, not just what it says

**Example of the difference:**

*Query engine response:* "47 members in Naperville have a license expiring in 90 days."

*Collaborative analyst response:* "47 members in Naperville have a license expiring before April 30 — that's actually higher than the same period last year (32 members). Worth noting: 31 of them have zero CE hours logged so far this cycle, which means they're cutting it close. Want me to find which upcoming classes have open seats that would satisfy their Core requirement?"

The second response uses the same data but leaves the user feeling like someone smart is thinking alongside them. This is the standard. The AI prompt in `aiQueryService.ts` must be written to produce this behavior consistently.

**Architectural note:** This behavior is driven entirely by the system prompt in `aiQueryService.ts` — not by model capability. Claude can do this today. It just needs to be instructed to.

### `sharedDatabaseSchema.ts` — The AI's Knowledge Base (And Its Biggest Problem)

This file is a ~37,000 character text document injected into every AI prompt across all three AI services (Chat, Audience Builder, Email Composer). It describes every table, every column, and how to query across them. It is how the AI knows what data exists and how to write correct SQL.

**Why it exists:** Without this context, the AI makes up table names and column names. With it, queries are accurate and joins are correct.

**Why it's a problem at current size:** At 37,000 characters, it consumes a significant portion of the context window on every single AI call — even simple ones. A user asking "how many members joined this month?" doesn't need the AI to know the full schema for compliance tables, event registration, or email analytics. But it gets all of it anyway. This increases cost, increases latency, and pushes the AI's attention toward irrelevant schema details.

**The solution: modular schema injection.** Instead of one monolithic document, maintain a set of focused schema modules:

| Module | Contents | Used By |
|---|---|---|
| `schema_members.ts` | member_metrics_cache, apmmember, apmmemberassociation | AI Chat (member queries), Audience Builder |
| `schema_transactions.ts` | apmproperty, volume calculations, MemberKey join pattern | AI Chat (production queries), Audience Builder |
| `schema_education.ts` | apmmembereducation, apmevent, activity_cache | AI Chat (CE queries), Compliance |
| `schema_email.ts` | email_campaigns, email_recipients, email_events | AI Chat (campaign analytics) |
| `schema_compliance.ts` | apmmemberdues, license status, COE tracking | Compliance module only |
| `schema_offices.ts` | apmoffice, office caches, broker resolution | AI Chat (office queries) |

Each AI service call loads only the schema modules relevant to its query type. A member engagement query loads `schema_members` + `schema_transactions`. A compliance query loads `schema_compliance` + `schema_members`. The email composer doesn't need transaction schema at all.

**Expected benefit:** 60–75% reduction in tokens per AI call for most query types. Faster responses, lower cost, and better AI focus on the relevant data.

**This is a Track 2 (production port) task** — the prototype continues using the monolithic file. But when porting `aiQueryService.ts`, `aiAudienceService.ts`, and `aiEmailService.ts`, split the schema file as part of that work. Do not port the monolith as-is.

---

## Compliance Configuration

Compliance tracking is different for associations and MLSs, but both have unique requirements. MemberSync will help clients alert their members and customers to compliance issues.

**MLSs** have compliance requirements around data accuracy, listing timeliness, and participant behavior standards. MLSs never enforce CE requirements, Code of Ethics, Fair Housing, or NAR designations — those are all local association obligations. When onboarding an MLS client, the compliance module should always be tailored to MLS-specific compliance issues (listing accuracy, submission deadlines, cooperation violations, NAR Settlement-related requirements).

**Associations** have two compliance domains: licensure/education and practice standards/Code of Ethics. Education requirements and license rules vary by state and must be parameterized per client. They are currently hardcoded for Illinois. NAR's Code of Ethics and Fair Housing requirements operate on a three-year national cycle but are administered by local associations, which may have their own timelines and procedures.

**The most important architectural principle:** Every state has different CE requirements for licensure and different course and class types. While NAR operates on a synchronized national triennial schedule, local associations administer their programs differently. This is why compliance must be configuration, not code.

### Illinois Rules (Current Client: Mainstreet)
- **Continuing Education:** 12 hours every 2 years (biennial, even years). Next deadline: April 30, 2026. Includes 6-hour Core course + 1 hour Sexual Harassment Prevention + 5 hours electives.
- **Code of Ethics:** Every 3 years via NAR. Current cycle: Jan 1, 2025 – Dec 31, 2027. 2.5+ hours required.
- **Illinois licensing quirk:** Every real estate professional holds a "broker" license. There is no separate "agent" license. The distinction is between an individual broker and a Designated Managing Broker (DMB).

### New York Rules (Needed for HGAR + GRAR)
Different CE requirements, different cycle dates, different course types. Must be added to tenant config before HGAR onboards.

> **Note:** Detailed compliance rules, fine structures, and enforcement workflows for both associations and MLSs are documented in `MemberSync_Compliance_Reference.md`. That document covers Code of Ethics violation tiers, MLS listing accuracy fines, NAR Settlement-related violations (post-August 2024), and non-fine enforcement actions. The CLAUDE.md compliance section covers architectural principles only — refer to the reference document when building compliance-specific features.

---

## Known Architectural Issues (Why We're Porting)

### Critical (Block Multi-Tenant)
1. **No multi-tenant data isolation** — Only the `users` table has a `client_id` column. Every other table needs one, and every query needs to filter by it.
2. **110+ hardcoded "MainStreet" references** — Spread across routes.ts (~30), storage.ts (~12), aiQueryService.ts (~33), aiEmailService.ts (~9), emailService.ts (~4), and others.
3. **Illinois-specific compliance hardcoded** — CE requirements, course types, cycle dates are all Illinois-specific with no configuration mechanism.
4. **Hardcoded email branding** — Mainstreet logo, colors, and sign-off text baked into email templates.

### Important (Fix Soon)
5. **Monolithic routes.ts** — 7,400+ lines, 110+ endpoints in one file.
6. **MemberKey / MRD prefix inconsistency** — Some code assumes the prefix, some doesn't.
7. **No database migration system** — Schema changes are manual. Production requires versioned migrations.
8. **Monolithic AI schema document** — 37K characters loaded into every AI prompt regardless of query type.

---

## Multi-Tenant Migration Plan

### Stage 0: Client Intake Configuration (Design Now)

Before any technical migration, the `tenant_config` table needs a "What do you care about?" section that captures the organization's type and which modules apply.

| Field | Purpose | Example Values |
|---|---|---|
| `org_type` | Association or MLS | `association`, `mls`, `association_and_mls` |
| `tracks_ce` | CE compliance? | `true` for associations, `false` for MLSs |
| `tracks_coe` | Code of Ethics tracking? | `true` for associations, `false` for MLSs |
| `tracks_designations` | NAR designations relevant? | `true` for associations, `false` for MLSs |
| `tracks_fair_housing` | Fair Housing compliance? | `true` for associations, `false` for MLSs |
| `has_education_program` | Does this org offer classes/events? | `true` for most associations |
| `compliance_state` | Which state's rules apply? | `Illinois`, `New York`, `California`, `null` for MLSs |
| `mls_id_prefix` | MLS key prefix (if any) | `MRD`, `CRMLS`, `null` |
| `billing_model` | How members are billed | `dues`, `subscription`, `hybrid` |
| `has_member_portal` | Membio member portal active? | Enables Portal Channels module |
| `has_website` | Membio enterprise website active? | Enables Education & Events module |
| `has_affiliates` | Affiliate membership program? | Enables Affiliates module |
| `product_tier` | Core, Plus, or Premium | Controls module availability |

### Stage 1: Database-Driven Tenant Config (Required for HGAR)
- Promote `clientConfig.ts` to a `tenant_config` database table keyed by `client_id`
- Add `client_id` to every application table
- Filter every query by `client_id`
- Separate SendGrid sender identities per client
- Client-specific branding loaded from config
- Per-client AI prompt context

### Stage 2: Admin-Assisted Provisioning (Target for CRMLS)
- Membio Super-Admin panel (see above)
- Automated cache table creation and initial data sync
- Template library for new clients
- Per-client usage monitoring and alerting

### Stage 3: Self-Service Onboarding (Growth Target)
- Public signup flow with payment processing
- Guided onboarding wizard
- Automated data connectors for supported AMS platforms

**Rule:** Every feature built today must be evaluated through the lens of "will this work when Client 4 shows up?"

---

## Client Pipeline

| Client | Members | Status | Special Requirements |
|---|---|---|---|
| Mainstreet REALTORS® | 18,275 | Demo/first to launch | Production platform needed |
| HGAR | 12,800 | Onboarding | Multi-tenant, NY compliance |
| GRAR | 3,400 | Third pilot | Multi-tenant, NY compliance |
| CRMLS | 103,000+ | CMO interested | SOC 2, enterprise SLA, batch email at scale |

---

## Production Port: Module Order

1. **Authentication + Users** — JWT auth, role-based access, user management
2. **Data Layer (Caches)** — member_metrics_cache, office caches, activity cache, daily snapshots
3. **Dashboard + Member/Office Profiles** — The read-heavy core of the app
4. **SmartSends** — Email campaigns, composer, templates, drafts, image library
5. **Audiences** — AI builder, picklist, member/bill type, CSV upload
6. **AI Chat** — Query service, saved chats, insights
7. **Analytics** — Overview, office leaderboards, agent rankings, visit briefs
8. **Automations** — Triggered campaigns, drip sequences, A/B testing
9. **Celebrations** — Milestone detection, recognition emails

---

## Standing Rules

1. **`member_metrics_cache` is the single source of truth** for member data displayed in the UI. Never compute metrics on the fly that the cache already provides.
2. **Every query against external AMS/MLS tables must deduplicate** using the DISTINCT ON / ROW_NUMBER pattern.
3. **Every query against external tables must filter by ApmClientId.**
4. **Never SUM(ClosePrice) across listing + buyer sides** without applying the volume split.
5. **All client-specific values go in `clientConfig.ts`** (or tenant_config table). No hardcoded client references anywhere else.
6. **Every feature must work for multiple clients** through configuration, not custom code.
7. **Real data only.** Preview systems, demo screens, and test flows show real member data. No fake/sample data.
8. **No manual schema changes in production.** All changes go through versioned database migrations.
9. **Cache-first architecture.** If a value can be pre-computed daily, it should be.
10. **One task at a time.** Don't combine unrelated changes. Each PR/commit should be focused and testable.
11. **Voluntary contributions (RPAC, REF) are excluded from risk scoring entirely.**
12. **Non-CE event attendance is a stronger engagement signal than CE attendance** — members who attend voluntary classes demonstrate genuine engagement.
13. **Office suspension is the gatekeeper** for Mainstreet Advantage fees — when an office goes inactive, all agents lose MLS/SentriLock access regardless of individual payment status.
14. **Every module must be gated by tenant_config.** A disabled module should not render in the UI, should not run background jobs, and should not consume AI budget.
15. **The 5% rule.** Every screen must earn its place. We build what clients asked for or dreamed about — not features that sound good in a roadmap.
16. **Mobile-first, performance-always.** Every UI component must be responsive and usable on mobile devices. Every data view must load in under 2 seconds. Cache-first architecture exists partly for this reason — never make a user wait for a calculation that could have been pre-computed.

---

## Environment Variables

```
# Database
DATABASE_URL=             # Local application database (Drizzle)
DB_HOST=                  # External production database
DB_NAME=
DB_USER=
DB_PASSWORD=
DB_PORT=

# Auth
JWT_SECRET=               # Required in production
SESSION_SECRET=

# AI
ANTHROPIC_API_KEY=        # Single key for all clients — never expose to clients

# Email
SENDGRID_API_KEY=
EMAIL_SANDBOX_MODE=true   # MUST be true until production launch
EMAIL_TEST_RECIPIENTS=    # Comma-separated allowed addresses in sandbox mode
MAX_CAMPAIGN_RECIPIENTS=  # Safety cap (set to 1 during testing)

# Replit-specific (will change for AWS)
REPL_ID=
REPLIT_DB_URL=
```

---

## Companion Documents

- **MemberSync Parking Lot** (`MemberSync_ParkingLot.md`) — Strategic ideas backlog
- **MemberSync Compliance Reference** (`MemberSync_Compliance_Reference.md`) — Detailed compliance rules, fine structures, and enforcement workflows for associations and MLSs. Read this before building any compliance feature.
- **MemberSync Development Plan** — Two-track model, team roles, port timeline
- **Membio AI Workflow Playbook** — How each team member should use Claude/Claude Code
- **MemberSync Project Summary (latest)** — Session-by-session development history

---

## What's Coming (Build With These in Mind)

### Lapse Prevention System
Members don't lapse overnight. They drift for months. MemberSync will track this trajectory and intervene before it's too late.

**Architectural implication:** The `member_metrics_cache` will need historical scoring (trend over time, not just today's score). The `membership_daily_snapshot` table is the first step.

### Broker Module
Office payment health, agent roster visibility, suspension impact analysis. Brokers have legal liability for their agents in Illinois.

**Architectural implication:** Keep `brokerResolutionService.ts` clean and well-tested. Email functionality for broker alerts stays in SmartSends, not in the broker module.

### AI Chart Rendering
The AI Chat currently returns tables and text. Enterprise clients expect charts. The AI will detect when results should be visualized and render Recharts components inline.

**Architectural implication:** AI query service response format needs a `visualization` field alongside `data` and `insights`.

### Additional Data Source Integration
Support tickets (ZenDesk from HGAR), lockbox access logs, benefits usage, Google Analytics. The query engine should support pluggable data sources.

**Architectural implication:** `sharedDatabaseSchema.ts` should be modular — load only relevant schema sections per query type.

### Lapse Pattern Analysis
Analyze the 24-month journey before members historically lapsed. "Members showing X pattern have an 80% chance of lapsing within 6 months."

**Architectural implication:** Don't purge old data aggressively — daily snapshots, score history, and email engagement data are the future training set.

### A/B Testing for Campaigns
Test subject lines, body content, and send times with automatic winner selection.

**Architectural implication:** The `triggered_campaign_steps` table already supports variants. Build email metrics tracking to be variant-aware from the start.

### Portal Channels (Module)
When a client has a Membio Member Portal, SmartSends gains two additional channel types: Banner (portal notification) and Recommendation (portal card with image + URL). These push to the member portal rather than sending email. Enabled via `has_member_portal` in tenant config.

### Education & Events (Module)
When a client has a Membio enterprise website or member portal, MemberSync gains awareness of the full education and events catalog — classes, courses, instructors, CE credits. The Proactive Engagement Engine can then surface opportunities like "this agent has 0 CE hours with renewal 60 days away, and this class is coming up." Enabled via `has_website` or `has_member_portal` in tenant config.

### Affiliates (Module)
Affiliate members (aligned businesses seeking access to REALTOR® members) are chronically underserved by associations. MemberSync's Affiliates module will track affiliate engagement with agents, surface introduction opportunities, and help affiliates demonstrate ROI from their membership. Enabled via `has_affiliates` in tenant config.

---

*Last updated: March 4, 2026. This document should be updated whenever architectural decisions change, new tables are added, or standing rules are established.*

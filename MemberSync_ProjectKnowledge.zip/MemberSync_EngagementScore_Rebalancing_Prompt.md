# Engagement Score Rebalancing â€” Replit Prompt

## The Problem (Two Parts)

### Part A: Tier Definitions Are Too Generous

The current tier thresholds classify 8,443 members (46%) as Rainmakers using a low bar of just 2+ transactions in 12 months. In reality, an agent who closed 2 deals has almost nothing in common with one who closed 90. Real production data from Mainstreet shows:

- Top 1% (183 agents): avg 91 sides/year
- Top 5% (914 agents): avg 41 sides/year
- Top 25% (4,569 agents): avg 16 sides/year

The correct thresholds, based on actual production analysis:

| Tier | Old Definition | New Definition | Count | % of Membership |
|------|---------------|----------------|-------|----------------|
| **Rainmaker** | 2+ tx in 12 months | **40+ sides in 12 months** | ~247 | ~1.4% |
| **Builder** | 1+ tx in 24 months | **6-39 sides in 12 months** | ~3,885 | ~21% |
| **Foundation** | 0 tx in 24 months | **0-5 sides in 12 months** | ~14,144 | ~77% |

This gives us the "75% story" we've been building toward â€” Foundation IS the majority, exactly as the product philosophy describes.

**Note:** The old definition used a 24-month lookback for Builder. The new definition uses 12 months for all tiers. This is intentional â€” it reflects current engagement state. An agent who was active last year but has done nothing this year is Foundation now, not Builder. The tier should reflect where they are, not where they were.

### Part B: Scoring Formula Is Too Generous

After deploying the initial engagement score redesign, the dashboard shows 97% of members as Connected or Highly Connected. The scoring formula gives too much credit for payment (which is the default state) and not enough weight to active engagement signals like education, events, and email interaction.

---

## FIX 1: Update Tier Assignment Thresholds

In `memberMetricsCacheService.ts`, find the tier assignment block (around line 240-242). Replace:

```typescript
// OLD â€” too generous
let tier = 'license_maintainer';
if (tx.tx12mo >= 2) tier = 'active_producer';
else if (tx.tx24mo >= 1) tier = 'occasional_producer';
```

With:

```typescript
// NEW â€” based on actual production analysis
// Rainmaker: 40+ sides in 12 months (top ~1.4%, the real producers)
// Builder: 6-39 sides in 12 months (working agents, ~21%)
// Foundation: 0-5 sides in 12 months (the 77% financial bedrock)
let tier = 'license_maintainer';
if (tx.tx12mo >= 40) tier = 'active_producer';
else if (tx.tx12mo >= 6) tier = 'occasional_producer';
```

**Note on how sides are counted:** The `tx12mo` field in the cache already counts transaction sides â€” each agent gets credit for being on either the listing or buyer side of a closed transaction. This matches how the thresholds were derived. No change needed to the transaction query itself, only to the tier threshold values that evaluate it.

**Also update the `tx24mo` dependency:** The old Builder tier used `tx.tx24mo >= 1`. The new definition doesn't need the 24-month lookback for tier assignment. The `tx24mo` field can stay in the cache (it's useful for other analysis), but tier assignment now only uses `tx12mo`.

## The Fix: Rebalance Scoring Weights

The principle: **Connected should mean the member is actively doing something to stay engaged.** Simply paying dues and having transactions is the baseline expectation, not engagement. Engagement means education, events, email interaction, or recent non-transaction activity.

### Updated Rainmaker Scoring (in `memberMetricsCacheService.ts`)

Replace the `active_producer` scoring block:

```typescript
if (tier === 'active_producer') {
  // ===== RAINMAKER SCORING (40+ sides in 12 months) =====
  // These agents are elite producers. Transactions are their baseline.
  // Score differentiates on engagement BEYOND production.
  
  // Transaction volume: 0-2 points (tiered within the elite)
  if (tx.tx12mo >= 80) score += 2;   // Superstar
  else if (tx.tx12mo >= 60) score += 1; // Strong
  // 40-59 transactions = 0 bonus â€” that's the entry level for Rainmaker
  
  // Education/Events: 0-3 points (THIS differentiates engaged Rainmakers)
  const eduEvents = activity.educationCount12mo + activity.eventsAttended12mo;
  if (eduEvents >= 3) score += 3;
  else if (eduEvents >= 2) score += 2;
  else if (eduEvents >= 1) score += 1;
  
  // Payment: 0-1 point (binary â€” overdue or not)
  if (pay.overdueCount === 0) score += 1;
  
  // Email engagement: 0-2 points (are they reading what you send?)
  if (emailEngagement.hasClicked) score += 2;
  else if (emailEngagement.hasOpened) score += 1;
  
  // Recency of NON-TRANSACTION activity: 0-1 point
  // Transaction recency doesn't count â€” we want to know if they engage BEYOND producing
  if (activity.activityCount90d > 0) score += 1;
  
  // Designation/Leadership: 0-1 point
  if (hasDesignations) score += 1;
}
```

**What this changes:** A Rainmaker who produces heavily but never takes a class, never opens an email, and has no recent non-transaction activity scores 2-3 (Drifting). A Rainmaker who produces AND takes classes AND opens emails scores 8-10 (Highly Connected). This correctly identifies the Rainmakers who are connected to the organization vs. those who just use the MLS.

### Updated Builder Scoring

Replace the `occasional_producer` scoring block:

```typescript
else if (tier === 'occasional_producer') {
  // ===== BUILDER SCORING (6-39 sides in 12 months) =====
  // Working agents at various activity levels. Growth + engagement matter.
  
  // Transaction volume within tier: 0-2 points
  if (tx.tx12mo >= 20) score += 2;   // Strong Builder, approaching Rainmaker territory
  else if (tx.tx12mo >= 12) score += 1; // Solid production
  // 6-11 transactions = 0 bonus â€” entry level for Builder
  
  // Education/Events: 0-3 points (this is how Builders stay connected)
  const eduEvents = activity.educationCount12mo + activity.eventsAttended12mo;
  if (eduEvents >= 4) score += 3;
  else if (eduEvents >= 2) score += 2;
  else if (eduEvents >= 1) score += 1;
  
  // Payment: 0-1 point (binary)
  if (pay.overdueCount === 0) score += 1;
  
  // Email engagement: 0-2 points
  if (emailEngagement.hasClicked) score += 2;
  else if (emailEngagement.hasOpened) score += 1;
  
  // Recency of any activity: 0-1 point
  if (activity.activityCount90d > 0) score += 1;
  
  // Designation/Leadership: 0-1 point
  if (hasDesignations) score += 1;
}
```

**What this changes:** A Builder who had one transaction 20 months ago, never takes classes, never opens emails, and has no recent activity scores 1 (Disconnected). A Builder with a recent transaction, 2 classes, email opens, and a designation scores 8+ (Highly Connected).

### Updated Foundation Scoring

Replace the `license_maintainer` scoring block:

```typescript
else {
  // ===== FOUNDATION SCORING (0 transactions in 24 months) =====
  // For Foundation members, ACTIVE engagement is what matters.
  // Paying dues is the baseline, not a signal of connection.
  
  // Education/Events: 0-4 points (this IS their engagement)
  const eduCount = activity.educationCount12mo;
  const eventCount = activity.eventsAttended12mo;
  const totalEduEvents = eduCount + eventCount;
  
  if (totalEduEvents >= 4) score += 4;
  else if (totalEduEvents >= 2) score += 3;
  else if (totalEduEvents >= 1) score += 2;
  // No activity = 0 points â€” being passive is the problem we're detecting
  
  // Payment behavior: 0-1 point (binary â€” it's expected, not a strong signal)
  if (pay.overdueCount === 0) score += 1;
  
  // Email engagement: 0-3 points (critical for Foundation â€” email may be their only touchpoint)
  if (emailEngagement.hasClicked) score += 3;
  else if (emailEngagement.hasOpened) score += 2;
  // No email engagement = 0 â€” this is a major disconnection signal
  
  // Recency of any activity: 0-1 point
  if (activity.activityCount90d > 0) score += 1;
  
  // Designation/Leadership: 0-1 point
  if (hasDesignations) score += 1;
}
```

**What this changes:** A Foundation member with no activities, no email engagement, no overdue invoices scores 1 (Disconnected). A Foundation member who takes 2 classes and opens emails scores 7 (Connected). A Foundation member who takes 4+ classes, clicks email links, and has a designation scores 10 (Highly Connected). Payment alone gets you to score 1 â€” still Disconnected, because paying a bill is not engagement.

### Summary of Weight Changes

**Rainmaker (max 10):**
| Category | Old Weight | New Weight | Why |
|----------|-----------|-----------|-----|
| Transactions | 0-3 | 0-2 | 40+ is the baseline; 80+ gets extra credit |
| Education/Events | 0-2 | 0-3 | This is what separates engaged from passive Rainmakers |
| Payment | 0-2 | 0-1 | Binary â€” overdue invoices are a problem, but no overdue is the default |
| Email | 0-1 | 0-2 | Split open vs. click â€” clicking shows deeper engagement |
| Recency | 0-1 | 0-1 | Only counts non-transaction activity now |
| Designation | 0-1 | 0-1 | Unchanged |

**Builder (max 10):**
| Category | Old Weight | New Weight | Why |
|----------|-----------|-----------|-----|
| Transaction volume | 0-2 | 0-2 | Within-tier differentiation (20+ vs 12+ vs entry) |
| Education/Events | 0-3 | 0-3 | Unchanged â€” this is how Builders connect |
| Payment | 0-2 | 0-1 | Binary |
| Email | 0-1 | 0-2 | Split open vs. click |
| Recency | 0-1 | 0-1 | Any non-transaction activity in 90 days |
| Designation | 0-1 | 0-1 | Unchanged |

**Foundation (max 10):**
| Category | Old Weight | New Weight | Why |
|----------|-----------|-----------|-----|
| Education/Events | 0-4 | 0-4 | Unchanged â€” this IS their engagement |
| Payment | 0-3 | 0-1 | Major reduction â€” paying a bill is not a connection signal |
| Email | 0-1 | 0-3 | Major increase â€” email may be Foundation's only touchpoint |
| Recency | 0-1 | 0-1 | Unchanged |
| Designation | 0-1 | 0-1 | Unchanged |

### Expected Distribution After Rebalancing

With the new tier thresholds AND scoring weights:

**Rainmakers (~247 members, 1.4%):**
- These are elite producers. Most who ONLY produce will score 1-3 (Disconnected/Drifting)
- Rainmakers who produce AND attend classes/events AND open emails will score 7-10 (Connected/Highly Connected)
- Expected: ~20-30% Connected+, ~30-40% Drifting, ~30-40% Disconnected
- This is the wake-up call for the board: your top producers use the association as a utility, not a community

**Builders (~3,885 members, 21%):**
- Active agents with varying levels of engagement beyond production
- Builders with strong production (20+) + education + email opens â†’ 7-10 (Connected/Highly Connected)
- Builders with entry-level production (6-11) and nothing else â†’ 1-2 (Disconnected)
- Expected: ~25-35% Connected+, ~30% Drifting, ~35-40% Disconnected

**Foundation (~14,144 members, 77%):**
- The largest group. Most will score low until email campaign data accumulates.
- Foundation with education + email clicks â†’ 7+ (Connected)
- Foundation with nothing but paid invoices â†’ 1 (Disconnected)
- Expected: ~55-65% Disconnected, ~15-20% Drifting, ~15-25% Connected+
- This is where SmartSends proves its value: send campaigns â†’ members open them â†’ scores improve visibly

This is a much more honest picture. It creates urgency to use the product, which IS the product's value proposition.

### Files Modified

Only one file changes:
- `server/services/memberMetricsCacheService.ts` â€” the three scoring blocks inside the member loop

After deploying, trigger a cache refresh (via the admin endpoint or app restart) and verify the dashboard numbers change to show more realistic distribution across Disconnected/Drifting/Connected/Highly Connected.

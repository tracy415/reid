# MemberSync / SmartSends â€” Project Summary
## February 17, 2026

---

## OVERVIEW

Tracy is the founder of Membio, building MemberSync â€” a member engagement and retention platform for real estate associations and MLSs. The platform analyzes MLS listing data and association management system (AMS) data to help association executives understand, engage, and retain their members. The first client is Mainstreet REALTORSÂ® (~18,275 active members, ~2,800 offices, 16 sub-associations, 18 bill types).

Tracy builds exclusively with AI tools: Claude for strategy and specs, Julius.AI for SQL, and Replit Agent for coding. The stack is React + Node.js + PostgreSQL, hosted on Replit with an AWS production database.

---

## WHAT WAS ACCOMPLISHED TODAY (Feb 17, 2026)

### Session 1: Code Audit & Stability (Early AM)

Comprehensive audit of the MemberSync codebase identifying data consistency issues, cache staleness risks, duplicate logic paths, and stability problems.

**Stability & Data Consistency Prompt** (`MemberSync_Stability_DataConsistency_Prompt.md`):
- Atomic cache refresh with staleness detection
- Duplicate logic consolidation (two different `getHealthStatus` functions with different thresholds)
- Dead code removal (mock data generators, debug endpoints)
- Analytics query optimization
- Strategic discussion about when to migrate off Replit to production infrastructure

### Session 2: Engagement Score Redesign (Afternoon)

Created the tier-aware engagement scoring system that replaces the old one-size-fits-all formula.

**Engagement Score Redesign Prompt** (`MemberSync_EngagementScore_Redesign_Prompt.md`):
- Three member tiers: Rainmaker, Builder, Foundation (replacing Active Producer, Occasional Producer, License Maintainer)
- Four engagement labels: Highly Connected (8-10), Connected (5-7), Drifting (3-4), Disconnected (0-2) â€” replacing risk-based language
- Tier-aware scoring where each tier has different weights reflecting what engagement means for that group
- Visual urgency indicators for the UI (green/blue/orange/red)
- Multi-tenant configuration strategy discussion (client_config table for future clients)

### Session 3: Dashboard Redesign + Scoring Rebalance (Evening â€” This Session)

This was the longest and most iterative session. Started with the dashboard redesign, then identified scoring problems from live screenshots, iterated on tier thresholds, and added real revenue data.

#### Scoring Rebalance (Critical Fix)

**Engagement Score Rebalancing Prompt** (`MemberSync_EngagementScore_Rebalancing_Prompt.md`):

The initial engagement score redesign deployed but showed 97% of members as Connected or Highly Connected â€” clearly wrong. Two root causes identified:

**Problem 1: Tier thresholds too generous.** The old definition (2+ transactions in 12 months = Rainmaker) classified 8,443 members (46%) as Rainmakers. Tracy's production analysis from Julius revealed the actual distribution:
- Top 1% (183 agents): avg 91 sides/year
- Top 5% (914 agents): avg 41 sides/year  
- 40.4% of members have zero transaction sides

**New thresholds based on transaction sides (12 months):**

| Tier | Old Definition | New Definition | Count | % |
|------|---------------|----------------|-------|---|
| Rainmaker | 2+ tx in 12mo | **40+ sides in 12mo** | ~247 | ~1.4% |
| Builder | 1+ tx in 24mo | **6-39 sides in 12mo** | ~3,885 | ~21% |
| Foundation | 0 tx in 24mo | **0-5 sides in 12mo** | ~14,144 | ~77% |

Key decision: All tiers now use 12-month lookback only (old Builder used 24 months). This reflects current engagement state, not historical credit.

Key clarification: `tx12mo` counts transaction sides â€” each agent gets credit for being on either the listing or buyer side of a closed transaction. No change needed to the transaction query.

**Problem 2: Payment scoring too generous.** "No overdue invoices" is the default state for most members, not an engagement signal. Under the old formula, payment alone gave 2-3 points, pushing most members past the Connected threshold.

**New scoring weights (all tiers):**

| Category | Rainmaker | Builder | Foundation | Philosophy |
|----------|-----------|---------|------------|-----------|
| Transactions | 0-2 (80+/60+) | 0-2 (20+/12+) | 0 | Expected baseline, not engagement |
| Education/Events | 0-3 | 0-3 | 0-4 | Primary differentiator â€” what the assoc. can influence |
| Email | 0-2 (click/open) | 0-2 | 0-3 | Critical for Foundation â€” may be only touchpoint |
| Payment | 0-1 (binary) | 0-1 | 0-1 | Table stakes â€” paying a bill is not engagement |
| Recency | 0-1 (non-tx only) | 0-1 | 0-1 | Non-transaction activity in last 90 days |
| Designation | 0-1 | 0-1 | 0-1 | Professional investment |

Expected distribution after rebalance:
- Rainmakers: ~20-30% Connected+, ~30-40% Drifting, ~30-40% Disconnected
- Builders: ~25-35% Connected+, ~30% Drifting, ~35-40% Disconnected
- Foundation: ~15-25% Connected+, ~15-20% Drifting, ~55-65% Disconnected

This creates the honest urgency that drives SmartSends usage: "Most of your Foundation members are Disconnected â€” here's how to reach them."

#### Dashboard Redesign

**Dashboard Redesign Prompt** (`MemberSync_Dashboard_Redesign_Prompt.md`):

Reorganizes dashboard into three sections. AI Chat and Celebrations sidebar unchanged.

**Section 1: The Pulse (Four Metric Cards)**

Card 1 â€” **Total Active Members**: Shows ~18,275 with Rainmaker/Builder/Foundation tier breakdown using new thresholds. Tier colors: amber/blue/emerald.

Card 2 â€” **Association Pulse** (replaces "Member Engagement Rate"): The old 74% engagement rate was misleading because it was dominated by transaction counts. New card shows real operational metrics:
- Headline: New members this month (â†‘/â†“ vs. last month)
- Breakdown: Total active members, class registrations + revenue, event registrations + revenue (all this quarter)
- Registration/revenue data comes from real AMS queries against `apmeventregistration` joined to `apmevent`, with spike detection (days with â‰¥ 1,000 registrations excluded as bulk NAR imports)
- Conditional footnote when days are excluded: "1 day excluded due to anomalous volume (â‰¥ 1,000 regs)"
- MetricCard needs new `footnote` prop and breakdown type updated to accept `number | string`

Card 3 â€” **Connection Status**: Shows engagement level distribution (Highly Connected/Connected/Drifting/Disconnected). Drifting and Disconnected are clickable â†’ SmartSends.

Card 4 â€” **Campaign Effectiveness**: Avg open rate, click rate, total reached from campaigns in last 30 days. Graceful "No campaigns yet" state.

**Section 2: Today's Activity Feed** (new component: `ActivityFeed.tsx`)
- News-feed style showing: new members this week (with Welcome action), education completions (with Celebrate action), event attendance (with Follow up action), recent campaign performance (with View action), milestone count
- Every item is actionable â€” buttons link to SmartSends or relevant pages

**Section 3: The Membership Story** (new component: `MembershipStory.tsx`)
- Replaces the old composition bar with three equal-weight tier cards
- Each card has a **color band on top** (amber/blue/emerald) â€” no misleading horizontal bar
- Member count with percentage shown in header: "Rainmaker Â· 247 (1.4%)"
- All three cards show **identical structure**: connected %, volume + market share in highlight box, four engagement signal indicators (Edu, Events, Email, Paid)
- Tier definitions displayed on each card ("40+ transaction sides in last 12 months")
- Rainmaker card includes concentration insight: "Top 914 agents (5%) control 49%"
- Volume/share on all cards creates the punchline: Rainmaker "$25.6B Â· 88%" vs. Foundation "$45M Â· 0.2%"

**Political design insight**: Board members are Rainmakers and Builders who care about their own kind. All three tiers get equal visual weight with tier-appropriate narratives so every board member sees themselves represented.

#### Member Detail Score Labels Fix

**Member Detail Score Labels + Dashboard Consistency Fix** (`MemberDetail_ScoreLabels_and_DashboardConsistency_Fix.md`):

The member detail page showed a 9.0/10 engagement score for a Rainmaker labeled "Disconnected" â€” contradictory because the old scoring formula was still computing the breakdown while the new labels were applied.

Fixes:
- `EngagementScore` interface updated: `transactionActivity` â†’ `transactions`, `license` â†’ `recency`, added `email` and `designation` fields
- `calculateTransactionScore()` becomes tier-aware (needs 80+ for 2 points as Rainmaker)
- Payment becomes binary (0 or 1) in `getMemberDetail()`
- New email engagement query added to member detail route
- Score breakdown display reordered: Education & Events first, Email second, Transactions third â€” puts the levers the executive can pull at the top
- Tooltip updated: shows engagement labels (Highly Connected 8-10, etc.) instead of old tier names
- Dashboard tier cards updated to include `totalVolume` and `volumeSharePct` for all three tiers

#### Daily Membership Snapshot

New infrastructure added to the dashboard prompt:
- `membership_daily_snapshot` table captures daily counts (total active, tier breakdown, connection status distribution)
- Cron job runs at 6:15 AM after cache refresh
- Also takes snapshot on app startup if none exists for today
- Starts collecting data immediately; will power trend sparklines after a few weeks of accumulation

---

## PROMPT DELIVERY ORDER FOR REPLIT

1. **Engagement Score Rebalancing** (`MemberSync_EngagementScore_Rebalancing_Prompt.md`) â€” Send FIRST. Changes tier thresholds and scoring weights in `memberMetricsCacheService.ts`. After deploy, verify: Rainmaker ~247, Builder ~3,885, Foundation ~14,144. Connection percentages should show realistic distribution.

2. **Dashboard Redesign** (`MemberSync_Dashboard_Redesign_Prompt.md`) â€” Send SECOND, after rebalancing is verified. New layout, Association Pulse card with real revenue data, Membership Story with color-banded cards, Activity Feed, daily snapshot table.

3. **Member Detail Score Labels + Dashboard Consistency** (`MemberDetail_ScoreLabels_and_DashboardConsistency_Fix.md`) â€” Send THIRD or alongside #2. Updates score breakdown labels, adds volume/share to all tier cards.

Note: The original **Engagement Score Redesign** prompt (`MemberSync_EngagementScore_Redesign_Prompt.md`) was already sent to Replit and deployed. The Rebalancing prompt builds on top of it.

---

## KNOWN ISSUES STILL OPEN

### The 172-Member Gap
- Dashboard shows 18,259 active members; Member Type Builder shows 18,087
- Difference = members active in `apmmember` but with no record in `apmmemberassociation` for AssociationId = 'MainStreet'
- Lower priority â€” cosmetic, not a data integrity issue

### AI Query Service
- AI sometimes generates SQL with wrong column names or join patterns
- Needs more example queries for events/registrations in the system prompt
- Conversation history fix was sent to Replit and is in progress

### Cache Health Monitoring
- Cron jobs can fail silently on Replit instance sleep/restart
- Need `cache_refresh_log` table, admin card showing last refresh, manual "Refresh Now" button
- The daily snapshot table partially addresses this â€” its presence confirms the cron system is running

### Email Engagement Data Cold Start
- Minimal email engagement data exists right now (0% email open rate)
- Foundation members will score very low until campaigns start flowing through SmartSends
- This is by design â€” creates a virtuous cycle where sending campaigns improves scores visibly
- As email data accumulates, the scoring formula's email components (worth up to 3 points for Foundation) will differentiate engaged vs. passive members

### Revenue Data as Proxy
- The Association Pulse card uses `MemberPrice`/`Price` from the event catalog as revenue estimates
- Actual invoiced amounts may differ (discounts, early bird pricing, comps)
- Tracy explored using `apmmemberinvoicedetails` for real invoice amounts but charge code patterns for education/event charges are not yet mapped
- Future enhancement: identify charge codes for class/event registrations to pull actual invoiced revenue

---

## WHAT TO BUILD NEXT (Updated Priority Order)

1. **Deploy Scoring Rebalance** â€” Send prompt to Replit, verify tier counts and connection distribution
2. **Deploy Dashboard Redesign** â€” Send prompt after rebalancing verified
3. **Deploy Member Detail Fix** â€” Score breakdown labels and dashboard consistency
4. **Expanded Celebrations** â€” More frequent personal milestones, member headshots
5. **Lapse Prevention Module** â€” Phase 3 spec exists (`SmartSends_Phase3_Complete.md`)
6. **Triggered Campaign Engine** â€” Automated email sequences (`SmartSends_TriggeredCampaigns.md`)
7. **Production Analytics Refinement** â€” Validate concentration numbers, add visual charts
8. **Trend Sparklines** â€” After daily snapshot table has 2-4 weeks of data, add membership trend visualization to Total Active Members card
9. **Education/Event Revenue from Invoices** â€” Map charge codes to pull actual invoiced revenue instead of catalog prices

---

## KEY ARCHITECTURAL DECISIONS

- `member_metrics_cache` is the single source of truth for active member status
- `apmmember.MemberStatus = 'Active'` is the canonical definition of an active member
- Two-step query pattern for cross-database operations (external DB for keys â†’ local cache for enrichment)
- `DISTINCT ON ("ApmClientId", "MemberKey") ORDER BY "ApmSourceModificationTimestamp" DESC` for all AMS table queries (snapshot deduplication)
- Tier assignment uses transaction SIDES (not unique properties) in 12-month window only
- Payment is table stakes (1 point max) â€” not a primary engagement signal
- Education, events, and email are the primary engagement differentiators across all tiers
- Spike detection at â‰¥ 1,000 daily registrations filters bulk NAR imports from real registration data
- Daily membership snapshots accumulate silently for future trending
- `externalPool` for cross-database queries to AMS/MLS data; `db` for local cache queries

---

## KEY FILES

### Prompts Ready for Replit (in delivery order)
- `MemberSync_EngagementScore_Rebalancing_Prompt.md` â€” Tier thresholds + scoring weights (SEND FIRST)
- `MemberSync_Dashboard_Redesign_Prompt.md` â€” Full dashboard redesign with Association Pulse, Membership Story, Activity Feed, snapshot table (SEND SECOND)
- `MemberDetail_ScoreLabels_and_DashboardConsistency_Fix.md` â€” Score breakdown labels + volume/share on tier cards (SEND THIRD)

### Previously Sent Prompts (already with Replit)
- `MemberSync_EngagementScore_Redesign_Prompt.md` â€” Original tier-aware scoring (deployed, being refined by rebalancing)
- `MemberSync_Stability_DataConsistency_Prompt.md` â€” Atomic cache refresh, staleness detection, dead code removal
- `CodeCleanup_DeadCode_and_Fixes.md` â€” Mock data removal, duplicate logic consolidation
- `AIChat_ContextAndFallback_Fix.md` â€” Conversation history for AI chat follow-ups

### Product Strategy Documents
- `MemberSync_Product_Philosophy_Dashboard.md` â€” The 75% problem, product principles, tier philosophy
- `MemberSync_Dashboard_Redesign_Prompt.md` â€” Also serves as the dashboard specification

### Backend Services
- `storage.ts` â€” Main data layer, dashboard metrics, member/office queries
- `memberMetricsCacheService.ts` â€” Daily cache refresh with engagement scoring (CHANGES IN REBALANCING)
- `aiQueryService.ts` â€” AI SQL generation, query execution, insights
- `aiAudienceService.ts` â€” Audience CRUD, smart audience execution, enrichment, CSV export
- `aiEmailService.ts` â€” AI email composition
- `emailService.ts` â€” Email sending, queue processing, campaign management
- `milestoneDetectionService.ts` â€” Celebration/milestone detection
- `sharedDatabaseSchema.ts` â€” Database schema documentation shared across AI services
- `anthropic.ts` â€” Fallback conversational AI provider

### Frontend Components
- `Dashboard.tsx` â€” Main dashboard (MAJOR CHANGES IN REDESIGN)
- `SmartSends.tsx` â€” SmartSends dashboard
- `AudienceBuilder.tsx` â€” AI audience builder
- `MemberBillTypeBuilder.tsx` â€” Member/Bill Type audience builder
- `PicklistBuilder.tsx` â€” Manual member picklist builder
- `SendEmail.tsx` â€” Email composition and sending flow
- `AIChatBox.tsx` â€” AI chat interface
- `AnalyticsOverview.tsx` â€” Production analytics dashboard
- `CelebrationInsights.tsx` â€” Milestone celebrations widget
- `MetricCard.tsx` â€” Shared metric card component (NEEDS footnote prop, string breakdown support)

### New Components (Created by Dashboard Redesign)
- `client/src/components/dashboard/ActivityFeed.tsx` â€” Today's Activity news feed
- `client/src/components/dashboard/MembershipStory.tsx` â€” Three-tier membership story with color-banded cards

### New Tables (Created by Dashboard Redesign)
- `membership_daily_snapshot` â€” Daily membership count snapshots for trending

---

## PRODUCTION DATA REFERENCE

From Tracy's Julius analysis of Mainstreet production data:
- Total active agents: 18,275
- Producing agents: 10,895 (59.6%)
- Non-producing: 7,380 (40.4% with zero sides)
- Top 1% (183 agents): 23.1% of volume, avg 91 sides
- Top 5% (914 agents): 48.7% of volume, avg 41 sides
- Top 25% (4,569 agents): 87.6% of volume, avg 16 sides
- Rainmaker threshold (40+ sides): 247 agents (1.4%)
- Builder range (6-39 sides): 3,885 agents (21%)
- Foundation (0-5 sides): 14,144 agents (77%)

This data drove the tier threshold decisions and is computed from `member_metrics_cache` (fast, local) rather than external database queries.

### AI Chat Known Quality Issues — Fix in Production Port

The following issues were identified in the Replit prototype as of March 2026. They represent a mix of a confirmed data bug and structural AI behavior problems. All are documented here for the production port team.

---

#### Issue 1: AI Memory Entries Not Reaching the AI

**Symptom:** Staff saves entries in the "What the AI Remembers" panel (e.g., competitor names, market territory notes). The AI then ignores those entries entirely when answering questions about those topics.

**Root cause (confirmed by code review):** The memory injection code in `aiQueryService.ts` is correct — `generateSql()` queries `tenant_config` for both `ai_business_context` and `ai_memory` at lines 1048–1061 and injects both into the system prompt. The bug is almost certainly upstream: the `ai_memory` column in `tenant_config` is likely null or empty at query time, meaning the memory entries visible in the UI are not being persisted to the database correctly.

**Where to investigate:**
- `POST /api/chats/settings/memory` (routes.ts ~line 4338) — the endpoint that saves memory entries. Confirm it is writing to `tenant_config.ai_memory` and that the write is committed before the next query.
- Confirm that the `client_id = 1` hardcode in the memory fetch (aiQueryService.ts line 1049) matches the `client_id` used in the memory write route. A mismatch would cause a silent read/write split.
- Add a console log in `generateSql()` to print `memoryContext.aiMemory?.length ?? 0` so the next test can confirm whether the value is arriving.

**Do not fix in Replit prototype.** Diagnose and fix during the production port.

---

#### Issue 2: AI Uses General Knowledge to Fill Gaps in Org Context

**Symptom:** When staff asks about competitors, territory, or organizational facts that aren't explicitly stored in AI Memory, the AI invents plausible-sounding answers rather than stopping. Example: asked "Who are our competitors?", the AI invented association names that don't exist.

**Current behavior:** The system prompt contains a hard-stop rule instructing the AI to respond with "I don't have that information on file yet. You can add it under Chats → AI Memory." when the answer is not in the injected context. This rule is present but partially ineffective — the AI complies sometimes and supplements with general knowledge other times.

**Root cause:** This is an inherent LLM behavior. The hard-stop rule needs to be reinforced more aggressively. In practice, this issue compounds Issue 1: if AI Memory entries aren't reaching the AI, the context block is empty, and the AI has nothing to fall back on — making hallucination inevitable.

**Fix for production port:**
- Resolve Issue 1 first. If AI Memory is injected correctly, the hard-stop rule works much better.
- Strengthen the hard-stop instruction: move it earlier in the system prompt (before the SQL instructions, not after), and add an explicit negative example showing the wrong behavior and the correct response.
- Consider a post-processing check: if the response includes named organizations that aren't in the injected context, flag or suppress the response.

---

#### Issue 3: Internal Database Labels Leaking Into Responses

**Symptom:** AI responses occasionally surface internal column values — "license maintainer," "occasional producer," "active producer" — rather than the correct display names or plain language descriptions.

**Current behavior:** The system prompt in `aiQueryService.ts` contains an `INTERNAL LABEL SUPPRESSION` rule that explicitly prohibits these terms. The rule is present but incomplete: it catches direct use of these exact phrases but doesn't prevent the AI from re-deriving equivalent language from context.

**Fix for production port:**
- The suppression rule is structurally correct. Reinforce it by also listing the suppressed terms in the negative examples section.
- The tier display names (Foundation, Builder, Rainmaker) should only appear when the user explicitly asks about the tier system. For all other questions, describe members by activity level: "members with 0–5 transactions in the last 12 months," not "Foundation members." This rule is in the prompt but should be tested against a broader set of questions.

---

#### Issue 4: "About Your Organization" Context Is a Hardcoded Constant

**Current state:** The `ai_business_context` field in `tenant_config` contains a hardcoded text block written during initial setup. It is currently correct for Mainstreet (updated March 2026 to use mission/value framing rather than churn/threat framing), but there is no UI for Membio staff to edit it during onboarding or update it for new clients.

**Risk:** When HGAR and GRAR are onboarded, their `ai_business_context` will need to be written manually via a database insert. There is no admin panel for this yet.

**Fix for production port:**
- `ai_business_context` must be editable through the Membio admin panel — one of the first things populated during client onboarding.
- The field should be validated for length and basic content before saving (it goes directly into an AI system prompt).
- This is not urgent for Mainstreet but is a blocker for client 3 and beyond.

---

**Summary for the production port team:** Fix Issue 1 (memory write/read gap) first — it is a data bug with a clear fix path. Issues 2 and 3 improve significantly once Issue 1 is resolved, since the AI will have real context to work with. Issue 4 is a process/admin gap that blocks self-service onboarding.

# MemberSync — Campaign Architect: Planner Intelligence Fix
## Multi-Event Series Recognition

*Written: March 7, 2026*
*Status: READY TO SEND TO REPLIT*

---

## WHAT THIS PROMPT FIXES

A single targeted improvement to the AI planner's system prompt in `aiCampaignPlannerService.ts`.

During testing, when a staff member selected three events spread across a year and described a campaign goal in one sentence, the AI defaulted to a short burst of emails leading up to the first event — requiring the staff member to correct it before it proposed a year-round series strategy. 

For the AEI demo, the AI must get this right on the first turn. The fix is a small addition to the system prompt. Nothing else changes.

---

## THE ONLY FILE TO TOUCH

`server/services/aiCampaignPlannerService.ts`

Do not touch any other file. Do not touch routes, frontend, or schema.

---

## THE CHANGE

In `buildSystemPrompt()`, locate the section that describes how the AI should analyze the campaign goal. Add the following block immediately **before** the paragraph that begins with "It asks at most one clarifying question" (or wherever the planning strategy guidance lives in the system prompt). Insert it as a distinct, clearly labeled section:

---

**INSERT THIS TEXT INTO THE SYSTEM PROMPT:**

```
MULTI-EVENT SERIES RECOGNITION — READ THIS BEFORE PROPOSING ANY PLAN:

Before proposing a campaign structure, count the number of events in context.

If there are TWO OR MORE events selected:
- These are almost certainly a series, not independent events.
- DO NOT default to a short burst of emails promoting only the first event.
- Your first instinct should be a year-round or full-timeline strategy that gives members multiple registration opportunities — one for each event in the series.
- Think about the member who joins the sequence in month 3: they should still get value and have a chance to register for upcoming events, even if they missed the first one.
- Structure the campaign so each email serves the series as a whole AND creates urgency around the next upcoming event at the time it sends.
- Only propose a single-event burst strategy if the user has explicitly asked for it or if all events are within 30 days of each other.

If there is ONE event selected, or no events:
- A focused pre-event sequence (awareness → value → urgency) is appropriate.
- Default timing: first email 3 weeks before the event, last email 3–5 days before.

This is the most important planning decision you make. Get the event count right before proposing anything.
```

---

## WHERE EXACTLY TO INSERT IT

The system prompt in `buildSystemPrompt()` contains a section describing the AI's planning approach — how it diagnoses goals, how it reasons about timing, how it asks questions. The new block should go at the **top of that planning strategy section**, before any guidance about tone, questions, or output format. It needs to fire before the AI starts reasoning about structure.

If you can't locate the exact insertion point, add it immediately after the opening personality description and before any instructions about how to respond.

---

## ACCEPTANCE CRITERIA

Test with this exact scenario:

1. Select audience: DMBs (1,779 members)
2. Select events: three Brokerage Forum events spread across the year (e.g. May, August, November)
3. Type: *"I want DMBs to attend these forums."*

**Expected result on the FIRST response:**
- The AI proposes a multi-email sequence that covers all three forums across the full year
- It does NOT anchor everything to the first event only
- It explains the year-round logic unprompted ("whether a DMB joins in January or September, they'll understand the full series value")
- A complete plan appears in the right panel on this first turn

**The AI should NOT:**
- Propose a 3-email burst leading up to May only
- Require the staff member to correct it before showing a series strategy
- Ask "should I promote all three or just the first one?" — it should infer series intent from the event count

**Second test — single event:**
1. Select one event only
2. Type any goal
3. Confirm the AI still proposes a focused pre-event sequence (the fix should not break single-event behavior)

---

## DO NOT CHANGE

- The JSON output format
- The parsePlannerResponse() function
- Any retry or error handling logic
- Any frontend code
- Any routes
- The AI model (`claude-sonnet-4-20250514`)

---

*This is a system prompt addition only. One insertion, one file, two acceptance tests.*

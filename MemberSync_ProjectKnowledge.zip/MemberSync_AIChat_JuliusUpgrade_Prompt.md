# Replit Prompt: AI Chat — Julius-Style Response Upgrade + Follow-Up Question Fix

## What This Prompt Does
Two focused fixes to the AI Chat (`aiQueryService.ts` + `AIChatBox.tsx`):
1. Upgrades the AI's response style from "query engine" to "collaborative analyst"
2. Fixes the follow-up question failure (context loss when a suggested question is clicked)

Do these two things only. Do not touch any other files.

---

## PART 1: Upgrade the AI Response Style in `aiQueryService.ts`

Open `server/services/aiQueryService.ts`.

Find the system prompt — the large string passed to the Anthropic API that instructs the AI how to behave. It likely contains instructions about generating SQL, formatting results, and returning JSON.

**Add the following instructions to the system prompt, after the existing SQL generation instructions:**

```
RESPONSE QUALITY STANDARD — COLLABORATIVE ANALYST

You are not a query engine. You are a collaborative analyst helping association and MLS staff understand their membership data. Every response should feel like a conversation with a smart colleague who is genuinely interested in helping them understand what they're looking at.

After answering the question and returning data, you must ALWAYS do all three of the following:

1. NOTICE WHAT'S INTERESTING
   Do not just return rows. Look at the data and say something meaningful about it. 
   - Is the number higher or lower than expected?
   - Is there a pattern worth noting?
   - Is there a segment of the data that stands out?
   - What does this number actually mean for the organization?
   
   Bad: "47 members have a license expiring in 90 days."
   Good: "47 members have a license expiring before April 30 — worth noting that 31 of them have zero CE hours logged so far this cycle, which means they're at real risk of missing the deadline."

2. SUGGEST ONE FOLLOW-UP
   Suggest the single most useful next question the user should ask, based on what you just returned.
   - Make it specific and actionable, not generic
   - It should flow naturally from what was just shown
   - Frame it as "Want me to..." or "You might also want to know..."
   
   Bad follow-up: "Would you like to see more data?"
   Good follow-up: "Want me to find which upcoming Core classes still have open seats that could help these 31 members complete their requirement before April 30?"

3. IDENTIFY COMBINATION OPPORTUNITIES
   If combining this data with another available dataset would make the answer more useful or accurate, say so proactively.
   - Think about what other data exists in the system that is relevant
   - Suggest the combination in plain language
   - Do not execute it automatically — suggest it and let the user decide
   
   Example: "I can also cross-reference these 47 members with their email engagement history — members who've stopped opening our emails are the highest-risk ones."

TONE: Be pleasant, supportive, and a touch enthusiastic. You genuinely find this data interesting. You want to help the user get maximum value from their data. Never be terse or robotic. Never just dump a table with no commentary.

IMPORTANT: If the query returns zero results, do not just say "No results found." Explain why that might be and suggest what the user could try instead.
```

**Do not change any other part of the system prompt.** Specifically, do not change the SQL generation instructions, the JSON response format, or the allowedTables whitelist.

---

## PART 2: Fix Follow-Up Question Context Loss

### The Problem
When a user clicks a suggested follow-up question in the chat UI, it sometimes fails with an error or returns wrong results. The cause: the follow-up question is being sent without the full conversation history, so the AI doesn't know what "that" or "those members" refers to.

### The Fix — Two Parts

#### Part 2a: Fix how follow-up questions are submitted (`AIChatBox.tsx` or wherever suggested questions are clicked)

Open the component that renders the suggested follow-up question buttons. Find the click handler for when a user clicks a suggested question.

Currently it likely does something like:
```javascript
onSuggestedQuestion(question) // sends just the question text
```

It must instead send the question **plus the full conversation history up to that point**, exactly as if the user had typed the question themselves as a follow-up message. The conversation history is what gives the AI the context to understand what "those members" or "that data" refers to.

Verify that when a suggested question is clicked, the message is submitted through the same code path as a manually typed follow-up message. If it goes through a different path, consolidate them into one. The click should be equivalent to the user typing the question and pressing Send.

#### Part 2b: Make suggested questions self-contained (`aiQueryService.ts`)

In the system prompt section where you instruct the AI to generate suggested follow-up questions, add the following instruction:

```
FOLLOW-UP QUESTION RULES:
- Each suggested follow-up question must be fully self-contained — meaning it can be understood and executed correctly even if the conversation history is partially unavailable.
- Do not write follow-up questions that rely on pronouns or references without including the specific subject.
  
  Bad: "Break that down by office"
  Bad: "Show me those members"
  Good: "Break down the 47 members with expiring licenses by office"
  Good: "Show me the Foundation members from this query who have zero CE hours completed"

- Each follow-up question should include the key subject, the key filter, and the key action — so it reads as a complete, unambiguous question when clicked.
```

---

## Verification Steps

After making these changes, test the following:

1. **Ask a simple question** — e.g., "How many members do we have?" — and verify the response now includes a meaningful observation and a natural follow-up suggestion, not just the number.

2. **Ask a data-rich question** — e.g., "Show me Foundation members who haven't attended an event in the last 6 months" — and verify the response notices something interesting about the results and offers a relevant combination opportunity.

3. **Click a suggested follow-up question** — verify it executes correctly and returns relevant results related to the original query. Test this 3-4 times with different initial queries.

4. **Verify zero-result handling** — ask a query likely to return nothing (e.g., "Show me members who joined yesterday") and verify the response explains why and suggests an alternative.

5. **Do not test by looking at the code** — test by actually using the AI Chat with real queries. The proof is in the behavior.

---

## What NOT to Change
- Do not modify the SQL generation logic
- Do not modify the JSON response schema (unless required for Part 2a)
- Do not modify the DataTable rendering
- Do not modify any other service files
- Do not modify the audience builder or email composer AI services

# MemberSync — Project Summary
## March 6, 2026

This document captures all strategic decisions, architectural decisions, and current state through March 6, 2026. Use this to resume work in a new conversation.

---

## TABLE OF CONTENTS

1. Project Overview
2. Build Philosophy and Team Structure
3. Client Pipeline
4. What Has Been Built (Complete)
5. What Was Accomplished This Session (March 6)
6. Prompts in Queue (Not Yet Sent)
7. Current Feature State
8. AEI Demo Path (3 Weeks Out)
9. Known Issues Still Open
10. AI Cost Model
11. Multi-Tenant Architecture Roadmap
12. Strategic Roadmap
13. Key Architectural Decisions (All Prior + New)
14. Standing Rules
15. Key Files Reference

---

## 1. PROJECT OVERVIEW

MemberSync is a member engagement and retention SaaS platform built by Membio for real estate associations and MLSs. It analyzes MLS listing data and AMS data to help association and MLS executives understand, engage, and retain members through AI-powered insights, smart email campaigns (SmartSends), member recognition, lapse prevention, and engagement scoring.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**Product philosophy:** "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

**The insight driving everything:** ~75% of association members produce ~12% of real estate volume but pay ~75% of dues revenue. Associations face existential threat as MLSs go non-Realtor. MemberSync's value is surfacing genuine engagement intelligence — celebrating connection, not just tracking production.

**Member tiers:** Rainmaker (40+ sides), Builder (6–39 sides), Foundation (0–5 sides) — framed positively, never pejoratively.

---

## 2. BUILD PHILOSOPHY AND TEAM STRUCTURE

**Two-track development model:**

- **Track 1 (Tracy + Claude + Replit):** Continue building and validating features for sales demos and product vision. Fast, iterative, prototype-quality.
- **Track 2 (Dev team + Claude Code):** Build production platform with proper multi-tenant architecture from day one, porting validated modules from Replit with developer-facing specs.

**Division of labor:**
- Tracy + Claude: product vision, feature decisions, architectural direction, specs ("what" and "why")
- Dev team: production readiness, implementation, testing, deployment ("how")
- Handoff artifacts: CLAUDE.md (product bible), technical debt document, developer-facing specs per feature

**Claude's role:** CTO, product visionary, AI architecture expert, strategic sparring partner. Pressure-tests every feature idea against multi-tenant scale and technical debt before speccing. Surfaces architectural risks proactively. Holds the full product picture across conversations.

**Proactive conversation management:** Claude flags when a conversation is getting long and a project summary is needed — specifically when substantial ground has been covered and a new major spec is about to begin.

**Tools:**
- Claude — strategy, architecture, specs, Replit prompts
- Julius.AI — SQL development and data validation
- Replit Agent — prototype implementation (Track 1)
- Claude Code — production implementation (Track 2)
- SendGrid — email delivery
- AWS — production database hosting
- React + Node.js + PostgreSQL — core stack

---

## 3. CLIENT PIPELINE

| Client | Members | Status |
|--------|---------|--------|
| Mainstreet REALTORS® | 18,275 | First client. Prototype on Replit. NOT in production yet. |
| HGAR | 12,800 | Onboarding. First true multi-tenant requirement. NY compliance. |
| GRAR | 3,400 | Follows HGAR. NY compliance. |
| CRMLS | 103,000+ | Major pilot prospect. SOC 2 required. CMO engaged. $2,500/mo × 90 days. |

**Important:** Mainstreet is NOT live. They want to use MemberSync but the prototype is still too rough. Production platform is what they will actually use.

---

## 4. WHAT HAS BEEN BUILT (COMPLETE)

- Full dashboard with AI Chat, Association Pulse cards, Activity Feed, Member Recognition sidebar, Mainstreet Community tier section
- Tier-aware engagement scoring (Rainmaker/Builder/Foundation with connection labels)
- Member detail pages with engagement score breakdown
- Office detail pages with agent rosters
- SmartSends email campaign creation (AI + manual + template)
- Audience building (AI builder, picklist, member/bill type, CSV upload)
- Saved audiences with count and preview
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail pages
- Triggered campaigns / Automations engine with 7 trigger types
- Automations full-page wizard UX
- Email queue safety infrastructure (per-member throttle, queue export/flush, sandbox mode)
- Campaign list performance optimization (bulk stats, SQL pagination, automation filtering)
- Email governor (weekly/daily caps per member, exempt categories, admin UI)
- Recognition Queue (AI-generated member recognition emails pending staff review)
- Open/click timestamp tracking on email recipients
- Recognition Queue frontend (queue list, review panel, sent history, governor badge)
- Email Health Dashboard — three tabs: Performance, Send Queue, Email Archive
- HTML storage for sent emails (object storage, `rendered_html_url` on campaigns)
- Image Library upgrade:
  - Required metadata at upload (name, category, alt text, tags)
  - Server-side image optimization via Sharp (max 1200px, compressed)
  - Thumbnail generation
  - Insert size picker (Small/Medium/Full Width)
  - Category-specific upload guidance with recommended dimensions and ratios
  - Soft dimension/ratio warnings at upload
  - Grid/List view toggle with localStorage persistence
  - Inline edit capability (no modal)
  - Delete/archive rules based on usage and age
  - Upload new version / supersede workflow
  - Archived images toggle
- Email Archive (searchable history, HTML preview, performance highlights)
- AI Duplicate Detection (similarity check at Preview step, Haiku-powered)
- Archive-Aware AI Composition (recent email context injected into generation)
- Recent Sends reference panel in composer
- Analytics overview with office and agent leaderboards
- Office visit brief PDF generation
- Compliance tracking
- Draft management
- Daily membership snapshots (accumulating for future trend visualization)
- Member headshot sync from AMS/MLS

---

## 5. WHAT WAS ACCOMPLISHED THIS SESSION (MARCH 6)

### Parts 1–4 Backend Verification (Recognition Queue + Governor)
Replit's self-review of Parts 1–4 flagged five items. Two were fixed (governor PATCH `sql.join` syntax confirmed correct, `canSendToMember` return type change verified at all call sites). Three deferred to parking lot (hardcoded exempt categories, SendGrid webhook live testing, count query efficiency).

### Parts 5–8 Frontend Built and Verified
Recognition Queue frontend complete:
- `/smartsends/recognition-queue` route with queue cards and review panel
- Email Controls tab within SmartSends (not admin menu — intentional decision)
- Open/click timestamp display on Member Detail email history
- Governor status badge on SmartSends dashboard

### Prompt B — Email Health Dashboard + HTML Storage + Image Library
Written and sent to Replit. Key decisions:
- HTML stored in object storage (not database column) — `rendered_html_url` reference in campaigns table
- Images are first-class objects with metadata (name, category, alt text, tags)
- Sharp for server-side optimization — one optimized file + one thumbnail, no Duda-style multi-size spawning
- Five image categories: Event Banner, Headshot, Logo, Illustration, Other + Notifications (portal-gated)
- Archive starts empty — no backfill of historical campaigns

### Prompt C — AI Duplicate Detection + Archive-Aware Composition
Written and sent to Replit. Key decisions:
- Haiku for all AI calls in this feature (lightweight, cost-efficient)
- Content summaries generated at send time and stored — comparisons use summaries not full HTML
- 70% similarity threshold (configurable per client in future)
- Duplicate check at Preview step only — composition is uninterrupted
- Three parts: duplicate warning, archive-aware generation, recent sends reference panel

### Image Insert Fix
Caught and fixed: Replit's plan to silently auto-default name and category on inline upload would have bypassed the metadata requirement. Corrected to show required fields in the composer upload dialog.

### Image Library Upgrade Prompt Written
Consolidated prompt covering: alt text + tags fields, inline edit, grid/list toggle, upload guidance with ratio warnings, Notifications category. Sent to Replit.

### Delete/Archive/Version Rules Added
Addendum sent to Replit before implementation:
- Never used → delete immediately
- Used in recent campaigns (<1 year) → archive only
- Used only in old campaigns (>1 year) → archive recommended, delete allowed with warning
- Upload new version → creates new record, auto-archives old, preserves historical references
- `status`, `superseded_by`, `archived_at` columns added to `email_images`

### Parking Lot Updated
Major update to `MemberSync_Parking_Lot.md`:
- Reorganized into four sections: Features to Build, Technical Debt, Infrastructure, Things Configured Per Client
- Section 4 (per-client config) added with 10 items
- Second review added 8 more per-client config items identified from other parking lot sections
- Standing note added: next CLAUDE.md revision must add `tenant_config` fields section

---

## 6. PROMPTS IN QUEUE (NOT YET SENT OR IN PROGRESS)

### In Progress with Replit Now
- **Image Library Upgrade** — metadata fields, edit, grid/list, upload guidance, delete/archive/versioning. Replit's plan reviewed and approved with one correction (inline upload metadata requirement preserved).

### Ready to Write (Next Session)
- **Campaign Architect** — ⭐ TOP PRIORITY for AEI demo. Replaces drip sequence builder entirely. Full design documented below.

### Written, Not Yet Sent
- **Prompt C (AI Duplicate Detection)** — send after Prompt B is verified working. Depends on email archive and HTML storage existing.

### On Hold (Intentionally)
- **A/B Testing** — superseded by Campaign Architect design
- **Automation Priority + Global Contact Limit** — waiting for stability

---

## 7. CURRENT FEATURE STATE

### SmartSends — What's Working
- Campaign creation (AI + manual + template)
- All four audience types (AI builder, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking with open/click timestamps
- Automations with 7 trigger types
- Email queue safety (governor, throttle, sandbox mode)
- Recognition Queue with review/approve/send flow
- Email Health Dashboard (Performance, Send Queue, Archive tabs)
- Image Library (upgraded — metadata, optimization, archive)
- AI duplicate detection at Preview step
- Archive-aware AI composition

### SmartSends — Known Issues
- Email Health metrics show 0% while in sandbox mode (correct behavior — resolves when live)
- Date range picker missing from Email Archive UI (backend supports it — frontend follow-up)
- Open/click badges on Member Detail not visually confirmed (no test email with engagement data yet)

### Dashboard — Working
- Association Pulse cards (Total Active Members, Connection Status, Campaign Effectiveness)
- Activity Feed
- Member Recognition sidebar
- Mainstreet Community tier cards with donut charts
- AI Chat (cross-domain queries working, SQL retry loop in place)
- Daily membership snapshot accumulating

---

## 8. AEI DEMO PATH (3 WEEKS OUT)

**Conference:** AEI, approximately March 23–27, Minneapolis
**Audience:** MLS executives and technical leaders

**Demo sequence (in order of impact):**

1. **AI Chat** — cross-domain queries, "which agents in Downers Grove closed in January with licenses expiring this year" → instant results. The "second brain" moment.
2. **Campaign Architect** — type one goal sentence, watch AI build a complete campaign. The "cancel HubSpot" moment. *(NOT YET BUILT — top priority)*
3. **Member Recognition** — show the queue, show AI-generated personal email with real member data, show the review/approve flow.
4. **Dashboard** — Association Pulse, the 75/12 insight visualized, tier distribution.

**Demo path must be narrow, stable, and locked before the show. No freestyle.**

**To do before demo path is locked:**
- Campaign Architect spec and build ← next session
- Demo data verification (real Mainstreet data, no fake anything)
- End-to-end run-through at least once before travel

---

## 9. KNOWN ISSUES STILL OPEN

### Important (Address Before Demo)
- Open/click badges on Member Detail need live email data to visually confirm
- Email Health metrics all show 0% in sandbox mode — acceptable until live but needs note for demo context

### Parking Lot (Deferred)
- Date range picker in Email Archive UI
- Async image optimization (Sharp currently synchronous — fine for single uploads)
- CDN-proof image URL tracking in `trackImageUsageInHtml`
- Governor PATCH backend cap validation (1–10 daily, 1–21 weekly)
- Configurable exempt categories in governor
- Recognition Queue dedicated count endpoint
- Drip Sequence step editor needs proper EmailComposer per step
- Revenue data uses catalog prices not actual invoiced amounts
- 172-member count gap (dashboard vs. member type builder)

---

## 10. AI COST MODEL

- All lightweight checks (duplicate detection, content summaries, image context) use **claude-haiku-4-5-20251001**
- Creative generation (email composition, campaign planning) uses **claude-sonnet-4-6**
- With prompt caching: $0.026–0.048 per request estimated
- CRMLS heavy usage: $600–1,000/month estimated
- Three-layer cost defense: technical guardrails (rate limiting, Haiku for lightweight tasks), tiered pricing, contract clauses

---

## 11. MULTI-TENANT ARCHITECTURE ROADMAP

**Stage 0 (Current — Prototype):** Everything hardcoded for Mainstreet. clientConfig.ts has all values.

**Stage 1 (Next — HGAR onboarding):** `tenant_config` database table. Every value in clientConfig.ts becomes a row keyed by `client_id`. HGAR gets its own config row. All queries filtered by `client_id`.

**Stage 2:** Admin provisioning dashboard. Staff can provision new clients without engineering.

**Stage 3:** Self-service onboarding. Credit card, connect APIs, go.

**The port approach:** New repository, proper architecture, porting logic module by module with developer specs. Not a rewrite, not an in-place refactor.

**Port order:** Authentication → Data layer (caches) → Dashboard + profiles → SmartSends → Audiences → AI Chat → Analytics → Automations → Celebrations

---

## 12. STRATEGIC ROADMAP

### Immediate (Next Session)
1. **Campaign Architect spec** — write the full Replit prompt. This is the AEI demo centerpiece.
2. **Verify Image Library Upgrade** — confirm Replit's implementation matches spec

### Near-Term (Before AEI, ~3 weeks)
3. **Campaign Architect build** — Replit implements from spec
4. **Demo path lock** — end-to-end run-through, identify and fix anything unstable
5. **Send Prompt C** — after Prompt B verified working
6. **CLAUDE.md revision** — add `tenant_config` fields section, Campaign Architect, Email Health, Image Library, Recognition Queue

### Post-AEI
7. **Proactive AI Engagement Engine** — makes Community Insights cards real
8. **AI Chart Rendering** — accelerated for CRMLS pilot
9. **Lapse Prevention System** — calendar-aware risk scoring
10. **Multi-Tenant Stage 1** — database-driven tenant config for HGAR
11. **Prompt Caching** — 90% reduction on AI input costs
12. **SOC 2 Type I preparation** — before CRMLS pilot

### Medium-Term
13. Broker Module
14. Multi-Tenant Stage 2 (admin provisioning)
15. Additional data source integrations
16. Exportable charts

### Longer-Term
17. AI Report Generation
18. Self-Service Onboarding (Stage 3)
19. Lapse Pattern Analysis
20. Integration Marketplace
21. AI Presentation Generation

---

## 13. KEY ARCHITECTURAL DECISIONS (ALL PRIOR + NEW)

- `member_metrics_cache` is single source of truth for member data
- `apmmember.MemberStatus = 'Active'` is canonical definition of active member
- Two-step query pattern is a WORKAROUND to eliminate in production (not a design pattern)
- Production = single database — two-DB setup is prototype safety measure only
- Cache-first at scale — pre-compute rather than calculate on demand
- Payment is table stakes (1 point max) — not a primary engagement signal
- Transactions are baseline — not how members connect with their organization
- All scoring signals must be client-configurable
- 100% Coverage Test — if <10% of membership covered, it's a vanity metric
- Compliance module is association-only — hidden for MLS clients
- Non-CE event attendance is stronger engagement signal than CE attendance
- Office suspension is the gatekeeper for Mainstreet Advantage fees
- Every module gated by tenant_config — disabled modules don't render, run, or consume AI budget
- Split large prompts — Replit performs better with focused, scoped prompts
- "Recognition" is user-facing term everywhere — "Celebration" stays in code only
- Email category must be set on every campaign record — no null categories
- Governor exemptions: transactional, compliance, critical, recognition
- Campaign Architect replaces drip sequence builder — no parallel UI
- AI suggestions must always be actionable (yes/no) — never configuration forms
- Object storage for binary assets (email HTML, images) — database holds metadata and URLs only
- Images are immutable once in use — use_count > 0 means archive not delete for recent campaigns
- HTML archive starts empty — no backfill of historical campaigns
- Content summaries generated at send time and stored — AI comparisons use summaries not full HTML
- No fake data in previews ever — real member data or clearly labeled sample data only
- SQL retry loop for query engine — self-healing beats dead ends
- "Attempt first, ask second" for AI queries
- The 5% rule — every screen must earn its place

---

## 14. STANDING RULES

1. No parallel systems — extend existing components, never build duplicate implementations
2. Don't break what works — verify before and after every change
3. Full-page patterns, not modals, for multi-step tasks
4. Shared components over duplicates
5. Server-side for anything touching more than 1,000 records
6. Test your work — happy path and at least one edge case
7. "Recognition" in UI everywhere — "Celebration" in code only
8. Email category must be set on every campaign record
9. Governor exemptions are: transactional, compliance, critical, recognition
10. Campaign Architect replaces drip sequence builder — no parallel UI
11. AI suggestions are always actionable (yes/no) — never configuration forms
12. Competitive intelligence queries must respect tenant isolation
13. No fake data. Ever. Real member data or clearly labeled sample data only.
14. Every module gated by tenant_config
15. The 5% rule — build what clients asked for or dreamed about
16. Mobile-first, performance-always — responsive UI, under 2 seconds load time
17. CLAUDE.md is the single source of truth for the production repository
18. Every scoring signal must pass the 100% Coverage Test
19. Claude flags proactively when conversation is long and a project summary is needed before starting a new major spec

---

## 15. KEY FILES REFERENCE

### Project Knowledge Files
- `CLAUDE.md` — Product bible for production repository (v2, 786 lines)
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog (updated this session — upload new version)
- `MemberSync_Development_Plan.docx` — Two-track model, team roles, port timeline
- `Membio_AI_Workflow_Playbook.docx` — How each team member uses Claude/Claude Code

### Prompts Written This Session (New Files)
- `MemberSync_PromptB_EmailHealth_ImageLibrary.md` — Email Health Dashboard + HTML storage + Image Library upgrade
- `MemberSync_PromptC_AIDuplicateDetection.md` — AI Duplicate Detection + Archive-Aware Composition
- `MemberSync_ImageLibrary_Upgrade_Prompt.md` — Image Library metadata, edit, grid/list, upload guidance, delete/archive/versioning

### Prior Prompts Still Relevant
- `MemberSync_SchemaModularization_Prompt.md` — deployed and verified
- `MemberSync_AIChat_JuliusUpgrade_Prompt.md` — deployed and verified
- `MemberSync_QueryEngine_RetryAndCrossDomain.md` — deployed and verified

### Backend Services
- `emailService.ts` — Email sending, queue processing, campaign management, governor
- `triggeredCampaignProcessor.ts` — Automation engine (DO NOT BREAK)
- `imageService.ts` — Image upload, optimization, metadata, usage tracking
- `aiEmailService.ts` — AI email composition with archive-aware context
- `aiQueryService.ts` — Natural language → SQL (AI Chat)
- `memberMetricsCacheService.ts` — Daily cache refresh with tier-aware scoring
- `milestoneDetectionService.ts` — Recognition/milestone detection

### Frontend Pages
- `SmartSends.tsx` — SmartSends dashboard with governor badge
- `SendEmail.tsx` — Email composition wizard (largest file — 201K)
- `RecognitionQueue.tsx` — Recognition Queue review interface
- `SmartSendsImages.tsx` — Image Library (upgraded this session)
- `MemberDetail.tsx` — Member detail with open/click timestamp display
- `CreateAutomation.tsx` — Automation wizard (Campaign Architect will modify this)

---

## CAMPAIGN ARCHITECT — DESIGN (READY TO SPEC NEXT SESSION)

### The Problem
The current drip sequence builder is the paradigm everyone hates — blank canvases, node graphs, step wizards that require you to already know what good looks like.

### The Decision
Replace the drip sequence builder entirely with an AI-first Campaign Architect. No fallback to the old UI — full replacement. Other trigger types (event registration, anniversary, milestone) are unchanged.

### The Design

**Entry point:** "Create Automation" → for drip_sequence type → single conversational prompt: *"What do you want this campaign to accomplish?"*

**What AI does:**
1. Diagnoses the goal — identifies audience, desired outcome, natural timeline
2. Recommends complete structure with reasoning: "Here's what I'd suggest: A 3-email sequence over 21 days..."
3. Writes all emails using real member data, tier context, existing email composer
4. Suggests one A/B test before activation — staff approves or skips

**The UI (replaces node canvas):**
```
📧 Email 1 — Day 0          [Edit] [Preview]
   Subject: Something's coming this spring...
   To: 4,120 Foundation members

⏱ Wait 7 days

📧 Email 2 — Day 7          [Edit] [Preview]
   Subject: What your peers are saying about CE classes
   A/B: Testing subject line variant

⏱ Wait 11 days

📧 Email 3 — Day 18         [Edit] [Preview]
   Subject: One class. Spring forward.

[Activate Campaign]
```

Clean vertical sequence. No drag handles, no connecting arrows, no conditions sidebar.

**AEI Demo sequence (3 minutes):**
1. Show competitor node canvas — "this is what everyone else asks you to do"
2. Switch to MemberSync — type one sentence goal
3. Watch AI build complete campaign
4. Show one A/B test suggestion — click approve
5. Activate

**Architectural implication:** New frontend interaction pattern in `CreateAutomation.tsx` for drip_sequence type. New AI system prompt for campaign planning. Reuses existing triggered campaign execution infrastructure. `ai_campaign_decisions` table needed for outcome tracking.

---

*Session date: March 6, 2026. Next session: Write Campaign Architect spec and Replit prompt. Start fresh conversation.*

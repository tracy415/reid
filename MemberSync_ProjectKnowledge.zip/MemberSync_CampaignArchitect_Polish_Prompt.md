# MemberSync — Campaign Architect: Polish & Audience Builder
*Written: March 6, 2026*
*Status: READY TO SEND TO REPLIT*

---

## OVERVIEW

This prompt addresses five issues found during demo testing of Campaign Architect. Work through them in the order listed. Read all existing code carefully before writing anything.

**Recommended order:** Parts 3 and 4 first (quick, self-contained prompt fixes), then Parts 1 and 2 (heavier UI work).

---

## PART 1: AUDIENCE SECTION REDESIGN

### Current problem
The audience section at the top of Campaign Architect is a passive dropdown. Users who don't have a saved audience must navigate away to build one, then return. This breaks the flow.

### What to build
Replace the current audience selector with an inline expandable section that matches the visual pattern of the Events section directly below it. Same open/close behavior, same styling.

**Default state (collapsed):**
```
Audience                                          [+]
No audience selected
```

**Expanded state:**
Three tabs inside the expanded panel: **Saved**, **Member/Bill Type**, **Picklist**

Do not include AI Builder or CSV Upload — those require separate flows that don't belong inline.

**Tab 1 — Saved:**
A searchable dropdown listing all saved audiences. When one is selected, show a brief preview chip: audience name, member count, type badge. This is the default tab and should open first.

**Tab 2 — Member/Bill Type:**
Embed the existing `MemberBillTypeBuilder` component directly. It already exists as a standalone page and as an inline component in Send Email. Use exactly the same component here. When the user saves, the new audience is auto-named based on the selected bill types (same pattern as Audience Builder), auto-selected in the Audience section, and the panel collapses. The saved audience gets `sourceType: 'member_bill_type'` and a tag: `createdIn: 'campaign_architect'`.

**Tab 3 — Picklist:**
Embed the existing `PicklistBuilder` component directly. Same pattern — save auto-names, auto-selects, collapses panel. Tag: `createdIn: 'campaign_architect'`.

### Conversational audience building
When the AI describes audience criteria in the conversation (e.g. "Foundation members who haven't attended an event in 12 months"), it should also trigger an audience resolution in the background:

1. The planner AI's response includes a structured `audienceCriteria` object in its JSON output alongside the conversational response and plan
2. When the frontend receives a response that includes `audienceCriteria`, it calls `POST /api/audiences/generate-from-criteria` with that criteria object
3. That endpoint calls the existing `getAudienceMembers` service with an AI-generated SQL query (same as AI Builder), saves the result as a named audience, and returns the `audienceId` and `audienceCount`
4. The frontend auto-selects this audience in the Audience section and shows a brief toast: "Audience built — 2,500 Foundation members selected"
5. The audience is saved permanently with `sourceType: 'ai_generated'` and `createdIn: 'campaign_architect'` tag and an auto-generated name based on the criteria description (same naming pattern as the standalone AI Audience Builder)
6. Staff can rename it inline by clicking the name chip, same as session naming

**If audience resolution fails** (zero results, query error, timeout): show a yellow inline message inside the audience section: "Couldn't build this audience automatically — select one above or build it in the Member/Bill Type or Picklist tabs." Never fail silently.

### AI system prompt addition for `aiCampaignPlannerService.ts`
Add to the planner system prompt:

> "When you have identified a clear audience definition from the conversation, include an `audienceCriteria` field in your JSON response describing the audience in plain language terms (member type, filters, tenure, activity). This will be used to automatically build the audience for the staff member. If you cannot identify a clear audience, omit this field. Never tell the user you cannot access the database — audience resolution happens automatically in the background when you describe criteria."

---

## PART 2: ANCHOR DATE ON ANY EMAIL CARD

### Current problem
Only the last email card shows an anchor date. Staff cannot set an anchor date on Email 1 or Email 2 — only the final email in the sequence.

### What to build
Every email card in the sequence editing view should show either "Day X" or an anchor indicator. Both should be clickable to open an inline date editor directly on the card.

**The inline editor (appears below the card header on click):**
```
┌─────────────────────────────────────────────┐
│  Timing for Email 2                         │
│                                             │
│  ○ Day offset from enrollment               │
│    Day: [14        ]                        │
│                                             │
│  ○ Anchored to event                        │
│    Event: [Affiliate Resource Mixer ▾]      │
│    Send:  [3 ▾] days [before ▾] event      │
│                                             │
│  ○ Specific date                            │
│    Date: [Mar 14, 2026    ]                 │
│                                             │
│  [Save]  [Cancel]                           │
└─────────────────────────────────────────────┘
```

Three options:
- **Day offset** — existing behavior, days from enrollment
- **Anchored to event** — populates from `selectedEventsJson` on the session; includes a before/after offset (e.g. "3 days before the Affiliate Mixer")
- **Specific calendar date** — fixed date picker

On Save: update `currentPlan.emails[stepNumber-1]` fields (`delayDays`, `anchorDate`, `anchorEventName`) via the existing PATCH route. The card header updates immediately to reflect the new timing.

**Staff can also describe the change conversationally** ("move Email 2 to be 3 days before the Affiliate Mixer") and the planner AI updates the plan in the right panel. Both paths lead to the same result — the card reflects the change.

---

## PART 3: HALLUCINATED TESTIMONIALS — SAFETY RULE

### Current problem
Email generation invented fictional member testimonials with fake names, fake transaction counts, and fake quotes attributed to real-sounding members. This is a safety violation — these emails cannot go out to real members.

### Fix
In the `generate` route in `routes.ts`, find where `context.additional_info` is built for each email in a Campaign Architect sequence. Add this text to `additional_info` for every generated email:

```
ABSOLUTE SAFETY RULE: Never fabricate member testimonials, invented quotes, or fictional 
social proof. Do not invent names like "Sarah M." or "Mike R." with fake transaction counts, 
tenure claims, or fake quotes attributed to them. This is a trust violation that could damage 
the organization's relationship with its members. If the email calls for social proof, use 
general language like "members tell us" or "we hear from members" without inventing specific 
people, specific quotes, or specific statistics. When in doubt, omit the social proof entirely.
```

---

## PART 4: SELECTED EVENTS PASSED TO EMAIL GENERATION

### Current problem
When events are selected in the session, the generated emails ignore them and reference other events (e.g. New Member Jumpstart) instead of the selected ones.

### Fix
In the `generate` route, when building `context.additional_info` for each email, include the session's `selectedEventsJson` array:

```typescript
const eventsContext = session.selectedEventsJson && (session.selectedEventsJson as any[]).length > 0
  ? `SELECTED EVENTS FOR THIS CAMPAIGN: The staff member has specifically selected these events to feature:\n${
      (session.selectedEventsJson as any[]).map((e: any) =>
        `- ${e.name} on ${e.startDateTime} at ${e.location || 'TBD'}`
      ).join('\n')
    }\nIf this email references events, use ONLY events from this list. Do not reference any other events not listed here.`
  : '';
```

Append `eventsContext` to `context.additional_info` for each email.

---

## ACCEPTANCE CRITERIA

1. **Audience section** opens and closes like the Events section. Saved, Member/Bill Type, and Picklist tabs all work inline without navigating away from the page.
2. **Conversational audience building** — when the AI identifies clear audience criteria in the conversation, the audience is auto-built, auto-saved with `createdIn: 'campaign_architect'` tag, and auto-selected in the audience section. Staff sees a toast confirmation with member count. If resolution fails, a clear inline message appears. Staff can rename the audience inline.
3. **Anchor date on any card** — clicking "Day X" or the anchor indicator on any email card opens the inline timing editor. All three timing options (day offset, anchored to event, specific date) work. Save updates the card immediately.
4. **No fabricated testimonials** — regenerate the Foundation re-engagement campaign and verify Email 2 contains no invented names, fake quotes, or fictional statistics.
5. **Selected events used** — with Affiliate Resource Mixer and Toastmasters Open House selected, generated emails reference only those two events, not New Member Jumpstart or any other event.
6. **No regressions** — existing Campaign Architect planning, generation, A/B testing, and activation all work exactly as before.

---

## DO NOT CHANGE

- The EmailComposer component
- The triggeredCampaignProcessor
- The existing audience builder standalone pages
- The Send Email flow audience selection
- Any SmartSends functionality outside Campaign Architect

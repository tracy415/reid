# Replit Prompt: Modularize sharedDatabaseSchema.ts

## What This Prompt Does
`sharedDatabaseSchema.ts` is currently ~37,000 characters injected into every AI call —
including simple queries that only need member data, and email generation that needs no
database schema at all. This makes every AI call slower and more expensive than it needs
to be, and dilutes the AI's focus with irrelevant schema context.

This prompt adds a routing layer so each AI service loads only the schema sections
relevant to its job. The existing named schema sections (AMS_MEMBER_SCHEMA,
MLS_MEMBER_SCHEMA, etc.) stay exactly as they are. We are only adding a smarter
assembly function alongside the existing one.

**Do not delete or modify any existing schema content.**
**Do not change any existing exported functions.**
**Only add new functions and wire them into the three AI services.**

---

## Step 1: Read the Current File First

Before writing any code, open `server/services/sharedDatabaseSchema.ts` and read the
full list of named schema section constants. They will look like:

```typescript
const AMS_MEMBER_SCHEMA = `...`;
const MLS_MEMBER_SCHEMA = `...`;
const OFFICE_SCHEMA = `...`;
// etc.
```

And an assembly function like:
```typescript
export function getSharedDatabaseSchema(): string {
  return [
    SHARED_DATABASE_OVERVIEW,
    AMS_MEMBER_SCHEMA,
    MLS_MEMBER_SCHEMA,
    // ... all sections joined
  ].join('\n');
}
```

Make a list of every named section constant in the file. You will need this list to
write the routing function correctly.

---

## Step 2: Add a New Routing Function

At the bottom of `sharedDatabaseSchema.ts`, add the following new exported function.
Use the actual constant names you found in Step 1 — the list below is representative,
not necessarily complete:

```typescript
/**
 * Query type constants for schema routing.
 * Pass one of these to getSchemaForQueryType() to get focused schema context.
 */
export const QUERY_TYPES = {
  MEMBER: 'member',           // Member profiles, engagement, tiers, status
  TRANSACTION: 'transaction', // Sales, volume, closings, production
  EDUCATION: 'education',     // CE hours, classes, events, registrations
  OFFICE: 'office',           // Office profiles, rosters, rankings
  COMPLIANCE: 'compliance',   // Dues, invoices, license status, COE
  EMAIL: 'email',             // Campaign analytics, open rates, sends
  AUDIENCE: 'audience',       // Audience building — member + association data
  GENERAL: 'general',         // Unknown/mixed queries — use broader context
} as const;

export type QueryType = typeof QUERY_TYPES[keyof typeof QUERY_TYPES];

/**
 * Returns only the schema sections relevant to the given query type.
 * Much smaller than getSharedDatabaseSchema() — use this for focused queries.
 * 
 * Always includes SHARED_DATABASE_OVERVIEW and KEY_FORMAT_RULES in every response
 * because these contain critical join patterns and deduplication rules that apply
 * to all queries.
 */
export function getSchemaForQueryType(queryType: QueryType): string {
  // These sections are always included — they contain rules that apply to every query
  const alwaysInclude = [
    SHARED_DATABASE_OVERVIEW,
    KEY_FORMAT_RULES,
    DATABASE_ROUTING_RULE,
  ];

  // These sections are included based on query type
  const byType: Record<QueryType, string[]> = {
    member: [
      AMS_MEMBER_SCHEMA,
      CACHE_TABLES_SCHEMA,
      CACHE_VS_RAW_GUIDANCE,
      CANONICAL_STATS,
    ],
    transaction: [
      AMS_MEMBER_SCHEMA,
      MLS_MEMBER_SCHEMA,
      LISTINGS_SCHEMA,
      CACHE_TABLES_SCHEMA,
      CACHE_VS_RAW_GUIDANCE,
      CANONICAL_STATS,
      BUSINESS_INTELLIGENCE,
    ],
    education: [
      AMS_MEMBER_SCHEMA,
      EVENTS_EDUCATION_SCHEMA,
      CACHE_TABLES_SCHEMA,
      CACHE_VS_RAW_GUIDANCE,
    ],
    office: [
      AMS_MEMBER_SCHEMA,
      OFFICE_SCHEMA,
      CACHE_TABLES_SCHEMA,
      CACHE_VS_RAW_GUIDANCE,
      CANONICAL_STATS,
      OFFICE_SWITCHING,
    ],
    compliance: [
      AMS_MEMBER_SCHEMA,
      INVOICES_SCHEMA,
      EVENTS_EDUCATION_SCHEMA,
      CACHE_TABLES_SCHEMA,
    ],
    email: [
      AMS_MEMBER_SCHEMA,
      CACHE_TABLES_SCHEMA,
      CACHE_VS_RAW_GUIDANCE,
    ],
    audience: [
      AMS_MEMBER_SCHEMA,
      MLS_MEMBER_SCHEMA,
      MEMBER_ASSOCIATION_SCHEMA,
      CACHE_TABLES_SCHEMA,
      CACHE_VS_RAW_GUIDANCE,
      CANONICAL_STATS,
      REFERENCE_DATA_SCHEMA,
    ],
    general: [
      // General gets a broader but still not full context
      AMS_MEMBER_SCHEMA,
      MLS_MEMBER_SCHEMA,
      OFFICE_SCHEMA,
      LISTINGS_SCHEMA,
      EVENTS_EDUCATION_SCHEMA,
      CACHE_TABLES_SCHEMA,
      CACHE_VS_RAW_GUIDANCE,
      CANONICAL_STATS,
      BUSINESS_INTELLIGENCE,
      ANNIVERSARY_QUERIES,
    ],
  };

  // Filter out any undefined sections (in case some constants don't exist yet)
  const typeSections = (byType[queryType] || byType.general).filter(Boolean);

  return [...alwaysInclude, ...typeSections].join('\n');
}

/**
 * Detects the most likely query type from a natural language question.
 * Used to automatically select the right schema context without requiring
 * the caller to specify query type explicitly.
 */
export function detectQueryType(question: string): QueryType {
  const q = question.toLowerCase();

  // Education and CE signals
  if (/\b(class|classes|course|courses|ce hours|continuing education|credit|credits|education|training|instructor|workshop|seminar|registration|registered|attend|attended)\b/.test(q)) {
    return QUERY_TYPES.EDUCATION;
  }

  // Compliance and billing signals
  if (/\b(dues|invoice|overdue|past due|suspended|suspension|license|expir|renewal|renew|compliance|code of ethics|fair housing|payment|unpaid)\b/.test(q)) {
    return QUERY_TYPES.COMPLIANCE;
  }

  // Transaction and production signals
  if (/\b(sold|sales|transaction|transactions|closing|closings|volume|sides|listing|listings|production|revenue|commission|close price|market share)\b/.test(q)) {
    return QUERY_TYPES.TRANSACTION;
  }

  // Office signals
  if (/\b(office|offices|broker|brokers|branch|brokerage|roster|team)\b/.test(q)) {
    return QUERY_TYPES.OFFICE;
  }

  // Email and campaign signals
  if (/\b(email|campaign|campaigns|open rate|click|sent|delivered|bounce|unsubscribe|newsletter)\b/.test(q)) {
    return QUERY_TYPES.EMAIL;
  }

  // Audience building signals
  if (/\b(audience|segment|list|bill type|affili|designated realtor|DR\b)\b/.test(q)) {
    return QUERY_TYPES.AUDIENCE;
  }

  // Member profile signals — broad fallback for member questions
  if (/\b(member|members|agent|agents|realtor|realtors|joined|join date|anniversary|engagement|score|tier|foundation|builder|rainmaker)\b/.test(q)) {
    return QUERY_TYPES.MEMBER;
  }

  // Default to general for anything unclear
  return QUERY_TYPES.GENERAL;
}
```

**Important:** If any constant referenced in `byType` does not exist in the file
(e.g., `MEMBER_ASSOCIATION_SCHEMA`, `ANNIVERSARY_QUERIES`), simply remove it from
that array. Do not invent constants that don't exist. Use only the constants you
found in Step 1.

---

## Step 3: Wire Into aiQueryService.ts

Open `server/services/aiQueryService.ts`.

Find where it imports from `sharedDatabaseSchema.ts`. It likely imports
`getSharedDatabaseSchema` or similar.

**Add to the import:**
```typescript
import { 
  getSharedDatabaseSchema,      // keep existing import
  getSchemaForQueryType,         // add this
  detectQueryType,               // add this
  QUERY_TYPES,                   // add this
} from './sharedDatabaseSchema';
```

Find the main query generation function — the one that builds the system prompt and
calls the Anthropic API. It will contain a large system prompt string that includes
the database schema.

Find the line that calls `getSharedDatabaseSchema()` and replace it with:

```typescript
// Detect query type from the user's question for focused schema loading
const queryType = detectQueryType(userQuestion);
const schemaContext = getSchemaForQueryType(queryType);

// Log schema size for monitoring (remove after confirming it works)
console.log(`[AIQueryService] Query type: ${queryType}, schema size: ${schemaContext.length} chars`);
```

Then replace the `getSharedDatabaseSchema()` call in the prompt string with
`schemaContext`.

The `userQuestion` variable is whatever holds the user's natural language input in
that function. Use the actual variable name from the code.

---

## Step 4: Wire Into aiAudienceService.ts

Open `server/services/aiAudienceService.ts`.

Apply the same import additions as Step 3.

Find where `getSharedDatabaseSchema()` is called in the audience building prompt.
Replace it with:

```typescript
// Audience building always uses AUDIENCE query type for full member/association context
const schemaContext = getSchemaForQueryType(QUERY_TYPES.AUDIENCE);
```

Audience building should always use `QUERY_TYPES.AUDIENCE` — not auto-detected —
because audience queries always need member + association + cache tables regardless
of how the question is phrased.

---

## Step 5: Wire Into aiEmailService.ts

Open `server/services/aiEmailService.ts`.

Find any calls to `getSharedDatabaseSchema()` or `getDataAwarenessSummary()` in
the email generation prompts.

**Remove them entirely.** Email generation does not need database schema context.
The AI is writing marketing copy, not querying data. Injecting schema into email
prompts wastes tokens and adds noise.

If `getSharedDatabaseSchema` is only used in email generation (not elsewhere in
the file), remove the import too. If it's used elsewhere in the file, keep the
import but remove it from the email generation prompt only.

---

## Step 6: Verify It Works

After making all changes, test the following — do not just read the code, actually
run these queries in the AI Chat:

**Test 1 — Member query (should use MEMBER schema):**
Ask: "How many Foundation members do we have?"
Check the console log: should show `Query type: member`

**Test 2 — Transaction query (should use TRANSACTION schema):**
Ask: "Who are the top 10 agents by sales volume this year?"
Check the console log: should show `Query type: transaction`

**Test 3 — Education query (should use EDUCATION schema):**
Ask: "How many members have completed their CE hours?"
Check the console log: should show `Query type: education`

**Test 4 — Office query (should use OFFICE schema):**
Ask: "Show me all offices with more than 20 agents"
Check the console log: should show `Query type: office`

**Test 5 — Verify results are still correct:**
For each test above, confirm the AI returns correct data — not just that it
detected the right type, but that the query actually works.

**Test 6 — Verify email generation still works:**
Go to SmartSends, compose an email with AI. Confirm it still generates correctly
now that schema has been removed from the email prompt.

**Test 7 — Verify audience builder still works:**
Go to Audience Builder, build an AI audience. Confirm it still generates a correct
member list.

---

## What NOT to Change
- Do not modify any existing schema constant content (the actual table descriptions)
- Do not delete or rename `getSharedDatabaseSchema()` — it must stay for backward
  compatibility in case anything else uses it
- Do not modify the SQL validation logic or allowedTables whitelist
- Do not modify any UI components
- Do not modify routes.ts
- Do not combine this work with any other changes

## If Something Breaks
If any query stops working after this change, the safe fallback is to replace
`getSchemaForQueryType(queryType)` with `getSharedDatabaseSchema()` — this
restores the original behavior instantly. The routing layer is additive, not
destructive.

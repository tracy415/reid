# MemberSync — AI Cost Controls & Usage Logging
*Written: March 8, 2026*
*Status: READY TO SEND TO REPLIT*

---

## WHAT THIS PROMPT BUILDS

Four targeted additions that give Membio visibility and control over AI and SendGrid costs from day one. This is foundational infrastructure — not a user-facing feature. The goal is to make every AI call measurable, every client's usage visible, and every feature rate-limited before Mainstreet goes live.

**No UI is built in this prompt.** This is all backend plumbing. The admin panel UI comes later. The plumbing must exist first.

**Files touched:**
- `shared/schema.ts` — one new table
- `server/services/aiUsageLogger.ts` — new file
- `server/routes.ts` — rate limit additions + admin endpoint
- `server/services/aiQueryService.ts` — wrap with usage logging
- `server/services/aiCampaignPlannerService.ts` — wrap with usage logging
- `server/services/aiEmailService.ts` — wrap with usage logging
- `server/services/aiAudienceService.ts` — wrap with usage logging

**Do not touch:** `triggeredCampaignProcessor.ts`, `sequenceEnrollmentService.ts`, any frontend files, any existing rate limiters already in place.

---

## PART 1 — AI USAGE LOGGING TABLE

### In `shared/schema.ts`

Add the following table after the existing campaign-related tables:

```typescript
export const aiUsageLogs = pgTable("ai_usage_logs", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().default(1), // will be dynamic in multi-tenant
  userId: integer("user_id"),                           // null for system-initiated calls
  feature: text("feature").notNull(),                   // see feature constants below
  inputTokens: integer("input_tokens").notNull().default(0),
  outputTokens: integer("output_tokens").notNull().default(0),
  estimatedCostUsd: numeric("estimated_cost_usd", { precision: 10, scale: 6 }).notNull().default("0"),
  modelUsed: text("model_used").notNull().default("claude-sonnet-4-20250514"),
  success: boolean("success").notNull().default(true),
  errorMessage: text("error_message"),                  // null on success
  metadata: jsonb("metadata"),                          // optional context (query type, campaign id, etc.)
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type AiUsageLog = typeof aiUsageLogs.$inferSelect;
export type InsertAiUsageLog = typeof aiUsageLogs.$inferInsert;
```

**Feature constants** — use these exact strings as the `feature` value:
- `"ai_chat"` — AI Chat queries
- `"campaign_architect"` — Campaign Architect planner turns
- `"email_composer"` — AI email generation and refinement
- `"audience_builder"` — AI audience generation
- `"duplicate_detection"` — Email duplicate detection
- `"content_summary"` — Email content summarization (archive)
- `"recognition_email"` — AI-generated recognition emails

Run the migration to create this table.

---

## PART 2 — AI USAGE LOGGER SERVICE

### Create `server/services/aiUsageLogger.ts`

This is a lightweight wrapper that logs every AI call result. It should be called after every successful or failed Anthropic API response.

```typescript
import { db } from '../db';
import { aiUsageLogs } from '../../shared/schema';

// Pricing constants — Claude Sonnet 4 as of March 2026
// Update these when Anthropic pricing changes
const COST_PER_INPUT_TOKEN = 0.000003;   // $3.00 per million
const COST_PER_OUTPUT_TOKEN = 0.000015;  // $15.00 per million
const CACHED_INPUT_MULTIPLIER = 0.1;     // 90% discount on cached input

interface LogAiCallParams {
  feature: string;
  inputTokens: number;
  outputTokens: number;
  cachedInputTokens?: number;  // if prompt caching is used
  modelUsed?: string;
  userId?: number;
  clientId?: number;
  success: boolean;
  errorMessage?: string;
  metadata?: Record<string, any>;
}

export async function logAiCall(params: LogAiCallParams): Promise<void> {
  try {
    const cachedTokens = params.cachedInputTokens || 0;
    const uncachedInputTokens = params.inputTokens - cachedTokens;
    
    const estimatedCost = 
      (uncachedInputTokens * COST_PER_INPUT_TOKEN) +
      (cachedTokens * COST_PER_INPUT_TOKEN * CACHED_INPUT_MULTIPLIER) +
      (params.outputTokens * COST_PER_OUTPUT_TOKEN);

    await db.insert(aiUsageLogs).values({
      clientId: params.clientId || 1,
      userId: params.userId,
      feature: params.feature,
      inputTokens: params.inputTokens,
      outputTokens: params.outputTokens,
      estimatedCostUsd: estimatedCost.toFixed(6),
      modelUsed: params.modelUsed || 'claude-sonnet-4-20250514',
      success: params.success,
      errorMessage: params.errorMessage,
      metadata: params.metadata || null,
    });
  } catch (err) {
    // Never let logging failure break the actual AI feature
    console.error('[aiUsageLogger] Failed to log AI call:', err);
  }
}

// Helper to extract token counts from Anthropic API response
export function extractTokenCounts(response: any): { 
  inputTokens: number; 
  outputTokens: number;
  cachedInputTokens: number;
} {
  return {
    inputTokens: response?.usage?.input_tokens || 0,
    outputTokens: response?.usage?.output_tokens || 0,
    cachedInputTokens: response?.usage?.cache_read_input_tokens || 0,
  };
}
```

**Critical rule:** The logger must never throw. If logging fails, the AI feature continues normally. Wrap all db calls in try/catch as shown.

---

## PART 3 — WIRE LOGGING INTO EXISTING AI SERVICES

For each of the four AI services below, add logging after the Anthropic API call. The pattern is the same in each:

1. Import `logAiCall` and `extractTokenCounts` from `aiUsageLogger`
2. After the API call succeeds, call `logAiCall` with the token counts from the response
3. If the API call fails (catch block), call `logAiCall` with `success: false` and the error message
4. Never await the logger in a way that could slow down the response — fire and forget is acceptable

### In `server/services/aiQueryService.ts`
- Feature string: `"ai_chat"`
- Add to metadata: `{ queryType: detectedQueryType }` if available

### In `server/services/aiCampaignPlannerService.ts`
- Feature string: `"campaign_architect"`
- Add to metadata: `{ sessionId: sessionId }` if available

### In `server/services/aiEmailService.ts`
- Feature string: `"email_composer"`
- Add to metadata: `{ campaignId: campaignId }` if available

### In `server/services/aiAudienceService.ts`
- Feature string: `"audience_builder"`

**Pattern example** (adapt to each file's actual structure):
```typescript
import { logAiCall, extractTokenCounts } from './aiUsageLogger';

// After the existing Anthropic API call:
try {
  const response = await anthropic.messages.create({ ... });
  
  // existing processing code...
  
  // Add logging (fire and forget — do not await if it could slow response)
  const tokens = extractTokenCounts(response);
  logAiCall({
    feature: 'ai_chat',
    inputTokens: tokens.inputTokens,
    outputTokens: tokens.outputTokens,
    cachedInputTokens: tokens.cachedInputTokens,
    success: true,
    metadata: { queryType: detectedQueryType },
  }).catch(err => console.error('[aiUsageLogger] Log failed:', err));

  return processedResult;

} catch (error) {
  // existing error handling...
  
  // Log the failure too
  logAiCall({
    feature: 'ai_chat',
    inputTokens: 0,
    outputTokens: 0,
    success: false,
    errorMessage: error instanceof Error ? error.message : 'Unknown error',
  }).catch(() => {}); // silently ignore logger errors
  
  throw error; // re-throw so existing error handling still works
}
```

---

## PART 4 — PER-FEATURE RATE LIMITS IN tenant_config

### In `shared/schema.ts`

Find the `tenantConfig` table (or equivalent). Add the following columns if they don't already exist:

```typescript
// AI feature rate limits (requests per user per day, 0 = unlimited)
aiChatDailyLimit: integer("ai_chat_daily_limit").notNull().default(100),
campaignArchitectDailyLimit: integer("campaign_architect_daily_limit").notNull().default(20),
emailComposerDailyLimit: integer("email_composer_daily_limit").notNull().default(50),
audienceBuilderDailyLimit: integer("audience_builder_daily_limit").notNull().default(30),

// Kill switches — set to false to disable a feature for this client entirely
aiChatEnabled: boolean("ai_chat_enabled").notNull().default(true),
campaignArchitectEnabled: boolean("campaign_architect_enabled").notNull().default(true),
emailComposerEnabled: boolean("email_composer_enabled").notNull().default(true),
audienceBuilderEnabled: boolean("audience_builder_enabled").notNull().default(true),
```

Run the migration.

### In `server/routes.ts`

The existing Campaign Architect rate limiter uses an in-memory Map. Add the same pattern for AI Chat and Audience Builder. These are per-user, per-day limits (reset at midnight, not rolling window).

**Add near the top of routes.ts with the other rate limit maps:**

```typescript
// Per-user daily AI usage counters (in-memory, resets at midnight)
// Key: `${userId}:${feature}:${dateString}`
const aiDailyUsageCounter = new Map<string, number>();

function checkAndIncrementDailyLimit(
  userId: number | string, 
  feature: string, 
  limit: number
): boolean {
  if (limit === 0) return true; // 0 = unlimited
  
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  const key = `${userId}:${feature}:${today}`;
  const current = aiDailyUsageCounter.get(key) || 0;
  
  if (current >= limit) return false; // limit exceeded
  
  aiDailyUsageCounter.set(key, current + 1);
  return true; // allowed
}
```

**Add rate limit checks to these existing routes:**

On `POST /api/chats` or equivalent AI Chat endpoint:
```typescript
const allowed = checkAndIncrementDailyLimit(
  req.user?.id || 'anonymous',
  'ai_chat',
  100 // default limit — later pull from tenant_config
);
if (!allowed) {
  return res.status(429).json({ 
    error: 'Daily AI Chat limit reached. Your limit resets at midnight.',
    feature: 'ai_chat'
  });
}
```

Apply the same pattern to:
- Audience generation endpoint — limit 30/day
- Email composer generation endpoint — limit 50/day

The Campaign Architect already has a rate limiter — leave it as-is.

---

## PART 5 — MEMBIO ADMIN USAGE ENDPOINT

### In `server/routes.ts`

Add a new admin-only endpoint that returns AI usage data. This is the foundation of the Membio admin panel — no UI yet, just the data.

```typescript
// GET /api/admin/usage — Membio internal only, admin role required
app.get('/api/admin/usage', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const { period = '7d', clientId } = req.query;
    
    // Calculate date range
    const days = period === '30d' ? 30 : period === '1d' ? 1 : 7;
    const since = new Date();
    since.setDate(since.getDate() - days);
    
    // Total usage by feature
    const byFeature = await db.execute(sql`
      SELECT 
        feature,
        COUNT(*)::int as call_count,
        SUM(input_tokens)::int as total_input_tokens,
        SUM(output_tokens)::int as total_output_tokens,
        SUM(estimated_cost_usd)::numeric as total_cost_usd,
        COUNT(CASE WHEN success = false THEN 1 END)::int as error_count
      FROM ai_usage_logs
      WHERE created_at >= ${since}
      ${clientId ? sql`AND client_id = ${Number(clientId)}` : sql``}
      GROUP BY feature
      ORDER BY total_cost_usd DESC
    `);
    
    // Daily totals for sparkline
    const dailyTotals = await db.execute(sql`
      SELECT 
        DATE(created_at) as date,
        COUNT(*)::int as call_count,
        SUM(estimated_cost_usd)::numeric as total_cost_usd
      FROM ai_usage_logs
      WHERE created_at >= ${since}
      ${clientId ? sql`AND client_id = ${Number(clientId)}` : sql``}
      GROUP BY DATE(created_at)
      ORDER BY date ASC
    `);
    
    // Grand totals
    const totals = await db.execute(sql`
      SELECT 
        COUNT(*)::int as total_calls,
        SUM(estimated_cost_usd)::numeric as total_cost_usd,
        COUNT(CASE WHEN success = false THEN 1 END)::int as total_errors
      FROM ai_usage_logs
      WHERE created_at >= ${since}
      ${clientId ? sql`AND client_id = ${Number(clientId)}` : sql``}
    `);

    res.json({
      period,
      since: since.toISOString(),
      totals: totals.rows[0],
      byFeature: byFeature.rows,
      dailyTotals: dailyTotals.rows,
    });

  } catch (error) {
    console.error('Admin usage query error:', error);
    res.status(500).json({ message: 'Failed to fetch usage data' });
  }
});
```

---

## VERIFICATION

After Replit completes this prompt, verify the following:

**Test 1 — Table exists:**
Check that `ai_usage_logs` table was created successfully. Query: `SELECT COUNT(*) FROM ai_usage_logs;` should return 0 without error.

**Test 2 — Logging works:**
Run an AI Chat query. Then check: `SELECT * FROM ai_usage_logs ORDER BY created_at DESC LIMIT 5;`
Should show a row with feature = 'ai_chat', non-zero token counts, and a cost value.

**Test 3 — Rate limiting works:**
The rate limit is 100/day for AI Chat by default — too high to hit in testing. Temporarily lower it to 2 in the code, run 3 queries, confirm the third returns a 429 with the correct error message. Then restore the limit to 100.

**Test 4 — Admin endpoint works:**
Call `GET /api/admin/usage?period=7d` as an admin user. Should return JSON with byFeature, dailyTotals, and totals. Should return 403 for non-admin users.

**Test 5 — Logger failure doesn't break AI:**
This is hard to test directly — just confirm that if the `ai_usage_logs` table is temporarily unavailable, the AI Chat still returns a response (the logger's try/catch protects it).

**Test 6 — No regressions:**
All existing AI features still work normally: AI Chat, Campaign Architect, Email Composer, Audience Builder.

---

## WHAT NOT TO BUILD IN THIS PROMPT

- No admin panel UI — that comes later
- No client-facing usage dashboard — that comes later  
- No automated billing or plan enforcement — that comes later
- No SendGrid usage logging — that comes later (separate prompt)
- No email alerts when limits are hit — that comes later
- Do not modify any existing rate limiters already in place
- Do not touch triggeredCampaignProcessor.ts or sequenceEnrollmentService.ts

---

## ARCHITECTURAL NOTE FOR PRODUCTION PORT

The in-memory daily usage counters (`aiDailyUsageCounter` Map) work fine for a single-process prototype. In production with multiple server instances, this must move to Redis or a database-backed counter. The `ai_usage_logs` table already provides the data needed to compute usage — the counter is just a fast lookup for rate limiting. The dev team should replace the in-memory Map with a Redis-backed counter during the production port.

The `clientId` is hardcoded to `1` (Mainstreet) throughout this prompt. In the production port, it must be pulled from the authenticated session's client context.

---

*This prompt installs the cost control plumbing. The admin panel UI, client-facing dashboard, automated alerts, and billing integration are all future prompts built on top of this foundation.*

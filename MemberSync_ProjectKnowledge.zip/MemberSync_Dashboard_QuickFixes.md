# MemberSync Dashboard — Quick Fixes (Celebrations Gap + Donuts)
## February 19, 2026

---

## FIX A: Activity Feed / Celebrations Height Mismatch

**Problem:** There is an empty gap below the Activity Feed because the Celebrations sidebar is taller. The two columns don't stretch to match each other.

**Fix in `Dashboard.tsx`:** The grid that contains the Activity Feed and Celebrations sidebar needs both children to stretch to equal height. 

Find the grid container that wraps `<ActivityFeed />` and `<CelebrationInsights />`. It should look something like:

```tsx
<div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-4 lg:items-start">
```

Change `lg:items-start` to `lg:items-stretch`:

```tsx
<div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-4 lg:items-stretch">
```

Then in `ActivityFeed.tsx`, make the outer Card fill its container height:

Find the Card wrapper:
```tsx
<Card data-testid="card-activity-feed">
```

Change to:
```tsx
<Card data-testid="card-activity-feed" className="h-full">
```

This makes both columns stretch to the height of the taller one, eliminating the gap.

Additionally, in `CelebrationInsights.tsx`, make sure the outer Card also has `h-full` and the internal content scrolls:

```tsx
<Card className="h-full flex flex-col">
  <CardHeader>...</CardHeader>
  <CardContent className="flex-1 overflow-y-auto">
    {/* celebration cards */}
  </CardContent>
</Card>
```

This way: if the Activity Feed is taller, Celebrations stretches to match. If Celebrations is taller, the Activity Feed stretches to match. No gap either way.

---

## FIX B: Donut Charts on Tier Cards

If the donut charts from the previous prompt were not implemented, here is a simplified version. Add a tiny donut chart to each tier card header in `MainstreetCommunity.tsx`.

**Add Recharts imports:**
```tsx
import { PieChart, Pie, Cell } from "recharts";
```

**Add this helper component inside the file:**
```tsx
function DuesDonut({ tierPct, tierColor }: { tierPct: number; tierColor: string }) {
  const data = [
    { value: tierPct },
    { value: 100 - tierPct },
  ];

  return (
    <div className="shrink-0" style={{ width: 40, height: 40 }}>
      <PieChart width={40} height={40}>
        <Pie
          data={data}
          cx={20}
          cy={20}
          innerRadius={12}
          outerRadius={19}
          startAngle={90}
          endAngle={-270}
          dataKey="value"
          stroke="none"
        >
          <Cell fill={tierColor} />
          <Cell fill="#e5e7eb" />
        </Pie>
      </PieChart>
    </div>
  );
}
```

Note: this version uses `PieChart` with fixed width/height instead of `ResponsiveContainer` — simpler and more reliable at small sizes.

**Add hex colors to the persona config:**
```typescript
const TIER_PERSONAS = {
  rainmaker: {
    ...existing properties,
    hexColor: '#f59e0b',
  },
  builder: {
    ...existing properties,
    hexColor: '#3b82f6',
  },
  foundation: {
    ...existing properties,
    hexColor: '#10b981',
  },
};
```

**In each tier card header**, add the donut and label after the tier name/count line. Find the header section of each tier card and add the donut to the right side:

```tsx
<div className="flex items-center gap-2.5">
  <Icon className={`h-7 w-7 ${persona.colorIcon}`} />
  <div className="flex-1 min-w-0">
    <div className="flex items-center justify-between">
      <span className="text-sm font-semibold">{persona.displayName}</span>
      <span className="text-xs text-muted-foreground">
        {comp.count.toLocaleString()} ({comp.percentage}%)
      </span>
    </div>
  </div>
  <div className="flex items-center gap-1.5">
    <DuesDonut tierPct={comp.percentage} tierColor={persona.hexColor} />
    <div className="text-right">
      <p className="text-xs font-semibold">~{comp.percentage}%</p>
      <p className="text-[10px] text-muted-foreground leading-tight">of dues<br/>revenue</p>
    </div>
  </div>
</div>
```

The `comp.percentage` value is already available from the membership-story API response — it's the percentage of total active members in that tier. Since Mainstreet dues are essentially flat-rate, membership percentage ≈ dues revenue percentage.

**Expected visual result:**
- Rainmaker card: tiny amber sliver, mostly gray donut, "~1% of dues revenue"
- Builder card: modest blue wedge, "~21% of dues revenue"  
- Foundation card: dominant emerald fill, "~77% of dues revenue" — the punchline is instant

---

## FILES CHANGED

- `client/src/pages/Dashboard.tsx` — Change `items-start` to `items-stretch` on the Activity/Celebrations grid
- `client/src/components/dashboard/ActivityFeed.tsx` — Add `h-full` to Card
- `client/src/components/dashboard/CelebrationInsights.tsx` — Add `h-full flex flex-col`, overflow scroll on content
- `client/src/components/dashboard/MainstreetCommunity.tsx` — Add DuesDonut component, hexColor to personas, donut in card headers

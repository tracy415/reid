# MemberSync Stability & Data Consistency Fix â€” Replit Prompt

## Context for Replit

MemberSync is a member engagement platform for Mainstreet REALTORSÂ® (~18,275 active members). It uses three local cache tables that are refreshed daily from a read-only AWS production database. The caches are the foundation of the entire platform â€” every dashboard metric, member list, audience builder, and analytics page reads from them. When they're stale or inconsistent, the numbers don't match and the client loses trust.

This prompt fixes five categories of issues. Each fix is independent â€” if one fails, the others should still work. Do not break any existing frontend functionality. All changes are backend only.

---

## FIX 1: Make Activity Cache Refresh Atomic (Prevent Data Loss)

### The Problem

`server/services/activityCacheService.ts` line 124 does `TRUNCATE activity_cache` BEFORE inserting new data. If the insert fails after the truncate (timeout, connection drop, error), the activity cache is empty until the next successful refresh. Everything that depends on it â€” education counts, event counts, engagement scores, compliance numbers â€” goes to zero.

The other two cache services (`memberMetricsCacheService.ts` and `analyticsProductionCacheService.ts`) already use an atomic pattern â€” they build data in a temp table and swap only on success.

### What to Change

In `server/services/activityCacheService.ts`, replace the truncate-then-insert pattern with the same atomic temp-table pattern used in `memberMetricsCacheService.ts`.

**Current code (lines 119-155):**
```typescript
if (activities.length === 0) {
  console.log("[ActivityCache] No activities found in production");
  return { success: true, count: 0 };
}

await db.execute(sql`TRUNCATE activity_cache`);  // <-- DANGEROUS

const batchSize = 500;
let insertedCount = 0;

for (let i = 0; i < activities.length; i += batchSize) {
  // ... batch insert ...
}
```

**Replace with:**
```typescript
if (activities.length === 0) {
  console.log("[ActivityCache] No activities found in production");
  return { success: true, count: 0 };
}

// Use atomic refresh: insert into temp table, then swap on success
const localClient = await localPool!.connect();

try {
  await localClient.query('BEGIN');
  
  // Create temp table with same structure
  await localClient.query(`
    CREATE TEMP TABLE activity_cache_new (LIKE activity_cache INCLUDING ALL) ON COMMIT DROP
  `);
  
  const batchSize = 500;
  let insertedCount = 0;
  
  for (let i = 0; i < activities.length; i += batchSize) {
    const batch = activities.slice(i, i + batchSize);
    
    const values: string[] = [];
    const params: unknown[] = [];
    let paramIndex = 1;
    
    for (const row of batch) {
      values.push(`($${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++})`);
      params.push(
        row.member_key,
        row.activity_source,
        row.event_type,
        row.course_type,
        row.activity_name,
        row.education_credits,
        row.is_completed,
        row.is_attended,
        row.completion_date ? new Date(row.completion_date) : null,
        row.start_datetime ? new Date(row.start_datetime) : null,
        row.event_id
      );
    }
    
    if (values.length > 0) {
      await localClient.query(`
        INSERT INTO activity_cache_new (
          member_key, activity_source, event_type, course_type, activity_name,
          education_credits, is_completed, is_attended, completion_date, start_datetime, event_id
        ) VALUES ${values.join(',')}
      `, params);
      insertedCount += batch.length;
      
      if (i % 2000 === 0 && i > 0) {
        console.log(`[ActivityCache] Inserted ${insertedCount} activities...`);
      }
    }
  }
  
  // All inserts succeeded â€” swap atomically
  await localClient.query('TRUNCATE activity_cache');
  await localClient.query('INSERT INTO activity_cache SELECT * FROM activity_cache_new');
  await localClient.query('COMMIT');
  
  console.log(`[ActivityCache] âœ“ Atomic refresh complete: ${insertedCount} records`);
  localClient.release();
  return { success: true, count: insertedCount };
  
} catch (txError) {
  try {
    await localClient.query('ROLLBACK');
    console.log('[ActivityCache] Transaction rolled back - old cache preserved');
  } catch (rollbackError) {
    console.error('[ActivityCache] Rollback failed:', rollbackError);
  }
  localClient.release();
  throw txError;
}
```

You will need to import `localPool` at the top of the file:
```typescript
import { externalPool, localPool } from '../db';
```

The existing import currently only has `db` and `externalPool`. Keep `db` for the existing compliance helper functions.

---

## FIX 2: Add Cache Refresh Logging and Staleness Detection

### The Problem

Cron jobs can fail silently. Replit instances sleep and wake. There is no record of when the last successful cache refresh happened, so stale data goes undetected.

### Step 2a: Create the `cache_refresh_log` table

Add to `shared/schema.ts` alongside the existing table definitions:

```typescript
export const cacheRefreshLog = pgTable("cache_refresh_log", {
  id: serial("id").primaryKey(),
  cacheName: text("cache_name").notNull(),  // 'member_metrics', 'activity', 'analytics_production', 'agent_headshots'
  startedAt: timestamp("started_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  success: boolean("success"),
  recordCount: integer("record_count"),
  durationMs: integer("duration_ms"),
  errorMessage: text("error_message"),
});
```

### Step 2b: Log every cache refresh

Wrap each cache refresh function to log its result. The simplest approach: add a helper function in a new file `server/services/cacheRefreshLogger.ts`:

```typescript
import { db } from '../db';
import { cacheRefreshLog } from '@shared/schema';

export async function logCacheRefresh(
  cacheName: string,
  refreshFn: () => Promise<{ count?: number; officeCount?: number; agentCount?: number; duration?: number }>
): Promise<boolean> {
  const startedAt = new Date();
  
  try {
    const result = await refreshFn();
    const durationMs = Date.now() - startedAt.getTime();
    const recordCount = result.count ?? (result.officeCount ?? 0) + (result.agentCount ?? 0);
    
    await db.insert(cacheRefreshLog).values({
      cacheName,
      startedAt,
      completedAt: new Date(),
      success: true,
      recordCount,
      durationMs,
    });
    
    console.log(`[CACHE_LOG] ${cacheName}: success, ${recordCount} records in ${durationMs}ms`);
    return true;
  } catch (error) {
    const durationMs = Date.now() - startedAt.getTime();
    
    await db.insert(cacheRefreshLog).values({
      cacheName,
      startedAt,
      completedAt: new Date(),
      success: false,
      recordCount: 0,
      durationMs,
      errorMessage: String(error).slice(0, 500),
    }).catch(logErr => console.error('[CACHE_LOG] Failed to log error:', logErr));
    
    console.error(`[CACHE_LOG] ${cacheName}: FAILED after ${durationMs}ms -`, error);
    return false;
  }
}

export async function getLastSuccessfulRefresh(cacheName: string): Promise<Date | null> {
  const result = await db.execute(
    sql`SELECT completed_at FROM cache_refresh_log 
        WHERE cache_name = ${cacheName} AND success = true 
        ORDER BY completed_at DESC LIMIT 1`
  );
  const row = result.rows[0] as any;
  return row?.completed_at ? new Date(row.completed_at) : null;
}
```

Import `sql` from drizzle-orm at the top of that file.

### Step 2c: Update startup to check staleness, not just emptiness

In `server/index.ts`, update the `checkAndRefreshCachesOnStartup` function. Currently it only refreshes if `count = 0`. Change it to also refresh if the last successful refresh was more than 25 hours ago:

```typescript
// Add import at top of index.ts
import { logCacheRefresh, getLastSuccessfulRefresh } from './services/cacheRefreshLogger';
```

Replace the cache emptiness checks with:

```typescript
const isStale = async (cacheName: string): Promise<boolean> => {
  const lastRefresh = await getLastSuccessfulRefresh(cacheName);
  if (!lastRefresh) return true;
  const hoursSinceRefresh = (Date.now() - lastRefresh.getTime()) / (1000 * 60 * 60);
  return hoursSinceRefresh > 25;
};

if (metricsCount === 0 || await isStale('member_metrics')) {
  console.log('[STARTUP] Member metrics cache needs refresh (empty or stale)...');
  refreshPromises.push(
    logCacheRefresh('member_metrics', () => refreshMemberMetricsCache())
  );
}

if (activityCount === 0 || await isStale('activity')) {
  console.log('[STARTUP] Activity cache needs refresh (empty or stale)...');
  refreshPromises.push(
    logCacheRefresh('activity', async () => {
      const result = await refreshActivityCache();
      return { count: result.count };
    })
  );
}

if (officeProductionCount === 0 || await isStale('analytics_production')) {
  console.log('[STARTUP] Analytics production cache needs refresh (empty or stale)...');
  refreshPromises.push(
    logCacheRefresh('analytics_production', () => refreshAnalyticsProductionCache())
  );
}
```

Also wrap the scheduled cron refreshes so they log. In each cache service's `schedule` function, wrap the refresh call with `logCacheRefresh`. For example in `memberMetricsCacheService.ts`:

```typescript
cron.schedule('0 4 * * *', async () => {
  console.log('[METRICS_CACHE] Running scheduled 4 AM refresh...');
  await logCacheRefresh('member_metrics', () => refreshMemberMetricsCache());
});
```

Do the same for `activityCacheService.ts` (5 AM) and `analyticsProductionCacheService.ts` (3:30 AM or whatever its current schedule is).

### Step 2d: Add an API endpoint to check cache health

In `server/routes.ts`, add:

```typescript
app.get("/api/admin/cache-health", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT DISTINCT ON (cache_name) 
        cache_name, completed_at, success, record_count, duration_ms, error_message
      FROM cache_refresh_log
      ORDER BY cache_name, completed_at DESC
    `);
    
    const caches = (result.rows as any[]).map(row => ({
      name: row.cache_name,
      lastRefresh: row.completed_at,
      success: row.success,
      recordCount: row.record_count,
      durationMs: row.duration_ms,
      error: row.error_message,
      isStale: row.completed_at ? (Date.now() - new Date(row.completed_at).getTime()) > 25 * 60 * 60 * 1000 : true,
    }));
    
    res.json({ caches });
  } catch (error) {
    res.status(500).json({ error: "Failed to get cache health" });
  }
});
```

### Step 2e: Add manual refresh endpoint

```typescript
app.post("/api/admin/cache-refresh/:cacheName", authMiddleware, requireRole("admin"), async (req, res) => {
  const { cacheName } = req.params;
  
  const refreshFns: Record<string, () => Promise<any>> = {
    'member_metrics': () => refreshMemberMetricsCache(),
    'activity': async () => { const r = await refreshActivityCache(); return { count: r.count }; },
    'analytics_production': () => refreshAnalyticsProductionCache(),
  };
  
  const fn = refreshFns[cacheName];
  if (!fn) {
    return res.status(400).json({ error: `Unknown cache: ${cacheName}. Valid: ${Object.keys(refreshFns).join(', ')}` });
  }
  
  // Don't await â€” run in background so the request doesn't timeout
  logCacheRefresh(cacheName, fn);
  
  res.json({ message: `${cacheName} refresh started in background. Check /api/admin/cache-health for status.` });
});
```

Add necessary imports at the top of routes.ts:
```typescript
import { logCacheRefresh } from './services/cacheRefreshLogger';
import { refreshActivityCache } from './services/activityCacheService';
import { refreshAnalyticsProductionCache } from './services/analyticsProductionCacheService';
import { refreshMemberMetricsCache } from './services/memberMetricsCacheService';
```

(Some of these may already be imported in index.ts but they're needed in routes.ts now too.)

---

## FIX 3: Consolidate Duplicate Health Status Logic

### The Problem

`server/storage.ts` has two different health status calculations using different thresholds:

**Function version (line 56)** â€” used for office detail pages:
```typescript
function getHealthStatus(atRiskPercentage: number, avgScore: number): HealthStatus {
  if (atRiskPercentage > 30 || avgScore < 5) return "at_risk";
  if (atRiskPercentage >= 20 || avgScore < 6) return "watch";
  return "healthy";
}
```

**Inline version (lines 351-353)** â€” used for dashboard office list:
```typescript
let healthStatus: HealthStatus = "healthy";
if (atRiskPercentage > 30) healthStatus = "at_risk";
else if (atRiskPercentage > 15) healthStatus = "watch";
```

The inline version ignores `avgScore` entirely and uses a different threshold for "watch" (15% vs 20%).

### What to Change

Replace the inline version on lines 351-353 of `server/storage.ts` with a call to the existing function:

```typescript
const healthStatus = getHealthStatus(atRiskPercentage, avgScore);
```

This is a one-line change. The `atRiskPercentage` and `avgScore` variables are already computed on lines 348-349.

---

## FIX 4: Consolidate isAtRisk Definition

### The Problem

The `isAtRisk` flag is computed differently in different code paths within `server/storage.ts`:

| Location | Logic | Used By |
|----------|-------|---------|
| Line 582 | `score < 6` | Compliance: IL CE members list |
| Line 630 | `score < 6` | Compliance: COE members list |
| Line 908 | `score < 5 OR has_overdue_invoice` | Members list page |
| Line 1035 | `score < 5 OR has_overdue_invoice` | Member detail page |
| Dashboard engaged count (line 284) | `score >= 5` (inverse: engaged) | Dashboard metric card |
| Engagement score service (line 147) | `score < 2 = critical, < 4 = high` | License expiring members |

The cache table already stores a `risk_level` field computed during the daily refresh with consistent thresholds: critical (<2), high (2-3), medium (4-5), low (6+).

### What to Change

Everywhere that computes `isAtRisk` from the score directly, use the cache's `risk_level` instead. The consistent rule should be:

```typescript
const isAtRisk = ['critical', 'high'].includes(row.risk_level);
```

**Line 582:** Change `isAtRisk: (row.engagement_score ?? 0) < 6` to:
```typescript
isAtRisk: ['critical', 'high'].includes(row.risk_level || 'medium'),
```

**Line 630:** Same change â€” replace `(row.engagement_score ?? 0) < 6` with:
```typescript
isAtRisk: ['critical', 'high'].includes(row.risk_level || 'medium'),
```

**Line 908:** Change `const isAtRisk = score < 5 || row.has_overdue_invoice;` to:
```typescript
const isAtRisk = ['critical', 'high'].includes(row.risk_level) || row.has_overdue_invoice;
```

**Line 1035:** Same change as line 908 â€” replace `score < 5 || row.has_overdue_invoice` with:
```typescript
const isAtRisk = ['critical', 'high'].includes(row.risk_level) || row.has_overdue_invoice;
```

These queries already select `risk_level` from the cache, so no new columns need to be added. The important thing is that "at risk" now means the same thing everywhere: the cache-computed risk level is critical or high (score below 4), optionally combined with overdue invoices.

---

## FIX 5: Remove Dead Code

### 5a: Remove unused functions from `activityCacheService.ts`

The following four exported functions in `server/services/activityCacheService.ts` are never imported or called anywhere in the codebase. The compliance calculations in `storage.ts` do their own queries directly against the `activity_cache` and `member_metrics_cache` tables.

Remove these functions (lines 172-263):
- `getCodeOfEthicsStatus()`
- `getIllinoisCEStatus()`
- `getMembersNeedingCOE()`
- `getMembersWithCEProgress()`

Keep `refreshActivityCache()`, `startActivityCacheScheduler()`, and all the code above line 172.

### 5b: Remove empty `server/smartsends/` directory

This directory exists but contains no files. Delete it.

### 5c: Plan for `engagementScoreService.ts` deprecation

`server/services/engagementScoreService.ts` is a 378-line duplicate scoring engine. It is only used in one place: `storage.ts` line 801, inside the `getLicenseExpiringMembers()` function. That function queries the external database for members with expiring licenses, then calls `batchCalculateEngagement()` to compute their engagement scores on the fly.

**For this prompt:** Do NOT remove it yet. Instead, refactor `getLicenseExpiringMembers()` to read engagement data from `member_metrics_cache` instead of computing it live. The cache already has all the fields needed (`engagement_score`, `tier`, `risk_level`).

Replace the current approach (lines 796-802):
```typescript
// Get all member keys for batch engagement calculation
const memberKeys = result.rows.map((row: any) => row.member_key);

// Import engagement service and calculate in batch
const { batchCalculateEngagement } = await import('./services/engagementScoreService');
const engagementMap = await batchCalculateEngagement(memberKeys);
```

With a cache lookup:
```typescript
// Get engagement data from cache instead of computing live
const memberKeys = result.rows.map((row: any) => row.member_key);
const engagementResult = await db.execute(sql`
  SELECT member_key, engagement_score, tier, risk_level
  FROM member_metrics_cache
  WHERE member_key = ANY(${memberKeys})
`);
const engagementMap = new Map<string, { engagementScore: number; tier: string; tierLabel: string; riskLevel: string; isAtRisk: boolean }>();
for (const row of engagementResult.rows as any[]) {
  const tier = row.tier || 'license_maintainer';
  engagementMap.set(row.member_key, {
    engagementScore: row.engagement_score ?? 0,
    tier,
    tierLabel: tier === 'active_producer' ? 'Active Producer' : tier === 'occasional_producer' ? 'Occasional Producer' : 'License Maintainer',
    riskLevel: row.risk_level || 'medium',
    isAtRisk: ['critical', 'high'].includes(row.risk_level || 'medium'),
  });
}
```

Then update the usages below it (around line 805-829) to use the new map shape. The `engagement?.riskLevel` and `engagement?.isAtRisk` references will still work with the new shape.

After this change, `engagementScoreService.ts` will have zero callers and can be safely deleted in a future cleanup. Add a comment at the top of the file: `// DEPRECATED: No longer called. Safe to delete. See memberMetricsCacheService for scoring logic.`

---

## FIX 6: Break Up the Analytics Production Query (Replit's Recommendation)

### The Problem

The agent production query in `server/services/analyticsProductionCacheService.ts` (starting at line 274) runs one massive CTE that scans the `apmproperty` table three separate times â€” current year, prior year, and all-time career. This takes 10-15+ minutes and times out frequently.

### What to Change

Split the single `agentProductionQuery` (lines 274-452) into three separate queries that run sequentially:

**Query 1: Current year production (last 365 days)**
This is the `prop_dedup`, `props`, `sides`, `sides_with_members`, `agent_rollup` CTEs. Run this first and save the results.

**Query 2: Prior year production (365-730 days)**
This is the `prop_dedup_prior`, `props_prior`, `sides_prior`, `prior_rollup` CTEs. Run this second.

**Query 3: Career totals (all time)**
This is the `prop_dedup_career`, `props_career`, `sides_career`, `career_rollup` CTEs. Run this last.

Then merge the results in JavaScript using the `member_key` as the join key.

**Important implementation details:**

1. Set a statement timeout on each query: `SET statement_timeout = '600000'` (10 minutes) at the start of each query. Reset after.

2. If query 3 (career totals) fails, save what we have from queries 1 and 2 with career data set to 0. Career totals change slowly and having partial data is better than no data.

3. Add a retry: if a query fails once, wait 10 seconds and retry once before giving up.

4. The `members` CTE (member deduplication) is used by all three queries. Run it once and pass the results to each query, or include it in each query's CTE (the dedup is fast â€” it's the property scans that are slow).

5. Keep the office production query (line 86) separate as it is â€” it's already fast enough.

6. Release the external database connection between queries to avoid holding it for the full duration. Reconnect for each query.

### Approach

Here's the recommended structure:

```typescript
// Step 2a: Current year agent production
console.log('[ANALYTICS_CACHE] Fetching current year agent production...');
const currentYearQuery = `
  WITH prop_dedup AS (
    -- same as current lines 277-290
  ),
  props AS (SELECT * FROM prop_dedup WHERE rn = 1),
  member_dedup AS (
    -- same as current lines 293-303  
  ),
  members AS (SELECT * FROM member_dedup WHERE rn = 1),
  sides AS (
    -- same as current lines 309-327
  ),
  sides_with_members AS (
    -- same as current lines 330-346
  ),
  agent_rollup AS (
    -- same as current lines 348-364
  )
  SELECT 
    member_key, member_mls_id, member_name, member_email, office_key,
    sides_count as transaction_sides, total_volume as production_volume,
    listing_sides, buyer_sides, avg_price, primary_property_type, primary_city, luxury_tx as luxury_transactions
  FROM agent_rollup
`;

// Step 2b: Prior year agent production  
console.log('[ANALYTICS_CACHE] Fetching prior year agent production...');
const priorYearQuery = `
  WITH prop_dedup_prior AS ( ... ),
  props_prior AS (SELECT * FROM prop_dedup_prior WHERE rn = 1),
  member_dedup AS ( ... ),
  members AS (SELECT * FROM member_dedup WHERE rn = 1),
  sides_prior AS ( ... ),
  prior_rollup AS ( ... )
  SELECT member_key, volume_prior as volume_12mo_prior
  FROM prior_rollup
`;

// Step 2c: Career totals (try, but don't fail the whole refresh)
console.log('[ANALYTICS_CACHE] Fetching career totals...');
let careerMap = new Map<string, { careerTx: number; careerVolume: number }>();
try {
  const careerQuery = `
    WITH prop_dedup_career AS ( ... ), ...
    SELECT member_key, career_tx as career_transactions, career_volume
    FROM career_rollup
  `;
  const careerResult = await runWithTimeout(externalClient, careerQuery, 600000);
  for (const row of careerResult.rows) {
    careerMap.set(row.member_key, { 
      careerTx: parseInt(row.career_transactions) || 0, 
      careerVolume: parseFloat(row.career_volume) || 0 
    });
  }
} catch (careerError) {
  console.warn('[ANALYTICS_CACHE] Career totals query failed, using zeros:', careerError.message);
  // Continue without career data â€” better partial data than no data
}

// Merge results
for (const agent of currentYearAgents) {
  agent.volume_12mo_prior = priorYearMap.get(agent.member_key)?.volume_prior || 0;
  agent.career_transactions = careerMap.get(agent.member_key)?.careerTx || 0;
  agent.career_volume = careerMap.get(agent.member_key)?.careerVolume || 0;
}
```

Add a timeout helper:
```typescript
async function runWithTimeout(client: any, query: string, timeoutMs: number): Promise<any> {
  await client.query(`SET statement_timeout = '${timeoutMs}'`);
  try {
    return await client.query(query);
  } finally {
    await client.query(`SET statement_timeout = '0'`).catch(() => {});
  }
}
```

---

## Testing Checklist

After implementing all fixes, verify:

1. **Activity cache refresh** â€” Trigger a manual refresh via the new admin endpoint. Confirm the old data stays if you cancel midway (test by stopping the server during refresh â€” old data should still be there on restart).

2. **Cache health endpoint** â€” Call `GET /api/admin/cache-health` and verify all three caches show recent timestamps.

3. **Dashboard numbers** â€” The "Total Active Members" card should still show ~18,275. The tier breakdown should still add up to the total.

4. **Office health status** â€” Verify office health badges on the dashboard match the office detail page. They were inconsistent before.

5. **Members list** â€” The "At Risk" filter should show the same members regardless of whether you access them from the dashboard link or the members page filter.

6. **Analytics refresh** â€” Trigger a manual refresh of `analytics_production`. Confirm it completes (may take several minutes). Check that the office leaderboard and agent rankings load correctly.

7. **Cache refresh log** â€” After running refreshes, query `SELECT * FROM cache_refresh_log ORDER BY started_at DESC LIMIT 10` and verify entries are being logged.

---

## Files Modified

| File | Changes |
|------|---------|
| `shared/schema.ts` | Add `cacheRefreshLog` table definition |
| `server/services/activityCacheService.ts` | Atomic refresh pattern, remove 4 dead functions |
| `server/services/cacheRefreshLogger.ts` | NEW FILE â€” logging and staleness helpers |
| `server/services/analyticsProductionCacheService.ts` | Split agent query into 3, add timeout/retry |
| `server/services/engagementScoreService.ts` | Add DEPRECATED comment at top |
| `server/storage.ts` | Fix health status (1 line), fix isAtRisk (4 locations), fix getLicenseExpiringMembers |
| `server/index.ts` | Staleness detection on startup, wrap refreshes with logger |
| `server/routes.ts` | Add cache-health and cache-refresh admin endpoints |

## Files to Delete

| File/Directory | Reason |
|---------------|--------|
| `server/smartsends/` (empty directory) | Contains no files |

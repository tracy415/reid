# MemberSync — Project Summary
## March 11, 2026 (Evening) · Resume Conversation Document

**AEI Conference: March 23–26 · 12 days out · RESO Conference: April 21–23**

---

## IMPORTANT: TRANSITION NOTE

As of March 11, 2026, all prototype development in Replit is complete. The project is transitioning to **Claude Code** for all future development. This document is the canonical handoff context for:

- Claude (CTO/architect role — reads this at the start of every new conversation)
- The dev team porting validated features into the production environment via Claude Code
- Tracy (CEO/founder) resuming work after any break in context

**CLAUDE.md** in the repository root is the single source of truth for the production codebase. This summary carries the strategic and architectural context that CLAUDE.md does not. Both documents are needed. Neither replaces the other.

---

## 1. Roles & Toolchain

Tracy is CEO and founder of Membio — a proptech SaaS company with 30+ years of real estate industry experience on the business side. Non-technical founder building MemberSync exclusively with Claude, Julius.ai, and now Claude Code.

**Claude's role: CTO, product visionary, AI architecture expert, and strategic sparring partner.**

- Write all prompts and review implementation plans before Tracy approves them
- Surface architectural risks proactively — never wait for Tracy to discover them
- Translate tradeoffs into business terms, not jargon
- Hold the full product picture across conversations
- Write and maintain CLAUDE.md (the product bible for the dev team)

**The Toolchain:**

- Claude — strategy, architecture, prompts, CLAUDE.md, project summaries
- Julius.ai — SQL development and data validation
- Claude Code — all future implementation (replaced Replit Agent as of March 11)

**Standing agreement established March 10:**
*No technical debt, no dead code, nothing left behind. If Claude sees it, Claude calls it. We fix it now.*

---

## 2. Product Vision & Philosophy

MemberSync is a member engagement and retention SaaS platform for real estate associations and MLSs. It analyzes MLS listing and AMS data to help executives understand, engage, and retain members.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**The existential context:** MLSs are going non-Realtor, removing the last transactional justification for association membership. MemberSync is the answer — real, actionable intelligence about members AND their competitive environment.

**Core UX philosophy:** *"We don't give you a blank canvas. We give you a recommendation. You say yes or no."*

### The 75/12 Rule

~75% of members produce ~12% of transaction volume — yet they pay ~75% of dues. These are Foundation members. MemberSync is built for all of them, not just the top producers.

**The 100% Coverage Test:** Any scoring signal covering fewer than 10% of membership is a vanity metric, not a scoring input.

| Display Name | Internal Code | Sides (12mo) | Mainstreet % |
|---|---|---|---|
| Rainmaker | active_producer | 40+ | ~1.4% |
| Builder | occasional_producer | 6–39 | ~21% |
| Foundation | license_maintainer | 0–5 | ~77% |

**Critical rules:** Display names only in UI. Foundation members who take classes, pay on time, and attend events can score 10/10 with zero transactions. Engagement is not production.

---

## 3. Client Pipeline

| Client | Members | Status | Notes |
|---|---|---|---|
| Mainstreet REALTORS® | 18,275 | First client / prototype | Chicago suburbs, IL compliance |
| HGAR / Hudson Gateway | 12,800 | Onboarding | Multi-tenant, NY compliance |
| GRAR / Greater Rochester | 3,400 | Third pilot | Multi-tenant, NY compliance |
| CRMLS | 103,000+ | Paused | Their team building competing product; CMO relationship warm |

---

## 4. Build Philosophy & Team Structure

### Two-Track Development Model

- **Track 1 (Tracy + Claude + Replit — now complete):** Rapid prototype, feature validation, connected to read-only production data, writes to Replit dev DB
- **Track 2 (Dev team + Claude Code):** Production platform, porting validated modules with proper multi-tenant architecture. Now the only active track.

### Dev Team Status (March 11, 2026)

- Completed: monolith split, dev/staging/prod environments, Cognito auth, unified DB, CI/CD, multi-tenant architecture foundation
- AWS spin-up expected imminently
- DevOps pulled Replit snapshot from March 5 — ~6 days behind current Replit state
- GitHub connection between Claude Project and repo: planned, not yet established
- CLAUDE.md: Tracy-edited version distributed March 9 — comprehensive update overdue (highest priority item after AEI)

### Two Databases in Replit (Reference Only — Production Uses AWS)

- Replit dev DB — all MemberSync-built tables; full read/write access
- Membio production DB — read-only; source of truth for member/MLS/AMS data

---

## 5. Current State: What's Built

### Core Platform
- Engagement scoring with tier classification (Rainmaker/Builder/Foundation)
- Member metrics cache (daily refresh, cache-first architecture)
- Dashboard with Association Pulse cards, Activity Feed, Member Recognition sidebar
- Member Detail pages with score breakdown, open/click timestamps, real profile data
- Daily membership snapshot for trend analysis

### SmartSends
- Campaign creation: AI + manual + template
- All four audience types (AI, manual, CSV upload, external contacts)
- Email Governor with sandbox mode, exempt categories
- Recognition Queue — full review/approve/send
- Email Health Dashboard (Performance, Send Queue, Email Archive tabs)
- Image Library upgraded with metadata, versioning, delete/archive rules
- AI duplicate detection at Preview step
- Reporting & Analytics — rebuilt as unified command center (March 9)
- Create flow rebuilt with 5 tiles (March 9)

### Campaign Architect — AEI Demo Centerpiece ✅
All 7 prompts fully deployed and verified. This is the demo centerpiece.
- Prompt 1: Conversation UI, planning, session persistence
- Prompt 2: Email generation, editing, A/B, activation
- Polish prompt: 5 UX improvements
- Hardening prompt: negative delayDays fix, audience accumulation cleanup, rate limiting
- Planner Intelligence Fix: multi-event series recognition
- Addendum: branch emails, social proof prohibition, minimum 3 emails per event
- Planner Voice & Grouping Fix: AI voice section, event grouping logic

### AI Services
- AI Chat: natural language → SQL, cross-domain queries, retry loop, Julius-style analyst behavior
- AI email composition with archive-aware context
- AI audience builder
- AI duplicate detection
- AI campaign planner (Campaign Architect)
- Schema modularization: 41–76% schema size reductions by query type
- AI usage logging, rate limiting, kill switches (infrastructure only — no UI yet)

---

## 6. Navigation Structure (Current)

```
Dashboard
SmartSends [collapsible — label navigates to /smartsends home]
  → Create (/smartsends/create)
  → Reporting & Analytics (/smartsends/reporting)
  → Audiences [collapsible]
      AI Builder, Picklist, Member/Bill Type, Saved, Upload
  → Content (/smartsends/images)
  → Templates
  → Settings
Chats (/chats)
Recognition [collapsible — badge shows pending count]
  → Templates (stub)
  → Performance (real data)
  → Settings (stub)
Engagement (greyed — Coming Soon, inert)
Retention (greyed — Coming Soon, inert)
Compliance [collapsible — hidden entirely for MLS clients]
  → Communications
  → Performance
Analytics [collapsible]
  → Market Stats
  → Create Brief
Members
Offices
```

---

## 7. Completed This Session (March 11, 2026)

- ✅ Items 1+2: Suppression schema hardening — email_address as PK, UPSERT patterns, health counter, startup migration
- ✅ Items 3+6: canSendToMember alias gap and legacy write paths — verified already fixed in prior session
- ✅ UX Fix 1: Settings nav restored — direct link to Email Governor, chevron expands to Unsubscribes child
- ✅ UX Fix 2: Context-aware send toast — shows recipient count, suppression count, or full-suppression warning (8 seconds)
- ✅ UX Fix 3: Suppression banner on campaign detail — amber banner when skipped_count > 0, links to Unsubscribes page
- ✅ UX Fix 4: Disambiguated queue processor logs — separate counters for sandbox skips, governor throttles, opt-out suppressions, hard bounce skips
- ✅ Webhook category fix — group_unsubscribe sets category-specific opt-out only; plain unsubscribe sets email_opt_out only (not marketing_opt_out)
- ✅ Nav cleanup — verified already clean from prior work; no action needed
- ✅ Item 5: SQL injection fix — staff unsubscribe search fully parameterized, ORDER BY whitelisted
- ✅ Parking lot updated — hard bounce exclusion gap documented in Section 2
- ✅ Staff manual suppression bug fixed — marketing category now sets `marketing_opt_out` only; `email_opt_out` no longer set as side effect. Recognition path confirmed already correct. Both INSERT and UPDATE paths fixed in `routes.ts`.

**All pre-AEI suppression and security work is now complete.**

---

## 8. Next Steps — Start Here

**⚠️ AEI/RESO Conference is March 23–27 in Minneapolis. 12 days out.**

### Priority Order

**1. Item 4 — Governor Not Applied to Non-Member Recipients (Prompt To Write)**
The Email Governor currently only checks limits for members via `canSendToMember`. External/non-member recipients in the 'External Contacts' audience type bypass the governor entirely. Needs a focused prompt.

**2. CLAUDE.md Comprehensive Update (Overdue — High Priority)**
The dev team has a Tracy-edited version from March 9. Must be updated before Claude Code work goes deep. Must include:
- All tenant_config fields (full list in Parking Lot Section 4)
- Campaign Architect architecture and standing rules
- Current suppression architecture (email_address as PK, category opt-outs, full fix history)
- Email Health Dashboard, Image Library, Recognition Queue infrastructure
- Navigation structure (current)
- SmartSends rebuild — canonical campaign types, Reporting & Analytics
- The 30 standing rules (canonical)

**3. Recognition Homepage (After CLAUDE.md)**
Stat cards, "What's resonating," "Coming up" queue, daily digest email, left nav badge count.

**4. Tracy's Questions**
Tracy has been saving strategic questions for a fresh conversation. Address before starting new feature prompts.

---

## 9. Email & Suppression Architecture — Full Context

### How We Got Here: What Was Broken and How It Was Fixed

This section exists because the suppression system went through a significant architectural repair in March 2026. The dev team must port the *corrected* architecture, not the earlier fragile version. Understanding what was wrong and why it was fixed is as important as knowing what the current state is.

**What was wrong (before March 10–11, 2026):**

The suppression system had been built incrementally and had accumulated several serious problems.

First, there was no consistent suppression key. Some code paths suppressed by `member_key`, others by `email_address`, and some tried both with an `OR member_key = ''` condition that could silently pass emails through when the member key was blank or missing. External contacts (non-members added via CSV upload) had no member_key at all, which meant the suppression check effectively didn't apply to them.

Second, all unsubscribe events were treated identically. When a member clicked "unsubscribe" — whether from a marketing email, a recognition email, or using SendGrid's category-specific preference center — the webhook handler set `email_opt_out = true` globally, regardless of what they actually opted out of. This meant a member opting out of marketing emails would also stop receiving their milestone recognition and compliance notices. That's both legally problematic (compliance emails should always reach members) and a product failure (recognition is a feature members value).

Third, the webhook handler had a secondary bug: when processing a plain unsubscribe event, it was setting *both* `email_opt_out = true` and `marketing_opt_out = true` simultaneously. These should be independent signals. Global opt-out means "don't email me at all." Category opt-out means "don't email me this type." Setting both conflated the two and made the data unreliable.

Fourth, the staff-facing unsubscribe management page had a SQL injection vulnerability. The search term, the sort column, the sort direction, the page size, and the offset were all interpolated directly into raw SQL strings. The single-quote escaping (`replace(/'/g, "''")`) that was supposed to protect the search term was insufficient. An authenticated staff user — or a compromised session — could have manipulated the `sortBy` query parameter to inject arbitrary SQL. The ORDER BY injection is particularly dangerous because it doesn't require quotes to exploit.

Fifth, there was no visibility into suppression health. When emails were blocked by suppression, there was no feedback to staff — no indication of how many recipients were excluded, no campaign-level record of suppressions, no system-level health monitoring. Staff had no way to know whether suppression was working correctly or silently failing.

**What was fixed and why each decision was made:**

*email_address as the universal suppression key:* The core architectural decision was to make email_address the primary key on `member_email_preferences` and the single lookup key for all suppression checks. This is correct because email address is the actual delivery mechanism. It doesn't matter what member_key a record has — if we can't send to that email address, we don't send. `member_key` is retained as an optional indexed column so member-linked records can be looked up by member, but it is never the suppression key. The `canSendToRecipient` function queries by email-only when no memberKey is present, with no `OR member_key = ''` fallback.

*Category-aware suppression:* Per-category opt-out columns (`marketing_opt_out`, `recognition_opt_out`) were already in the schema but weren't being set correctly. The webhook fix routes `group_unsubscribe` events to the correct column based on the `asm_group_id` in the SendGrid payload, matched against four group IDs stored in `tenant_config` (marketing: 366438, recognition: 366439, compliance: 366440, transactional: 366441). Compliance and transactional group unsubscribes are logged but never applied as suppression — those categories are required and members cannot opt out. Plain `unsubscribe` events (no group context) set `email_opt_out = true` only — never `marketing_opt_out`. Global opt-out and category opt-out are independent signals and must stay that way.

*SQL injection fix:* The entire `GET /api/smartsends/unsubscribes` handler was replaced with a parameterized version using Drizzle's `sql` tagged template. Search terms are passed as parameterized values. Sort column is validated against a whitelist (`allowedSortColumns` map) before use — unknown values fall back to `opted_out_date`. `sql.raw()` is used only for the ORDER BY clause, which is now constructed entirely from whitelisted values, never from raw user input. LIMIT and OFFSET are parameterized values.

*Suppression visibility:* The send toast now reports how many recipients were excluded and why (opted out vs. no email address). The campaign detail page shows an amber banner when `skipped_count > 0`. The queue processor logs distinguish between sandbox skips, governor throttles, opt-out suppressions, and hard bounce skips. `getSuppressionHealthStatus()` provides a 24-hour rolling window with a degraded threshold at 10+ failures, surfaced in `GET /api/admin/usage`.

**What remains incomplete (known gaps):**

- Hard bounce exclusions are not yet counted separately in the send toast or campaign detail banner. Documented in Parking Lot Section 2.
- The Email Governor does not apply to non-member (external contact) recipients. Item 4 addresses this.
- The resubscribe path (`group_resubscribe` events) is handled in the webhook but has not been tested with real member data — only one test account was available during development.

**Final codebase verification (March 11, before closing Replit):**

A search of all `.ts` files confirmed zero remaining instances of `OR member_key = ''`. The only references to this pattern exist in spec documents describing the problem. The live `canSendToRecipient` function in `emailService.ts` (lines 407–434) uses the correct pattern: queries by `email_address` first, falls back to `member_key` only when truthy. The old broken pattern is fully gone from the codebase.

### Current Architecture — Canonical State

**Suppression key:** `email_address` is the PK on `member_email_preferences`. All suppression lookups use email address. `member_key` is an optional indexed column, never the lookup key.

**UPSERT pattern:** All webhook writes use `ON CONFLICT (email_address)` — never plain INSERT. Duplicate events from SendGrid will update the existing row, not fail or create duplicates.

**Never delete opt-out rows:** Rows with `migration_status = 'unresolved'` stay in place. Hard bounce suppressions are permanent — staff cannot reverse them through the UI.

**Category opt-outs:**
- `marketing_opt_out` — set by `group_unsubscribe` for sg_group_marketing (366438)
- `recognition_opt_out` — set by `group_unsubscribe` for sg_group_recognition (366439)
- Compliance (366440) and Transactional (366441) — log only, no suppression applied
- Plain `unsubscribe` (no asm_group_id) — sets `email_opt_out = true` ONLY
- Unknown group ID — falls back to global `email_opt_out` with warning log

**`emailCategory` required:** Every campaign record must have an emailCategory. No nulls. This flows from the client through the campaignData payload to `queueEmailCampaign()` — client-side derivation is insufficient.

**Governor exemptions:** transactional, compliance, critical, recognition.

**Suppression health:** `getSuppressionHealthStatus()` — 24h rolling window, degraded threshold at 10+ failures. Surfaced in `GET /api/admin/usage` as `suppression_health`.

**Key files:**
- `server/services/emailService.ts` — `canSendToMember`, `canSendToRecipient`, `queueEmailCampaign`, `processEmailQueue`
- `shared/schema.ts` — `member_email_preferences` table definition (email_address as PK)
- `server/routes.ts` — webhook handler (~line 5780), staff unsubscribe endpoint (~line 10714)

---

## 10. The 30 Standing Rules

### ⛔ Rules 28–30 are absolute. Never violate them under any circumstances.

### Architecture & Data
1. No parallel systems — extend existing components, never build duplicate implementations
2. Don't break what works — verify before and after every change
3. Full-page patterns, not modals, for multi-step tasks
4. Shared components over duplicates
5. Server-side for anything touching more than 1,000 records
6. Test your work — happy path and at least one edge case before reporting complete

### UI & Language
7. "Recognition" in UI everywhere — "Celebration" in code only
8. Email category is required on all campaigns — no null categories
9. Governor exemptions are: transactional, compliance, critical, recognition
10. Campaign Architect replaces drip sequence builder — no parallel UI
11. AI suggestions are always actionable (yes/no) — never configuration forms
12. Competitive intelligence queries must respect tenant isolation — no cross-client data leakage
13. No fake data. Ever. Real member data or clearly labeled sample data only
14. Every module gated by tenant_config — disabled = not rendered, no background jobs, no AI budget
15. The 5% rule — build what clients asked for or dreamed about, not what sounds good in a roadmap
16. Mobile-first, performance-always — responsive UI, under 2 seconds load time
17. CLAUDE.md is the single source of truth for the production repository
18. Every scoring signal must pass the 100% Coverage Test before inclusion

### Process
19. Complete prompts sequentially — do not batch all changes and deploy simultaneously
20. Spec-first development — implement exactly what is specified, no more and no less

### Campaign Architect
21. Social proof is never used in Campaign Architect emails — no attendance numbers, no testimonials
22. Minimum 3 emails per event in any Campaign Architect sequence
23. Campaign Architect branch points are shallow — registration status and prior attendance only

### Navigation
24. Recognition is a top-level nav module — never nest inside SmartSends
25. Nav items are destinations — actions live in buttons

### AI & Email
26. Every email sent must be real and verifiable — no hallucinated data, no invented member details
27. Every AI call must be logged — every AI feature must have a rate limit and a kill switch

### ⛔ Absolute — Never Violate
28. ⛔ DO NOT modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts` for any reason
29. ⛔ When refactoring a function called by those files, keep the original function name as a thin wrapper — never update call sites in those files
30. ⛔ Before any change to a table's primary key or core identifier, search the entire codebase for every reference and report the complete list first. Applies especially to: `member_email_preferences`, `email_campaigns`, `member_metrics_cache`, `triggered_campaigns`

---

## 11. Architectural Decisions — Canonical

### Database
- Single PostgreSQL database in production (two-database Replit setup is a safety workaround only)
- Cache-first: `member_metrics_cache` is single source of truth for member data at scale
- Every query against AMS/MLS tables must deduplicate via `ROW_NUMBER() OVER (PARTITION BY ...)`
- Snapshot deduplication is non-negotiable — no exceptions

### Multi-Tenant
- Multi-tenant isolation is a critical gap in Replit prototype (only 1 of 20+ tables has client_id)
- Production port must have proper multi-tenant architecture from day one
- Stage 0: single `tenant_config` row drives scoring, UI visibility, AI prompts, and compliance panels

### Campaign Architect
- `anchorOffset` + `anchorDirection` replace `delayDays` — never negative values
- `saveAudience` accepts metadata in single INSERT
- Audience accumulation cleanup between campaigns
- Rate limiter is in-memory (per-process) — must move to Redis for multi-instance production

### MemberKey Format
- AMS keys: no prefix (e.g., 259036)
- MLS keys: MRD prefix (e.g., MRD259036)
- Join pattern: `'MRD' || ams_key = mls_key`
- MRD prefix is Mainstreet-specific — must become configurable per client in `tenant_config`

### AI Model Selection
- Claude Sonnet: complex queries (AI Chat, Audience Builder, Campaign Architect)
- Claude Haiku: short-form variations (subject line alternatives, short copy)
- One Anthropic API key for all clients — Membio controls all AI usage, cost visibility, rate limits

---

## 12. Known Issues & Technical Debt

### Critical Production Blockers
- `routes.ts` is ~10,900 lines — monolith must be split by dev team
- No multi-tenant data isolation — only `users` table has `client_id`; 19+ tables missing it
- 110+ hardcoded 'MainStreet' references — must become `tenant_config` in production
- Illinois-specific compliance hardcoded — HGAR/GRAR need NY rules

### Important Before Mainstreet Goes Live
- Item 4: Governor not applied to non-member (external) recipients — prompt to write
- CLAUDE.md comprehensive update — overdue, dev team waiting
- `MAX_CAMPAIGN_RECIPIENTS = 1` — needs bumping for real sends
- AI Chat UI: no suggested starters, no conversation history sidebar
- Date range picker missing from Email Archive UI (backend supports it)
- 172-member gap between dashboard count and member type builder count

### Technical Debt (Parking Lot)
- Campaign Architect rate limiter is per-process in-memory — needs Redis for multi-instance
- Missing event warning at activation when anchor event has been removed
- Drip Sequence Step Editor needs proper EmailComposer integration
- Templates system needs full rework
- Hard bounce exclusions not surfaced in send toast or campaign detail banner
- Revenue data uses catalog prices, not actual invoiced amounts

---

## 13. Key Files Reference

**⛔ Sensitive — Handle With Extreme Care:**
- `server/services/triggeredCampaignProcessor.ts` — DO NOT MODIFY for any reason
- `server/services/sequenceEnrollmentService.ts` — DO NOT MODIFY without explicit written instruction

**Key Application Files:**

| File | Purpose |
|---|---|
| `server/routes.ts` | Monolith (~10,900 lines) |
| `shared/schema.ts` | All tables and TypeScript types |
| `server/services/emailService.ts` | All outbound email; canSendToMember wrapper |
| `server/services/triggeredCampaignProcessor.ts` | ⛔ DO NOT MODIFY |
| `server/services/sequenceEnrollmentService.ts` | ⛔ DO NOT MODIFY |
| `client/src/pages/CampaignArchitect.tsx` | Campaign Architect UI (~1,834 lines) |
| `server/services/aiCampaignPlannerService.ts` | Campaign Architect planner |
| `client/src/pages/SendEmail.tsx` | Email send flow |
| `client/src/components/layout/AppSidebar.tsx` | Navigation |
| `server/services/clientConfig.ts` | All client-specific values (must become tenant_config) |
| `server/services/memberMetricsCacheService.ts` | Engagement scoring engine |

---

## 14. AEI Demo Plan

**AEI Conference, Minneapolis — March 23–26. RESO Conference — April 21–23.**
Priority is solid software, not demo pressure. AEI is an opportunity; clean architecture is the goal.

### Demo Path (3–5 minutes)
1. **AI Chat** — natural language query returning real member data with analyst-style follow-up suggestions
2. **Campaign Architect** — type one goal sentence, watch AI build a complete campaign, activate
3. **Member Recognition** — show a milestone approval and personalized email preview
4. **Dashboard** — Association Pulse cards, engagement scores, real member data

### Must Be Working Cleanly Before Travel
- ✅ Campaign Architect: end-to-end, verified, no rough edges
- ✅ Suppression hardening: all items complete
- ✅ Navigation: clean, no broken links
- ✅ Dashboard: Association Pulse cards showing real data
- ✅ Recognition Queue: working
- ✅ Engagement and Retention 'Coming Soon' labels visible in nav

---

*MemberSync Project Summary · March 11, 2026 (Evening) · Confidential — Membio*

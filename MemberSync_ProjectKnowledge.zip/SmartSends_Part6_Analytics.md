# SmartSends: Analytics & Production Profile

This prompt adds the Analytics section to SmartSends - office and agent leaderboards, visit prep tools, and printable PDF briefs.

**Prerequisites:** This should be implemented AFTER the Performance Fixes & Celebration Engine prompt (Parts 1-5), as it depends on the member_metrics_cache and member_milestones tables.

---

# PART 6: ANALYTICS / PRODUCTION PROFILE

## The Business Need

Mainstreet executives need data-driven insights to make decisions about office visits and member engagement. The data reveals stark realities:

**Key Findings from 2025 Data:**
- **2,688 active offices** with 20,823 active agents
- **70% of total production** comes from just **145 offices** (5.4% of offices)
- **1,035 offices have ZERO transactions** (38.5% of offices with 1,413 agents)
- **Top 10 offices** generate 16.6% of all volume
- The production gap between top performers and the rest is enormous

This information helps staff prepare for office visits, identify at-risk offices, and celebrate high performers.

## New Navigation Item

Add "Analytics" or "Production Profile" to the left navigation, containing:
1. **Executive Dashboard** - High-level market overview
2. **Office Leaderboard** - Ranked list of offices by production
3. **Agent Leaderboard** - Top producing agents
4. **Office Profile** - Deep dive into any office (for visit prep)
5. **Market Concentration** - Understanding production distribution

## Database: Pre-computed Analytics Tables

### office_production_cache (daily refresh)
```sql
CREATE TABLE office_production_cache (
  office_key TEXT PRIMARY KEY,
  office_name TEXT NOT NULL,
  office_status TEXT,
  broker_key TEXT,
  broker_name TEXT,
  
  -- Agent counts
  active_agents INTEGER DEFAULT 0,
  inactive_agents INTEGER DEFAULT 0,
  total_agents INTEGER DEFAULT 0,
  
  -- Production metrics (12 months)
  transaction_sides INTEGER DEFAULT 0,
  production_volume NUMERIC DEFAULT 0,
  avg_volume_per_transaction NUMERIC DEFAULT 0,
  listing_sides INTEGER DEFAULT 0,
  buyer_sides INTEGER DEFAULT 0,
  
  -- Rankings
  rank_by_volume INTEGER,
  rank_by_transactions INTEGER,
  rank_by_agent_count INTEGER,
  
  -- Market share
  pct_of_total_volume NUMERIC DEFAULT 0,
  cumulative_pct_volume NUMERIC DEFAULT 0,
  
  -- Productivity metrics
  avg_transactions_per_agent NUMERIC DEFAULT 0,
  avg_volume_per_agent NUMERIC DEFAULT 0,
  
  -- Top performers in office
  top_agent_key TEXT,
  top_agent_name TEXT,
  top_agent_volume NUMERIC DEFAULT 0,
  
  -- Year-over-year comparison
  volume_12mo_prior NUMERIC DEFAULT 0,
  volume_change_pct NUMERIC DEFAULT 0,
  
  -- Engagement indicators
  agents_with_overdue_invoices INTEGER DEFAULT 0,
  avg_engagement_score NUMERIC DEFAULT 0,
  
  cached_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_office_prod_rank_volume ON office_production_cache(rank_by_volume);
CREATE INDEX idx_office_prod_rank_tx ON office_production_cache(rank_by_transactions);
CREATE INDEX idx_office_prod_status ON office_production_cache(office_status);
```

### agent_production_cache (daily refresh)
```sql
CREATE TABLE agent_production_cache (
  member_key TEXT PRIMARY KEY,
  member_mls_id TEXT,
  member_name TEXT NOT NULL,
  member_email TEXT,
  office_key TEXT,
  office_name TEXT,
  member_status TEXT,
  
  -- Production metrics (12 months)
  transaction_sides INTEGER DEFAULT 0,
  production_volume NUMERIC DEFAULT 0,
  listing_sides INTEGER DEFAULT 0,
  buyer_sides INTEGER DEFAULT 0,
  avg_price NUMERIC DEFAULT 0,
  
  -- Rankings
  rank_by_volume INTEGER,
  rank_by_transactions INTEGER,
  rank_within_office INTEGER,
  
  -- Market share
  pct_of_total_volume NUMERIC DEFAULT 0,
  pct_of_office_volume NUMERIC DEFAULT 0,
  
  -- Specialization
  primary_property_type TEXT,
  primary_city TEXT,
  luxury_transactions INTEGER DEFAULT 0,  -- $1M+
  
  -- Year-over-year
  volume_12mo_prior NUMERIC DEFAULT 0,
  volume_change_pct NUMERIC DEFAULT 0,
  
  -- Career totals
  career_transactions INTEGER DEFAULT 0,
  career_volume NUMERIC DEFAULT 0,
  
  -- Tenure
  nar_join_date DATE,
  years_as_member NUMERIC DEFAULT 0,
  
  cached_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_agent_prod_rank_volume ON agent_production_cache(rank_by_volume);
CREATE INDEX idx_agent_prod_office ON agent_production_cache(office_key);
CREATE INDEX idx_agent_prod_status ON agent_production_cache(member_status);
```

### market_concentration_cache (daily refresh)
```sql
CREATE TABLE market_concentration_cache (
  threshold_pct INTEGER PRIMARY KEY,  -- 70, 80, 90, 95
  cutoff_rank INTEGER,
  office_count INTEGER,
  production_share_pct NUMERIC,
  agent_count INTEGER,
  membership_share_pct NUMERIC,
  cached_at TIMESTAMP DEFAULT NOW()
);
```

## API Endpoints

### Executive Dashboard
```typescript
// GET /api/analytics/dashboard
app.get("/api/analytics/dashboard", authMiddleware, async (req, res) => {
  try {
    // Market overview
    const overview = await localPool.query(`
      SELECT 
        COUNT(*) as total_offices,
        COUNT(*) FILTER (WHERE transaction_sides > 0) as producing_offices,
        COUNT(*) FILTER (WHERE transaction_sides = 0) as zero_production_offices,
        SUM(active_agents) as total_active_agents,
        SUM(transaction_sides) as total_transactions,
        SUM(production_volume) as total_volume,
        AVG(avg_transactions_per_agent) FILTER (WHERE transaction_sides > 0) as avg_productivity
      FROM office_production_cache
      WHERE office_status = 'Active'
    `);
    
    // Concentration data
    const concentration = await localPool.query(`
      SELECT * FROM market_concentration_cache ORDER BY threshold_pct
    `);
    
    // Top 10 offices
    const topOffices = await localPool.query(`
      SELECT office_key, office_name, active_agents, transaction_sides, 
             production_volume, pct_of_total_volume, rank_by_volume
      FROM office_production_cache
      WHERE office_status = 'Active'
      ORDER BY rank_by_volume
      LIMIT 10
    `);
    
    // Top 10 agents
    const topAgents = await localPool.query(`
      SELECT member_key, member_name, office_name, transaction_sides,
             production_volume, pct_of_total_volume, rank_by_volume
      FROM agent_production_cache
      WHERE member_status = 'Active'
      ORDER BY rank_by_volume
      LIMIT 10
    `);
    
    res.json({
      overview: overview.rows[0],
      concentration: concentration.rows,
      topOffices: topOffices.rows,
      topAgents: topAgents.rows
    });
  } catch (error) {
    console.error("Analytics dashboard error:", error);
    res.status(500).json({ message: "Failed to fetch analytics" });
  }
});
```

### Office Leaderboard
```typescript
// GET /api/analytics/offices
app.get("/api/analytics/offices", authMiddleware, async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 50,  // Options: 50, 100, 250
      sortBy = 'rank_by_volume',
      sortOrder = 'asc',
      filter = 'all'  // 'all', 'producing', 'zero_production'
    } = req.query;
    
    const offset = (Number(page) - 1) * Number(limit);
    
    let whereClause = "WHERE office_status = 'Active'";
    if (filter === 'producing') whereClause += " AND transaction_sides > 0";
    if (filter === 'zero_production') whereClause += " AND transaction_sides = 0";
    
    const validSortColumns = ['rank_by_volume', 'rank_by_transactions', 'active_agents', 'production_volume', 'avg_transactions_per_agent', 'office_name'];
    const sortColumn = validSortColumns.includes(sortBy as string) ? sortBy : 'rank_by_volume';
    const order = sortOrder === 'desc' ? 'DESC' : 'ASC';
    
    const [countResult, dataResult] = await Promise.all([
      localPool.query(`SELECT COUNT(*) FROM office_production_cache ${whereClause}`),
      localPool.query(`
        SELECT * FROM office_production_cache
        ${whereClause}
        ORDER BY ${sortColumn} ${order} NULLS LAST
        LIMIT $1 OFFSET $2
      `, [limit, offset])
    ]);
    
    res.json({
      data: dataResult.rows,
      total: parseInt(countResult.rows[0].count),
      page: Number(page),
      limit: Number(limit)
    });
  } catch (error) {
    console.error("Office leaderboard error:", error);
    res.status(500).json({ message: "Failed to fetch offices" });
  }
});
```

### Agent Leaderboard
```typescript
// GET /api/analytics/agents
app.get("/api/analytics/agents", authMiddleware, async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 50,
      sortBy = 'rank_by_volume',
      sortOrder = 'asc',
      officeKey = null
    } = req.query;
    
    const offset = (Number(page) - 1) * Number(limit);
    
    let whereClause = "WHERE member_status = 'Active' AND transaction_sides > 0";
    if (officeKey) whereClause += ` AND office_key = '${officeKey}'`;
    
    const validSortColumns = ['rank_by_volume', 'rank_by_transactions', 'production_volume', 'transaction_sides', 'member_name'];
    const sortColumn = validSortColumns.includes(sortBy as string) ? sortBy : 'rank_by_volume';
    const order = sortOrder === 'desc' ? 'DESC' : 'ASC';
    
    const [countResult, dataResult] = await Promise.all([
      localPool.query(`SELECT COUNT(*) FROM agent_production_cache ${whereClause}`),
      localPool.query(`
        SELECT * FROM agent_production_cache
        ${whereClause}
        ORDER BY ${sortColumn} ${order} NULLS LAST
        LIMIT $1 OFFSET $2
      `, [limit, offset])
    ]);
    
    res.json({
      data: dataResult.rows,
      total: parseInt(countResult.rows[0].count),
      page: Number(page),
      limit: Number(limit)
    });
  } catch (error) {
    console.error("Agent leaderboard error:", error);
    res.status(500).json({ message: "Failed to fetch agents" });
  }
});
```

### Office Profile (Visit Prep)
```typescript
// GET /api/analytics/offices/:officeKey/profile
// This endpoint provides everything staff needs before an office visit
app.get("/api/analytics/offices/:officeKey/profile", authMiddleware, async (req, res) => {
  try {
    const { officeKey } = req.params;
    
    // Office overview
    const office = await localPool.query(`
      SELECT * FROM office_production_cache WHERE office_key = $1
    `, [officeKey]);
    
    if (office.rows.length === 0) {
      return res.status(404).json({ message: "Office not found" });
    }
    
    // Top agents in office
    const topAgents = await localPool.query(`
      SELECT member_key, member_name, member_email, transaction_sides,
             production_volume, rank_within_office, years_as_member
      FROM agent_production_cache
      WHERE office_key = $1 AND member_status = 'Active'
      ORDER BY rank_within_office
      LIMIT 20
    `, [officeKey]);
    
    // Agents needing attention (at-risk)
    const atRiskAgents = await localPool.query(`
      SELECT m.member_key, m.member_name, m.risk_level, m.has_overdue_invoice, m.days_overdue
      FROM member_metrics_cache m
      WHERE m.office_key = $1 
        AND m.member_status = 'Active'
        AND (m.risk_level IN ('critical', 'high') OR m.has_overdue_invoice = true)
      ORDER BY m.days_overdue DESC NULLS LAST
      LIMIT 20
    `, [officeKey]);
    
    // Recent milestones/kudos for this office
    const recentCelebrations = await localPool.query(`
      SELECT * FROM (
        SELECT milestone_id as id, 'milestone' as type, member_name, milestone_label as title, 
               milestone_emoji as emoji, detected_at as date
        FROM member_milestones
        WHERE office_key = $1 AND detected_at >= NOW() - INTERVAL '90 days'
        UNION ALL
        SELECT kudos_id as id, 'kudos' as type, member_name, title,
               CASE kudos_type WHEN 'community_service' THEN 'ðŸ ' WHEN 'award' THEN 'ðŸ†' ELSE 'â­' END as emoji,
               created_at as date
        FROM member_kudos
        WHERE office_key = $1 AND created_at >= NOW() - INTERVAL '90 days'
      ) combined
      ORDER BY date DESC
      LIMIT 10
    `, [officeKey]);
    
    // Office compared to peers (similar size)
    const agentCount = office.rows[0].active_agents;
    const peerComparison = await localPool.query(`
      SELECT 
        AVG(transaction_sides) as avg_transactions,
        AVG(production_volume) as avg_volume,
        AVG(avg_transactions_per_agent) as avg_productivity
      FROM office_production_cache
      WHERE office_status = 'Active'
        AND active_agents BETWEEN $1 * 0.5 AND $1 * 1.5
        AND office_key != $2
    `, [agentCount, officeKey]);
    
    res.json({
      office: office.rows[0],
      topAgents: topAgents.rows,
      atRiskAgents: atRiskAgents.rows,
      recentCelebrations: recentCelebrations.rows,
      peerComparison: peerComparison.rows[0]
    });
  } catch (error) {
    console.error("Office profile error:", error);
    res.status(500).json({ message: "Failed to fetch office profile" });
  }
});
```

## UI Components

### Executive Dashboard Card
Shows at-a-glance metrics:
- Total production volume (with YoY comparison)
- Transaction count
- Producing vs. non-producing offices
- Market concentration visual (70% from top 145 offices)

### Office Leaderboard Table
Columns:
- Rank
- Office Name
- Active Agents
- Transaction Sides
- Production Volume
- % of Total Volume
- Avg per Agent
- YoY Change

Features:
- Pagination: 50, 100, 250 per page
- Sortable columns
- Filter: All / Producing / Zero Production
- Click office name â†’ Office Profile

### Agent Leaderboard Table
Columns:
- Rank
- Agent Name
- Office
- Transaction Sides
- Volume
- % of Total
- Specialization
- Years Member

Features:
- Pagination: 50, 100, 250 per page
- Sortable columns
- Filter by office (dropdown)
- Click agent name â†’ Member Profile

### Office Profile (Visit Prep Page)
Sections:
1. **Header** - Office name, rank, broker name
2. **Key Metrics** - Volume, transactions, agents, productivity
3. **Peer Comparison** - How they compare to similar-sized offices
4. **Top Agents** - List of top performers
5. **Needs Attention** - At-risk agents, overdue invoices
6. **Recent Celebrations** - Milestones and kudos from this office
7. **Quick Actions** - "Email Broker", "Email All Agents", "Add Kudos", **"Generate Visit Brief (PDF)"**

### Office Visit Brief (PDF Export)

A printable PDF that staff can bring to office visits. Generated from the Office Profile page.

**PDF Options Dialog:**
- â˜‘ï¸ Office Overview (Page 1) - Always included
- â˜‘ï¸ Agents & Recognition (Page 2) - Always included
- â˜ Outstanding Invoices (Page 3) - Optional, separate document

**Branding:**
- Include the Mainstreet REALTORSÂ® logo in the top-right corner of each page
- Logo file: `Mainstreet_logo_RGB.png` (already in project assets)
- Font: **Overpass** (Google Font - https://fonts.google.com/specimen/Overpass)
- Text color: **Black** (#000000)
- Brand colors for accents only: Purple (#5B4B8A) and Teal (#2A9D8F)

**Page 1: Office Overview**
```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  OFFICE VISIT BRIEF                          [Mainstreet Logo]  â”‚
â”‚  [Office Name]                                                  â”‚
â”‚  Generated: [Date]                                              â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                                                                 â”‚
â”‚  QUICK FACTS                                                    â”‚
â”‚  Rank: #X of 2,688 offices       Broker: [Name]                â”‚
â”‚  Active Agents: XXX              Market Share: X.XX%           â”‚
â”‚                                                                 â”‚
â”‚  PRODUCTION (Last 12 Months)                                    â”‚
â”‚  Total Volume:        $XXX,XXX,XXX                             â”‚
â”‚  Transaction Sides:   X,XXX                                     â”‚
â”‚  Avg per Transaction: $XXX,XXX                                 â”‚
â”‚  Avg per Agent:       X.X sides / $X.XXM                       â”‚
â”‚                                                                 â”‚
â”‚  PEER COMPARISON (similar-sized offices)                        â”‚
â”‚  Their Productivity:  X.X sides/agent                          â”‚
â”‚  Peer Average:        X.X sides/agent        â–²/â–¼ XX% vs peers  â”‚
â”‚                                                                 â”‚
â”‚  YEAR OVER YEAR                                                 â”‚
â”‚  Volume Change:       +/-XX.X% vs prior year                   â”‚
â”‚  Agent Change:        +/-XX agents                             â”‚
â”‚                                                                 â”‚
â”‚  ATTENTION ITEMS                                                â”‚
â”‚  âš  X agents with overdue invoices ($X,XXX total)              â”‚
â”‚  âš  X agents at high lapse risk                                 â”‚
â”‚                                                                 â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Page 2: Agents & Recognition**
```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  OFFICE VISIT BRIEF (continued)                   [Office Name] â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                                                                 â”‚
â”‚  TOP 10 PRODUCERS                                               â”‚
â”‚   #  Agent Name          Sides   Volume        Specialty        â”‚
â”‚   1  [Name]                XX    $XX.XM        [Type]           â”‚
â”‚   2  [Name]                XX    $XX.XM        [Type]           â”‚
â”‚   ...                                                           â”‚
â”‚                                                                 â”‚
â”‚  RECENT CELEBRATIONS ðŸŽ‰                                         â”‚
â”‚  â€¢ [Name] - [Achievement] ([Date])                             â”‚
â”‚  â€¢ [Name] - [Achievement] ([Date])                             â”‚
â”‚  â€¢ [Name] - [Achievement] ([Date])                             â”‚
â”‚                                                                 â”‚
â”‚  NEEDS ATTENTION                                                â”‚
â”‚  Agent              Issue                    Days Overdue       â”‚
â”‚  [Name]             [Issue description]      XX days            â”‚
â”‚  [Name]             [Issue description]      XX days            â”‚
â”‚                                                                 â”‚
â”‚  TALKING POINTS                                                 â”‚
â”‚  âœ“ [Auto-generated based on celebrations]                      â”‚
â”‚  âœ“ [Auto-generated based on achievements]                      â”‚
â”‚  âœ“ [Auto-generated based on attention items]                   â”‚
â”‚                                                                 â”‚
â”‚  Prepared by SmartSends | Mainstreet REALTORSÂ®                  â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Page 3: Outstanding Invoices (Separate Document)**

A professional, factual summary of unpaid invoices that can be printed separately and handed to the Designated REALTORÂ® privately.

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  OUTSTANDING INVOICES                        [Mainstreet Logo]  â”‚
â”‚  [Office Name]                                                  â”‚
â”‚  As of: [Date]                                                  â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                                                                 â”‚
â”‚  OFFICE ACCOUNT                                                 â”‚
â”‚  Invoice #    Description              Due Date    Amount Due   â”‚
â”‚  â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€  â”‚
â”‚  [INV-#]      [Description]            [Date]      $X,XXX.XX   â”‚
â”‚               Late Fee:                            $XXX.XX      â”‚
â”‚                                        Subtotal:   $X,XXX.XX   â”‚
â”‚                                                                 â”‚
â”‚  AGENT ACCOUNTS                                                 â”‚
â”‚                                                                 â”‚
â”‚  [Agent Name]                                                   â”‚
â”‚  Invoice #    Description              Due Date    Amount Due   â”‚
â”‚  â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€  â”‚
â”‚  [INV-#]      [Description]            [Date]      $XXX.XX     â”‚
â”‚               Late Fee:                            $XX.XX       â”‚
â”‚                                        Subtotal:   $XXX.XX     â”‚
â”‚                                                                 â”‚
â”‚  [Repeat for each agent with outstanding invoices]              â”‚
â”‚                                                                 â”‚
â”‚  â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•  â”‚
â”‚  SUMMARY                                                        â”‚
â”‚  Office Account:                                   $X,XXX.XX   â”‚
â”‚  Agent Accounts (X agents):                        $X,XXX.XX   â”‚
â”‚                                        TOTAL:      $X,XXX.XX   â”‚
â”‚                                                                 â”‚
â”‚  Questions? Call Customer Service: (630) 324-8400               â”‚
â”‚  Payment portal: mainstreet.membio.com                          â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Design principles for the invoices page:**
- Professional, factual tone - no accusatory language
- Just the facts: invoice number, description, due date, amount, late fees
- Office invoices listed first (broker's direct responsibility)
- Agent invoices grouped by agent name
- Clear totals at bottom
- Contact information for questions (phone) and payments (portal)
- Can be printed separately and handed to broker discreetly

**API Endpoint for PDF Generation:**
```typescript
// POST /api/analytics/offices/:officeKey/visit-brief
app.post("/api/analytics/offices/:officeKey/visit-brief", authMiddleware, async (req, res) => {
  const { officeKey } = req.params;
  const { includeInvoices = false } = req.body;
  
  // Gather all data needed for the PDF
  // Generate PDF using a library like PDFKit or Puppeteer
  // Return PDF file or separate files if invoices requested
});
```

### Market Concentration Visual
A simple chart showing:
- "145 offices (5%) produce 70% of volume"
- "1,035 offices (39%) have zero production"

This provides instant context about the market reality.

## Daily Jobs Schedule (Updated)

| Time | Job | Description |
|------|-----|-------------|
| 3:30 AM | **Office Production Cache** | Calculate office rankings and metrics |
| 3:45 AM | **Agent Production Cache** | Calculate agent rankings and metrics |
| 4:00 AM | Member Metrics Cache | Refresh engagement metrics |
| 4:15 AM | Office Metrics Cache | Refresh office health metrics |
| 4:30 AM | Milestone Detection | Detect celebrations |
| 4:45 AM | **Market Concentration** | Calculate 70/80/90/95 thresholds |
| 5:00 AM | Activity Cache Refresh | Pull education/events |
| 6:00 AM | Member Status Capture | Detect status changes |
| 7:00 AM | Risk Score Calculation | Calendar-aware risk |
| 8:00 AM | Office Health Calculation | Office payment metrics |

## Important Note: Member Limits and Pagination

The 1,000 member limit in the AI audience builder is a safety guardrail for preview queries, NOT a hard cap on audience size. Here's how limits should work across different contexts:

| Context | Limit | Reasoning |
|---------|-------|-----------|
| AI-generated audience **preview** | 1,000 | Quick preview while building query |
| **Saved audience** for email campaign | No limit | Campaign needs ALL matching members |
| Member/Office list screens | **Paginated** | User selects 50, 100, or 250 per page |
| Dashboard metrics/counts | No limit | Show accurate totals (e.g., "3,847 members match") |
| CSV export | No limit | Staff needs complete data |

**Pagination for Member and Office Lists:**

The member list and office list screens should be paginated with user-selectable page sizes:
- **50 rows** (default) - fastest loading
- **100 rows** - balanced
- **250 rows** - for power users who want to scroll more

Staff should be able to browse through all 18,000+ members by paging, not be artificially capped at 1,000.

**Why this matters:** With the new `member_metrics_cache` table, querying pre-computed data is fast. The 1,000 limit was more critical when every request hit production with complex joins. Now we can be more generous while keeping previews snappy.


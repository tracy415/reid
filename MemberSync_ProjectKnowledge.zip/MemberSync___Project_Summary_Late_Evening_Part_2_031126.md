# MemberSync — Project Summary

## March 11, 2026 (Late Evening)

⛔ CRITICAL — DEV TEAM CODEBASE WARNING: The dev team pulled a Replit snapshot on March 10\. That snapshot does NOT include the major email infrastructure stability and security corrections made on March 10–11 (suppression hardening, webhook fixes, recipient tracking, unsubscribe architecture). **The 3/10 code is incomplete and must NOT be used as the foundation going forward**. The correct baseline is the Replit codebase from March 12 onward. 

**Mike and Dale must pull a fresh snapshot from Replit on 3/12 and merge accordingly before any further production work.** 

**After 10 a.m. PT on 3/12, Tracy will not touch Replit again, and all further development will take place in Claude Code once Mike and Dale establish procedures and process.**

---

## ⛔ NON-NEGOTIABLE: ROCK SOLID SOFTWARE FIRST

**This must be read and internalized before any other instruction in this document.**

We are building production-worthy software. Full stop. AEI is an opportunity — not a mandate to cut corners.

**The following are flat nos, under any circumstances, for any reason, including AEI:**

- Shortcuts  
- Technical debt  
- Dead code  
- Missing documentation or poor documentation  
- Any compromise to architecture, data integrity, or code quality

AEI will show whatever Tracy's branch in Claude Code contains at that point in time. That is what it will be. The demo adapts to the software — the software does not bend to the demo.

If a feature isn't ready and solid, it doesn't get shown. That is not a problem. That is discipline.

**Claude's standing instruction:** If any prompt, request, or suggestion would incur technical debt, leave dead code, skip documentation, or shortcut architecture to hit a demo deadline — flag it immediately and refuse to write it that way. There are no exceptions to this rule.

---

## IMPORTANT: HOW TO USE THIS DOCUMENT

This summary picks up where `MemberSync_Project_Summary_Mar11_2026_Evening.md` left off. Read that document first for foundational context (roles, product philosophy, client pipeline, what's built, standing rules, key files). This document captures everything that happened in the session that followed — decisions made, documents produced, and what's next.

**Do not skip the prior summary.** The two documents together are the complete picture.

---

## WHAT HAPPENED THIS SESSION

### Primary Deliverable: Membio Admin Panel Specification v2

The major work of this session was designing and writing a comprehensive product specification for the Membio Admin Panel. This document had been accumulating as scattered decisions across many previous sessions — this session consolidated it into a single authoritative reference.

**File:** `MemberSync_AdminPanel_Spec_v2.md` — in project knowledge and outputs.

Tracy reviewed the spec section by section, added comments, and we discussed every one before updating the document. The v2 incorporates all feedback. Do not use v1.

The spec covers:

- Three access levels (Membio Super-Admin / Client Admin / Client Staff)  
- Part 1: Membio Super-Admin Panel (client roster, AI usage dashboard, SendGrid health, data health monitor, tenant config editor, AI business context seeding, support & impersonation, billing overview)  
- Part 2: Client-facing account & settings (account settings, user management, AI Settings / RAG memory, competitive intelligence configuration)  
- Part 3: Compliance module architecture, template design philosophy, self-service onboarding (deferred), future capabilities  
- Open questions (3 remaining — see below)

---

## ARCHITECTURAL & PRODUCT DECISIONS MADE THIS SESSION

These decisions must carry forward into all future work. They are not in CLAUDE.md yet — CLAUDE.md update is overdue and remains a priority after AEI.

---

### AUTH: Cognito Integration

MemberSync's role system (Admin / Staff / Contributor / Leadership/Board) maps onto AWS Cognito, which Membio already uses across its product suite. Cognito handles authentication (who you are). MemberSync roles handle authorization (what you can do).

The Super-Admin access level for Membio staff is a separate Cognito user pool or a privileged group within the existing one. **This requires a design conversation with the dev team before implementation — do not build a parallel auth system.**

Client-facing user management must sync with the existing Membio product suite workflow, keyed off MemberID. Impersonation tools (Section 1.7 of the spec) must also sync with the existing Membio support workflow.

---

### CLIENT TIERS: Three Service Levels

Clients are classified by service tier. This appears in the client roster and drives support priority and onboarding approach:

- **Self-Service** — configures their own account within Membio-set bounds  
- **Mid-Tier** — Membio-assisted onboarding, standard support  
- **Enterprise/Concierge** — white-glove onboarding, Membio seeds AI context and competitive intelligence, dedicated support

---

### WHAT CLIENTS CAN AND CANNOT CONFIGURE

**Clients can change:**

- Organization profile, logo, contact info  
- User management (invite, assign roles, deactivate)  
- AI memory (add, edit, delete entries; which roles can edit — configurable by Client Admin)  
- Competitive intelligence (premium plans only — client-configured, not Membio-configured for self-service/mid-tier)  
- Email preferences (from name, reply-to)  
- Billing (payment method, billing contact)

**Only Membio staff can change:**

- Module visibility  
- AI feature kill switches and daily limits  
- Tier thresholds and engagement score weights  
- SendGrid ASM group configuration  
- Anything affecting how data is calculated or platform behavior at system level

**The Geek Squad Principle (named this session):** Some clients' IT support is consumer-grade. The tenant config editor must be built with extreme care — plain English labels, tooltips explaining what each setting does and what happens if changed, confirmation dialogs for anything consequential. If a non-technical person could misconfigure something and cause scoring or data problems, that field requires a confirmation step in plain English before saving.

---

### COMPLIANCE MODULE: Configurable Framework, Not Binary Toggle

The Compliance module is a configurable framework where the types of compliance being tracked are defined per client. Every locale is unique — state CE rules differ, MLS obligations differ, local mandates differ.

**Association compliance (built):** CE hours (state-specific), Code of Ethics, Fair Housing training, license renewal tracking. Clients can add local compliance requirements within the framework.

**MLS compliance:**

- NAR settlement obligations: **already implemented for both associations and MLSs**  
- Clear Cooperation: **gone — no longer in effect, not to be referenced as something to build**  
- Remaining MLS opportunity: data input accuracy, timeliness, rules enforcement, subscriber obligations

**MLS compliance positioning (decided this session):** MemberSync is notice delivery and acknowledgment infrastructure for MLSs — not a pre-built compliance rulebook. MLSs define their compliance obligations in their own CRM, billing module, or compliance system. MemberSync sends the notices, tracks acknowledgment, surfaces non-responders, and maintains an audit trail.

**Sales framing:** "We don't pretend to know your compliance rulebook. We give you the infrastructure to enforce it — and send whatever notices you need straight from your CRM, compliance system, or billing module."

**MLS compliance rule sets** are a discovery item — to be defined with input from first MLS client actively using the module. Do not pre-build assumptions.

License State field in tenant config is labeled "License" (not just "State") — it drives CE rules and compliance logic, not just a display label.

---

### TEMPLATE DESIGN PHILOSOPHY (New — Critical for Daniel/UX)

Clients with full template control will produce emails that damage their own open rates and harm MemberSync's reputation. This is not hypothetical.

**The rule: clients control content, Membio controls the design system.**

Every email sent through MemberSync renders inside a locked template shell designed by Membio. The shell defines typography, color palette (within brand colors), layout structure, content zones, maximum sections, button styles, spacing. Clients fill in content within zones — text, images from library, button label, subject line. They cannot restructure the layout, add zones, change fonts, or inject additional color treatments.

**Starter template library (Membio-designed):**

- Single announcement  
- Event promotion  
- CE / license renewal reminder  
- Welcome email (new member)  
- Newsletter digest (structured, not freeform)  
- Recognition / milestone celebration  
- Compliance notice

Each template has one job, one clear message, one call to action.

**Deliverability note:** Locked template shells protect open rates technically, not just aesthetically. Inconsistent HTML, multiple font stacks, and complex formatting trigger spam filters. This is a business argument to use when clients push back on constraints.

**Upsell path:** Enterprise clients who need custom layouts get them designed by Membio as a professional services engagement.

**This philosophy must inform template system architecture before any template UI is built. Daniel needs to read it before touching templates.**

---

### LEADERSHIP / BOARD ROLE: Genuinely Separate Experience

The Leadership/Board role is not a read-only version of the staff dashboard with buttons grayed out. It is a genuinely separate, curated view — designed to be shown in a board meeting.

What board members see: high-level membership health, tier distribution trends, campaign performance summaries, key engagement metrics. Clean, beautiful, strategic. Nothing operational. No individual member records. No campaign library. No AI Chat.

The CEO may not want board members seeing the full operational product. The Leadership view is explicitly scoped to protect that.

**Business model:** Charge per Leadership seat. Zero marginal cost to Membio. Real perceived value to the client. Pricing is an open question — needs a decision before commercial launch.

---

### AI MEMORY / RAG SYSTEM: Architecture Confirmed

The organizational memory system is a three-layer RAG architecture:

- **Layer 1 (built):** Schema RAG — relevant schema slice injected before SQL generation  
- **Layer 2 (analyst prompt, built):** Business Context RAG — static client config (deadlines, competitors, member counts) from `tenant_config.ai_business_context`  
- **Layer 3 (to build next):** Memory RAG — accumulated organizational learning that grows over time, stored in `tenant_config.ai_memory`

**Injection order into AI Chat system prompt:**

1. Static business context (`ai_business_context`) — Membio-seeded, read-only to clients  
2. Client memory (`ai_memory`) — client-editable, grows over time  
3. Schema context — modular, query-type specific

**tenant\_config fields needed:**

- `ai_business_context` (text) — Membio-seeded static briefing. Read-only to clients.  
- `ai_memory` (text, up to 10,000 characters) — client-editable accumulated memory  
- `ai_memory_suggestions` (jsonb) — pending AI suggestions awaiting staff approval. Array of `{text, category, source_query, created_at}`  
- `ai_memory_updated_at` (timestamp) — last update  
- `ai_memory_editor_roles` (text\[\]) — which roles can edit memory. Default: \['admin'\]. Client-configurable.

**The Easter Egg interaction (decided this session):** The AI suggestion queue does NOT show an empty state after every session. It only appears when there is something in it. The appearance is the signal — it earns its way in.

When it appears: *"Great chatting with you today\! I learned something worth remembering: \[specific insight\]. Mind if I add this to my memory?"* **\[Remember this\] \[No thanks\]**

The specific insight is always shown. User reads it, decides, approves or dismisses. If dismissed, gone — no guilt, no follow-up.

**Memory limit interaction (decided this session):** When approaching the 5,000 character soft limit, the system surfaces the oldest/least-referenced entry with the message: *"This tip has enriched my memory\! Mind if I make room for something new?"* Shows the specific entry that would be removed. User can approve deletion or choose to delete something else instead. No silent deletions.

**Which roles can edit AI memory:** Client Admin configures this. Default is Admin only. Configurable to include Staff if the organization has a dedicated marketing manager or membership coordinator.

**Competitive intelligence configuration:** Client-configured on premium plans. Membio does not write competitive context for self-service or mid-tier clients — the client knows their competitive landscape better than Membio does. For Enterprise/Concierge, Membio seeds it during the kickoff conversation as a white-glove service.

---

### BILLING: Credit Card First

Primary billing model is recurring Stripe credit card charges. Monthly invoicing is the exception path, not the default.

**Payment data:** Stripe handles everything. MemberSync stores only a Stripe customer ID and last 4 digits for display. Full card numbers are never stored, logged, or transmitted through MemberSync systems.

**Billing contact:** Separate from primary admin. The person who approves budgets is rarely the same person who manages the software. Both should be on file. Invoices and payment notifications go to billing contact; product notifications go to primary admin.

---

### SENDGRID DASHBOARD: DNS Visibility Added

When diagnosing a deliverability issue urgently, DNS configuration should be visible on the SendGrid dashboard page — not buried in tenant config. Section 1.3 of the admin spec includes MX records, SPF, DKIM, DMARC status indicators alongside email metrics.

---

### SELF-SERVICE ONBOARDING: Deferred to Client \#4+

Deferred until four or five clients have been manually onboarded and AMS field mapping patterns are well understood. The field mapping step (AMS non-standardization) is the hard part and the reason for the delay. Do not build self-service onboarding until Tracy explicitly says to.

---

### CRMLS: Removed from Forward-Looking Documents

CRMLS is on ice (their team is building a competing product). Removed from the Admin Panel spec and any forward-looking documents. Historical references in prior project summaries are accurate but should not be carried forward as active targets.

Stage 2 trigger is now "after client \#4 onboards" — not tied to any specific named client.

---

## WHAT'S NEXT: PROMPT QUEUE

The following prompts are ready to be written, in priority order. The RAG memory prompt was deliberately saved for the next fresh conversation.

### 1\. RAG Memory System — Replit Prompt (NEXT — Write First in New Conversation)

The spec is fully written in Section 2.3 of `MemberSync_AdminPanel_Spec_v2.md`. Blueprint is complete. Write a focused Replit prompt to build:

- `tenant_config` fields: `ai_business_context`, `ai_memory`, `ai_memory_suggestions`, `ai_memory_updated_at`, `ai_memory_editor_roles`  
- Client-facing AI Settings page at `/chats/settings` with four sections (Membio briefing read-only, memory cards, manual add form, Easter Egg suggestion queue)  
- Memory injection into `aiQueryService.ts` system prompt (after business context, before schema)  
- Memory limit handling with warm messaging  
- The Easter Egg suggestion queue (stretch goal — implement if time permits, manual add is sufficient for AEI if not)

**Sensitive files — do not touch in this prompt:**

- `triggeredCampaignProcessor.ts`  
- `sequenceEnrollmentService.ts`

### 2\. Dashboard Warmth \+ Membership Widget Fix

The dashboard needs more humanity — warmth and personality in copy, not just data. The membership widget shows a scary \-73% MoM figure that needs context and explanation. Separate prompt from the RAG memory work.

### 3\. Campaign Architect Streaming

Currently generates all emails at once. Should stream them one by one — each email appears as it's generated. Better UX, feels more alive. Important for AEI demo.

### 4\. Recognition Dashboard Widget Fix

Recognition section is largely empty. The dashboard widget needs fixing. Recognition full homepage is pushed to Claude Code — not a Replit prompt.

### 5\. AI Chat \+ Recharts

After the analyst upgrade prompt (already written and ready to deploy), add Recharts visualizations inline in AI Chat responses. This is a premium feature per the module table in CLAUDE.md.

### 6\. Quick Campaign (New Feature — Do If Time Allows)

Lightweight Campaign Architect variant. User provides: dates, goal, URLs. AI builds a campaign. No full conversation UI — just inputs and output. Reframed from "Drip Sequence." Lower priority than items 1–5.

### 7\. Email Archive / Templates

Need more information on exactly what's broken before writing a prompt. Ask Tracy to clarify before speccing.

---

## OPEN QUESTIONS (3 Remaining)

**1\. Leadership/Board pricing:** How much should a Leadership seat cost? Zero marginal cost to Membio, real perceived value to client. Needs a pricing decision before commercial launch.

**2\. MLS compliance rule sets:** What does MLS data accuracy and timeliness compliance look like in practice? To be answered with input from first MLS client using the module. Do not pre-build assumptions.

**3\. Billing integration timing:** When does Stripe integration get built? Currently manual invoicing for the few clients on invoiced billing. Target: before client \#4 onboards.

---

## DOCUMENTS PRODUCED THIS SESSION

| Document | Location | Status |
| :---- | :---- | :---- |
| `MemberSync_AdminPanel_Spec_v2.md` | Project knowledge \+ outputs | ✅ Final — use this, not v1 |
| `MemberSync_AIChat_AnalystUpgrade.md` | Outputs (prior session) | ✅ Ready to deploy to Replit |

---

## REMINDERS FOR NEXT CONVERSATION

- The AI Chat analyst upgrade prompt is written and ready — deploy to Replit before writing the RAG memory prompt if not already done.  
- CLAUDE.md is overdue for a comprehensive update. This is a post-AEI priority but should not slip further after the conference.  
- ⛔ CRITICAL — DEV TEAM CODEBASE WARNING: The dev team pulled a Replit snapshot on March 10\. That snapshot does NOT include the major email infrastructure stability and security corrections made on March 10–11 (suppression hardening, webhook fixes, recipient tracking, unsubscribe architecture). That code is incomplete and must NOT be used as the foundation going forward. The correct baseline is the Replit codebase from March 12 onward. The dev team must pull a fresh snapshot from Replit and merge accordingly before any further production work. This must be communicated to the dev team explicitly before they write another line of code.  
- Campaign Architect is the AEI demo centerpiece. Touch it only for the streaming prompt — no other changes.  
- ⛔ DO NOT modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts` under any circumstances.

---

*MemberSync Project Summary · March 11, 2026 (Late Evening) · Confidential — Membio* *Maintained by: Tracy (CEO) \+ Claude (CTO role)* *Continues from: MemberSync\_Project\_Summary\_Mar11\_2026\_Evening.md* *Next: New conversation — RAG memory Replit prompt first* *Governing principle: Rock solid software first. No shortcuts. No exceptions.*  

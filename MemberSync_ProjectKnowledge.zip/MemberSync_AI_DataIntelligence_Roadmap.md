# MemberSync AI Data Intelligence — Feature Roadmap
## February 19, 2026

---

## THE VISION

The AI Chat ("Ask Anything") evolves from a query tool into the **primary interface to the association's institutional knowledge**. Instead of just answering questions and building audiences, it becomes the thing every staff member opens when they need to understand, present, or act on their membership data.

Association executives spend hours every week assembling board reports, budget justifications, committee presentations, and broker meeting prep — manually pulling data from multiple systems and creating charts in Excel. MemberSync already sits on top of the richest unified member dataset the association has ever had. The AI already translates natural language to SQL. The missing piece is the **output layer** — turning query results into presentation-ready artifacts.

**Why this matters for the business:** Once a CEO discovers she can say "Show me new member trends by quarter for the board meeting" and get a chart in 10 seconds, she will never give up this tool. That's not engagement platform stickiness — it's **operational dependency**. The association can't function as efficiently without it.

**Why this is technically feasible now:** The stack already has Recharts installed and wrapped in a shadcn chart component (`client/src/components/ui/chart.tsx`). The AI query service already returns structured data (`QueryResult.data` as `Record<string, unknown>[]`). The AIChatBox already renders data tables from query results. The gap is: detecting when a visualization would be better than a table, and rendering a chart instead.

---

## IMPLEMENTATION STAGES

### Stage 1: Current State (Done)
- Natural language → SQL → text table results
- "Save as Audience" button for query results with member keys
- Suggested follow-up questions
- Conversation history for follow-up queries

### Stage 2: Inline Chart Rendering (Next Priority)

**Goal:** When the AI detects that a query result would be better shown as a chart, it renders a Recharts visualization inline in the chat response instead of (or alongside) the data table.

**How it works:**

1. **Chart detection in the AI query service:** After generating SQL and getting results, Claude makes a second determination: "Would this result be better as a chart?" The heuristic is straightforward:
   - Time series data (dates in one column, numbers in another) → **Line chart**
   - Categorical comparison (names/labels with numeric values) → **Bar chart**
   - Part-of-whole (percentages or counts that sum to a meaningful total) → **Pie/donut chart**
   - Two numeric dimensions → **Scatter plot** (rare)
   - Single aggregate number → **Keep as text** (no chart needed)

2. **Extended QueryResult response:** Add optional chart metadata to the response:

```typescript
interface QueryResult {
  success: boolean;
  data?: Record<string, unknown>[];
  sql?: string;
  error?: string;
  rowCount?: number;
  responsePhrase?: string;
  suggestions?: string[];
  isAggregate?: boolean;
  // NEW: Chart recommendation
  chart?: {
    type: 'line' | 'bar' | 'pie' | 'area';
    title: string;
    xKey: string;          // Column name for X axis
    yKeys: string[];       // Column name(s) for Y axis
    yLabels?: string[];    // Human-readable labels for Y series
    xLabel?: string;       // X axis label
    yLabel?: string;       // Y axis label
    colors?: string[];     // Optional color overrides
  };
}
```

3. **Chart generation prompt:** Add a second Claude call (or extend the existing response parsing) that analyzes the SQL result columns and returns the chart metadata. This is cheap — it's a small classification task, not a full generation.

Example prompt addition to the query service:
```
After generating the SQL results, determine if the data should be visualized as a chart.
If yes, include a "chart" object in your response with:
- type: 'line' for time series, 'bar' for categorical comparisons, 'pie' for proportions
- title: a concise chart title
- xKey: the column name to use for the X axis or categories
- yKeys: array of column names for the Y values
- yLabels: human-readable labels for each Y series

Only recommend a chart when the data has at least 3 rows and a clear visual story.
Single-number aggregates or simple lookups should remain as text.
```

4. **Frontend chart rendering in AIChatBox:** When `message.queryResult.chart` exists, render a Recharts component instead of (or above) the DataTable:

```tsx
// New component: QueryChart.tsx
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from "recharts";

const CHART_COLORS = ['#3a8a8c', '#f59e0b', '#6366f1', '#ec4899', '#14b8a6', '#f97316'];

function QueryChart({ data, chart }: { data: Record<string, unknown>[]; chart: ChartConfig }) {
  // Render appropriate Recharts component based on chart.type
  // Line, Bar, or Pie with the specified keys and labels
}
```

5. **"Download as Image" button:** Add a button below charts that uses `html2canvas` or the Recharts `toDataURL` method to export the chart as a PNG. This is the bridge to presentations — staff can drop the chart into PowerPoint or Google Slides.

**Example interactions after Stage 2:**

- "How many new members joined each month this year?" → Line chart showing monthly new member count
- "Show me the top 10 offices by production volume" → Horizontal bar chart
- "What percentage of members are in each tier?" → Donut chart with Rainmaker/Builder/Foundation
- "Compare CE vs non-CE class registrations by month" → Dual-line chart
- "How many members have overdue invoices?" → Single number, no chart (text response)

**Estimated effort:** This is primarily frontend work with a moderate AI prompt change. The backend already returns the data — we're adding chart metadata to the response and a chart renderer to the frontend. Roughly 2-3 Replit prompts.

### Stage 3: Exportable Artifacts (Future)

**Goal:** "Download as PDF" and "Copy to clipboard" buttons on chart responses. Staff can grab any chart or data table and use it in their own documents.

**Components:**
- PDF generation of individual charts with title and data source attribution
- CSV export button on data tables (already exists as "Save as Audience" but could be generalized)
- "Copy chart" button that puts the image on the clipboard
- Formatted text export of the AI's narrative response + chart

**Estimated effort:** 1-2 Replit prompts, mostly frontend.

### Stage 4: AI-Generated Reports (Future)

**Goal:** Multi-section documents generated from natural language requests.

"Build me a board report with membership trends, education stats, and top office performance" generates a structured document with multiple charts, narrative text, and key insights.

**Components:**
- Multi-query orchestration (the AI breaks a report request into multiple SQL queries)
- Layout engine that assembles charts and text into a PDF or HTML document
- Template system for recurring reports ("Generate the monthly board report")
- Scheduled reports ("Email the board report to the CEO on the first Monday of each month")

**Estimated effort:** Significant — this is a feature epic, probably 5-8 Replit prompts. But by this point, each query and chart is already working individually. The report is an orchestration layer on top.

### Stage 5: Presentation Mode (Future Vision)

**Goal:** Direct generation of slide-ready content.

"Make me a 5-slide presentation about membership renewal trends for 2026" generates actual slides — or at minimum, a set of titled charts with talking points that can be dropped into a slide deck.

This could integrate with the existing PPTX generation capability or generate a self-contained HTML presentation.

---

## BECOMING THE MEMBER DATA HUB

The AI is only as smart as the data it can see. Right now MemberSync has two data sources: the AMS (Rapattoni) for member records, billing, education, and events, and the MLS (also Rapattoni) for production data. That's already more than any single system at the association has ever had unified in one place. But there's a much bigger picture.

Associations and MLSs interact with their members across dozens of touchpoints that currently live in completely separate systems, each one a silo that nobody connects to anything else:

**Support & service interactions** — When a member calls the help desk because they can't log into SentriLock, or submits a ticket about a billing error, or asks how to access their MLS feed — that's an engagement signal. A member who calls support three times in a month is either frustrated (risk signal) or deeply invested in using their benefits (engagement signal). Either way, it's information the association doesn't currently factor into anything. Common systems: Zendesk, Freshdesk, HubSpot Service, Salesforce Service Cloud, or even just a shared inbox.

**Website and portal behavior** — When a member logs into the member portal to check their CE credits, browses the event calendar, or downloads a form — that's behavioral data that shows what they actually care about. Google Analytics or a similar tool already tracks this for most associations, but nobody connects it to individual member records. A Foundation member who visits the education page three times but hasn't registered is someone the association should nudge with a "here's what's coming up" email.

**Social and community engagement** — Some associations run Facebook groups, Slack channels, or online forums. Participation in those communities is a strong engagement signal. A member who's active in the association's Facebook group but hasn't attended an event in a year has a different engagement profile than someone who's completely dark.

**Financial systems** — QuickBooks, Sage, or whatever the association uses for actual accounting. The AMS has billing and invoice data, but the accounting system has the real revenue picture — refunds, write-offs, payment plans, returned checks. For a CFO, connecting this gives a true revenue retention metric.

**Third-party benefits usage** — Many associations offer member benefits like Zipforms, SentriLock/Supra, legal hotlines, tech support, discounted services. Some of these have APIs or usage reports that could show which members are actually using their benefits and which are paying for access they never touch.

**LMS platforms** — Some associations use separate learning management systems beyond what's in Rapattoni — platforms like Elevate, CE Shop, or custom LMS solutions. Course completion data from these systems would strengthen the education engagement picture.

### How This Works Technically

You don't need to understand the plumbing in detail, but here's the concept in plain terms:

**Connectors** are small pieces of code that know how to talk to a specific system. A Zendesk connector knows how to pull tickets. A Google Analytics connector knows how to pull page views. Each connector translates data from the external system into a common format that MemberSync can store and query.

**The integration pattern** is the same every time:
1. Connect to the external system (usually via an API key the client provides)
2. Pull data on a schedule (daily, hourly, or in real-time depending on the system)
3. Transform it into a standard format and store it in MemberSync's database
4. Link it to the member record using email address, member key, or another identifier
5. Make it available to the AI query service and the engagement scoring formula

**The member record gets richer with each connection.** Today, Claude knows a member's production, education, events, payments, and email engagement. Add support tickets and Claude also knows "this member called three times about billing issues last month." Add website analytics and Claude knows "this member browses the event calendar every week but never registers." Each data source makes the AI smarter and the engagement score more accurate.

### Integration Stages

**Near-term (6-12 months):**
- **Webhook receiver** — A generic endpoint that accepts incoming data pushes from systems that support webhooks (many modern tools do). This is the simplest integration pattern: the external system sends us data when something happens, we store it.
- **Google Analytics integration** — GA4 has a well-documented API. We'd pull member portal page views by user, match to member records by email or user ID, and surface "portal activity" as an engagement signal.
- **Support ticket integration** — Zendesk and Freshdesk both have APIs. Pull ticket history by requester email, match to member record. Surface "support interactions" as a new activity type in the Activity Feed and as an engagement signal.

**Mid-term (12-18 months):**
- **Integration marketplace UI** — An admin page in MemberSync where the client can connect their systems: "Connect your Zendesk" → enter API key → data starts flowing. Like how Zapier or HubSpot shows connected apps. Each integration has a status indicator (connected, syncing, error) and a last-sync timestamp.
- **Benefits usage tracking** — Partner with SentriLock, Zipforms, etc. to pull usage data. This is harder because it requires business relationships, not just technical integration.
- **Configurable engagement scoring** — As new data sources come in, the engagement score formula needs to incorporate them. The scoring weights in `clientConfig.ts` expand to include new signal types, and the admin UI lets the client adjust how much each signal matters.

**Long-term (18+ months):**
- **Real-time event stream** — Instead of polling on schedules, systems push events as they happen. A member opens a support ticket at 2 PM and by 2:01 PM the AI knows about it. This requires an event bus architecture (something like AWS EventBridge or a simple Redis pub/sub).
- **Predictive intelligence from cross-source patterns** — This is where it gets really powerful. With enough data sources connected, the AI can spot patterns that no single system reveals: "Members who call support twice, stop logging into the portal, and skip their CE renewal have an 80% chance of lapsing within 6 months." That's not a metric any association has ever been able to calculate because the data has never lived in one place before.
- **Automated action triggers** — When the AI spots a pattern, it can automatically trigger an intervention: "Member X matches the lapse risk pattern → send them the re-engagement email series." This connects the data hub to the triggered campaign engine.

### What This Means for the Business

Every integration Membio adds makes the product stickier in two ways:

1. **More data = better AI** — The AI's answers get smarter, the engagement scores get more accurate, the charts get richer. The client sees this directly in the quality of insights they get from "Ask Anything."

2. **More connections = harder to leave** — Once an association has connected their Zendesk, their Google Analytics, their LMS, and their accounting system to MemberSync, switching costs become substantial. Not because we're locking them in, but because we're the only place all that data lives together. That's a genuine moat.

For sales: "We don't just show you your member data. We connect ALL your member data — from every system you use — into one place, and we put Claude on top of it. The more you connect, the smarter it gets."

---

If the AI Chat becomes this powerful, it deserves the top position on the dashboard — not buried between metric cards. The recommended dashboard layout becomes:

1. **Page header** — "Good morning, Tracy. Here's what's happening at Mainstreet REALTORS®."
2. **AI Chat** — The primary interaction surface. Top of the page. "Ask Anything" with smart suggested questions that change based on what's happening in the data.
3. **The Pulse** — Three metric cards (Membership, Education, Events) as the passive morning briefing
4. **Today's Activity** — Action engine alongside Celebrations sidebar
5. **Mainstreet Community** — Strategic context at the bottom

The AI Chat is the *hero feature*. The Pulse cards are the *glanceable summary*. The Activity Feed is the *action prompt*. The Community section is the *strategic frame*.

---

## PRIORITY & SEQUENCING

| Stage | What | When | Depends On |
|-------|------|------|------------|
| Dashboard Redesign Part 1 | Pulse cards, Activity Feed, layout | Now | — |
| Dashboard Redesign Part 2 | Mainstreet Community, chat placement | After Part 1 | Part 1 |
| Stage 2: Inline Charts | Chart rendering in AI Chat | After dashboard | Dashboard done |
| Stage 3: Export | Download charts as PNG/PDF | After Stage 2 | Stage 2 |
| Webhook Receiver | Generic inbound data endpoint | After dashboard | — |
| Google Analytics Integration | Portal behavior as engagement signal | 6-12 months | Webhook receiver |
| Support Ticket Integration | Zendesk/Freshdesk ticket history | 6-12 months | Webhook receiver |
| Stage 4: AI Reports | Multi-query document generation | After Stage 3 | Stage 3 |
| Integration Marketplace UI | Admin page for connecting systems | 12-18 months | At least 2 integrations |
| Configurable Engagement Scoring | Admin-adjustable signal weights | 12-18 months | New data sources |
| Stage 5: Presentations | Slide-ready output | After Stage 4 | Stage 4 |
| Real-time Event Stream | Live data from connected systems | 18+ months | Integration marketplace |
| Predictive Cross-Source Intelligence | Pattern detection across all data | 18+ months | 3+ data sources |

The dashboard redesign (Parts 1 & 2) and the AI Chat chart rendering (Stage 2) are the two highest-impact investments right now. Together, they transform MemberSync from "a tool you use to send emails" into "the place you go to understand and act on your membership data."

---

## TECHNICAL NOTES FOR FUTURE PROMPTS

**Recharts is already installed** — the `chart.tsx` shadcn component wraps it. Available chart types: Line, Bar, Pie, Area, Radar, Scatter, plus composed charts.

**The AI query service already returns structured data** — `QueryResult.data` is `Record<string, unknown>[]`, which is exactly what Recharts expects as its `data` prop.

**The AIChatBox already conditionally renders** — it checks `message.queryResult?.data` and renders a `DataTable`. Adding a `QueryChart` renderer alongside is a straightforward pattern match.

**Chart export:** `recharts` supports `ref` on chart containers. Combined with `html-to-image` or `html2canvas` (installable via npm), charts can be exported as PNG with a single button click.

**Multi-query for Stage 4:** The AI query service currently handles one question → one SQL → one result. For reports, it would need a planning step: "Break this report request into 3-5 individual queries, execute each, then assemble the results with narrative." This is an AI orchestration pattern, not a database architecture change.

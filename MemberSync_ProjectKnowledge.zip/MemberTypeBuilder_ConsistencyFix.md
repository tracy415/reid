# Member Type Builder: Data Consistency Fix
## Replit Prompt â€” February 2026

**Problem:** The Member Type Builder page counts members differently than the Dashboard, producing different totals. The Dashboard reads from `member_metrics_cache` (refreshed daily from `AMS.apmmember`) and shows 18,259 active members. The Member Type Builder queries `AMS.appmemberassociation` directly and shows 18,093. The difference comes from members whose status is Active in one table but Suspended/Inactive in the other, plus a handful of MLS-Only members who exist in `appmemberassociation` but not `apmmember`.

**Solution:** Make `member_metrics_cache` the single source of truth for "who is an active member" across the entire app. The Member Type Builder should use `member_metrics_cache` to get the active member list, then enrich it with bill type data from `appmemberassociation`. This guarantees every page in the app agrees on the member count.

**CRITICAL: Do NOT modify the Dashboard, the member_metrics_cache refresh job, or any AI services. This prompt changes ONLY the Member Type Builder backend queries.**

---

## WHAT TO CHANGE

### 1. Replace the Bill Type Counts Query

Find the API endpoint that serves bill type counts for the Member Type Builder page. This is the endpoint that returns the numbers shown next to each checkbox (e.g., R â€” REALTOR (14,783)). It is likely at `GET /api/audiences/member-bill-type/counts` or similar.

**Current behavior:** It queries `AMS.appmemberassociation` directly, filtering to `Status = 'Active'`, and counts by BillType. This produces counts that don't match the Dashboard's member total.

**Replace the query with this:**

```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."AssociationId",
    ma."BillType",
    ma."Status"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT la."BillType" as bill_type_code,
       COUNT(DISTINCT la."MemberKey") as member_count
FROM latest_assoc la
INNER JOIN member_metrics_cache mmc
  ON la."MemberKey" = mmc.member_key
  AND mmc.member_status = 'Active'
WHERE COALESCE(NULLIF(TRIM(la."BillType"), ''), '') <> ''
GROUP BY la."BillType"
ORDER BY member_count DESC
```

**Key changes from the old query:**
- Added `AND ma."AssociationId" = 'MainStreet'` to filter to the primary association record
- Removed `WHERE la."Status" = 'Active'` â€” we no longer rely on the association table's status field
- Added `INNER JOIN member_metrics_cache` â€” this is the filter. Only members who are Active in the cache (and therefore Active in `apmmember`) get counted
- The join is on `la."MemberKey" = mmc.member_key` (both are unprefixed AMS keys, no MRD prefix needed)

This means the sum of all bill type counts will match (or very closely match) the Dashboard's Total Active Members number. The only small difference would be members who are active in `apmmember` but have no record at all in `appmemberassociation` for AssociationId = 'MainStreet' â€” these are rare edge cases.

Keep the 1-hour cache on this endpoint â€” the counts change slowly.

---

### 2. Replace the Preview/Count Query

Find the API endpoint that runs when the user clicks "Generate Preview" on the Member Type Builder page. It is likely at `POST /api/audiences/member-bill-type/preview` or similar.

**Replace the preview query with this:**

```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."BillType"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT DISTINCT la."MemberKey" AS "MemberKey",
  mmc.member_name AS "MemberFullName",
  mmc.member_email AS "MemberEmail",
  mmc.office_name AS "OfficeName"
FROM latest_assoc la
INNER JOIN member_metrics_cache mmc
  ON la."MemberKey" = mmc.member_key
  AND mmc.member_status = 'Active'
WHERE la."BillType" = ANY($1)
LIMIT 15
```

**And replace the count query (for the "X members found" number) with:**

```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."BillType"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT COUNT(DISTINCT la."MemberKey") as total
FROM latest_assoc la
INNER JOIN member_metrics_cache mmc
  ON la."MemberKey" = mmc.member_key
  AND mmc.member_status = 'Active'
WHERE la."BillType" = ANY($1)
```

**Key changes:**
- Same `AssociationId = 'MainStreet'` filter and `INNER JOIN member_metrics_cache` pattern as the counts query
- The preview now pulls member name, email, and office name from `member_metrics_cache` instead of joining `AMS.apmmember` and `AMS.apmoffice` separately. This is faster (local table vs. external DB joins) and guaranteed to match the Dashboard's data
- Removed the old `WHERE la."Status" = 'Active'` filter â€” the cache join handles this

**IMPORTANT about the parameter:** The `$1` parameter is an array of selected bill type codes (e.g., `['R', 'DR']`). This comes from the frontend checkboxes. The query uses `ANY($1)` to match any of the selected codes. If no bill types are selected, the endpoint should return 0 results (require at least one selection).

---

### 3. Replace the Saved Audience SQL

When the user saves a Member Type audience, the system constructs a SQL query and stores it in the `saved_audiences` table (as a smart audience that re-runs on each use). The saved SQL needs to use the same cache-joined pattern.

Find the code that constructs the SQL string for saving. It likely builds the query from the selected bill type codes and stores it in the `sqlQuery` field.

**Replace the saved SQL template with this pattern:**

For a user who selects bill types `['R', 'DR']`, the saved SQL should be:

```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."BillType"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT DISTINCT la."MemberKey" AS "MemberKey",
  mmc.member_name AS "MemberFullName",
  mmc.member_email AS "MemberEmail",
  mmc.office_name AS "OfficeName"
FROM latest_assoc la
INNER JOIN member_metrics_cache mmc
  ON la."MemberKey" = mmc.member_key
  AND mmc.member_status = 'Active'
WHERE la."BillType" = ANY(ARRAY['R','DR'])
```

Note: No LIMIT on saved queries â€” when the audience is used for sending email, we need all matching members.

**Also ensure `member_metrics_cache` is in the `allowedTables` set** in `aiAudienceService.ts` for SQL validation. Check the `validateSQLQuery` function â€” `member_metrics_cache` should already be there. If not, add it.

---

### 4. Database Routing for the Saved Query

The saved SQL now references BOTH an external table (`AMS.appmemberassociation`) and a local table (`member_metrics_cache`). The existing `getAudienceMembers()` function in `aiAudienceService.ts` has a `usesLocalTables()` helper that checks whether to use the local or external database.

**This is a cross-database join and cannot run on a single connection.** The existing code handles this for smart audiences by running the SQL on the appropriate database and then enriching with the other database. But since our new query joins both, it won't work as a single SQL statement sent to either database alone.

**The simplest fix:** Change the saved SQL to use a two-step approach. Instead of a cross-database JOIN in SQL, the saved query should ONLY query the external table:

```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."BillType"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT DISTINCT la."MemberKey" AS "MemberKey"
FROM latest_assoc la
WHERE la."BillType" = ANY(ARRAY['R','DR'])
```

Then `getAudienceMembers()` will run this query on the external database to get the member keys, and the existing enrichment step (which already looks up names, emails, and office names) will handle the rest. The enrichment already queries `AMS.apmmember` â€” but we need to make sure it also filters to only active members.

**Find the enrichment query** in `getAudienceMembers()` â€” it's the block that runs when `rawMembers.length > 0 && !useLocalDb && externalDb`. The enrichment query currently looks like:

```typescript
const enrichQuery = `
  SELECT 
    m."MemberKey",
    m."MemberFirstName",
    m."MemberLastName",
    o."OfficeName"
  FROM "AMS"."apmmember" m
  LEFT JOIN "AMS"."apmoffice" o ON m."OfficeKey" = o."OfficeKey"
  WHERE m."MemberKey" IN (${keysArray})
`;
```

**Add the deduplication pattern and active-only filter:**

```typescript
const enrichQuery = `
  SELECT DISTINCT ON (m."ApmClientId", m."MemberKey")
    m."MemberKey",
    m."MemberFirstName",
    m."MemberLastName",
    o."OfficeName"
  FROM "AMS"."apmmember" m
  LEFT JOIN (
    SELECT DISTINCT ON ("ApmClientId", "OfficeKey")
      "OfficeKey", "OfficeName"
    FROM "AMS"."apmoffice"
    WHERE "ApmClientId" = 'MainStreet'
    ORDER BY "ApmClientId", "OfficeKey", "ApmSourceModificationTimestamp" DESC
  ) o ON m."OfficeKey" = o."OfficeKey"
  WHERE m."MemberKey" IN (${keysArray})
    AND m."ApmClientId" = 'MainStreet'
    AND m."MemberStatus" = 'Active'
  ORDER BY m."ApmClientId", m."MemberKey", m."ApmSourceModificationTimestamp" DESC
`;
```

This ensures that even if the association query returns a member key for someone who has since become inactive, the enrichment step will filter them out. The count returned by `getAudienceMembers()` should reflect only the members that were successfully enriched (i.e., found and active in `apmmember`).

---

### 5. Preview and Counts Endpoints â€” Use Local + External Two-Step

For the live preview and counts endpoints (Steps 1 and 2 above), the cross-database join pattern works differently than for saved queries. These endpoints have handler functions that can run multiple queries in sequence.

**Recommended approach for the preview endpoint:**

Step A: Query the external database to get matching member keys:
```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."BillType"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT DISTINCT la."MemberKey"
FROM latest_assoc la
WHERE la."BillType" = ANY($1)
```

Step B: Filter those keys against the local `member_metrics_cache` and get display data:
```sql
SELECT member_key AS "MemberKey",
       member_name AS "MemberFullName",
       member_email AS "MemberEmail",
       office_name AS "OfficeName"
FROM member_metrics_cache
WHERE member_key = ANY($1)
  AND member_status = 'Active'
LIMIT 15
```

Step C: For the total count:
```sql
SELECT COUNT(*) as total
FROM member_metrics_cache
WHERE member_key = ANY($1)
  AND member_status = 'Active'
```

Where `$1` in Steps B and C is the array of member keys returned from Step A.

**For the counts endpoint (checkbox counts):**

Step A: Query external DB for all bill type â†’ member key mappings:
```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."BillType"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT la."MemberKey", la."BillType"
FROM latest_assoc la
WHERE COALESCE(NULLIF(TRIM(la."BillType"), ''), '') <> ''
```

Step B: Get all active member keys from local cache:
```sql
SELECT member_key FROM member_metrics_cache WHERE member_status = 'Active'
```

Step C: In the handler code (JavaScript/TypeScript), intersect the two sets and count by bill type:
```typescript
const activeKeys = new Set(activeMembersResult.rows.map(r => r.member_key));
const counts: Record<string, number> = {};
for (const row of assocResult.rows) {
  if (activeKeys.has(row.MemberKey)) {
    counts[row.BillType] = (counts[row.BillType] || 0) + 1;
  }
}
```

Keep the 1-hour cache on the counts endpoint.

---

## TESTING CHECKLIST

- [ ] Member Type Builder page loads with bill type counts
- [ ] The sum of all bill type counts closely matches the Dashboard "Total Active Members" number (they won't be exactly equal because some active members may not have a record in appmemberassociation, but the difference should be single digits, not hundreds)
- [ ] Clicking "Generate Preview" with one or more bill types selected shows the correct count and sample members
- [ ] The preview count for "Select All" should closely match the Dashboard total
- [ ] Saving a Member Type audience creates a record in saved_audiences with sourceType 'member_bill_type'
- [ ] Using a saved Member Type audience in Send Email returns the correct members
- [ ] Dashboard Total Active Members number is unchanged (we did not touch the dashboard)
- [ ] AI Builder and AI Chats still work normally (we did not touch AI services)
- [ ] Existing saved audiences of all types still work (we only changed enrichment to add dedup + active filter)

---

## DO NOT CHANGE

- Dashboard metrics queries (storage.ts getDashboardMetrics)
- member_metrics_cache refresh job (memberMetricsCacheService.ts)
- sharedDatabaseSchema.ts
- AI Audience Builder or AI Query Service
- Any other audience types (picklist, csv_upload, ai_generated)
- The Member Type Builder frontend layout or checkboxes â€” only the backend queries change

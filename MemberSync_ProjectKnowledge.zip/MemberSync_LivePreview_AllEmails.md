# MemberSync — Live Data Preview for ALL Emails

## Date: February 27, 2026
## Priority: High — Every email preview must show real recipient data, not fake sample data. This is fundamental to staff confidence before sending to thousands of members.

---

## REPLIT STANDING RULES

**These rules apply to this prompt and ALL future prompts for this project.**

### Rule 1: No Parallel Systems
Before building any new component, search for existing functionality. Extend rather than duplicate.

### Rule 2: Don't Break What Works
The existing `replaceMergeFieldsWithSampleData` function stays as-is — it's still used in the email composer (Compose step) where we don't yet have recipient context. This change only affects the Preview step.

### Rule 3: Shared Components Over Duplicates
The live preview logic must work identically for celebration emails, regular audience emails, compliance emails, and any future email type. One component, one pattern.

### Rule 4: Test Your Work
Test with celebration emails (milestone-specific data), regular audience emails (member name/office), and edge cases (1 member, empty fields).

---

## CONTEXT AND PHILOSOPHY

**Every email sent through MemberSync must be verifiable with real data before it goes out.** No fake names, no fake milestones, no generic "Sarah Johnson at Coldwell Banker." When a staffer is about to send to 2,000 members, they need to see what the actual email looks like for actual people in the audience.

Currently, the Preview step uses a static `EXAMPLE_MERGE_DATA` dictionary that shows "Hi Sarah" with hardcoded sample values for every email, regardless of who the recipients are or what type of email it is. This needs to change:

**For celebration/milestone emails:** The preview should show each member's real name, real milestone label, and real milestone detail — pulling from the `celebrationAudience.milestones` array that's already loaded on the frontend.

**For regular audience emails:** The preview should show each member's real first name, last name, office name, and email — fetched from the server using the first 15 member keys from the audience.

**For both types:** Left/right navigation arrows let the staffer cycle through recipients, seeing how the email looks for different people. The subject line and preview text update per-recipient too.

The Compose step (where you're writing/editing the email) continues to use sample data since you don't have a specific recipient in mind yet. Live data only applies to the Preview step where you're verifying what will actually be sent.

---

## PART 1: FETCH PREVIEW MEMBER DATA FOR ALL AUDIENCES

### Task 1A: Expand the Preview Members Fetch

**File: `client/src/pages/SendEmail.tsx`**

The current `fetchPreviewMembers` useEffect (around line 816) only fetches member details for audiences with ≤20 members. We need it to always fetch the first 15 members for preview purposes, regardless of audience size.

Replace the entire useEffect with:

```typescript
// Fetch first 15 member details for live preview (all audience sizes)
useEffect(() => {
  const fetchPreviewMembers = async () => {
    // For celebration audiences, we already have member data — use it directly
    if (celebrationAudience && celebrationAudience.milestones.length > 0) {
      setPreviewMembers(celebrationAudience.milestones.slice(0, 15).map(m => ({
        memberKey: m.memberKey,
        memberName: m.memberName,
        email: m.memberEmail || 'No email',
        firstName: m.memberName.split(' ')[0] || '',
        lastName: m.memberName.split(' ').slice(1).join(' ') || '',
        officeName: '', // Not available in milestone data
      })));
      setPreviewMembersLoading(false);
      return;
    }
    
    // For regular audiences, fetch from server
    if (!selectedAudience?.memberKeys || selectedAudience.memberKeys.length === 0) {
      setPreviewMembers([]);
      return;
    }
    
    const firstKeys = selectedAudience.memberKeys.slice(0, 15);
    
    // Check if keys are already emails (external/CSV audiences)
    const firstKey = firstKeys[0];
    if (firstKey && firstKey.includes('@')) {
      setPreviewMembers(firstKeys.map(email => ({
        memberKey: `csv-${email}`,
        memberName: email.split('@')[0],
        email: email,
        firstName: email.split('@')[0],
        lastName: '',
        officeName: '',
      })));
      return;
    }
    
    // Internal audience — fetch real member details
    setPreviewMembersLoading(true);
    try {
      const response = await apiRequest('POST', '/api/members/by-keys', {
        memberKeys: firstKeys,
      });
      const members = await response.json();
      setPreviewMembers(members.map((m: any) => ({
        memberKey: m.memberKey,
        memberName: m.fullName || `${m.firstName || ''} ${m.lastName || ''}`.trim() || 'Unknown',
        email: m.email || 'No email',
        firstName: m.firstName || '',
        lastName: m.lastName || '',
        officeName: m.officeName || '',
      })));
    } catch (error) {
      console.error('Error fetching member details for preview:', error);
      // Fallback to showing member keys
      setPreviewMembers(firstKeys.map(key => ({
        memberKey: key,
        memberName: '',
        email: '',
        firstName: '',
        lastName: '',
        officeName: '',
      })));
    } finally {
      setPreviewMembersLoading(false);
    }
  };
  
  fetchPreviewMembers();
}, [selectedAudience?.memberKeys?.length, selectedAudience?.audienceId, celebrationAudience?.type]);
```

### Task 1B: Update the previewMembers Type

The current `previewMembers` state type is `Array<{memberKey: string; memberName: string; email: string}>`. Expand it to include the additional fields needed for merge field replacement:

```typescript
const [previewMembers, setPreviewMembers] = useState<Array<{
  memberKey: string;
  memberName: string;
  email: string;
  firstName?: string;
  lastName?: string;
  officeName?: string;
}>>([]);
```

---

## PART 2: BUILD THE MERGE DATA FUNCTIONS

### Task 2A: Add Helper Functions

**File: `client/src/pages/SendEmail.tsx`**

Add these functions inside the component, after the `getEmailPreviewHtml` function:

```typescript
/**
 * Build a merge field replacement map from real member data.
 * For celebration emails: includes milestone-specific fields.
 * For regular emails: includes member identity fields.
 */
const buildLivePreviewMergeData = (memberIndex: number): Record<string, string> | null => {
  // Start with the static sample data as a base
  // (covers any fields we don't have real data for)
  const mergeData = { ...EXAMPLE_MERGE_DATA };
  
  // Check if we're in a celebration flow with milestone data
  if (celebrationAudience && celebrationAudience.milestones.length > 0) {
    const milestone = celebrationAudience.milestones[memberIndex];
    if (!milestone) return null;
    
    // Parse name
    const nameParts = milestone.memberName.trim().split(/\s+/);
    const firstName = nameParts[0] || 'Member';
    const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : '';
    
    // Override with real member data
    mergeData["{{FirstName}}"] = firstName;
    mergeData["{{LastName}}"] = lastName;
    mergeData["{{FullName}}"] = milestone.memberName;
    mergeData["{{Email}}"] = milestone.memberEmail || '';
    
    // Override with real milestone data
    if (milestone.milestoneLabel) mergeData["{{MilestoneLabel}}"] = milestone.milestoneLabel;
    if (milestone.milestoneValue) mergeData["{{MilestoneValue}}"] = milestone.milestoneValue;
    if (milestone.milestoneEmoji) mergeData["{{MilestoneEmoji}}"] = milestone.milestoneEmoji;
    
    // Build MilestoneDetail from contextJson
    if (milestone.contextJson && Object.keys(milestone.contextJson).length > 0) {
      const ctx = milestone.contextJson;
      const parts: string[] = [];
      if (ctx.totalVolume) {
        const vol = ctx.totalVolume >= 1000000 
          ? `$${(ctx.totalVolume / 1000000).toFixed(1)}M`
          : ctx.totalVolume >= 1000 ? `$${Math.round(ctx.totalVolume / 1000)}K` : `$${ctx.totalVolume}`;
        parts.push(`with ${vol} in career volume`);
      }
      if (ctx.city) parts.push(`primarily in ${ctx.city}`);
      if (ctx.recentSides) parts.push(`including ${ctx.recentSides} recent transactions`);
      if (ctx.propertyType) parts.push(`focusing on ${ctx.propertyType}`);
      if (ctx.luxuryTransactions) parts.push(`with ${ctx.luxuryTransactions} luxury transaction${ctx.luxuryTransactions > 1 ? 's' : ''}`);
      if (ctx.avgPrice) {
        const avg = ctx.avgPrice >= 1000000 ? `$${(ctx.avgPrice / 1000000).toFixed(1)}M` : `$${Math.round(ctx.avgPrice / 1000)}K`;
        parts.push(`averaging ${avg} per transaction`);
      }
      if (parts.length > 0) mergeData["{{MilestoneDetail}}"] = parts.join(', ');
    }
    
    return mergeData;
  }
  
  // Regular audience — use fetched member data
  if (previewMembers.length > 0) {
    const member = previewMembers[memberIndex];
    if (!member) return null;
    
    mergeData["{{FirstName}}"] = member.firstName || member.memberName.split(' ')[0] || '';
    mergeData["{{LastName}}"] = member.lastName || member.memberName.split(' ').slice(1).join(' ') || '';
    mergeData["{{FullName}}"] = member.memberName || `${member.firstName || ''} ${member.lastName || ''}`.trim();
    mergeData["{{Email}}"] = member.email || '';
    if (member.officeName) mergeData["{{OfficeName}}"] = member.officeName;
    
    return mergeData;
  }
  
  // No real data available — return null to signal "use sample data"
  return null;
};

/**
 * Replace merge fields in content using a specific merge data map.
 */
const replaceMergeFieldsWithLiveData = (html: string, mergeData: Record<string, string>): string => {
  if (!html) return html;
  let result = html;
  
  for (const [tag, value] of Object.entries(mergeData)) {
    result = result.replace(new RegExp(tag.replace(/[{}]/g, '\\$&'), 'g'), value);
  }
  
  // Style any remaining unreplaced fields as blue badges
  result = result.replace(
    /\{\{(\w+)\}\}/g,
    '<span style="background-color: #e0f2fe; color: #0369a1; padding: 1px 4px; border-radius: 3px; font-size: 0.9em;">[$1]</span>'
  );
  
  return result;
};
```

Make sure `EXAMPLE_MERGE_DATA` is imported at the top of the file:
```typescript
import { replaceMergeFieldsWithSampleData, EXAMPLE_MERGE_DATA } from "@/lib/emailBlocks";
```

(If `EXAMPLE_MERGE_DATA` is not already exported from emailBlocks.ts, add the `export` keyword to its declaration.)

---

## PART 3: UPDATE getEmailPreviewHtml

### Task 3A: Accept Optional Custom Merge Data

**File: `client/src/pages/SendEmail.tsx`**

Update `getEmailPreviewHtml` to accept an optional merge data map. When provided, use it instead of the static sample data:

Change the function signature and the body replacement line:

```typescript
const getEmailPreviewHtml = (customMergeData?: Record<string, string>) => {
  if (!emailDraft) return '';
  
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const logoUrl = `${baseUrl}/mainstreet-logo.png`;
  
  // Use custom merge data if provided (live preview), otherwise use sample data
  const processedBody = customMergeData 
    ? replaceMergeFieldsWithLiveData(emailDraft.body, customMergeData)
    : replaceMergeFieldsWithSampleData(emailDraft.body);
  
  // ... rest of the template stays exactly the same, but replace the body injection line:
  // CHANGE: ${replaceMergeFieldsWithSampleData(emailDraft.body)}
  // TO:     ${processedBody}
  
  // Everything else in the HTML template remains unchanged.
```

Only the body content injection line changes. The logo, header, footer, styles — all stay the same.

---

## PART 4: REPLACE THE PREVIEW STEP UI

### Task 4A: Add Preview Navigation State

**File: `client/src/pages/SendEmail.tsx`**

Add this state variable near the existing state declarations:

```typescript
const [previewMemberIndex, setPreviewMemberIndex] = useState(0);
```

Add a reset effect:

```typescript
// Reset preview navigation when audience changes
useEffect(() => {
  setPreviewMemberIndex(0);
}, [selectedAudience?.audienceId, celebrationAudience?.type]);
```

### Task 4B: Replace the Preview Step

Replace the entire preview step section (currently around lines 2561-2617) with:

```tsx
{currentStep === 'preview' && emailDraft && (() => {
  // Determine how many members we can preview
  const previewableCount = celebrationAudience 
    ? celebrationAudience.milestones.length 
    : previewMembers.length;
  const totalAudienceCount = celebrationAudience
    ? celebrationAudience.milestones.length
    : selectedAudience?.memberCount || selectedAudience?.memberKeys?.length || previewMembers.length;
  const hasLiveData = previewableCount > 0;
  const safeIndex = Math.min(previewMemberIndex, Math.max(0, previewableCount - 1));
  const liveMergeData = hasLiveData ? buildLivePreviewMergeData(safeIndex) : null;
  
  // Get current member info for the nav bar
  const currentMember = celebrationAudience
    ? celebrationAudience.milestones[safeIndex]
    : previewMembers[safeIndex];
  const currentName = celebrationAudience
    ? currentMember?.memberName
    : (currentMember as any)?.memberName;
  const currentMilestone = celebrationAudience
    ? (currentMember as any)?.milestoneLabel
    : null;
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Eye className="w-5 h-5" />
          Preview Email
        </CardTitle>
        <CardDescription>
          {hasLiveData 
            ? `Previewing with real recipient data`
            : `See how your email will appear to recipients`
          }
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Recipient navigator — shown when we have real member data */}
        {hasLiveData && (
          <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setPreviewMemberIndex(prev => Math.max(0, prev - 1))}
              disabled={safeIndex === 0}
              data-testid="button-preview-prev"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Previous
            </Button>
            
            <div className="text-center min-w-0 px-2">
              <p className="text-sm font-medium text-purple-800 dark:text-purple-200 truncate">
                {currentName || 'Loading...'}
              </p>
              <p className="text-xs text-purple-600 dark:text-purple-400">
                Recipient {safeIndex + 1} of {previewableCount > totalAudienceCount ? previewableCount : totalAudienceCount.toLocaleString()}
                {previewableCount < totalAudienceCount && ` (previewing first ${previewableCount})`}
                {currentMilestone && (
                  <> — {currentMilestone}</>
                )}
              </p>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setPreviewMemberIndex(prev => Math.min(previewableCount - 1, prev + 1))}
              disabled={safeIndex >= previewableCount - 1}
              data-testid="button-preview-next"
            >
              Next
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        )}
        
        {/* Loading state while member data is being fetched */}
        {previewMembersLoading && (
          <div className="flex items-center justify-center py-3 text-sm text-muted-foreground">
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Loading recipient data for preview...
          </div>
        )}
        
        {/* Subject line and preview text — with real data when available */}
        <div className="space-y-4">
          <div className="flex items-center gap-4 p-3 rounded-lg bg-muted/50">
            <div className="flex-1">
              <p className="text-sm text-muted-foreground">Subject:</p>
              <p className="font-medium">
                {liveMergeData 
                  ? replaceMergeFieldsWithLiveData(subjectLine || emailDraft.subject, liveMergeData)
                  : replaceMergeFieldsWithSampleData(subjectLine || emailDraft.subject)
                }
              </p>
            </div>
            {(previewText || emailDraft.preview_text) && (
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Preview:</p>
                <p className="text-sm">
                  {liveMergeData
                    ? replaceMergeFieldsWithLiveData(previewText || emailDraft.preview_text || '', liveMergeData)
                    : replaceMergeFieldsWithSampleData(previewText || emailDraft.preview_text || '')
                  }
                </p>
              </div>
            )}
          </div>
        </div>
        
        {/* Email preview iframe — with real data when available */}
        <div className="border rounded-lg overflow-hidden">
          <iframe
            srcDoc={getEmailPreviewHtml(liveMergeData || undefined)}
            className="w-full bg-gray-100 dark:bg-gray-800"
            style={{ minHeight: '600px', border: 'none', width: '100%' }}
            title="Email Preview"
            data-testid="iframe-email-preview"
          />
        </div>
        
        <div className="flex justify-between pt-4">
          <Button 
            variant="outline"
            onClick={() => setCurrentStep('compose')}
            data-testid="button-back-to-compose"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button 
            onClick={() => setCurrentStep('send')}
            data-testid="button-next-to-send"
          >
            Next
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
})()}
```

---

## PART 5: ENSURE EXAMPLE_MERGE_DATA IS EXPORTED

**File: `client/src/lib/emailBlocks.ts`**

Verify the export exists:
```typescript
export const EXAMPLE_MERGE_DATA: Record<string, string> = {
```

If it says just `const`, add `export`. The live preview imports it as a base to overlay real data on top of.

---

## IMPORTANT: WHAT STILL USES SAMPLE DATA (AND THAT'S OK)

The **Compose step** (where the staffer is writing/editing the email body) continues to show sample data in the Quill editor and in any inline previews. This is correct because:
- The staffer is writing the email template, not previewing it for a specific recipient
- Merge field tags like `{{FirstName}}` need to be visible as tags while editing
- The "Edit with AI" preview in the compose step is about content, not personalization

The live data preview ONLY applies to the **Preview step** — the dedicated "see how your email will appear to recipients" step that comes after composing.

---

## VERIFICATION CHECKLIST

### Celebration Emails — Live Preview with Milestone Data
- [ ] Select "Volume Milestones" → Preview shows FIRST member's real name and real milestone (not "Sarah" / "50th Career Transaction")
- [ ] Click Next → shows SECOND member with their own milestone data
- [ ] Navigation shows "Recipient 1 of 65 — [milestone label]"
- [ ] Subject line updates per-member with real milestone label
- [ ] Preview text updates per-member

### Different Milestone Types
- [ ] "Rising Stars" → shows "Rising Star" labels with real new-agent names
- [ ] "Volume Milestones" → shows volume-specific labels with real names
- [ ] "Top Producers This Month" → shows production milestones
- [ ] Each type shows different data, not the same "50th Career Transaction"

### Regular Audience Emails — Live Preview with Member Data
- [ ] Create email to "All Active Members" (18,000+) → Preview shows first member's real name and office
- [ ] Navigation shows "Recipient 1 of 18,275 (previewing first 15)"
- [ ] Click through all 15 → each shows different real member name
- [ ] Subject line "Hi {{FirstName}}" → shows "Hi [Real First Name]"
- [ ] Office name merge field shows real office name

### Small Audiences
- [ ] Audience of 5 members → All 5 previewable, navigation shows "Recipient 1 of 5"
- [ ] Audience of 1 member → Shows that member, both arrows disabled

### Edge Cases
- [ ] Member with no email → preview still shows name (email field empty)
- [ ] Member with no office → OfficeName falls back to sample data from EXAMPLE_MERGE_DATA
- [ ] External CSV audience → shows email-based preview
- [ ] Switch between celebration and regular audience → preview resets to first member
- [ ] Preview step while members are loading → shows loading spinner, then real data

### Compose Step — No Regressions
- [ ] Email composer still shows sample data in inline previews
- [ ] Merge field tags still visible as `{{FirstName}}` in the editor
- [ ] "Edit with AI" flow works as before

---

## FILES CHANGED

**Modified:**
- `client/src/pages/SendEmail.tsx` — Expanded previewMembers fetch to always get first 15, added previewMemberIndex state, added buildLivePreviewMergeData and replaceMergeFieldsWithLiveData functions, updated getEmailPreviewHtml to accept custom merge data, replaced preview step UI with live data navigation for all email types
- `client/src/lib/emailBlocks.ts` — Added export to EXAMPLE_MERGE_DATA if not already exported

**NOT modified:**
- `server/services/emailService.ts` — No changes
- `server/routes.ts` — No changes (the /api/members/by-keys endpoint already returns all needed fields)
- `client/src/pages/CreateAutomation.tsx` — Automation preview can be enhanced in a future prompt using the same pattern

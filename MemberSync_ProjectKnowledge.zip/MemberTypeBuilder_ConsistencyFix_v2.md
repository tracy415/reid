# Member Type Builder: Data Consistency Fix
## Replit Prompt â€” February 2026

**Problem:** The Member Type Builder page counts members differently than the Dashboard, producing different totals. The Dashboard reads from `member_metrics_cache` (refreshed daily from `AMS.apmmember`) and shows 18,259 active members. The Member Type Builder queries `AMS.appmemberassociation` directly and shows 18,093. The difference comes from members whose status is Active in one table but Suspended/Inactive in the other, plus a handful of MLS-Only members who exist in `appmemberassociation` but not `apmmember`.

**Solution:** Make `member_metrics_cache` the single source of truth for "who is an active member" across the entire app. The Member Type Builder queries will use a two-step pattern: get bill type data from the external production database, then filter/enrich against the local `member_metrics_cache` to confirm active status and get display data.

**CRITICAL: Do NOT modify the Dashboard, the member_metrics_cache refresh job, or any AI services.**

---

## FILES THAT CHANGE

1. **server/index.ts** (or wherever the Express routes are registered) â€” the handlers for:
   - `GET /api/smartsends/audiences/member-bill-type/counts`
   - `POST /api/smartsends/audiences/member-bill-type/preview`
2. **client/src/components/MemberBillTypeBuilder.tsx** â€” the `buildSQL()` function (line 32)
3. **server/aiAudienceService.ts** â€” the enrichment query in `getAudienceMembers()` (around line 670)

---

## CHANGE 1: Bill Type Counts Endpoint

**Endpoint:** `GET /api/smartsends/audiences/member-bill-type/counts`

The current query only hits the external database (`AMS.appmemberassociation`) and filters by `Status = 'Active'`. This produces counts that don't match the Dashboard.

**Replace with a two-step approach in the handler:**

Step A â€” Query the external database for all bill type â†’ member key mappings:
```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."BillType"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT la."MemberKey", la."BillType"
FROM latest_assoc la
WHERE COALESCE(NULLIF(TRIM(la."BillType"), ''), '') <> ''
```

Step B â€” Query the local database for all active member keys:
```sql
SELECT member_key FROM member_metrics_cache WHERE member_status = 'Active'
```

Step C â€” In the handler code, intersect the two sets and count by bill type:
```typescript
const activeKeys = new Set(activeMembersResult.rows.map((r: any) => r.member_key));
const counts: Record<string, number> = {};
for (const row of assocResult.rows as any[]) {
  if (activeKeys.has(row.MemberKey)) {
    counts[row.BillType] = (counts[row.BillType] || 0) + 1;
  }
}
return res.json({ counts });
```

**Key changes:**
- Added `AND ma."AssociationId" = 'MainStreet'` to filter to the primary association record
- Removed `WHERE la."Status" = 'Active'` â€” we no longer rely on the association table's status field
- The intersection with `member_metrics_cache` ensures only members who are Active in `apmmember` get counted
- Keep the existing 1-hour cache on this endpoint

---

## CHANGE 2: Preview Endpoint

**Endpoint:** `POST /api/smartsends/audiences/member-bill-type/preview`

**Replace with a two-step approach in the handler:**

Step A â€” Query the external database to get matching member keys:
```sql
WITH latest_assoc AS (
  SELECT DISTINCT ON (ma."ApmClientId", ma."MemberKey", ma."AssociationId")
    ma."MemberKey",
    ma."BillType"
  FROM "AMS"."appmemberassociation" ma
  WHERE ma."ApmClientId" = 'MainStreet'
    AND ma."AssociationId" = 'MainStreet'
  ORDER BY ma."ApmClientId", ma."MemberKey", ma."AssociationId",
           ma."ApmSourceModificationTimestamp" DESC
)
SELECT DISTINCT la."MemberKey"
FROM latest_assoc la
WHERE la."BillType" = ANY($1)
```

Where `$1` is the array of selected bill type codes from the request body (`req.body.billTypeCodes`).

Step B â€” Filter those keys against the local cache and get display data + count:
```sql
SELECT member_key AS "MemberKey",
       member_name AS "MemberFullName",
       member_email AS "MemberEmail",
       office_name AS "OfficeName"
FROM member_metrics_cache
WHERE member_key = ANY($1)
  AND member_status = 'Active'
LIMIT 15
```

```sql
SELECT COUNT(*) as total
FROM member_metrics_cache
WHERE member_key = ANY($1)
  AND member_status = 'Active'
```

Where `$1` in these queries is the array of member keys returned from Step A.

Return the response in the same format the frontend expects:
```json
{
  "totalCount": 18259,
  "members": [
    { "MemberKey": "259036", "MemberFullName": "Jane Smith", "MemberEmail": "jane@email.com", "OfficeName": "RE/MAX" },
    ...
  ]
}
```

---

## CHANGE 3: Frontend buildSQL() Function

**File:** `client/src/components/MemberBillTypeBuilder.tsx`

The `buildSQL` function (starting at line 32) constructs the SQL that gets stored in the `saved_audiences` table when the user saves a Member Type audience. This SQL is re-run by `getAudienceMembers()` every time the audience is used.

**IMPORTANT:** This saved SQL runs on the **external** database only (the `getAudienceMembers()` function routes it there because it references `AMS` schema tables). It cannot join against `member_metrics_cache` (which is on the local database). So the saved SQL should ONLY return MemberKeys â€” the existing enrichment step in `getAudienceMembers()` handles looking up names, emails, and office names.

**Replace the `buildSQL` function with:**

```typescript
function buildSQL(billTypeCodes: string[]): string {
  const billArray = billTypeCodes.map((code) => `'${code}'`).join(", ");

  return `WITH latest_assoc AS (
  SELECT DISTINCT ON ("ApmClientId", "MemberKey", "AssociationId")
    "MemberKey", "BillType"
  FROM "AMS"."apmmemberassociation"
  WHERE "ApmClientId" = 'MainStreet'
    AND "AssociationId" = 'MainStreet'
  ORDER BY "ApmClientId", "MemberKey", "AssociationId", "ApmSourceModificationTimestamp" DESC
)
SELECT DISTINCT la."MemberKey"
FROM latest_assoc la
WHERE la."BillType" = ANY(ARRAY[${billArray}])`;
}
```

**Key changes from the old function:**
- Added `AND "AssociationId" = 'MainStreet'` filter
- Removed `WHERE la."Status" = 'Active'` â€” the enrichment step will filter to active members
- Only returns `"MemberKey"` â€” no longer joins `AMS.apmmember` or returns name/email (the enrichment step handles this)
- No LIMIT â€” when sending email, we need all matching members

---

## CHANGE 4: Enrichment Query in getAudienceMembers()

**File:** `server/aiAudienceService.ts`

In the `getAudienceMembers()` function, find the enrichment block that runs for smart audiences when results come from the external database. It's around line 666-693 and looks like:

```typescript
if (rawMembers.length > 0 && !useLocalDb && externalDb) {
  const memberKeys = rawMembers.map(m => m.MemberKey || m.member_key).filter(Boolean);
  if (memberKeys.length > 0) {
    const keysArray = memberKeys.map(k => `'${k}'`).join(',');
    const enrichQuery = `
      SELECT 
        m."MemberKey",
        m."MemberFirstName",
        m."MemberLastName",
        o."OfficeName"
      FROM "AMS"."apmmember" m
      LEFT JOIN "AMS"."apmoffice" o ON m."OfficeKey" = o."OfficeKey"
      WHERE m."MemberKey" IN (${keysArray})
    `;
```

**Replace the enrichment query with:**

```typescript
    const enrichQuery = `
      SELECT DISTINCT ON (m."ApmClientId", m."MemberKey")
        m."MemberKey",
        m."MemberFirstName",
        m."MemberLastName",
        o."OfficeName"
      FROM "AMS"."apmmember" m
      LEFT JOIN (
        SELECT DISTINCT ON ("ApmClientId", "OfficeKey")
          "OfficeKey", "OfficeName"
        FROM "AMS"."apmoffice"
        WHERE "ApmClientId" = 'MainStreet'
        ORDER BY "ApmClientId", "OfficeKey", "ApmSourceModificationTimestamp" DESC
      ) o ON m."OfficeKey" = o."OfficeKey"
      WHERE m."MemberKey" IN (${keysArray})
        AND m."ApmClientId" = 'MainStreet'
        AND m."MemberStatus" = 'Active'
      ORDER BY m."ApmClientId", m."MemberKey", m."ApmSourceModificationTimestamp" DESC
    `;
```

**What this fixes:**
- Adds `DISTINCT ON` deduplication pattern (was missing â€” `apmmember` has snapshot duplicates)
- Adds `"MemberStatus" = 'Active'` filter so inactive members are excluded from ALL smart audience results, not just Member Type audiences
- Adds proper deduplication on the `apmoffice` join
- Adds `"ApmClientId" = 'MainStreet'` filter (was missing)

**This change improves ALL smart audiences**, not just Member Type. Any AI-generated audience or future smart audience will also benefit from the dedup fix.

After the enrichment query runs and populates the `enrichMap`, the count of successfully enriched members may be lower than `rawMembers.length` (because some member keys from the association query may not match an active member in `apmmember`). The existing code sets `totalCount` from the count query, which may overcount. After the enrichment, add:

```typescript
// Update count to reflect only active, enriched members
const enrichedCount = members.filter(m => enrichMap.has(m.MemberKey)).length;
if (enrichedCount < totalCount) {
  totalCount = enrichedCount;
}
```

---

## TESTING CHECKLIST

- [ ] Member Type Builder page loads with bill type counts next to each checkbox
- [ ] Sum of all bill type counts closely matches Dashboard "Total Active Members" (within single digits, not hundreds)
- [ ] "Select All" â†’ "Generate Preview" count closely matches Dashboard total
- [ ] Selecting just "DR" shows ~1,768 members (Designated REALTORs)
- [ ] Saving a Member Type audience works â€” appears in Saved Audiences list with correct count
- [ ] Using a saved Member Type audience in Send Email pulls correct members with names and emails
- [ ] Dashboard Total Active Members number is unchanged
- [ ] Existing AI-generated smart audiences still work correctly
- [ ] Existing picklist and CSV upload audiences still work correctly
- [ ] AI Builder and AI Chats still work normally

---

## DO NOT CHANGE

- Dashboard metrics queries (`storage.ts` `getDashboardMetrics`)
- `member_metrics_cache` refresh job (`memberMetricsCacheService.ts`)
- `sharedDatabaseSchema.ts`
- AI Audience Builder or AI Query Service
- Any other audience types (picklist, csv_upload, ai_generated, external_contacts)
- The Member Type Builder frontend layout, checkboxes, or UI â€” only the `buildSQL` function changes
- The `PicklistBuilder.tsx` component

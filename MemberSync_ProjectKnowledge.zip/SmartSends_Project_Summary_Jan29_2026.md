# SmartSends Project Summary
## As of January 29, 2026

This document captures all decisions, schemas, requirements, and context for the SmartSends Phase 3 build. Use this to resume work in a new conversation.

---

# TABLE OF CONTENTS

1. [Project Overview](#1-project-overview)
2. [Database Architecture](#2-database-architecture)
3. [Production Schemas (Read-Only)](#3-production-schemas-read-only)
4. [SmartSends Tables (Replit DB - Read/Write)](#4-smartsends-tables-replit-db-readwrite)
5. [Billing Calendar & Charge Codes](#5-billing-calendar--charge-codes)
6. [Annual Dues Cycle](#6-annual-dues-cycle)
7. [Mainstreet Advantage Cycle](#7-mainstreet-advantage-cycle)
8. [Risk Scoring System](#8-risk-scoring-system)
9. [Status Tracking](#9-status-tracking)
10. [Daily Jobs Schedule](#10-daily-jobs-schedule)
11. [Phase 3 Deliverables](#11-phase-3-deliverables)
12. [Phase 4 Preview: Broker Module](#12-phase-4-preview-broker-module)
13. [Bookmarked Future Ideas](#13-bookmarked-future-ideas)
14. [Key Files & Resources](#14-key-files--resources)

---

# 1. PROJECT OVERVIEW

## What is SmartSends?

SmartSends is an email marketing and member retention system for Mainstreet REALTORSÂ®. It builds on MemberSync (member engagement tracking) to add:

- **Phase 1** (Complete): Email sending infrastructure, tracking, templates
- **Phase 2** (Complete): AI-powered audience building, email composition
- **Phase 3** (In Progress): Lapse prevention, risk scoring, intervention management
- **Phase 4** (Planned): Broker & Office Management module

## The Lapse Problem

Members lapse when payment issues persist. Mainstreet (via Sirius) controls status changes:
- Active â†’ Suspended (non-payment)
- Suspended â†’ Inactive (didn't pay by deadline)
- Recovery: Suspended/Inactive â†’ Active (paid and restored)

## Technical Setup

- **Production Database**: Read-only access to Mainstreet's data via Sirius ETL
- **Replit Database**: Read/write for SmartSends-specific tables
- **ETL Frequency**: ~15 minutes from Sirius
- **History Retention**: 14-day rolling window in `history.change_history`

---

# 2. DATABASE ARCHITECTURE

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                 PRODUCTION DATABASE (Read-Only)             â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  "AMS" Schema:                                              â”‚
â”‚    - apmmember (member data)                                â”‚
â”‚    - apmmemberdues (invoices)                               â”‚
â”‚    - apmevent (classes/events)                              â”‚
â”‚    - apmeventregistration (attendance)                      â”‚
â”‚    - apmmembereducation (course completions)                â”‚
â”‚    - apmoffice (office data - but use MLS for status)       â”‚
â”‚    - receipt_invoice (payment tracking)                     â”‚
â”‚                                                             â”‚
â”‚  "MLS" Schema:                                              â”‚
â”‚    - apmoffice (USE THIS - has OfficeStatus)                â”‚
â”‚                                                             â”‚
â”‚  "history" Schema:                                          â”‚
â”‚    - change_history (14-day rolling, status changes)        â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
                            â”‚
                            â”‚ Read
                            â–¼
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                 REPLIT DATABASE (Read/Write)                â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  SmartSends Tables:                                         â”‚
â”‚    - activity_cache (daily refresh from production)         â”‚
â”‚    - member_status_tracking (permanent history)             â”‚
â”‚    - office_status_tracking (permanent history)             â”‚
â”‚    - member_risk_scores (daily calculations)                â”‚
â”‚    - office_payment_health (daily calculations)             â”‚
â”‚    - intervention_log (track all interventions)             â”‚
â”‚    - billing_calendar (configurable dates)                  â”‚
â”‚    - broker_liability (DR Formula tracking)                 â”‚
â”‚                                                             â”‚
â”‚  Phase 1 & 2 Tables (already exist):                        â”‚
â”‚    - email_campaigns                                        â”‚
â”‚    - email_sends                                            â”‚
â”‚    - email_events                                           â”‚
â”‚    - audiences                                              â”‚
â”‚    - templates                                              â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

# 3. PRODUCTION SCHEMAS (READ-ONLY)

## AMS.apmmember

| Field | Type | Description |
|-------|------|-------------|
| MemberKey | text | Primary key |
| MemberMlsId | text | Links to MLS data |
| MemberFullName | text | Display name |
| MemberFirstName | text | First name |
| MemberLastName | text | Last name |
| MemberEmail | text | Email address |
| MemberMobilePhone | text | Mobile phone |
| MemberType | text | 'REALTOR', 'Leasing Agent', 'Secondary' |
| MemberStatus | text | 'Active', 'Suspended', 'Inactive' |
| MemberStateLicense | text | License number |
| MemberStateLicenseExpirationDate | date | License expiration |
| MemberDesignations | jsonb | Professional certifications |
| NarJoinDate | date | When joined Mainstreet REALTORSÂ® |
| OfficeKey | text | Links to office |
| ApmClientId | text | ALWAYS filter = 'MainStreet' |
| ApmSourceModificationTimestamp | timestamptz | For deduplication |

## AMS.apmmemberdues

| Field | Type | Description |
|-------|------|-------------|
| MemberKey | text | Links to member |
| InvoiceKey | text | Invoice identifier |
| InvoiceDate | date | When invoice created |
| DueDate | date | Payment due date |
| InvoiceTotal | numeric | Total amount |
| AmountPaid | numeric | Amount paid so far |
| BalanceDue | numeric | Remaining balance |
| PaidStatus | boolean | Fully paid flag |
| is_pending | boolean | Pending invoice flag |
| ApmClientId | text | ALWAYS filter = 'MainStreet' |

## AMS.receipt_invoice

| Field | Type | Description |
|-------|------|-------------|
| InvoiceKey | text | Links to apmmemberdues |
| IncurredMemberKey | text | Who payment is for |
| OfficeKey | text | Which office |
| Amount | numeric(20,2) | Payment amount |
| ReceiptDate | date | When payment received |
| PaidBy | text | Who paid: 'Member', 'Broker', 'Office' |
| ApmClientId | text | ALWAYS filter = 'MainStreet' |

## AMS.apmmemberinvoicedetails

| Field | Type | Description |
|-------|------|-------------|
| InvoiceKey | text | Links to invoice |
| ChargeCode | text | Billing code (e.g., 'RM101', 'S0426') |
| InvoiceDescription | text | Line item description |
| Amount | numeric | Line item amount |

## MLS.apmoffice (USE THIS FOR OFFICE STATUS)

| Field | Type | Description |
|-------|------|-------------|
| OfficeKey | text | Primary key |
| OfficeName | text | Display name |
| OfficeEmail | text | Office email |
| OfficePhone | text | Office phone |
| OfficeBrokerKey | text | Links to DR/broker member |
| OfficeStatus | text | **'Active' or 'Inactive' ONLY** |
| OfficeAddress1 | text | Street address |
| OfficeCity | text | City |
| OfficeStateOrProvince | text | State |
| OfficePostalCode | text | ZIP |
| ApmClientId | text | ALWAYS filter = 'MainStreet' |
| ApmSourceModificationTimestamp | timestamptz | For deduplication |

**CRITICAL:** Office status is the gatekeeper. If office is Inactive, ALL agents lose MLS/SentriLock access even if their individual status is Active.

## history.change_history

| Field | Type | Description |
|-------|------|-------------|
| unique_id | uuid | Primary key |
| client_id | text | ALWAYS filter = 'MainStreet' |
| source_unique_id | text | Fallback member/office key |
| received_datetime | timestamptz | When change captured |
| source_modification | timestamptz | When change occurred |
| jrecord | jsonb | Full record as JSON |

Access member fields: `jrecord->>'MemberKey'`, `jrecord->>'MemberStatus'`, etc.

**IMPORTANT:** This is a parent table that auto-routes to monthly partitions. Query the parent table, NOT hardcoded partition names. Data retention is 14 days rolling.

---

# 4. SMARTSENDS TABLES (REPLIT DB - READ/WRITE)

## activity_cache

Cached education/event data refreshed daily from production.

```sql
CREATE TABLE activity_cache (
  cache_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_key TEXT NOT NULL,
  activity_source TEXT,        -- 'event_registration' or 'member_education'
  event_type TEXT,             -- 'class' or 'event'
  course_type TEXT,            -- 'Core', 'Elective', etc.
  activity_name TEXT,
  education_credits TEXT,
  is_completed BOOLEAN,
  is_attended BOOLEAN,
  completion_date DATE,
  start_datetime TIMESTAMP,
  event_id TEXT,
  cached_at TIMESTAMP DEFAULT NOW()
);
```

## member_status_tracking

Permanent record of member status changes.

```sql
CREATE TABLE member_status_tracking (
  tracking_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_key TEXT NOT NULL,
  member_name TEXT,
  member_email TEXT,
  office_key TEXT,
  old_status TEXT NOT NULL,
  new_status TEXT NOT NULL,
  detected_at TIMESTAMP NOT NULL,
  membership_days_at_change INTEGER,
  membership_years_at_change NUMERIC,
  days_overdue_at_change INTEGER,
  balance_due_at_change NUMERIC,
  last_transaction_date DATE,
  last_ce_date DATE,
  last_event_date DATE,
  is_recovery BOOLEAN DEFAULT false,
  recovered_from_status TEXT,
  days_in_problem_status INTEGER,
  is_first_inactive BOOLEAN DEFAULT false,  -- Non-member detection
  intervention_sent BOOLEAN DEFAULT false,
  intervention_campaign_id UUID,
  intervention_sent_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  CONSTRAINT unique_status_change UNIQUE (member_key, detected_at, new_status)
);
```

## office_status_tracking

Permanent record of office status changes.

```sql
CREATE TABLE office_status_tracking (
  tracking_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  office_key TEXT NOT NULL,
  office_name TEXT,
  broker_key TEXT,
  old_status TEXT NOT NULL,
  new_status TEXT NOT NULL,
  detected_at TIMESTAMP NOT NULL,
  total_agents_affected INTEGER,
  paid_agents_affected INTEGER,    -- Agents who paid but lost access
  unpaid_agents_in_office INTEGER,
  total_unpaid_balance NUMERIC,
  intervention_sent BOOLEAN DEFAULT false,
  intervention_campaign_id UUID,
  created_at TIMESTAMP DEFAULT NOW(),
  CONSTRAINT unique_office_status_change UNIQUE (office_key, detected_at, new_status)
);
```

## member_risk_scores

Daily risk assessment for all Active members.

```sql
CREATE TABLE member_risk_scores (
  score_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_key TEXT NOT NULL,
  scored_at DATE DEFAULT CURRENT_DATE,
  current_status TEXT NOT NULL,
  membership_days INTEGER NOT NULL,
  membership_years NUMERIC NOT NULL,
  office_key TEXT,
  office_status TEXT,              -- Track if office is Active/Inactive
  
  -- Annual Dues Risk (calendar-aware)
  annual_dues_balance NUMERIC DEFAULT 0,
  annual_dues_risk_score INTEGER DEFAULT 0,
  annual_dues_risk_factors TEXT[],
  days_to_hard_deadline INTEGER,   -- Days until Jan 31
  
  -- Advantage Risk (office-level, but tracked per member)
  advantage_balance NUMERIC DEFAULT 0,
  office_advantage_risk_score INTEGER DEFAULT 0,
  office_at_risk BOOLEAN DEFAULT false,
  
  -- Engagement Risk
  months_since_transaction INTEGER,
  months_since_ce INTEGER,
  months_since_event INTEGER,
  engagement_risk_score INTEGER DEFAULT 0,
  engagement_risk_factors TEXT[],
  
  -- Combined
  total_risk_score INTEGER DEFAULT 0,
  risk_tier TEXT,                  -- 'Critical', 'High', 'Medium', 'Low'
  
  -- Recent changes
  changed_in_last_14_days BOOLEAN DEFAULT false,
  last_change_date TIMESTAMP,
  last_change_to_status TEXT,
  
  created_at TIMESTAMP DEFAULT NOW(),
  CONSTRAINT unique_member_score_date UNIQUE (member_key, scored_at)
);
```

## office_payment_health

Daily office-level payment analytics.

```sql
CREATE TABLE office_payment_health (
  health_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  office_key TEXT NOT NULL,
  calculated_at DATE DEFAULT CURRENT_DATE,
  office_name TEXT,
  office_status TEXT,             -- Current status
  broker_key TEXT,
  
  -- Member counts
  total_members INTEGER,
  members_with_unpaid_dues INTEGER,
  members_with_unpaid_advantage INTEGER,
  members_suspended INTEGER,
  members_inactive INTEGER,
  
  -- Financial
  total_unpaid_dues NUMERIC,
  total_unpaid_advantage NUMERIC,
  worst_days_overdue INTEGER,
  
  -- Risk breakdown
  critical_risk_count INTEGER,
  high_risk_count INTEGER,
  moderate_risk_count INTEGER,
  
  -- Payment patterns
  broker_paid_count INTEGER,
  member_paid_count INTEGER,
  
  -- Success metrics
  recoveries_last_30_days INTEGER,
  
  -- Health score
  payment_health_score NUMERIC,
  health_tier TEXT,               -- 'Excellent', 'Good', 'Fair', 'Poor', 'Critical'
  
  created_at TIMESTAMP DEFAULT NOW(),
  CONSTRAINT unique_office_health_date UNIQUE (office_key, calculated_at)
);
```

## intervention_log

Track all interventions and outcomes.

```sql
CREATE TABLE intervention_log (
  intervention_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Target (member or office)
  member_key TEXT,
  office_key TEXT,
  target_type TEXT NOT NULL,      -- 'member', 'office', 'broker'
  
  -- Intervention details
  intervention_type TEXT NOT NULL,
  trigger_reason TEXT NOT NULL,
  billing_cycle TEXT,             -- 'ANNUAL_DUES', 'ADVANTAGE_SPRING', etc.
  
  -- Campaign
  campaign_id UUID,
  email_subject TEXT,
  email_sent_at TIMESTAMP,
  
  -- State at intervention
  status_at_intervention TEXT,
  days_overdue_at_intervention INTEGER,
  balance_at_intervention NUMERIC,
  risk_score_at_intervention INTEGER,
  
  -- Outcomes
  email_opened BOOLEAN DEFAULT false,
  email_opened_at TIMESTAMP,
  email_clicked BOOLEAN DEFAULT false,
  email_clicked_at TIMESTAMP,
  payment_received BOOLEAN DEFAULT false,
  payment_received_at TIMESTAMP,
  status_restored BOOLEAN DEFAULT false,
  status_restored_at TIMESTAMP,
  days_to_payment INTEGER,
  days_to_restoration INTEGER,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

## billing_calendar

Configurable billing dates - Finance can update yearly.

```sql
CREATE TABLE billing_calendar (
  calendar_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  billing_year INTEGER NOT NULL,
  billing_cycle TEXT NOT NULL,    -- 'ANNUAL_DUES', 'ADVANTAGE_SPRING', 'ADVANTAGE_FALL'
  
  -- Invoice timing
  invoice_date DATE,
  due_date DATE,
  
  -- Suspension escalation (for Advantage)
  mls_suspension_date DATE,
  dr_suspension_date DATE,
  office_suspension_date DATE,
  
  -- Hard deadline (for Annual Dues)
  suspension_start_date DATE,     -- When individual suspensions begin
  hard_deadline DATE,             -- Pay-or-terminate deadline
  inactive_date DATE,             -- When members become Inactive/Non-Member
  
  -- Charge code pattern
  charge_code_pattern TEXT,       -- Regex for matching codes
  
  -- Status
  is_active BOOLEAN DEFAULT true,
  notes TEXT,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT unique_year_cycle UNIQUE (billing_year, billing_cycle)
);
```

## broker_liability

Track DR Formula liability by broker.

```sql
CREATE TABLE broker_liability (
  liability_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  broker_key TEXT NOT NULL,
  office_key TEXT NOT NULL,
  billing_year INTEGER NOT NULL,
  calculated_at DATE DEFAULT CURRENT_DATE,
  
  -- Liability details
  unpaid_agent_count INTEGER,
  unpaid_agent_keys TEXT[],       -- List of agent MemberKeys
  estimated_liability NUMERIC,
  
  -- After Feb 1 (actual DR invoice)
  dr_invoice_generated BOOLEAN DEFAULT false,
  dr_invoice_amount NUMERIC,
  dr_invoice_date DATE,
  dr_invoice_paid BOOLEAN DEFAULT false,
  dr_invoice_paid_date DATE,
  
  created_at TIMESTAMP DEFAULT NOW(),
  CONSTRAINT unique_broker_liability UNIQUE (broker_key, billing_year, calculated_at)
);
```

---

# 5. BILLING CALENDAR & CHARGE CODES

## Charge Code Patterns

Codes are created ~1 month before billing. Pattern is consistent but codes can't be reused.

### Annual Dues Codes

| Pattern | Example | Description |
|---------|---------|-------------|
| RM1xx | RM101, RM110, RM120 | 2026 REALTOR dues |
| RM108 | RM108 | 2026 Secondary dues |
| RM106 | RM106 | 2026 Appraiser dues |
| RD9xx | RD901, RD910, RD920 | 2025 dues (prior year) |

Components: Mainstreet local + IL REALTORS state + NAR national + R-VOICE + Public Awareness

### Mainstreet Advantage Codes

| Prefix | Meaning |
|--------|---------|
| S | Semi-Annual (standard) |
| A | Annual (standard) |
| N | Non-Member |

| Period Code | Meaning |
|-------------|---------|
| 04 | April cycle (March billing) |
| 10 | October cycle (September billing) |

| Year | Meaning |
|------|---------|
| 26 | 2026 |
| 25 | 2025 |

**Examples:**
- S0426 = Semi-Annual April 2026
- A0426 = Annual April 2026
- N0426 = Non-Member April 2026
- S1026 = Semi-Annual October 2026
- N1026 = Non-Member October 2026

**Note:** Personal Assistant codes (P0426, P426, P1026) exist but we don't receive PA data from Sirius.

### Codes to EXCLUDE from Risk Scoring

| Code Pattern | Description |
|--------------|-------------|
| RD980, RM180, etc. | RPAC (voluntary political contribution) |
| REF26, REF25 | REALTOR Education Foundation (voluntary) |
| PPFEB, PPFED, etc. | Payment processing fees |
| CE*, RA*, LAW* | Education and events |
| LATE, LATD | Late fees (follow parent invoice) |

---

# 6. ANNUAL DUES CYCLE

## Timeline

| Date | Event |
|------|-------|
| End of July | Invoices sent |
| December 1 | **Payment due** |
| December 20 | Urgent reminder window |
| January 2 | **Suspensions begin** (agents suspended individually) |
| January 15 | Critical - 2 weeks to deadline |
| January 25 | Final week |
| January 31 | **Hard deadline** - Pay or broker terminates sponsorship |
| February 1 | **Inactive** - Invoice written off, broker invoiced via DR Formula |

## What Happens

1. **Agent doesn't pay by Dec 1**: Invoice overdue
2. **January 2**: Agent status â†’ Suspended (loses portal/MLS access)
3. **January 31 deadline**: Broker must either:
   - Ensure agent pays, OR
   - Terminate sponsorship
4. **February 1 (no action taken)**:
   - Agent status â†’ Inactive (first-time = Non-Member)
   - Agent's invoice written off
   - Broker invoiced under DR Formula
   - Broker is financially responsible

## DR Formula

The Designated REALTORÂ® (broker) pays dues for non-member licensees in their office. When an agent becomes Non-Member:
- Their unpaid invoice is written off
- Broker receives a new invoice for that agent's dues
- Broker pays regardless of whether they terminated sponsorship

---

# 7. MAINSTREET ADVANTAGE CYCLE

## Timeline (Spring - April Cycle)

| Date | Event |
|------|-------|
| March 3 | Invoices sent |
| March 31 | Due (same month as billing) |
| April 1 | **MLS/SentriLock suspended** (for unpaid agents) |
| April 15 | **DR suspended** |
| April 22 | **Office suspended** (ALL agents lose access) |

## Timeline (Fall - October Cycle)

| Date | Event |
|------|-------|
| September (TBD) | Invoices sent |
| September 30 | Due |
| October 1 | MLS/SentriLock suspended |
| October 15 | DR suspended |
| October 22 | Office suspended |

**Note:** September dates confirmed in late July/August each year. Use billing_calendar configurator.

## CRITICAL: Office Suspension is the Gatekeeper

- Individual agents are NOT suspended for Advantage non-payment
- The **OFFICE** gets suspended
- When office status = Inactive:
  - ALL agents lose MLS/SentriLock access
  - Even agents who paid personally are blocked
  - Creates pressure on broker to ensure everyone pays

## What This Means for Risk Scoring

- Advantage risk is **office-level**, not agent-level
- Track which offices have unpaid Advantage invoices
- Alert brokers, not individual agents
- "Sorry for the interruption" email to paid-up agents when office suspended

---

# 8. RISK SCORING SYSTEM

## Calendar-Aware Scoring

Risk scores based on WHERE WE ARE in the billing calendar, not generic "days overdue."

### Annual Dues Risk (Agent-Level)

| Calendar Position | Risk Score | Factors |
|-------------------|------------|---------|
| Dec 1-15 (overdue) | 1 | december_overdue |
| Dec 16-31 (urgent) | 2 | december_urgent, suspension_imminent |
| Jan 2-14 (suspended) | 3 | january_suspended |
| Jan 15-24 (critical) | 4 | january_suspended, two_weeks_to_deadline |
| Jan 25-31 (final) | 5 | final_week_before_inactive |
| Feb 1+ | N/A | should_be_inactive |

### Advantage Risk (Office-Level)

| Calendar Position | Risk Score | Factors |
|-------------------|------------|---------|
| March overdue | 1 | advantage_fees_overdue |
| March 20+ | 2 | mls_suspension_imminent |
| April 1-14 | 3 | mls_suspended |
| April 15-21 | 4 | dr_suspended, office_suspension_imminent |
| April 22+ | 5 | office_suspended |

### Engagement Risk (Always Applies)

| Condition | Points |
|-----------|--------|
| No transactions 18+ months | 2 |
| No transactions 12-17 months | 1 |
| No CE 18+ months | 2 |
| No CE 12-17 months | 1 |
| No events 12+ months | 1 |

### Combined Risk Tiers

| Total Score | Tier |
|-------------|------|
| 7+ | Critical |
| 5-6 | High |
| 3-4 | Medium |
| 1-2 | Low |
| 0 | None |

---

# 9. STATUS TRACKING

## Valid Member Statuses

| Status | Meaning |
|--------|---------|
| Active | Full member, can access services |
| Suspended | Temporarily blocked, can restore by paying |
| Inactive | Terminated, no longer a member |

## Valid Office Statuses

| Status | Meaning |
|--------|---------|
| Active | Office operational, agents can access services |
| Inactive | Office suspended, ALL agents blocked |

## Non-Member Detection

Non-members are agents who became Inactive on/after Feb 1 due to unpaid Annual Dues:

```sql
-- First-time Inactive after Feb 1 = Non-Member
SELECT member_key
FROM member_status_tracking
WHERE new_status = 'Inactive'
  AND detected_at >= '[year]-02-01'
  AND is_first_inactive = true
```

---

# 10. DAILY JOBS SCHEDULE

| Time | Job | Description |
|------|-----|-------------|
| 5:00 AM | Activity Cache Refresh | Pull education/events from production â†’ activity_cache |
| 6:00 AM | Member Status Capture | Detect Activeâ†’Suspendedâ†’Inactive from history.change_history |
| 6:15 AM | Office Status Capture | Detect office Activeâ†’Inactive from MLS.apmoffice |
| 7:00 AM | Risk Score Calculation | Calculate calendar-aware risk for all Active members |
| 8:00 AM | Office Health Calculation | Calculate office-level payment metrics |

---

# 11. PHASE 3 DELIVERABLES

## Database
- [ ] All SmartSends tables created in Replit DB
- [ ] billing_calendar seeded with 2026 dates
- [ ] All indexes created

## Daily Jobs
- [ ] Activity cache refresh (5 AM)
- [ ] Member status capture (6 AM)
- [ ] Office status capture (6:15 AM)
- [ ] Risk scoring with calendar awareness (7 AM)
- [ ] Office health calculation (8 AM)

## API Endpoints
- [ ] Dashboard metrics
- [ ] Risk distribution
- [ ] Recent status changes
- [ ] Member risk details
- [ ] Member status history
- [ ] Office payment health
- [ ] Office at-risk members
- [ ] Billing calendar CRUD

## UI Components
- [ ] Enhanced member profile with lapse risk indicators
- [ ] Member lapse history timeline
- [ ] Enhanced office profile with payment health
- [ ] Office payment dashboard
- [ ] Lapse prevention dashboard
- [ ] Billing calendar admin (nice-to-have)

## Smart Audiences
- [ ] Critical Risk - Active Members
- [ ] High Risk - Active Members
- [ ] December Overdue (Annual Dues)
- [ ] January Suspended (Annual Dues)
- [ ] Recently Suspended
- [ ] Recently Inactive (Non-Members)
- [ ] Recently Recovered
- [ ] Offices at Risk (Advantage)

## Email Templates
- [ ] Payment Reminder - December
- [ ] Suspension Notice - January
- [ ] Final Notice - January 25
- [ ] Account Inactive Notice
- [ ] Broker Liability Alert
- [ ] Office Suspension Notice (to broker)
- [ ] Sorry for Interruption (to paid-up agents)
- [ ] Recovery Thank You
- [ ] Win-Back (Inactive members)

---

# 12. PHASE 4 PREVIEW: BROKER MODULE

Separate module (hybrid approach) for broker/office management:

## Planned Features
- Broker liability dashboard
- Office payment health reports
- DR Formula tracking and calculations
- Agent roster by office (paid/unpaid)
- Intervention history by broker/office
- Billing calendar admin UI
- Office suspension impact tracking

## Integration with SmartSends
- Broker module shows data and dashboards
- SmartSends provides "Send Alert" actions
- Shared data layer for risk scores, status, interventions

---

# 13. BOOKMARKED FUTURE IDEAS

## Lapse Pattern Analysis
Analyze the 24-month journey before members lapse:
- Transaction decline patterns
- Education/event engagement dropoff
- Payment history warnings
- Identify early warning signals

Goal: Predictive model - "Members showing X pattern have 80% chance of lapsing within 6 months."

---

# 14. KEY FILES & RESOURCES

## Project Files (in /mnt/project/)
- `MemberSync_for_MainStreet_Realtors_-_Customized_Replit_Prompts.md` - Original MemberSync build guide
- `SmartSends_Phase3_Complete.md` - Original Phase 3 prompt (pre-billing-calendar updates)

## Uploaded Reference Files
- `ms_top50_charge_codes_with_sample_description_2025_2026.csv` - Charge code analysis
- `mls_apmoffice_schema.csv` - MLS office table schema
- `New_Members_January_-_June_2026.pdf` - New member fee schedule

## Key Queries

### Activity Stream CTE (for activity_cache refresh)
The full CTE is in the MemberSync prompt. It combines:
- AMS.apmevent + AMS.apmeventregistration (event attendance)
- AMS.apmmembereducation (course completions)

### Member Deduplication Pattern
```sql
SELECT DISTINCT ON (m."ApmClientId", m."MemberKey")
  m.*
FROM "AMS"."apmmember" m
WHERE m."ApmClientId" = 'MainStreet'
ORDER BY m."ApmClientId", m."MemberKey", 
         m."ApmSourceModificationTimestamp" DESC NULLS LAST
```

### Office Status Query
```sql
SELECT DISTINCT ON (o."ApmClientId", o."OfficeKey")
  o."OfficeKey",
  o."OfficeName", 
  o."OfficeBrokerKey",
  o."OfficeStatus"
FROM "MLS"."apmoffice" o
WHERE o."ApmClientId" = 'MainStreet'
ORDER BY o."ApmClientId", o."OfficeKey",
         o."ApmSourceModificationTimestamp" DESC NULLS LAST
```

---

# END OF SUMMARY

This document should provide complete context to resume SmartSends Phase 3 development in a new conversation. Start by sharing this document, then proceed with Part 1 of the Phase 3 prompts.

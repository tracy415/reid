# MemberSync — Navigation Redesign (Final)
*Written: March 8, 2026*
*Status: READY TO SEND TO REPLIT*
*Supersedes: MemberSync_NavigationRedesign.md (prior version in outputs)*

---

## WHAT THIS PROMPT BUILDS

A complete restructure of the left sidebar navigation in `client/src/components/app-sidebar.tsx`. This is primarily a renaming, restructuring, and new-page task. The underlying routes and data infrastructure are not changing. The goal is a navigation that reflects the full product vision, is clean enough for a demo, and gives the dev team the correct structure to build toward in production.

**Read the entire prompt before touching anything.**

---

## THE COMPLETE NEW NAVIGATION STRUCTURE

```
Dashboard
SmartSends                          ← homepage (new page — see below)
  → Create                          ← new page (see below)
  → Reporting & Analytics           ← replaces "Campaigns" + "Drafts"
  → Audiences                       ← unchanged
  → Content                         ← was "Image Library"
  → Templates                       ← was standalone nav item
  → Settings                        ← was SmartSends Settings sub-item
Chats                               ← unchanged
Recognition                         ← top-level module (was nested)
  → Templates                       ← new sub-item (stub page for now)
  → Performance                     ← new sub-item (stub page for now)
  → Settings                        ← new sub-item (stub page for now)
Engagement                          ← COMING SOON (greyed, not clickable)
Retention                           ← COMING SOON (greyed, not clickable)
Compliance                          ← top-level module
  → Communications                  ← existing compliance send flow
  → Performance                     ← new sub-item (stub page for now)
  → Settings                        ← new sub-item (stub page for now)
Market Stats                        ← was "Analytics" / "Overview"
  → Office Leaderboard              ← was "Office Volume"
  → Agent Leaderboard               ← was "Agent Production"
  → Create Brief                    ← unchanged
Members                             ← was "All Members"
Offices                             ← was "All Offices"
```

---

## SECTION 1 — SIDEBAR CHANGES (app-sidebar.tsx)

### Items to REMOVE from sidebar
- **Send Email** — removed entirely. Sending starts from SmartSends → Create.
- **Drafts** — removed entirely. Drafts live in SmartSends → Reporting & Analytics.
- **SmartSends Dashboard** as a sub-item — SmartSends itself is now the homepage.
- **Automations** — removed. Replaced by SmartSends → Create (sequences and triggers accessed from there).
- **Recognition Queue** as a standalone nav label — Recognition is now the top-level item; the queue is accessed from the Recognition homepage.

### Items to RENAME (display label only — do not change URLs or route paths)
- "Analytics" → **"Market Stats"** (top-level item)
- "Overview" (under Analytics) → stays as the Market Stats homepage, no sub-label needed
- "Office Volume" → **"Office Leaderboard"**
- "Agent Production" → **"Agent Leaderboard"**
- "Image Library" → **"Content"**
- "All Members" → **"Members"**
- "All Offices" → **"Offices"**

### Items to ADD
- **SmartSends** as a collapsible top-level item with sub-items: Create, Reporting & Analytics, Audiences, Content, Templates, Settings
- **Recognition** as a collapsible top-level item with sub-items: Templates, Performance, Settings
- **Compliance** as a collapsible top-level item with sub-items: Communications, Performance, Settings
- **Engagement** — greyed out, not clickable, shows "Coming Soon" badge
- **Retention** — greyed out, not clickable, shows "Coming Soon" badge

### Coming Soon styling
Engagement and Retention items should:
- Appear in the nav at their correct position (between Recognition and Compliance)
- Be visually muted (reduced opacity, e.g. `opacity-50`)
- Show a small "Coming Soon" badge or label next to the item name
- Not be clickable — cursor default, no hover state, no navigation on click
- Not be collapsible — no sub-items yet

---

## SECTION 2 — NEW PAGES TO CREATE

### 2A — SmartSends Homepage (`/smartsends`)

This is the landing page when staff clicks "SmartSends" in the nav. It is the command center for the entire email program. It should feel alive and informative — not a static list.

**Page title:** "SmartSends"
**Page subtitle:** "Your member communication command center"

**Layout (top to bottom):**

**Row 1 — Today's Activity Strip**
A horizontal strip showing emails sent today or scheduled for today. Each item is a small card showing: campaign name, category badge (color-coded), recipient count, send time. Cards are clickable — clicking navigates to that campaign's analytics. If nothing sent today, show: "Nothing sent today — ready when you are." with a Create button.

**Row 2 — Performance Pulse (4 stat cards)**
Key metrics for the last 30 days with trend indicators:
- Total Emails Sent (vs. prior 30 days — up/down arrow)
- Average Open Rate (vs. prior 30 days)
- Average Click Rate (vs. prior 30 days)
- Unsubscribe Rate (vs. prior 30 days — flag if trending up)

Pull data from existing campaign analytics tables. Show "—" if no data yet.

**Row 3 — Top Performer**
A single highlighted card showing the best-performing campaign in the last 30 days (highest open rate, minimum 100 recipients to qualify). Shows: campaign name, category, send date, open rate, click rate, recipient count. "View Report" button links to its analytics. Label: "⭐ Top Performer — Last 30 Days"

**Row 4 — Quick Actions**
Three teal-outlined buttons in a row:
- "+ Create Campaign" → navigates to `/smartsends/create`
- "View Queue" → navigates to `/smartsends/settings` (queue tab)
- "View All Campaigns" → navigates to `/smartsends/reporting`

**Important:** All data on this page must come from real database queries. If data is unavailable or there are no campaigns yet, show appropriate empty states with "—" or helpful prompts. Never show fake or placeholder numbers.

---

### 2B — Create Page (`/smartsends/create`)

This is the orientation and entry point page for creating any type of campaign. It is graphical, friendly, and designed for staff who may be new to email marketing. Think of it as the "what would you like to do?" moment before any work begins.

**Page title:** "What would you like to send?"
**Page subtitle:** "Choose the type of communication that fits your goal."

**Layout:** Four large cards in a 2×2 grid (or 4-across on wide screens). Each card has:
- An icon (use lucide-react icons)
- A bold title
- A 1-sentence description
- A "Get Started" or "Start Building" button

**The four cards:**

**Card 1 — Send an Email**
- Icon: `Mail`
- Title: "Send an Email"
- Description: "Reach your members with a focused message — announcements, updates, or any one-time communication."
- Button: "Compose Email" → navigates to existing email composer (`/smartsends/compose` or equivalent existing route)

**Card 2 — Build a Sequence**
- Icon: `Layers` (or `GitBranch`)
- Title: "Build a Sequence"
- Description: "Plan a multi-email campaign with AI. Describe your goal and let MemberSync build the strategy."
- Button: "Open Campaign Architect" → navigates to `/campaign-architect` (existing route)

**Card 3 — Set Up a Trigger**
- Icon: `Zap`
- Title: "Set Up a Trigger"
- Description: "Send automatically when members do something — register for an event, complete a class, earn a designation, etc."
- Button: "Create Trigger" → navigates to existing automations/triggers creation flow

**Card 4 — Member Journey** *(Coming Soon)*
- Icon: `Route` (or `Map`)
- Title: "Member Journey"
- Description: "Guide members through an extended experience with a series of triggered emails."
- Tooltip on the card or "Coming Soon" button: "Great for new member onboarding."
- Button: "Coming Soon" — greyed out, not clickable
- Card has a subtle "Coming Soon" overlay or badge
- Slightly reduced opacity compared to the other three cards

**Below the cards:** A subtle "Not sure where to start?" text link that opens a brief tooltip or inline help explaining the difference between the four types.

---

### 2C — Stub Pages for New Sub-Items

The following new sub-items need stub pages — simple placeholder pages that confirm the nav works and the route exists, ready for future content:

**Recognition → Templates** (`/recognition/templates`)
- Page title: "Recognition Templates"
- Placeholder: "Manage the email templates used for member recognition milestones. Coming soon."
- Back link to Recognition homepage

**Recognition → Performance** (`/recognition/performance`)
- Page title: "Recognition Performance"
- Placeholder: "Track how your recognition emails are performing over time. Coming soon."
- Back link to Recognition homepage

**Recognition → Settings** (`/recognition/settings`)
- Page title: "Recognition Settings"
- Placeholder: "Configure milestone definitions, thresholds, and queue behavior. Coming soon."
- Back link to Recognition homepage

**Compliance → Performance** (`/compliance/performance`)
- Page title: "Compliance Performance"
- Placeholder: "Track open rates and member response to compliance communications. Coming soon."
- Back link to Compliance homepage

**Compliance → Settings** (`/compliance/settings`)
- Page title: "Compliance Settings"
- Placeholder: "Configure compliance rulesets, deadlines, and notification schedules. Coming soon."
- Back link to Compliance homepage

**Note:** Compliance → Communications already exists — this is the existing compliance send flow. Do not rebuild it; just make sure it's accessible from the new nav path.

---

## SECTION 3 — REPORTING & ANALYTICS PAGE

The existing "Campaigns" page becomes "Reporting & Analytics" at `/smartsends/reporting`.

**Changes to this page:**
- Rename page title from "Campaigns" to "Reporting & Analytics"
- Add performance charts at the top of the page (above the campaign list):
  - Recipients over time (line chart, last 90 days)
  - Open rate over time (line chart, last 90 days)
  - Click rate over time (line chart, last 90 days)
  - Use existing Recharts library
  - Pull from existing campaign analytics data
  - Show "Not enough data yet" gracefully if fewer than 3 campaigns exist

- **Unified campaign list** — all campaign types in one list:
  - Emails, Sequences, Triggers, Recognition emails, Compliance emails
  - Filter by Status: All, Draft, Scheduled, Active, Sent, Paused
  - Filter by Type: All, Email, Sequence, Trigger, Recognition, Compliance
  - Search by campaign name
  - Each row shows: name, type badge, status badge, audience, send date, open rate, click rate
  - Clicking a row navigates to that campaign's individual analytics/detail view
  - Every sent campaign has an analytics link — no exceptions

- **Drafts** now live here as a status filter (Draft), not a separate page. The Drafts nav item is removed.

- **Member-level drill-down** — on any individual campaign analytics page, staff must be able to see which specific members opened the email, which clicked, and which did not engage. This must be readable on mobile. If this drill-down doesn't exist yet for all campaign types, add it now as a table: Member Name | Status (Opened/Clicked/Delivered/No Open) | Timestamp.

---

## SECTION 4 — MARKET STATS HOMEPAGE

The existing "Overview" page at `/analytics` becomes the Market Stats homepage. It is accessible by clicking "Market Stats" in the nav (not a sub-item).

**Changes:**
- Page title: "Market Stats" (was "Analytics" or "Overview")
- Sub-items "Office Leaderboard" and "Agent Leaderboard" replace "Office Volume" and "Agent Production" in the nav — display labels only, URLs unchanged
- No content changes to the existing Overview, Office Volume, or Agent Production pages — rename display labels only

---

## SECTION 5 — ITEMS THAT DO NOT CHANGE

The following pages/routes are unchanged in content. Only their nav labels change as specified above:

- Dashboard (`/`) — unchanged
- Chats (`/chats`) — unchanged
- Recognition homepage (`/recognition`) — unchanged (Recognition Queue existing page)
- Compliance communications flow — unchanged
- Audiences (`/smartsends/audiences`) — unchanged
- Content/Image Library — page title changes to "Content", content unchanged
- Templates — moved to SmartSends sub-nav, content unchanged
- Settings — moved to SmartSends sub-nav, content unchanged
- Members page — label changes to "Members", content unchanged
- Offices page — label changes to "Offices", content unchanged
- Market Stats sub-pages — labels change, content unchanged

---

## SECTION 6 — STANDING RULES FOR THIS PROMPT

- **Nav items are destinations. Actions live in buttons.** The nav tells you where you are. Buttons tell you what to do. Never put action verbs ("Send Email," "Create Audience") as nav items.
- **No fake data anywhere.** If the SmartSends homepage has no campaign data yet, show empty states. Never fabricate numbers.
- **All URLs unchanged** unless a new page is being created. Display labels change; route paths do not.
- **No regressions.** Every existing page must still load and function correctly after this prompt. Test each nav item before marking complete.
- **Coming Soon items are visible but inert.** They appear in the nav, they look intentional, they do not navigate anywhere.
- **Member-level drill-down on all sent campaigns** is a hard requirement. Every sent email has analytics. Every analytics view has member-level detail.

---

## VERIFICATION CHECKLIST

Work through this list top to bottom before marking the prompt complete:

**Sidebar structure:**
- [ ] Dashboard loads correctly
- [ ] SmartSends (top-level) expands to show: Create, Reporting & Analytics, Audiences, Content, Templates, Settings
- [ ] SmartSends homepage loads at `/smartsends` with activity strip, pulse cards, top performer, quick actions
- [ ] Create page loads at `/smartsends/create` with 4 cards; Member Journey card is greyed/coming soon
- [ ] Reporting & Analytics loads with performance charts + unified campaign list + status/type filters
- [ ] Audiences loads correctly (unchanged)
- [ ] Content loads correctly (was Image Library — label change only)
- [ ] Templates loads correctly (label change only)
- [ ] Settings loads correctly (label change only)
- [ ] Chats loads correctly (unchanged)
- [ ] Recognition (top-level) expands to show: Templates, Performance, Settings
- [ ] Recognition homepage loads correctly (existing queue page)
- [ ] Recognition → Templates stub page loads
- [ ] Recognition → Performance stub page loads
- [ ] Recognition → Settings stub page loads
- [ ] Engagement shows as greyed Coming Soon — not clickable
- [ ] Retention shows as greyed Coming Soon — not clickable
- [ ] Compliance (top-level) expands to show: Communications, Performance, Settings
- [ ] Compliance → Communications loads existing compliance flow
- [ ] Compliance → Performance stub page loads
- [ ] Compliance → Settings stub page loads
- [ ] Market Stats (top-level) loads existing Overview page
- [ ] Market Stats → Office Leaderboard loads (was Office Volume)
- [ ] Market Stats → Agent Leaderboard loads (was Agent Production)
- [ ] Market Stats → Create Brief loads (unchanged)
- [ ] Members loads correctly (was All Members)
- [ ] Offices loads correctly (was All Offices)

**Removed items:**
- [ ] "Send Email" no longer appears in nav
- [ ] "Drafts" no longer appears as standalone nav item
- [ ] "Automations" no longer appears in nav
- [ ] "Recognition Queue" no longer appears as standalone nav item
- [ ] "Analytics" no longer appears as top-level nav label (replaced by Market Stats)
- [ ] "All Members" / "All Offices" labels replaced

**Functionality:**
- [ ] Clicking any sent campaign in Reporting & Analytics opens its analytics detail
- [ ] Analytics detail shows member-level open/click data
- [ ] SmartSends homepage stat cards show real data (or "—" if no data)
- [ ] Top Performer card shows real campaign (or appropriate empty state)
- [ ] Create page buttons navigate to correct existing flows
- [ ] Mobile layout renders correctly — nav collapses, pages are readable

---

## WHAT NOT TO BUILD IN THIS PROMPT

- Do not build the Recognition homepage redesign (stat cards, "What's resonating," projections) — that is the next prompt
- Do not build the Campaign Engagement Map visualization — that is a future prompt
- Do not build the SmartSends homepage AI suggestions section — that is a future prompt
- Do not change any existing page content beyond what is explicitly specified above
- Do not change any database queries, API routes, or backend logic
- Do not touch triggeredCampaignProcessor, sequenceEnrollmentService, or any email sending infrastructure

---

*Navigation Redesign — Final version based on March 8, 2026 decisions.*
*Next prompt after this is verified: Recognition Homepage.*

# MemberSync / SmartSends — Project Summary
## February 20, 2026

This document captures all decisions, architecture, prompts, and current state through February 20, 2026. Use this to resume work in a new conversation.

---

## TABLE OF CONTENTS

1. Project Overview
2. Client and Membership Context
3. Technical Architecture
4. What Has Been Built (Complete)
5. What Was Accomplished Feb 13–20, 2026
6. Current Database Schema (Key Tables)
7. Production Database Schema (Read-Only)
8. Daily Jobs Schedule
9. AI Services Architecture
10. Engagement Scoring System
11. Dashboard Architecture
12. SmartSends Current State
13. Prompts Ready for Replit (Not Yet Built)
14. Known Issues Still Open
15. Strategic Roadmap
16. Key Architectural Decisions
17. Key Files Reference
18. Production Data Reference

---

# 1. PROJECT OVERVIEW

## What We Are Building

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs. SmartSends is the email marketing and automation layer within MemberSync. The first client is Mainstreet REALTORS®, a trade association with approximately 18,275 active members and approximately 2,800 offices in the Chicago suburbs.

The platform uses predictive analytics to help association executives retain and engage members by analyzing residential real estate listings and association management system (AMS) data.

## Product Model

MemberSync is a **SaaS product** — not a custom build for Mainstreet. Mainstreet REALTORS® is the first client and the prototype environment, but the platform is designed to be sold to associations and MLSs everywhere. Every feature, data model, and UI decision should be evaluated through the lens of "will this work for any association?" not "does this work for Mainstreet?"

**Configurability, not customization, is the key principle.** The platform should adapt to each client through configuration (tier thresholds, celebration types, scoring weights, branding, billing calendars) rather than custom code per client. A new association should be able to onboard by connecting their AMS/MLS data and configuring their preferences — not by hiring developers to modify the application.

## Build Philosophy

Tracy (founder of Membio) is a non-technical business leader building exclusively with AI tools:
- **Claude** for strategy, specifications, and Replit prompts
- **Julius.AI** for SQL development against the production database
- **Replit Agent** for all coding implementation

Technical specifications are split into manageable prompts for Replit. Each prompt is self-contained with enough context for Replit to implement without breaking existing functionality. The prompts explicitly reference existing code by filename and function name.

## Product Philosophy: Celebrating Connection Over Compliance

The core insight driving the product: 75% of association members produce only 12% of real estate volume, yet pay 75% of dues revenue. At Mainstreet specifically, the top 25% of agents control 88% of volume while the remaining members maintain membership for decades despite minimal transactions.

This creates an existential threat as MLSs go non-Realtor, removing the last transactional justification for membership. MemberSync exists to help associations prove their value to all members — not just the top producers — by measuring and improving engagement with the organization itself.

All member tiers are framed positively. We celebrate connection, not police compliance. A Foundation member who takes classes, attends events, pays on time, and opens emails is highly connected — even with zero transactions.

---

# 2. CLIENT AND MEMBERSHIP CONTEXT

## Mainstreet REALTORS®

- ~18,275 active members (agents, brokers, appraisers, affiliates)
- ~2,800 offices in the Chicago suburbs
- 16 sub-associations (administrative divisions)
- 18 bill types

## Three-Tier Member Classification (Membio Volume Standard)

Based on transaction sides in last 12 months:

| Tier | Definition | Count | % of Members | Volume Share |
|------|-----------|-------|-------------|-------------|
| Rainmaker | 40+ sides in 12mo | ~247 | ~1.4% | ~88% |
| Builder | 6–39 sides in 12mo | ~3,885 | ~21% | ~12% |
| Foundation | 0–5 sides in 12mo | ~14,144 | ~77% | <1% |

Key decisions: All tiers use 12-month lookback only (not 24 months). `tx12mo` counts transaction sides — each agent gets credit for being on either the listing or buyer side.

## Member Associations (16 within Mainstreet)

Core Membership: RWS (Mainstreet Organization of REALTORS), MLSN (Mainstreet MLS), MB (Membership), KEY (Key Association / SentriLock)

Advantage Services (MLS/Tools): ADV (Advantage), ADVR (Advantage REALTOR), ADVN (Advantage Non-REALTOR)

Education/Events: ED (Education), various sub-associations for committees and programs

## Bill Types (18)

REALTOR Members: R (REALTOR, 14,771), DR (Designated REALTOR, 1,768), SM (Secondary Member, 351), SDR (Secondary Designated REALTOR, 235), EM (Emeritus, 118), HM (Honorary, 23), RAA (REALTOR-ASSOCIATE Appraiser, 24)

Appraisers: LAD (Licensed Appraiser Designated, 249), LAR (Licensed Appraiser REALTOR, 80), AST (Appraiser State Licensed, 51), LA (Licensed Appraiser, 27), NIA (Non-Member Inactive Appraiser, 9)

Affiliates & Other: AFF (Affiliate, 82), AFCI (Affiliate Corporate/Institutional, 44), AFC (Affiliate Corporate, 14), PA (Personal Assistant, 224), MO (MLS Only, 4), DM/SAD (Other, 2)

---

# 3. TECHNICAL ARCHITECTURE

## Stack
- **Frontend:** React + TypeScript + Tailwind CSS + shadcn/ui + Recharts
- **Backend:** Node.js + Express
- **Database:** PostgreSQL (local Replit DB for cache/app data) + AWS RDS (production AMS/MLS data, read-only)
- **Email:** SendGrid for delivery + webhook tracking
- **AI:** Claude (Anthropic API) for query generation, email composition, audience building
- **Hosting:** Replit (current), production migration planned

## Database Architecture
- **Local Replit DB (`db`):** Application tables — campaigns, recipients, email_events, audiences, member_metrics_cache, office_production_cache, member_milestones, membership_daily_snapshot
- **External AWS DB (`externalPool`):** Read-only access to AMS tables (apmmember, apmmemberassociation, apmmemberinvoice, apmevent, apmeventregistration) and MLS tables (apmproperty)
- **Two-step query pattern:** External DB for member keys → local cache for enrichment. Never join across databases.

---

# 4. WHAT HAS BEEN BUILT (COMPLETE)

## Phase 1: Email Infrastructure (Complete)
- SendGrid integration for email delivery
- Webhook processing for open/click/bounce/delivered events
- Email templates with merge field personalization
- Campaign creation, scheduling, and tracking
- Recipients table with per-member delivery status

## Phase 2: AI-Powered Features (Complete)
- AI audience building — natural language to member queries
- AI email composition — describe what you want, get a draft
- CSV upload for external contact lists
- Audience preview and member count estimation

## Phase 3: Analytics & Engagement (Complete)
- Parts 1–5: Performance analytics, celebration engine, engagement scoring, member profiles
- Part 6: Analytics dashboard, office leaderboards, agent production, PDF generation for office visit briefs

## Audience Builder Improvements (Complete — Implemented)
- Inline audience creation during email composition
- Picklist audiences for hand-picking members with non-member support
- Member/Bill Type audiences using association and billing relationship data
- CSV upload with three-outcome handling (matched member, unmatched with email, unusable)

## Volume Fix (Complete — Implemented)
- Fixed critical double-counting bug where every transaction's dollar amount was counted twice when both listing and buyer agents were association members
- Established the **Membio Volume Standard**: Personal Production Volume (full ClosePrice per side for individual metrics) vs. Market Volume Contribution (ClosePrice split 50/50 for accurate market totals)
- Membership Story tier cards now use `personal_volume_12mo` (correct) instead of `total_volume_12mo` (which was the split market volume)

---

# 5. WHAT WAS ACCOMPLISHED FEB 13–20, 2026

This section captures the intensive development sprint that occurred across multiple sessions.

## Feb 13: Audience Builder + Triggered Campaign Prompts

**Session focus:** Wrote two major Replit prompts.

1. **Audience Builder Improvements** (`SmartSends_AudienceBuilder_Improvements.md`) — Now implemented.
2. **Triggered Campaign Engine** (`SmartSends_TriggeredCampaigns.md`) — Original version with 5 Phase A triggers (event registration, event reminder, event followup, membership anniversary, production milestone).

## Feb 16: Data Consistency + Product Philosophy

**Session focus:** Comprehensive data consistency audit and product philosophy document.

- Identified the 172-member gap between dashboard (18,259) and Member Type Builder (18,087) — diagnosed as members active in apmmember but without apmmemberassociation records for MainStreet
- Established `member_metrics_cache` as single source of truth for active member status
- Implemented two-step query pattern for cross-database operations
- Created `MemberSync_Product_Philosophy_Dashboard.md` — the 75% problem, tier philosophy, celebration principles
- Created prompts for code cleanup: dead code removal, duplicate logic consolidation
- Renamed tiers: Active Producer → Rainmaker, Occasional Producer → Builder, License Maintainer → Foundation
- Renamed engagement labels: risk-based language → connection-based (Highly Connected, Connected, Drifting, Disconnected)

## Feb 17: Engagement Score Redesign + Dashboard Redesign + Scoring Rebalance

Three major sessions in one day:

**Session 1 — Code Audit & Stability:**
- `MemberSync_Stability_DataConsistency_Prompt.md`: Atomic cache refresh, staleness detection, dead code removal, analytics optimization

**Session 2 — Engagement Score Redesign:**
- `MemberSync_EngagementScore_Redesign_Prompt.md`: Tier-aware scoring system replacing one-size-fits-all formula. Three tiers with different weights reflecting what engagement means for each group.

**Session 3 — Scoring Rebalance (Critical Fix):**
The initial engagement score deployment showed 97% of members as Connected or Highly Connected — clearly wrong. Two root causes:

- **Problem 1:** Tier thresholds too generous. Old definition (2+ transactions = Rainmaker) classified 46% as Rainmakers. New thresholds based on actual production data: Rainmaker 40+ sides, Builder 6–39 sides, Foundation 0–5 sides.
- **Problem 2:** Payment scoring too generous. "No overdue invoices" is the default state, not engagement. Payment reduced to binary 0/1.

**Scoring weights (final):**

| Category | Rainmaker | Builder | Foundation | Philosophy |
|----------|-----------|---------|------------|-----------|
| Transactions | 0-2 | 0-2 | 0 | Expected baseline, not engagement |
| Education/Events | 0-3 | 0-3 | 0-4 | Primary differentiator |
| Email | 0-2 | 0-2 | 0-3 | Critical for Foundation |
| Payment | 0-1 | 0-1 | 0-1 | Table stakes |
| Recency | 0-1 | 0-1 | 0-1 | Non-transaction activity in last 90 days |
| Designation | 0-1 | 0-1 | 0-1 | Professional investment |

**Dashboard Redesign:**
- `MemberSync_Dashboard_Redesign_Prompt.md`: Complete dashboard overhaul. Four Pulse cards (Total Active Members, Association Pulse, Connection Status, Campaign Effectiveness), Activity Feed as action engine, Membership Story with three equal-weight tier cards.
- `MemberDetail_ScoreLabels_and_DashboardConsistency_Fix.md`: Fixed score breakdown display, added volume/share to all tier cards.
- Added `membership_daily_snapshot` table for future trend tracking.

## Feb 18: Consolidated Fix Prompt (9 Issues)

`MemberSync_Consolidated_Fix_Prompt_Feb18_2026.md` — Addressed 9 issues in three batches:

**Batch 1 — Data Accuracy (Critical):**
- Fix 1A: Email event type mismatch (SendGrid sends `open`/`click`, code looked for `opened`/`clicked`)
- Fix 1B: Membership Story using wrong volume column (`total_volume_12mo` → `personal_volume_12mo`)
- Fix 1C: Analytics office agent count inconsistency between `office_production_cache` and `member_metrics_cache`

**Batch 2 — UI Improvements:**
- Fix 2A: Score breakdown display on member detail page (reordered: Education & Events first, Email second, Transactions third)
- Fix 2B: Updated interface comments in engagementScoreService.ts

**Batch 3 — Infrastructure:**
- Fix 3A: Daily membership snapshot table and cron job
- Fix 3B: Client configuration system for multi-tenant readiness
- Fix 3C: Events data integration into Association Pulse card

## Feb 19: Dashboard Visual Polish (Multiple Rounds)

Intensive day of dashboard polish across multiple prompts, preparing for a CRMLS demo:

**Dashboard Redesign Part 2** (`MemberSync_Dashboard_Redesign_Part2.md`):
- Renamed "Membership Story" → "Mainstreet Community"
- Tier cards redesigned with persona descriptions, dynamic insight lines, connection highlight boxes
- Added demographic context (age range, brokerage type, experience level)

**Dashboard Cleanup** (`MemberSync_Dashboard_Cleanup.md`):
- Fixed empty gap below Activity Feed
- Added upcoming event nudge and Foundation engagement ratio to activity items
- Fixed tier card text readability and framing
- Added donut charts showing dues revenue percentage on each tier card

**Dashboard Fixes Round 2** (`MemberSync_Dashboard_Fixes_Round2.md`):
- Constrained Celebrations sidebar height with scroll
- Restored month-over-month percentage on Membership card
- Fixed Average Sides display (showing count not average)

**Dashboard Quick Fixes** (`MemberSync_Dashboard_QuickFixes.md`):
- Activity Feed / Celebrations height matching
- Simplified donut chart implementation for tier cards

**AI Data Intelligence Roadmap** (`MemberSync_AI_DataIntelligence_Roadmap.md`):
- Five-stage roadmap from inline chart rendering to full presentation generation
- Stage 2 (next priority): AI Chat detects when results should be charts, renders Recharts inline
- Stage 3: Exportable charts as PNG/PDF
- Stage 4: Multi-chart dashboards ("Show me a board meeting summary")
- Stage 5: Full presentation generation (the operational dependency play)
- Vision: AI Chat becomes the primary interface to institutional knowledge, creating operational dependency

**Key strategic insight from CRMLS demo discussion:** Celebrations need to scale from manual "click to send" to automated campaign reporting tiles. At 110,000 members, nobody can manually send celebration emails. Solution: celebrations become triggered campaigns that the client configures once and monitors through dashboard tiles showing counts, headshots, and open rates.

## Feb 20: Triggered Campaigns + A/B Testing Prompt

`SmartSends_TriggeredCampaigns_ABTesting.md` — Comprehensive 1,411-line prompt combining:

**Triggered Campaign Engine:**
- 5 Phase A trigger types: event_registration, event_reminder, event_followup, membership_anniversary, production_milestone
- Drip sequence support (multi-step campaigns with delays and branching conditions)
- Send window enforcement (8 AM – 5 PM Central, weekend control)
- Deduplication via `triggered_campaign_sends` table
- Trigger-specific merge fields ({{ClassName}}, {{YearsAsMember}}, {{MilestoneLabel}}, etc.)
- Auto-stop configuration for event-based triggers

**A/B Testing:**
- Uses existing `parentCampaignId` and `campaignVersion` fields already in schema
- Deterministic variant assignment (same member always gets same variant)
- Works for both triggered campaigns (built into triggered_campaigns table) and regular campaigns
- Winner badge after 100+ sends per variant
- A/B comparison view on campaign detail page

**Drip Sequences:**
- Freeform multi-step campaigns to a chosen audience on a configured schedule
- Step-level email content with configurable delays
- Branching conditions (only send if opened/didn't open previous step)
- Audience enrollment via activate-drip endpoint
- Members marked 'completed' after final step

---

# 6. CURRENT DATABASE SCHEMA (KEY TABLES)

## Local Replit Database

**member_metrics_cache** — Single source of truth for active member data. Refreshed daily at 6:00 AM.
- member_key, member_status, first_name, last_name, email, office_key, office_name
- member_tier (rainmaker/builder/foundation), engagement_score, engagement_label
- tx_sides_12mo, personal_volume_12mo, total_volume_12mo
- education_count_12mo, event_count_12mo, email_open_rate
- profile_image_url, nar_join_date, designated_realtor
- bill_type, association_ids

**office_production_cache** — Office-level production metrics
**member_milestones** — Detected celebrations/milestones for the celebration engine
**membership_daily_snapshot** — Daily counts for trending (total, per-tier, per-connection-level)

**campaigns** — Email campaigns (sent, scheduled, draft)
- parentCampaignId, campaignVersion (for A/B testing)
**campaign_recipients** — Per-member delivery records
**email_events** — SendGrid webhook events (open, click, delivered, bounce)

**audiences** — Saved audience definitions (AI-built, picklist, member/bill type, CSV)
**triggered_campaigns** — (Schema ready, not yet implemented) Automated campaign configurations
**triggered_campaign_sends** — (Schema ready, not yet implemented) Deduplication and history

## Production Database (Read-Only via externalPool)

**AMS Tables:** apmmember, apmmemberassociation, apmmemberinvoice, apmmemberinvoicedetails, apmevent, apmeventregistration
**MLS Tables:** apmproperty (residential real estate listings)

All AMS/MLS table queries require: `DISTINCT ON ("ApmClientId", "MemberKey") ORDER BY "ApmSourceModificationTimestamp" DESC` for snapshot deduplication.

---

# 7. DAILY JOBS SCHEDULE

| Time | Job | Description |
|------|-----|-------------|
| 6:00 AM | Cache refresh | member_metrics_cache full rebuild |
| 6:15 AM | Daily snapshot | membership_daily_snapshot capture |
| 6:30 AM | Milestone detection | Scan for new celebrations |
| Every 60s | Scheduled email processor | Check for campaigns ready to send |
| (Planned) Every 15m | Triggered campaign processor | Evaluate active triggers |

---

# 8. AI SERVICES ARCHITECTURE

**aiQueryService.ts** — Natural language → SQL → results. Uses Claude to generate SQL queries against the production database, executes them, and returns structured results with suggested follow-ups. Conversation history for follow-up queries.

**aiAudienceService.ts** — Audience CRUD, smart audience execution via AI-generated SQL, enrichment from member_metrics_cache, CSV export. Handles all audience types: AI-built, picklist, member/bill type.

**aiEmailService.ts** — AI email composition. Describe the email you want, get a formatted draft with merge fields.

**sharedDatabaseSchema.ts** — Database schema documentation shared across all AI services so Claude knows what tables and columns are available.

---

# 9. ENGAGEMENT SCORING SYSTEM

## Score Range: 0–10

| Label | Score Range | Color | Meaning |
|-------|------------|-------|---------|
| Highly Connected | 8–10 | Green | Multiple active engagement signals |
| Connected | 5–7 | Blue | Moderate engagement |
| Drifting | 3–4 | Orange | Minimal recent activity |
| Disconnected | 0–2 | Red | No meaningful engagement signals |

## Scoring is Tier-Aware

Each tier weights categories differently. Foundation members can't score on transactions (they don't have any), so education, events, and email carry more weight. Rainmakers are expected to have transactions, so those are baseline — their differentiator is whether they engage with the association beyond just doing deals.

## Expected Distribution (After Rebalancing)

- Rainmakers: ~20-30% Connected+, ~30-40% Drifting, ~30-40% Disconnected
- Builders: ~25-35% Connected+, ~30% Drifting, ~35-40% Disconnected
- Foundation: ~15-25% Connected+, ~15-20% Drifting, ~55-65% Disconnected

This honest distribution creates the urgency that drives SmartSends usage: "Most of your Foundation members are Disconnected — here's how to reach them."

---

# 10. DASHBOARD ARCHITECTURE

## Layout (Top to Bottom)

1. **AI Chat** ("Ask Anything") — Persistent at top
2. **The Pulse** — Four metric cards in a row:
   - Total Active Members (with tier breakdown)
   - Association Pulse (new members, registrations, revenue)
   - Connection Status (engagement distribution, clickable to SmartSends)
   - Campaign Effectiveness (open/click rates, total reached)
3. **Activity Feed + Member Recognition** — Two-column layout:
   - Left (2/3): Today's Activity as news-feed with action buttons
   - Right (1/3): Member Recognition sidebar (celebration tiles with headshot thumbnails, counts, campaign stats)
4. **Mainstreet Community** (formerly "Membership Story") — Three equal-weight tier cards with persona descriptions, connection highlight boxes, volume/share stats, engagement signal indicators, and donut charts showing dues revenue share

## Key Dashboard Endpoints
- `/api/dashboard/metrics` — Pulse card data
- `/api/dashboard/membership-story` — Tier card data with volume, connection rates, concentration stats
- `/api/dashboard/activity-feed` — Today's activity items
- `/api/milestones/recent` — Celebration data for recognition sidebar

---

# 11. SMARTSENDS CURRENT STATE

## What's Built
- Campaign creation with AI-composed or manual email body
- Audience selection (AI-built, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail page with recipient-level status
- Analytics overview with office leaderboards and agent production
- PDF generation for office visit briefs
- Saved audiences with count and preview

## What's Prompt-Ready But Not Built
- **Triggered Campaigns + A/B Testing** (`SmartSends_TriggeredCampaigns_ABTesting.md`)

---

# 12. PROMPTS READY FOR REPLIT (NOT YET BUILT)

**Priority order:**

1. **Triggered Campaigns + A/B Testing** (`SmartSends_TriggeredCampaigns_ABTesting.md`) — 1,411 lines. Automated email engine with 5 trigger types, drip sequences, A/B testing, send windows. This is the next major feature to build.

---

# 13. KNOWN ISSUES STILL OPEN

### The 172-Member Gap
- Dashboard shows 18,259 active members; Member Type Builder shows 18,087
- Difference = members active in apmmember but with no record in apmmemberassociation for AssociationId = 'MainStreet'
- Lower priority — cosmetic, not a data integrity issue

### AI Query Service
- AI sometimes generates SQL with wrong column names or join patterns
- Needs more example queries for events/registrations in the system prompt
- Conversation history fix was sent to Replit

### Cache Health Monitoring
- Cron jobs can fail silently on Replit instance sleep/restart
- Need cache_refresh_log table, admin card showing last refresh, manual "Refresh Now" button
- Daily snapshot table partially addresses this

### Email Engagement Data Cold Start
- Minimal email engagement data exists currently
- Foundation members score very low until campaigns start flowing through SmartSends
- By design — creates virtuous cycle where sending campaigns improves scores visibly

### Revenue Data as Proxy
- Association Pulse uses MemberPrice/Price from event catalog as revenue estimates
- Actual invoiced amounts may differ (discounts, early bird, comps)
- Future: map charge codes for class/event registrations to pull actual invoiced revenue

### CRMLS Demo Polish
- Discovery cards in Mainstreet Community section use mocked data (AI pattern-detection engine is future feature)
- Celebration tiles are placeholder for the automated triggered campaign reporting concept

---

# 14. STRATEGIC ROADMAP

## Near-Term (Next to Build)

1. **Triggered Campaigns + A/B Testing** — Prompt ready. Enables automated celebration emails, event confirmations/reminders, anniversary recognition, drip welcome sequences.

2. **Lapse Prevention System** — Status tracking, calendar-aware risk scoring, intervention management. Payment behavior is a critical lapse predictor. Office suspension is the gatekeeper for MLS access (affects all agents in an office regardless of individual payment).

## Medium-Term

3. **AI Data Intelligence — Stage 2** — Inline chart rendering in AI Chat. When AI detects results should be visual, render Recharts inline. Leverages existing chart.tsx component.

4. **Automated Celebration Tiles** — Transform celebrations from manual "click to send" into configured triggered campaigns with dashboard reporting tiles showing counts, headshots, and performance metrics. Essential for scaling to large MLSs (110,000+ members).

5. **Broker Module (Phase 4)** — Separate module for broker/office management dashboards. Broker liability, office payment health, agent roster by office. Email stays in SmartSends; Broker Module handles dashboards.

## Longer-Term

6. **AI Presentation Generation (Stages 3–5)** — Exportable charts → multi-chart dashboards → full board meeting presentations. The operational dependency play: once a CEO can say "show me new member trends for the board" and get a chart in 10 seconds, they never give up the tool.

7. **Lapse Pattern Analysis** — Examine member behavior in the 24 months before they leave to build predictive models.

8. **Trend Sparklines** — After daily snapshot table accumulates 2–4 weeks of data, add membership trend visualization to dashboard cards.

9. **Education/Event Revenue from Invoices** — Map charge codes to pull actual invoiced revenue instead of catalog price estimates.

---

# 15. KEY ARCHITECTURAL DECISIONS

- `member_metrics_cache` is the single source of truth for active member status
- `apmmember.MemberStatus = 'Active'` is the canonical definition of an active member
- Two-step query pattern for cross-database operations (external DB for keys → local cache for enrichment)
- `DISTINCT ON ("ApmClientId", "MemberKey") ORDER BY "ApmSourceModificationTimestamp" DESC` for all AMS table queries
- Tier assignment uses transaction SIDES (not unique properties) in 12-month window only
- Payment is table stakes (1 point max) — not a primary engagement signal
- Education, events, and email are the primary engagement differentiators across all tiers
- Spike detection at ≥ 1,000 daily registrations filters bulk NAR imports from real registration data
- Personal Production Volume for member-facing metrics; Market Volume Contribution for aggregate market totals
- Cache-first approach works better than on-the-fly calculations at scale (19,000+ members)
- Daily membership snapshots accumulate silently for future trending
- `externalPool` for cross-database queries to AMS/MLS data; `db` for local cache queries
- Celebrations will evolve from manual sends to automated triggered campaigns with reporting tiles
- **SaaS-first mindset:** Every feature should work for any association, not just Mainstreet. Configurability over customization — clients adapt the platform through settings, not code changes.
- Multi-tenant readiness via `client_config` table pattern (discussed in Feb 18 consolidated fix prompt)

---

# 16. KEY FILES REFERENCE

### Prompts Ready for Replit
- `SmartSends_TriggeredCampaigns_ABTesting.md` — Triggered campaigns + A/B testing (NEXT TO BUILD)

### Previously Implemented Prompts
- `SmartSends_AudienceBuilder_Improvements.md` — Inline creation, Picklist, Member/Bill Type (COMPLETE)
- `MemberSync_Volume_Fix_Replit_Prompt.md` — Double-counting fix (COMPLETE)
- `MemberSync_Consolidated_Fix_Prompt_Feb18_2026.md` — 9-issue fix batch (COMPLETE)
- `MemberSync_Dashboard_Redesign_Prompt.md` — Full dashboard overhaul (COMPLETE)
- `MemberSync_Dashboard_Redesign_Part2.md` — Mainstreet Community section (COMPLETE)
- `MemberSync_Dashboard_Cleanup.md` — Visual polish (COMPLETE)
- `MemberSync_Dashboard_Fixes_Round2.md` — Targeted fixes (COMPLETE)
- `MemberSync_Dashboard_QuickFixes.md` — Height matching, donuts (COMPLETE)
- `MemberSync_Dashboard_CRMLS_Demo.md` — Member Recognition tiles, Discovery cards (COMPLETE)
- `MemberSync_EngagementScore_Redesign_Prompt.md` — Tier-aware scoring (COMPLETE)
- `MemberSync_EngagementScore_Rebalancing_Prompt.md` — Threshold + weight corrections (COMPLETE)
- `MemberDetail_ScoreLabels_and_DashboardConsistency_Fix.md` — Score breakdown fix (COMPLETE)
- `MemberSync_Stability_DataConsistency_Prompt.md` — Atomic cache, staleness detection (COMPLETE)
- `CodeCleanup_DeadCode_and_Fixes.md` — Mock data removal (COMPLETE)

### Strategy Documents
- `MemberSync_Product_Philosophy_Dashboard.md` — The 75% problem, product principles, tier philosophy
- `MemberSync_AI_DataIntelligence_Roadmap.md` — Five-stage AI presentation generation roadmap
- `SmartSends_TriggeredCampaigns.md` — Original triggered campaign spec (superseded by ABTesting version)

### Backend Services
- `storage.ts` — Main data layer, dashboard metrics, member/office queries
- `memberMetricsCacheService.ts` — Daily cache refresh with tier-aware engagement scoring
- `engagementScoreService.ts` — Engagement score calculation logic
- `aiQueryService.ts` — AI SQL generation, query execution, insights
- `aiAudienceService.ts` — Audience CRUD, smart audience execution, enrichment, CSV export
- `aiEmailService.ts` — AI email composition
- `emailService.ts` — Email sending, queue processing, campaign management
- `milestoneDetectionService.ts` — Celebration/milestone detection
- `scheduledEmailProcessor.ts` — Processes scheduled campaigns
- `analyticsProductionCacheService.ts` — Office/agent production analytics
- `activityCacheService.ts` — Activity feed data
- `visitBriefService.ts` — Office visit PDF generation
- `brokerResolutionService.ts` — Broker/office relationship resolution
- `csvUploadService.ts` — CSV audience import processing
- `imageService.ts` — Image handling
- `agentHeadshotService.ts` — Member profile photo management
- `sharedDatabaseSchema.ts` — Database schema documentation for AI services
- `systemTemplates.ts` — Email template definitions
- `anthropic.ts` — Claude API client
- `sendgrid.ts` — SendGrid API client
- `objectStorage.ts` / `objectAcl.ts` — Object storage for uploads

### Frontend — Pages
- `SmartSends.tsx` — SmartSends dashboard
- `SendEmail.tsx` — Email composition and sending (201K — largest file)
- `AudienceBuilder.tsx` — AI audience builder
- `MemberBillTypeBuilder.tsx` — Member/Bill Type audience builder
- `PicklistBuilder.tsx` — Manual member picklist builder
- `SavedAudiences.tsx` — Saved audience management
- `CampaignDetail.tsx` — Individual campaign detail view
- `Drafts.tsx` — Email drafts
- `AnalyticsOverview.tsx` — Production analytics dashboard
- `SmartSendsImages.tsx` — Image management for emails
- `PicklistPage.tsx` — Picklist audience page

### Frontend — Dashboard Components
- `CelebrationInsights.tsx` — Member Recognition sidebar
- `MetricCard.tsx` — Shared metric card component (with footnote prop, string breakdown support)
- `ScoreBadge.tsx` — Engagement score display badge
- `MemberAvatar.tsx` — Member headshot/initials avatar
- `DataTable.tsx` — Reusable data table component
- `AIChatBox.tsx` — AI chat interface
- `CampaignTable.tsx` — Campaign list table
- `AudiencePreviewModal.tsx` — Audience preview modal
- `ObjectUploader.tsx` — File upload component

### Configuration
- `schema.ts` — Drizzle ORM schema definitions
- `routes.ts` — All API endpoints (223K — largest backend file)
- `db.ts` — Database connection setup
- `vite_config.ts` / `vite.ts` / `build.ts` — Build configuration
- `tailwind_config.ts` — Tailwind CSS configuration
- `tsconfig.json` — TypeScript configuration

---

# 17. PRODUCTION DATA REFERENCE

From Tracy's Julius analysis of Mainstreet production data:
- Total active agents: 18,275
- Producing agents: 10,895 (59.6%)
- Non-producing: 7,380 (40.4% with zero sides)
- Top 1% (183 agents): 23.1% of volume, avg 91 sides
- Top 5% (914 agents): 48.7% of volume, avg 41 sides
- Top 25% (4,569 agents): 87.6% of volume, avg 16 sides
- Rainmaker threshold (40+ sides): 247 agents (1.4%)
- Builder range (6–39 sides): 3,885 agents (21%)
- Foundation (0–5 sides): 14,144 agents (77%)

## The Office Suspension Discovery

For Mainstreet Advantage fees (MLS/SentriLock access), individual agents are NOT suspended for non-payment. Instead, the **office** gets suspended. When that happens, ALL agents in the office lose MLS and SentriLock access — even agents who paid on time. This creates enormous pressure on the broker to ensure everyone pays. Advantage risk is an office-level problem, not an agent-level one.

---

*End of project summary. This document supersedes all previous project summaries.*

# MemberSync Dashboard Redesign â€” Part 2: Mainstreet Community
## February 19, 2026

---

## CONTEXT FOR REPLIT AGENT

This is Part 2 of the dashboard redesign. Part 1 (layout, Pulse cards, Activity Feed) must be deployed first.

This prompt replaces the "Membership Story" section at the bottom of the dashboard with the **Mainstreet Community** â€” a redesigned section that gives each member tier a persona-driven identity with real engagement data. The section title, subtitle, card layout, and content all change.

---

## RENAME AND REDESIGN

### Section Title

Change from "The Membership Story" to **"Mainstreet Community"**

The static subtitle "Three tiers, one community. How connected is each part of your membership?" becomes a **dynamic insight line** that changes based on what's actually happening in the data. Examples:
- "Builder connection rate is up 2 points this quarter" (when snapshot data shows improvement)
- "247 Rainmakers, 3,896 Builders, and 14,122 Foundation members make up your community" (default when no trend data exists yet)
- "12 Foundation members attended their first event this month" (when first-timer data is available â€” future enhancement)

For now, use the default version since the snapshot table only has a few days of data. The endpoint should include the counts so the subtitle can be built client-side.

---

## TIER CARD REDESIGN

Each tier card serves three purposes:
1. **Persona** â€” Who are these people? (demographics, brokerage type, experience)
2. **Connection** â€” How connected are they to the association right now? Are there any wins?
3. **Stats** â€” Volume, sides, and engagement signals

### Visual Structure of Each Card

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ â•â•â• color band (amber/blue/emerald) â•â•â•  â”‚
â”‚                                          â”‚
â”‚  [Icon]  Tier Name       Count (X%)      â”‚
â”‚                                          â”‚
â”‚  Persona description text in muted color â”‚
â”‚  Age range Â· Brokerage type Â· Experience â”‚
â”‚                                          â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”    â”‚
â”‚  â”‚  XX% connected to your           â”‚    â”‚
â”‚  â”‚  organization                     â”‚    â”‚
â”‚  â”‚  (Scored 5+ out of 10 on         â”‚    â”‚
â”‚  â”‚  engagement activities)           â”‚    â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜    â”‚
â”‚                                          â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”    â”‚
â”‚  â”‚  Volume Â· Share Â· Avg sides       â”‚    â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜    â”‚
â”‚                                          â”‚
â”‚  [Edu] [Events] [Email] [Avg Sides]      â”‚
â”‚   9%     9%       0%      52.3           â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

### Icons Instead of Stock Photos

Use lucide-react icons for each tier. These are cleaner, more inclusive, and reusable across clients:

- **Rainmaker**: `Crown` (from lucide-react) â€” represents market leadership
- **Builder**: `Hammer` (from lucide-react) â€” represents actively building their business
- **Foundation**: `Home` (from lucide-react) â€” represents the stable base of the community

Display each icon at `h-8 w-8` with the tier's color (`text-amber-500`, `text-blue-500`, `text-emerald-500`).

### Persona Descriptions (Hardcoded for Now)

These go in `clientConfig.ts` as part of the client configuration, since they'll be different for each association:

**Add to `server/services/clientConfig.ts`:**

```typescript
// ============================================================
// TIER PERSONA DESCRIPTIONS (for Community section)
// ============================================================

export const TIER_PERSONAS = {
  rainmaker: {
    displayName: 'Rainmaker',
    icon: 'Crown',
    color: 'amber',
    description: '40â€“65 years old Â· Independent (70%) or major brokerage (30%) Â· Likely team leader',
    detail: '55% male / 45% female Â· College degree Â· 10â€“25 years in real estate Â· Primarily residential Â· 70/30 list/buy',
  },
  builder: {
    displayName: 'Builder',
    icon: 'Hammer',
    color: 'blue',
    description: '40â€“65 years old Â· Independent (60%) or major brokerage (40%) Â· Possibly team member',
    detail: '45% male / 55% female Â· College degree Â· 10â€“20 years in real estate Â· Primarily residential Â· 60/40 list/buy',
  },
  foundation: {
    displayName: 'Foundation',
    icon: 'Home',
    color: 'emerald',
    description: '55â€“65 years old Â· Major brokerage (80%) or independent (20%) Â· Possibly solo broker',
    detail: '60% male / 40% female Â· Some college or degree Â· 10â€“40 years in real estate Â· Residential, will buy or sell anything Â· 20/80 list/buy',
  },
} as const;
```

These are NOT in the API response â€” they're hardcoded on the frontend using the config. For the first version, you can import them from a shared location or just hardcode them directly in the component. When Membio onboards a second client, these move to the `tenant_config` table.

### Replace "Paid" Signal with "Avg Sides"

The current tier cards show four engagement signals: Edu, Events, Email, Paid.

**Change:** Replace "Paid" with "Avg Sides" â€” the average transaction sides per member in that tier. Payment is table stakes (binary 0/1 in the scoring formula) and doesn't provide meaningful differentiation. Average sides tells you *how productive* the tier is, which is the one production metric that matters for context.

**Backend change:** The membership story endpoint (`/api/dashboard/membership-story`) needs to include `avgSides` for each tier. 

Add to the tier query in `routes.ts` (membership-story endpoint):

```sql
-- In the existing tier query, add:
ROUND(AVG(CAST(transactions_12mo AS NUMERIC)), 1) as avg_sides
```

Then include `avgSides` in the response for each tier's insights object.

### Explain What "Connected" Means

The current card shows "14% connected to your organization" with no explanation. Add a brief tooltip or inline explanation:

Under the connected percentage, show:
```
(Scored 5+ out of 10 on education, events, email, and activity)
```

This explains the methodology without overwhelming the viewer. It also tells the executive what levers they can pull â€” education, events, and email are all things the association controls.

---

## UPDATED `MembershipStory.tsx` â†’ Renamed Component

Rename the file to `MainstreetCommunity.tsx` (and update the import in Dashboard.tsx).

**File: `client/src/components/dashboard/MainstreetCommunity.tsx`**

```tsx
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Crown, Hammer, Home, GraduationCap, CalendarCheck, Mail, TrendingUp } from "lucide-react";

// Tier persona data â€” hardcoded for Mainstreet, moves to tenant_config for future clients
const TIER_PERSONAS = {
  rainmaker: {
    displayName: 'Rainmaker',
    Icon: Crown,
    colorBand: 'bg-amber-500',
    colorDot: 'bg-amber-500',
    colorIcon: 'text-amber-500',
    colorHighlight: 'bg-amber-50 dark:bg-amber-950/30',
    colorHighlightText: 'text-amber-800 dark:text-amber-200',
    description: '40â€“65 years old Â· Independent (70%) or major brokerage (30%) Â· Likely team leader',
    detail: '55% male / 45% female Â· College degree Â· 10â€“25 years in real estate Â· Primarily residential Â· 70/30 list/buy',
  },
  builder: {
    displayName: 'Builder',
    Icon: Hammer,
    colorBand: 'bg-blue-500',
    colorDot: 'bg-blue-500',
    colorIcon: 'text-blue-500',
    colorHighlight: 'bg-blue-50 dark:bg-blue-950/30',
    colorHighlightText: 'text-blue-800 dark:text-blue-200',
    description: '40â€“65 years old Â· Independent (60%) or major brokerage (40%) Â· Possibly team member',
    detail: '45% male / 55% female Â· College degree Â· 10â€“20 years in real estate Â· Primarily residential Â· 60/40 list/buy',
  },
  foundation: {
    displayName: 'Foundation',
    Icon: Home,
    colorBand: 'bg-emerald-500',
    colorDot: 'bg-emerald-500',
    colorIcon: 'text-emerald-500',
    colorHighlight: 'bg-emerald-50 dark:bg-emerald-950/30',
    colorHighlightText: 'text-emerald-800 dark:text-emerald-200',
    description: '55â€“65 years old Â· Major brokerage (80%) or independent (20%) Â· Possibly solo broker',
    detail: '60% male / 40% female Â· Some college or degree Â· 10â€“40 years in real estate Â· Residential Â· 20/80 list/buy',
  },
};

interface MembershipStoryData {
  composition: {
    rainmaker: { count: number; percentage: number };
    builder: { count: number; percentage: number };
    foundation: { count: number; percentage: number };
  };
  rainmakerInsights: {
    totalVolume: number;
    avgTransactions: number;
    connectedPercentage: number;
    avgScore: number;
    top5PctCount: number;
    top5PctLabel: number;
    top5PctVolShare: number;
    withEducation: number;
    withEvents: number;
    withEmailEngagement: number;
    paidOnTime: number;
    avgSides: number;  // NEW
  };
  builderInsights: {
    connectedPercentage: number;
    avgScore: number;
    totalVolume: number;
    volumeSharePct: number;
    withEducation: number;
    withEvents: number;
    withEmailEngagement: number;
    paidOnTime: number;
    avgSides: number;  // NEW
  };
  foundationInsights: {
    avgScore: number;
    connectedPercentage: number;
    totalVolume: number;
    volumeSharePct: number;
    withEducation: number;
    withEvents: number;
    withEmailEngagement: number;
    paidOnTime: number;
    avgSides: number;  // NEW
  };
}

function formatCurrency(value: number): string {
  if (value >= 1_000_000_000) return `$${(value / 1_000_000_000).toFixed(1)}B`;
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(0)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(0)}K`;
  return `$${value.toFixed(0)}`;
}

export function MainstreetCommunity() {
  const { data, isLoading } = useQuery<MembershipStoryData>({
    queryKey: ["/api/dashboard/membership-story"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader><Skeleton className="h-5 w-48" /></CardHeader>
        <CardContent><Skeleton className="h-64 w-full" /></CardContent>
      </Card>
    );
  }

  if (!data) return null;

  const { composition, rainmakerInsights, builderInsights, foundationInsights } = data;

  // Dynamic subtitle â€” defaults to member count summary until we have trend data
  const subtitle = `${composition.rainmaker.count.toLocaleString()} Rainmakers, ${composition.builder.count.toLocaleString()} Builders, and ${composition.foundation.count.toLocaleString()} Foundation members make up your community`;

  const tiers = [
    { key: 'rainmaker', persona: TIER_PERSONAS.rainmaker, comp: composition.rainmaker, insights: rainmakerInsights },
    { key: 'builder', persona: TIER_PERSONAS.builder, comp: composition.builder, insights: builderInsights },
    { key: 'foundation', persona: TIER_PERSONAS.foundation, comp: composition.foundation, insights: foundationInsights },
  ];

  return (
    <Card data-testid="card-mainstreet-community">
      <CardHeader>
        <CardTitle className="text-base font-semibold">
          Mainstreet Community
        </CardTitle>
        <p className="text-sm text-muted-foreground">{subtitle}</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {tiers.map(({ key, persona, comp, insights }) => {
            const { Icon } = persona;
            return (
              <div key={key} className="border rounded-lg overflow-hidden">
                {/* Color band */}
                <div className={`h-1.5 ${persona.colorBand}`} />
                
                <div className="p-4 space-y-3">
                  {/* Header with icon */}
                  <div className="flex items-center gap-2.5">
                    <Icon className={`h-7 w-7 ${persona.colorIcon}`} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold">{persona.displayName}</span>
                        <span className="text-xs text-muted-foreground">
                          {comp.count.toLocaleString()} ({comp.percentage}%)
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Persona description */}
                  <div className="space-y-0.5">
                    <p className="text-[11px] text-muted-foreground leading-relaxed">{persona.description}</p>
                    <p className="text-[10px] text-muted-foreground/70 leading-relaxed">{persona.detail}</p>
                  </div>
                  
                  {/* Connection status with explanation */}
                  <div className={`${persona.colorHighlight} rounded-md p-2.5`}>
                    <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                      {insights.connectedPercentage}%
                    </p>
                    <p className="text-xs text-muted-foreground">connected to your organization</p>
                    <p className="text-[10px] text-muted-foreground/70 mt-0.5">
                      Scored 5+ out of 10 on education, events, email, and activity
                    </p>
                  </div>
                  
                  {/* Volume and sides */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      {formatCurrency(insights.totalVolume)} volume
                      {key === 'rainmaker' && insights.top5PctVolShare > 0
                        ? ` Â· Top ${insights.top5PctCount?.toLocaleString()} (${insights.top5PctLabel}%) control ${insights.top5PctVolShare}%`
                        : (insights as any).volumeSharePct !== undefined
                          ? ` Â· ${(insights as any).volumeSharePct}% of total`
                          : ''
                      }
                    </span>
                  </div>
                  
                  {/* Four signal indicators: Edu, Events, Email, Avg Sides */}
                  <div className="grid grid-cols-4 gap-1 text-center pt-1 border-t">
                    <SignalMini 
                      icon={GraduationCap} 
                      label="Edu" 
                      value={insights.withEducation} 
                      total={comp.count} 
                      color="text-blue-500" 
                      isPercentage={true}
                    />
                    <SignalMini 
                      icon={CalendarCheck} 
                      label="Events" 
                      value={insights.withEvents} 
                      total={comp.count} 
                      color="text-purple-500" 
                      isPercentage={true}
                    />
                    <SignalMini 
                      icon={Mail} 
                      label="Email" 
                      value={insights.withEmailEngagement} 
                      total={comp.count} 
                      color="text-amber-500" 
                      isPercentage={true}
                    />
                    <SignalMini 
                      icon={TrendingUp} 
                      label="Avg Sides" 
                      value={insights.avgSides} 
                      total={1} 
                      color="text-slate-500" 
                      isPercentage={false}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

function SignalMini({
  icon: Icon,
  label,
  value,
  total,
  color,
  isPercentage = true,
}: {
  icon: React.ElementType;
  label: string;
  value: number;
  total: number;
  color: string;
  isPercentage?: boolean;
}) {
  const display = isPercentage
    ? `${total > 0 ? Math.round((value / total) * 100) : 0}%`
    : value.toFixed(1);
    
  return (
    <div className="space-y-0.5">
      <Icon className={`h-3.5 w-3.5 mx-auto ${color}`} />
      <p className="text-sm font-semibold">{display}</p>
      <p className="text-[10px] text-muted-foreground">{label}</p>
    </div>
  );
}
```

### Backend Change: Add `avgSides` to Membership Story Response

**File: `server/routes.ts`** â€” In the `/api/dashboard/membership-story` endpoint:

In the tier aggregation query (around line 518-530), add:
```sql
ROUND(AVG(CAST(transactions_12mo AS NUMERIC)), 1) as avg_sides
```

Then include `avgSides: parseFloat(row.avg_sides) || 0` in each tier's insights response object (rainmakerInsights, builderInsights, foundationInsights).

### Dashboard.tsx Updates

**1. Import update:**

Replace:
```tsx
import { MembershipStory } from "@/components/dashboard/MembershipStory";
```
With:
```tsx
import { MainstreetCommunity } from "@/components/dashboard/MainstreetCommunity";
```

And replace `<MembershipStory />` with `<MainstreetCommunity />` in the JSX.

**2. Move AI Chat above the Pulse cards:**

The AI Chat ("Ask Anything") is the hero feature of MemberSync. It should be the first interactive element on the page, immediately below the page header. Move `<AIChatBox />` out of the `grid-cols-[2fr_1fr]` layout and place it directly below the greeting, above the Pulse cards grid. It should span the full width (not sharing a column with Celebrations).

Layout order should be:
1. Page header greeting
2. AI Chat (full width)
3. Three Pulse cards (full width, 3-column grid)
4. Activity Feed + Celebrations sidebar (2fr/1fr grid)
5. Mainstreet Community (full width)

**3. Make the Membership card's new member line more prominent:**

In the Membership MetricCard, the subtitle showing "107 new this month (-46% vs last month)" is too subtle. It's the most important trend number on the card. The MetricCard component currently renders subtitles as `text-xs text-muted-foreground`. 

Rather than changing the shared MetricCard component (which would affect all cards), add a custom rendering for the Membership card's subtitle. One approach: use the MetricCard's `trend` prop instead of putting the growth data in the subtitle:

```tsx
<MetricCard
  title="Membership"
  value={metrics.totalActiveMembers.total}
  subtitle="active members"
  trend={metrics.associationPulse?.newMemberGrowthPct !== null && metrics.associationPulse?.newMemberGrowthPct !== undefined
    ? {
        value: metrics.associationPulse.newMemberGrowthPct,
        label: `(${metrics.associationPulse.newMembersThisMonth} new this month)`,
      }
    : undefined
  }
  icon={Users}
  variant="default"
  testId="card-membership"
  breakdown={[
    { label: "Rainmaker", value: metrics.totalActiveMembers.activeProducers, variant: "amber" },
    { label: "Builder", value: metrics.totalActiveMembers.occasionalProducers, variant: "blue" },
    { label: "Foundation", value: metrics.totalActiveMembers.licenseMaintainers, variant: "emerald" },
  ]}
  onClick={() => setLocation("/members")}
/>
```

The `trend` prop already renders with a larger, colored font (green for positive, red for negative) â€” making the growth number visually prominent without changing the shared component.

---

## VERIFICATION CHECKLIST

After implementing Part 2:

- [ ] Section titled "Mainstreet Community" (not "The Membership Story")
- [ ] Dynamic subtitle shows member counts
- [ ] Each tier card has an icon (Crown, Hammer, Home) instead of just a colored dot
- [ ] Each tier card shows persona description text (age, brokerage, experience)
- [ ] Connected percentage has explanation: "Scored 5+ out of 10 on education, events, email, and activity"
- [ ] Fourth signal indicator is "Avg Sides" (not "Paid")
- [ ] Avg sides shows a decimal number (e.g., 52.3) not a percentage
- [ ] Volume numbers are correct (personal_volume_12mo from the fix deployed earlier)
- [ ] Mobile layout stacks the three tier cards vertically
- [ ] Persona descriptions are in `clientConfig.ts` (or hardcoded in component for now â€” either is fine)
- [ ] Old `MembershipStory.tsx` is either renamed or replaced

---

## FILES CHANGED

**New files:**
- `client/src/components/dashboard/MainstreetCommunity.tsx` â€” Replaces MembershipStory.tsx

**Modified files:**
- `server/routes.ts` â€” Add `avgSides` to membership-story endpoint
- `server/services/clientConfig.ts` â€” Add `TIER_PERSONAS` configuration
- `client/src/pages/Dashboard.tsx` â€” Update import from MembershipStory to MainstreetCommunity

**Removed/replaced:**
- `client/src/components/dashboard/MembershipStory.tsx` â€” Replaced by MainstreetCommunity.tsx (can delete or keep as backup)

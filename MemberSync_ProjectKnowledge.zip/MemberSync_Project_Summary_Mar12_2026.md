# MemberSync — Project Summary
## March 12, 2026

---

## ⛔ CRITICAL — DEV TEAM CODEBASE WARNING (STILL IN EFFECT)

The dev team pulled a Replit snapshot on March 10. That snapshot does NOT include the major email infrastructure work from March 10–11 (suppression hardening, webhook category fix, recipient tracking, unsubscribe architecture). **That snapshot is incomplete and must NOT be used as the foundation for production work.**

**Mike and Dale must pull a fresh snapshot from Replit dated March 12 or later before writing any further production code.**

After 10 a.m. PT on March 12, Tracy stopped touching Replit. All further prototype development moves to Claude Code once Mike and Dale establish procedures and process.

---

## ⛔ NON-NEGOTIABLE: ROCK SOLID SOFTWARE FIRST

We are building production-worthy software. AEI is an opportunity — not a mandate to cut corners.

**The following are flat nos, under any circumstances, for any reason, including AEI:**
- Shortcuts
- Technical debt
- Dead code
- Missing or poor documentation
- Any compromise to architecture, data integrity, or code quality

AEI will show whatever Tracy's branch contains at that point. The demo adapts to the software — the software does not bend to the demo. If a feature isn't ready and solid, it doesn't get shown.

**Claude's standing instruction:** If any prompt, request, or suggestion would incur technical debt, leave dead code, skip documentation, or shortcut architecture to hit a demo deadline — flag it immediately and refuse to write it that way. No exceptions.

---

## HOW TO USE THIS DOCUMENT

This summary picks up from `MemberSync___Project_Summary_Late_Evening_Part_2_031126.md`. Read that document first for foundational context on roles, product philosophy, client pipeline, full feature inventory, and standing rules. This document captures everything from the March 12 session only.

**Do not skip the prior summary.** The two documents together are the complete picture.

---

## ROLES AND WORKING MODEL

- **Tracy** — CEO and founder of Membio. Non-technical but deeply product-literate. 30+ years in proptech. Drives product vision and feature decisions.
- **Claude** — Acts as CTO, product visionary, AI architecture expert, and strategic sparring partner. Owns product specs, architectural direction, and all Replit prompts. Pressure-tests every feature idea before writing it. Holds the full product picture across conversations.
- **Dev team (Mike and Dale)** — Own the production port. Use Claude Code for implementation. Own the repository, deployment pipeline, monitoring, and operations.
- **Division of responsibility:** Tracy + Claude own the "what" and "why." Dev team owns the "how." Handoff artifacts: CLAUDE.md (product bible), technical debt document, and developer-facing specs per feature.

**Two-track model:**
- Track 1 (Tracy + Claude + Replit): Rapid prototype development and feature validation. Continue building in Replit.
- Track 2 (Dev team + Claude Code): Production platform. Port validated modules from Replit with proper multi-tenant architecture from day one.

---

## CLIENT PIPELINE

| Client | Members | Status |
|--------|---------|--------|
| Mainstreet REALTORS® | ~18,275 | First client. Prototype on Replit. **Not yet in production.** AEI demo target. |
| HGAR (Hudson Gateway) | ~12,800 | Onboarding. First true multi-tenant requirement. New York compliance rules. |
| GRAR (Greater Rochester) | ~3,400 | Third paying client. New York compliance. Follows HGAR. |
| CRMLS | 103,000+ | **On ice.** Their team is building a competing product. Do not include in forward-looking documents. Stage 2 trigger is now "after client #4 onboards" — not tied to CRMLS. |

---

## AEI CONFERENCE

**March 23–27, Minneapolis.** Association executives. This is the primary near-term demo target.

**Demo path:** AI Chat → Campaign Architect → Recognition → Dashboard

**Campaign Architect is the centerpiece.** Touch it only for the streaming prompt — no other changes until after AEI.

---

## WHAT THIS SESSION BUILT: RAG MEMORY SYSTEM

### What It Is

The AI Chat now has two persistent memory layers injected into every query. Previously, every session started from zero — the AI knew the schema but nothing about the organization it was serving. This is now fixed.

**Layer 1 — Business context (`ai_business_context`):** A Membio-authored briefing seeded at onboarding. Read-only to clients. Contains organizational identity, membership composition, key concerns, tone guidance, and — critically — member terminology in the client's own language. The Mainstreet seed is the reference model for how this should be written for future clients.

**Layer 2 — AI memory (`ai_memory`):** Accumulated context that staff build over time. Managed through the new `/chats/settings` page. Staff add entries manually. The AI can optionally suggest entries worth saving (Easter Egg — see below).

### Schema Changes

Five new columns added to `tenant_config`:

```
ai_business_context       text         — Membio-seeded, read-only to clients
ai_memory                 text         — Client-editable, soft limit 5K, hard cap 8K
ai_memory_suggestions     jsonb        — Array of {text, category, source_query, created_at}
ai_memory_updated_at      timestamp    — Last update time
ai_memory_editor_roles    text[]       — Which roles can edit. Default: ['admin']. Client-configurable.
```

`ai_memory_suggestions` stores **objects, not plain strings.** Each suggestion has:
- `text` — the insight (1–3 sentences, max 200 chars)
- `category` — one of: preference | competitive | sensitivity | priority | concern
- `source_query` — the question that triggered the insight (first 100 chars)
- `created_at` — ISO timestamp

### AI Injection Architecture

**`getSqlGenerationPrompt()` stays synchronous.** Memory is fetched asynchronously in `generateSql()` (which is already async and has database access), then passed as optional parameters to `getSqlGenerationPrompt()`. This is the correct pattern — do not make `getSqlGenerationPrompt()` async.

**Injection order** (prepended to the system prompt, before schema context):
1. `## About This Organization` — business context
2. `## Terminology Rule` — instruction to use client language, not Membio's internal vocabulary
3. `## Important Context to Apply` — AI memory entries

**The Terminology Rule (new — critical):** The injected system prompt now includes an explicit instruction: *"Use the member categories, tier names, and organizational language defined in the business context above. Do not substitute generic labels or Membio's internal terminology (Foundation, Builder, Rainmaker) unless this organization's context specifically uses those terms. If the business context does not define member categories, do not invent them — describe members by their activity levels using plain language."*

This is how client terminology is handled. Foundation/Builder/Rainmaker are Mainstreet's terms — Membio named them and Mainstreet adopted them. HGAR or any future client may define completely different categories or none at all. The `ai_business_context` field is where each client's language is established at onboarding. The Membio onboarding team must write that context using the client's own words.

**Failure safety:** The memory fetch is wrapped in try/catch. If it fails for any reason, AI Chat continues without context — it never blocks. Console log confirms injection status.

**The retry call:** `generateSql()` retries on first failure. `memoryContext` must be passed to the retry call as well as the first attempt. If missing from the retry, failed queries run without organizational context on the second attempt.

### Mainstreet Business Context Seed

The seeded `ai_business_context` for Mainstreet now explicitly names their tier structure and defines the terms, so the AI knows to use "Foundation," "Builder," and "Rainmaker" for this client. This is the reference model — every client onboarded after Mainstreet gets a custom context written in their language.

### Memory Limit Interaction

**Soft limit: 5,000 characters.** When adding a new entry would exceed this:
- The API returns `softLimitExceeded: true` AND the `oldestEntry` text
- The UI shows: *"This tip has enriched my memory! Mind if I make room for something new?"*
- Shows the specific oldest entry text
- Two buttons: **"Remove this one"** | **"I'll choose"**
- "I'll choose" dismisses the prompt and highlights all entry cards so the user picks
- No silent deletions — ever

**Hard cap: 8,000 characters.** Hard reject at this point.

### The Easter Egg — Suggestion Generator

After every AI Chat session, a fire-and-forget background job runs (never blocks the user response). It uses `claude-haiku-4-5-20251001` (Haiku only — do not upgrade, cost matters) to review the conversation and decide if anything is worth saving as a memory entry.

**The suggestion queue only renders when suggestions exist.** No empty state, no heading, no placeholder — the appearance is the signal. It earns its way into the UI.

**Copy (exact — do not paraphrase):**
*"Great chatting with you today! I learned something worth remembering: [specific insight]. Mind if I add this to my memory?"*
Buttons: **[Remember this]** | **[No thanks]**

- The full insight text is always shown — never summarized
- "No thanks" dismisses silently — no confirmation, no guilt, no follow-up
- Shows one suggestion at a time (oldest first)
- After action on one, next appears if any remain
- Cap at 5 pending suggestions in the queue

**`generateMemorySuggestion()` returns an object** `{text, category, source_query, created_at}` — not a plain string. The accept/dismiss endpoints filter on `s.text`, not `s`.

### New API Endpoints

All use `authMiddleware` (not `requireAuth`) and raw SQL against `localPool`:

- `GET /api/chats/settings` — fetch business context, memory entries, suggestions, char counts
- `POST /api/chats/settings/memory` — add entry (500 char per entry, 5K soft, 8K hard)
- `DELETE /api/chats/settings/memory` — remove by text match
- `POST /api/chats/settings/memory/suggestion/accept` — accept suggestion into memory
- `DELETE /api/chats/settings/memory/suggestion` — dismiss suggestion

### New ChatsSettings Page

Route: `/chats/settings`
Registered in `App.tsx`.

Four sections:
1. **Membio Briefing** — read-only display of `ai_business_context`. Clearly labeled as Membio-managed. No edit controls.
2. **AI Memory** — cards, one per entry. Each card shows text, character count, inline delete with confirmation (no modal). Total character counter displayed.
3. **Add to Memory** — textarea, 500 char per entry limit, counter, submit button. On soft limit: surfaces oldest entry interaction (described above).
4. **Something Worth Remembering** — suggestion queue. Only renders when non-empty.

### Nav Change

Chats nav item in `AppSidebar.tsx` converted from simple `SidebarMenuItem` to `Collapsible` pattern. Sub-link label: **"AI Memory"** (not "Settings"). Uses `Settings` icon from lucide-react (already imported). Collapses when navigating away from `/chats` section.

### Verification Confirmed

- Five new columns visible in `tenant_config`
- `ai_business_context` seeded for Mainstreet (700+ chars)
- AI Chat responds to "What do you know about this organization?" with real Mainstreet context
- Console log confirms: `[AIQueryService] Memory context: business_context=true`
- `/chats/settings` loads with all four sections
- CRUD on memory entries working
- "AI Memory" sub-link appears in nav
- No regression on existing AI Chat queries
- `ai_usage_logs` still receives entries for standard queries

---

## KEY ARCHITECTURAL DECISIONS — CARRY FORWARD INTO ALL FUTURE WORK

These are not yet in CLAUDE.md. They must be added in the next CLAUDE.md update session.

### 1. Client Terminology Is Owned by `ai_business_context`, Not Code

Foundation, Builder, and Rainmaker are not universal product vocabulary. They are Mainstreet's member categories — Membio named them, Mainstreet adopted them. The AI is explicitly instructed to use whatever terminology appears in the business context and never substitute Membio's internal vocabulary. Future clients define their own categories in their onboarding context. The Membio onboarding team writes each client's context in that client's own words.

### 2. AI Memory Is the Right Architecture for Organizational Intelligence

The `ai_business_context` + `ai_memory` two-layer system is the foundation for the AI knowing the organization it's serving. Business context is Membio-seeded and stable. AI memory is staff-accumulated and grows over time. Together they give the AI durable organizational intelligence that persists across sessions.

### 3. Soft Limit Interaction Requires User Agency

Memory limits are handled through warm, conversational UI that surfaces the specific oldest entry and requires user approval before anything is removed. Silent deletions are never acceptable. The user always controls what leaves memory.

### 4. The Easter Egg Is a Required Feature, Not a Stretch Goal

The suggestion generator (Part 6 of the RAG memory prompt) is a required part of the build. It is sequenced after Parts 1–5 are verified — not optional or deferrable.

### 5. Admin Panel Architecture (From Prior Session — Still Pending Implementation)

Three access levels: Membio Super-Admin / Client Admin / Client Staff.

**What clients can change:** org profile, user management, AI memory, competitive intelligence (premium only), email preferences, billing.

**Only Membio can change:** module visibility, AI feature kill switches and daily limits, tier thresholds, SendGrid ASM config, anything affecting data calculation or platform behavior.

**The Geek Squad Principle:** The tenant config editor must be built with plain English labels, tooltips explaining consequences, and confirmation dialogs for anything consequential. Non-technical users must never be able to misconfigure something that affects scoring or data integrity without a clear warning.

### 6. CRMLS Is Off the Active Prospect List

CRMLS is building a competing product internally. Remove from forward-looking plans, roadmaps, and prospect discussions. Historical references in prior summaries are accurate. Stage 2 trigger is "after client #4 onboards."

### 7. MLS Compliance Positioning

MemberSync is **notice delivery and acknowledgment infrastructure** for MLSs — not a pre-built compliance rulebook. MLSs define their compliance obligations in their own systems. MemberSync sends notices, tracks acknowledgment, surfaces non-responders, and maintains an audit trail.

Clear Cooperation is **gone** — no longer in effect, do not reference it as something to build.

NAR settlement obligations are **already implemented** for both associations and MLSs.

### 8. Billing Architecture

Primary billing is recurring Stripe credit card charges. Monthly invoicing is the exception path. MemberSync stores only a Stripe customer ID and last 4 digits — full card data never stored, logged, or transmitted. Billing contact is separate from primary admin and must both be on file.

---

## SENSITIVE FILES — NEVER TOUCH

- `triggeredCampaignProcessor.ts` — do not modify for any reason
- `sequenceEnrollmentService.ts` — sensitive execution infrastructure, handle with extreme care

---

## COMPLETE STATE OF EMAIL INFRASTRUCTURE (AS OF MARCH 12)

All email infrastructure work is complete and verified on Replit as of March 12. The dev team's snapshot from March 10 is missing all of this — they must pull a fresh snapshot before any production work on email.

**Suppression hardening (complete):**
- Schema migration: `member_email_preferences` primary key swapped from `member_key` to `email_address` — permanent and irreversible
- End-to-end unsubscribe flow verified: email delivered → unsubscribe recorded with `email_address` as PK → second marketing email correctly blocked

**UX fixes (complete):**
- Settings nav link to Email Governor restored in `AppSidebar.tsx`
- Context-aware send toast: 8-second duration, three scenarios (clean send, partial suppression, full suppression)
- `skipped_count` and `skip_reasons` columns added to `email_campaigns`
- Amber suppression banner on campaign detail page
- Queue processor log counters disambiguated

**SendGrid unsubscribe architecture (complete):**
- Four ASM unsubscribe groups created programmatically
- Category-aware one-click unsubscribe handling
- Member-facing preference center at `/email-preferences`
- Staff-facing unsubscribe management panel at `/smartsends/settings/unsubscribes`
- All four `sg_group_*` SendGrid group ID columns in `tenant_config` populated with real values
- Webhook handler updated to process unsubscribes by ASM group, not globally

---

## PROMPT QUEUE — CURRENT STATE

### ✅ Completed This Session
1. RAG Memory System — built, verified, working

### Next in Queue (Priority Order)

**2. Dashboard Warmth + Membership Widget Fix**
The dashboard needs more humanity — warmth and personality in copy, not just data. The membership widget shows a scary -73% MoM figure that needs context and framing. Separate prompt from the RAG memory work.

**3. Campaign Architect Streaming**
Currently generates all emails at once. Should stream them one by one — each email appears as it's generated. Better UX, feels more alive. Important for AEI demo. Do not make any other changes to Campaign Architect alongside this — it is the AEI centerpiece.

**4. Recognition Dashboard Widget Fix**
Recognition section is largely empty. Dashboard widget needs fixing. Recognition full homepage is a Claude Code build — not a Replit prompt.

**5. AI Chat + Recharts Visualizations**
After the analyst upgrade prompt (already written and ready to deploy), add Recharts visualizations inline in AI Chat responses. Premium feature per module table in CLAUDE.md.

**6. Quick Campaign (Do If Time Allows)**
Lightweight Campaign Architect variant. User provides: dates, goal, URLs. AI builds a campaign. No full conversation UI — just inputs and output. Reframed from "Drip Sequence." Lower priority than items 2–5.

**7. Email Archive / Templates**
Need clarification from Tracy on exactly what's broken before writing a prompt.

### Pending in Claude Code (Not Replit)
- Recognition homepage (stat cards, "what's resonating," queue as opportunity, projections, daily digest, left nav badge, unified top-nav notification bell)
- CLAUDE.md update (see below — next immediate priority)

---

## CLAUDE.md UPDATE — IMMEDIATE NEXT PRIORITY

CLAUDE.md was last updated March 9. It is now meaningfully out of date. The update should happen in a fresh conversation with full context. Key gaps:

**Missing entirely:**
- Campaign Architect (full architecture, branch types, standing rules, AI personality, two-panel UI, session persistence)
- Recognition module as first-class module (terminology: "Recognition" in UI, "Celebration" in code; queue architecture; Email Governor exemption; homepage direction)
- Navigation structure (canonical reference — new nav designed March 8)
- AI Memory / RAG system (two-layer architecture, `tenant_config` fields, injection order, terminology rule)
- Unsubscribe architecture (four ASM groups, category-aware handling, preference center, webhook handler)
- Email Health Dashboard (three tabs: Performance, Send Queue, Archive)
- Image Library (upgraded — metadata, optimization, archive rules, delete/version rules)
- AI cost controls plumbing (`ai_usage_logs` table, `aiUsageLogger` service, per-feature daily limits in `tenant_config`)
- Persistent memory architecture and philosophy
- Client terminology principle (business context owns language, not code)
- Admin panel architecture (three access levels, what clients can/cannot change, Geek Squad Principle)
- Two-track development model (explicit section)
- Prototype → Production handoff process

**Out of date:**
- "Celebrations" in Production Port module order → should be "Recognition"
- Standing rules (missing ~6 new rules from March 7–12)
- Client pipeline (CRMLS status, GRAR added as third paying client)
- What's Coming section (several items now built; new items on horizon)
- Campaign Architect listed as "Automations" in module order — needs dedicated section

**New standing rules to add (not yet in CLAUDE.md):**
- Do not modify `triggeredCampaignProcessor.ts` for any reason
- `sequenceEnrollmentService.ts` is sensitive execution infrastructure — handle with extreme care
- Recognition and Compliance never appear in SmartSends Reporting & Analytics under any filter
- Email category is required on all campaigns — no null categories
- `email_address` is the permanent primary key on `member_email_preferences` — `member_key` is gone
- Pagination must happen at SQL level only — no in-memory slicing of large datasets
- Dead code is deleted, not commented out
- AI suggestions are always actionable yes/no — never configuration forms
- Client terminology is owned by `ai_business_context` — the AI uses the client's language, not Membio's internal tier names
- Every AI call must be logged via `aiUsageLogger`
- Schema is modularized by query type — do not re-inject full schema into every AI call
- `member_metrics_cache` is the single source of truth for member metrics
- Scoring engine must be data-driven, not code-driven — weights and active signals come from `tenant_config`, not if-statements
- Two-step query pattern required for cross-database operations (prototype only — eliminate in production)
- No fake data, ever — every email sent must be real and verifiable

---

## OPEN QUESTIONS (CARRY FORWARD)

1. **Leadership/Board pricing:** How much should a Leadership seat cost? Zero marginal cost to Membio, real perceived value to client. Needs a pricing decision before commercial launch.

2. **MLS compliance rule sets:** What does MLS data accuracy and timeliness compliance look like in practice? To be answered with input from first MLS client using the module. Do not pre-build assumptions.

3. **Billing integration timing:** When does Stripe integration get built? Currently manual invoicing for clients on invoiced billing. Target: before client #4 onboards.

4. **Email Archive / Templates:** What specifically is broken? Need Tracy's clarification before writing a prompt.

---

## KEY FILES REFERENCE

### In Project Knowledge
- `CLAUDE.md` — Product bible (last updated March 9 — overdue for update)
- `CLAUDE_030926.md` — Superseded draft; use current CLAUDE.md
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog
- `MemberSync___Project_Summary_Late_Evening_Part_2_031126.md` — Prior summary (Admin Panel spec session)
- `MemberSync_Project_Summary_Mar11_2026_Evening.md` — One prior to that
- `MemberSync_RecipientTracking_UnsubscribeArchitecture.md` — Complete unsubscribe architecture spec
- `MemberSync_Webhook_CategoryUnsubscribeFix.md` — Webhook fix prompt
- `MemberSync_SuppressionHardening_Items1and2.md` — Suppression hardening spec
- `MemberSync_CampaignArchitect_Hardening.md` — Campaign Architect hardening (deployed March 7)
- `MemberSync_NavigationRedesign_Final.md` — Nav redesign spec
- `MemberSync_AICostControls_Prompt.md` — AI cost controls plumbing

### Replit Agent Documents
- `MemberSync_Replit_Orientation.md` — Full orientation for new Replit agents (send before any implementation plan)
- `MemberSync_Replit_StandingRules_Header.md` — Compact header to prepend to every future prompt

### Output Files (This Session)
- `MemberSync_RAGMemory_Prompt.md` — The RAG memory Replit prompt (final, sent, verified working)
- `MemberSync_Project_Summary_Mar12_2026.md` — This document

---

## REPLIT WORKFLOW REMINDERS

- **Every new Replit agent receives the full orientation document** (`MemberSync_Replit_Orientation.md`) before any implementation plan is approved
- **Every prompt is prepended** with the standing rules header block
- **Tracy reviews Replit's plan first** — Claude assesses before Tracy approves execution
- **Manual end-to-end verification** required after every build — do not rely solely on Replit's self-reported checklist
- **Replit loses history on restart** — always treat new agents as starting from zero
- **Context window accumulation** across long sessions degrades performance — start fresh conversations per work session
- **SendGrid webhook URL must be updated** after Replit restarts

---

## STANDING RULES SUMMARY (ALL 30 — CANONICAL)

1. No parallel systems — extend existing components, never build duplicate implementations
2. Don't break what works — verify before and after every change
3. Full-page patterns, not modals, for multi-step tasks
4. Shared components over duplicates
5. Server-side for anything touching more than 1,000 records
6. Test your work — happy path and at least one edge case before reporting complete
7. "Recognition" in UI everywhere — "Celebration" in code only
8. Email category is required on all campaigns — no null categories
9. Governor exemptions are: transactional, compliance, critical, recognition
10. Campaign Architect replaces drip sequence builder — no parallel UI
11. AI suggestions are always actionable (yes/no) — never configuration forms
12. Competitive intelligence queries must respect tenant isolation — no cross-client data leakage
13. No fake data. Ever. Real member data or clearly labeled sample data only
14. Every module gated by `tenant_config` — disabled = not rendered, no background jobs, no AI budget
15. The 5% rule — build what clients asked for or dreamed about, not what sounds good in a roadmap
16. Mobile-first, performance-always — responsive UI, under 2 seconds load time
17. Social proof is never used in Campaign Architect emails — no "thousands of members" language
18. Minimum 3 emails per event in any Campaign Architect sequence
19. Campaign Architect branch points are shallow — registration + prior attendance only
20. Recognition is a top-level nav module — never nest inside SmartSends
21. Nav items are destinations. Actions live in buttons
22. Every email sent through MemberSync must be real and verifiable — no hallucinated data
23. Every AI call must be logged via `aiUsageLogger`
24. Pagination must happen at SQL level — no in-memory slicing of large datasets
25. Dead code is deleted, not commented out
26. Do not modify `triggeredCampaignProcessor.ts` for any reason
27. `sequenceEnrollmentService.ts` is sensitive execution infrastructure — handle with extreme care
28. Audience language always reflects what staff created — never expose internal tier labels
29. Recognition and Compliance never appear in SmartSends reporting under any filter
30. Member drill-down with individual event timestamps is required on every sent campaign

---

## REMINDERS FOR NEXT CONVERSATION

- **First task: CLAUDE.md update.** Open a fresh chat, load the current CLAUDE.md, and do a comprehensive update covering everything listed in the CLAUDE.md Update section above. This is overdue and must not slip further.
- **Second task:** Dashboard Warmth + Membership Widget Fix (Replit prompt).
- **Do not touch Campaign Architect** except for the streaming prompt. It is the AEI demo centerpiece.
- **⛔ Dev team codebase warning still in effect.** They must pull a March 12+ snapshot before any production work.
- **⛔ Do not modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts` under any circumstances.**
- The AI Chat analyst upgrade prompt is written and ready — confirm it has been deployed before writing the Recharts visualization prompt.
- CRMLS is off the prospect list. Do not include in any forward-looking documents.
- `email_address` is the permanent primary key on `member_email_preferences` — this migration is irreversible and must be respected in all future email infrastructure work.

---

*MemberSync Project Summary · March 12, 2026 · Confidential — Membio*
*Maintained by: Tracy (CEO) + Claude (CTO role)*
*Continues from: MemberSync___Project_Summary_Late_Evening_Part_2_031126.md*
*Next conversation: CLAUDE.md update first, then Dashboard Warmth prompt*
*Governing principle: Rock solid software first. No shortcuts. No exceptions.*

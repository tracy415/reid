# MemberSync — Project Summary
## March 7, 2026 (Comprehensive)

This document is the authoritative state-of-the-project as of end of day March 7, 2026. Use this to resume work in any new conversation. The March 6 Evening summary is superseded by this one for current state.

---

## TABLE OF CONTENTS

1. Project Overview & Vision
2. Build Philosophy & Team Structure
3. Client Pipeline
4. Complete Feature Inventory (What Has Been Built)
5. Campaign Architect — Full Design & Status
6. Navigation Redesign — Full Decision Record
7. Recognition Module — Redesign Direction
8. Member Journey — Architecture Decision
9. This Session's Accomplishments
10. Prompt Queue — Current Status
11. AEI Demo Path (March 23–27, Minneapolis)
12. Known Issues & Technical Debt
13. Strategic Decisions & Market Positioning
14. AI Cost Model
15. Multi-Tenant Architecture Roadmap
16. Strategic Roadmap
17. All Architectural Decisions (Canonical List)
18. Standing Rules (Canonical List)
19. Key Files Reference
20. Parking Lot Summary

---

## 1. PROJECT OVERVIEW & VISION

**MemberSync** is a member engagement and retention SaaS platform built by Membio for real estate associations and MLSs. It analyzes MLS listing data and AMS data to help executives understand, engage, and retain members through AI-powered insights, smart email campaigns, member recognition, lapse prevention, and engagement scoring.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**Product philosophy:** "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

**The lightsaber:** Organized real estate is in an existential fight for survival. MLSs are going non-Realtor, removing the last transactional justification for association membership. MemberSync is the lightsaber — real, specific, actionable intelligence about their own members AND the competitive environment those members operate in.

**The 75/12 Rule:** ~75% of association and MLS members produce ~12% of real estate transaction volume, yet pay ~75% of dues and fee revenue. Foundation members are the financial backbone. MemberSync exists to serve and celebrate them.

**Member tiers (display names, always positive):**
- **Rainmaker** — 40+ sides/year (~1.4% of Mainstreet membership)
- **Builder** — 6–39 sides/year (~21%)
- **Foundation** — 0–5 sides/year (~77%)

Internal code names: `active_producer`, `occasional_producer`, `license_maintainer`. Never shown to users.

---

## 2. BUILD PHILOSOPHY & TEAM STRUCTURE

**Two-track development model:**
- **Track 1 (Tracy + Claude):** Continue building and validating features in Replit for sales demos and product vision
- **Track 2 (Dev team):** Build production platform using Claude Code, porting validated modules from Replit

**Claude's role:** CTO, product visionary, AI architecture expert, and strategic sparring partner. Pressure-test every feature idea against multi-tenant scale, technical debt, and timing. Surface architectural risks proactively. Push back when something doesn't make sense.

**Spec-first development:** Tracy identifies product issues and vision; Claude writes detailed implementation prompts. Dev team implements via Claude Code.

---

## 3. CLIENT PIPELINE

- **Mainstreet REALTORS®** (~18,275 members, Chicago suburbs) — first client, prototype stage on Replit, not yet in production
- **HGAR / Hudson Gateway** (~12,800 members, New York) — onboarding, first true multi-tenant requirement
- **GRAR / Greater Rochester** (~3,400 members) — follows HGAR
- **CRMLS** (103,000+ members, California) — major pilot prospect; requires SOC 2 compliance

---

## 4. COMPLETE FEATURE INVENTORY (WHAT HAS BEEN BUILT)

### Core Platform
- Engagement scoring with tier classification (Rainmaker/Builder/Foundation)
- Member metrics cache (daily refresh, cache-first architecture)
- Dashboard with Association Pulse cards, Activity Feed, Member Recognition sidebar
- Member Detail pages with score breakdown, open/click timestamps
- Daily membership snapshot accumulating for trend analysis

### SmartSends
- Campaign creation (AI + manual + template)
- All four audience types (AI builder, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking with open/click timestamps
- Email Governor (daily/weekly caps, sandbox mode, exempt categories)
- Recognition Queue with review/approve/send flow (Parts 1–8 complete)
- Email Health Dashboard (Performance, Send Queue, Archive tabs)
- Image Library (upgraded — metadata, optimization, archive, delete/version rules)
- AI duplicate detection at Preview step
- Archive-aware AI composition
- Automations with 7 trigger types

### Campaign Architect (NEW — centerpiece of AEI demo)
- Conversational AI planning interface
- Session persistence — saved to Automations center
- Audience picker (Saved, Member/Bill Type, Picklist tabs inline)
- Event multi-select with anchor-date timing
- Live plan preview panel with watch-outs
- AI parse failure retry + hardening (deployed March 7)
- Email generation, editing, A/B test suggestion, activation (Prompt 2 — deployed)
- Polish pass (5 improvements — deployed)
- Hardening pass (3 production fixes — deployed March 7)

### AI Services
- AI Chat (natural language → SQL, cross-domain queries, retry loop)
- AI email composition with archive-aware context
- AI audience builder
- AI duplicate detection
- AI campaign planner (Campaign Architect)
- Schema modularization for AI context

### Analytics
- Production Analytics (Office Volume, Agent Production, Market Concentration)
- Market Stats with concentration thresholds
- Top 10 Offices and Agents

---

## 5. CAMPAIGN ARCHITECT — FULL DESIGN & STATUS

### What It Is
Conversational AI-first campaign creation. Staff describes a goal in plain language; AI proposes complete campaign structure, writes all emails, suggests a single A/B test. No configuration forms, no node canvas.

### Prompts Status
- **Prompt 1** (conversation UI, planning, session persistence) ✅ Deployed
- **Prompt 2** (email generation, editing, A/B, activation) ✅ Deployed
- **Polish prompt** (5 UX improvements) ✅ Deployed
- **Hardening prompt** (3 production fixes) ✅ Deployed March 7
- **Planner Intelligence Fix** (`MemberSync_CampaignArchitect_PlannerFix.md`) 📝 Sent to Replit March 7 — awaiting verification

### Planner Intelligence Fix (Critical for AEI)
**Problem identified in testing:** When staff selected 3 events spread across a year and typed a one-sentence goal, the AI defaulted to a short burst of emails promoting only the first event. Staff had to correct it twice before it proposed a year-round series strategy. For AEI this is unacceptable — the plan must be right on the first turn.

**Fix:** Added multi-event series recognition block to `buildSystemPrompt()` in `aiCampaignPlannerService.ts`. Forces AI to count events first, then choose strategy: 2+ events = series thinking by default; 1 event = focused pre-event burst.

**Acceptance test:** DMBs audience + 3 Brokerage Forum events (May, Aug, Nov) + "I want DMBs to attend these forums" → complete year-round plan on first response, no corrections needed.

### Three Additional Fixes Needed (Prompt to be written next session)
These were identified in testing March 7 and need a focused addendum prompt:

**Fix 1 — No social proof, ever.**
The AI must never use social proof in campaign emails — no "members like you are attending," no attendance numbers, no testimonials. Reason: campaigns can be approved in May and send in October. The AI has no access to real-time attendance or registration data at send time. Fabricated social proof is a safety issue, not a UX issue. This rule goes in the planner system prompt AND in the email generation prompt.

**Fix 2 — Minimum 3 emails per event.**
The AI is defaulting to 3-4 emails for a 3-event series (roughly 1 per event). This is wrong. Every event in a series needs: awareness, value reinforcement, and urgency. Minimum 3 emails per event = 9 emails minimum for a 3-event series. The AI must be told this explicitly with the rationale: "High-value audiences like DMBs need awareness → value reinforcement → urgency for each event. Never propose fewer than 3 emails per event."

**Fix 3 — Conditional branching design capability.**
Campaign Architect must be able to design branching campaigns where email content varies based on member state. Two branch points:

*Branch 1 — Registration status:*
- Default: registrants stay in the sequence as normal
- Staffer option A: skip registered members entirely
- Staffer option B: send them an alternate email they create (confirmation, "see you there," etc.)
- AI asks this question naturally during planning: "Some of your DMBs may register for Forum 1 before Email 2 sends. Want to skip them at that point, or send them something different — like a reminder of what to expect?"
- Alternate email created inside Campaign Architect flow, in the same EmailComposer

*Branch 2 — Prior attendance in series:*
- Default: treat each event independently, same sequence for everyone
- Staffer option: acknowledge prior attendance ("you attended Forum 1, here's why Forum 2 builds on that")
- Series relationship is configurable: tight (attend all three, get a discount) or loose (three separate events marketed together but independent)
- AI asks: "Since these are three forums in a series — are they connected for members who attend multiple, or does each stand alone?"

*Execution note:* Plan preview shows branching visually:
```
📧 Email 3 — 5 days before Forum 1
   → Not yet registered: "Last chance to claim your seat"
   → Already registered: "See you Tuesday — here's what to expect"
```
Full conditional execution engine to be built after plan preview is working. For AEI: show the design capability in the plan panel. Wire the execution in the triggered campaign processor post-AEI.

---

## 6. NAVIGATION REDESIGN — FULL DECISION RECORD

### Current Problems Identified
1. Two items called "Dashboard" (main nav + SmartSends sub-item)
2. "Send Email" is an action in a nav built for destinations
3. "Campaigns" is actually email history/analytics — the name implies creation
4. "Automations" is ambiguous — unclear what it covers vs. Campaign Architect
5. "Recognition Queue" is a process label, not a destination
6. "Drafts" as a top-level nav item — Mailchimp doesn't do this; drafts live in the campaign list
7. SmartSends sub-nav mixes creation, destinations, and operational tools
8. The SmartSends Dashboard shows a full campaign table AND the Campaigns page shows the same table — duplicate data in two places
9. "Analytics" at top level actually means Market Stats (production volume, office rankings) — name doesn't reflect content

### Design Principles Applied
- Nav items are places you go, not actions you take
- Actions live in buttons (+ Create), not nav items
- The nav should tell the product story: reach, recognize, engage, retain
- Match patterns users know from Mailchimp where appropriate
- SmartSends stays as a branded module name — future modules (Engagement, Retention) will be peer-level items
- Drafts disappear from nav — they're a status badge on campaigns, not a destination

### Approved Top-Level Navigation Structure
```
Dashboard
SmartSends          [expands to sub-nav]
Recognition         [top-level — first-class feature]
Engagement          [coming soon]
Retention           [coming soon]
Chats               [stays in left nav — demo-critical]
Market Stats        [renamed from Analytics]
Members
Offices
Compliance
```

**Notes:**
- Chats stays in left nav (not profile menu) — it's a demo centerpiece and executives find it addictive once they discover it
- Recognition at top level signals it's a first-class capability, not a sub-feature of email
- Engagement and Retention appear as "Coming Soon" items — shows product vision in the nav itself
- Compliance surfaces for both associations AND MLSs (different compliance types, not hidden for MLSs)

### SmartSends Sub-Navigation
When SmartSends is expanded, sub-nav shows:
```
+ Create            [prominent teal button above sub-nav items — always visible]
─────────────────
Campaigns           [SmartSends home — landing page when clicking SmartSends]
Triggers            [replaces Automations]
Audiences
Content             [Image Library now; Templates + brand assets later]
Templates
Settings            [governor, sandbox mode, SendGrid status, throttle]
```

**Create button selector (4 options):**
- Email — one-time send, goes to existing Send Email flow
- Trigger — event-based automation, goes to existing trigger setup
- Sequence — multi-email campaign, goes to Campaign Architect
- Member Journey — *(Coming Soon)* — shows preview modal with wireframe of journey builder UI

**Campaigns page (SmartSends home):**
- Performance stat cards at top (Campaigns sent, Emails sent, Open Rate, Click Rate) — no campaign table on this view
- Four tabs below stats: **Emails** | **Sequences** | **Triggers** | **Recognition**
- Each tab has its own relevant columns — Recognition tab shows recipient, milestone type, sent date, opened; Sequences tab shows campaign name, emails in sequence, active members, completion rate
- Drafts appear as a status badge within each tab — no separate Drafts nav item
- Mobile: stat cards stack full-width, table becomes simplified list with tap-to-expand
- Individual member open/click data and email creative accessible from row detail view

**Create page:**
- Exists as a guided starting point for new/unfamiliar staff
- Inspired by Mailchimp's "Create something that gets noticed" pattern
- Four illustrated cards: Send an Email, Build a Sequence, Set Up a Trigger, Member Journey (Coming Soon — greyed with preview)
- Does NOT replace the + Create button — both exist
- Accessible from the + Create button or as a "Start here" link for new users

**Templates:**
- Lives under SmartSends sub-nav as its own item
- Staff can browse Membio-provided starter templates by category (event promotion, compliance, welcome, recognition, CE/education)
- "Save as Template" button available on any sent campaign
- Templates saved by staff appear in a "My Templates" section
- Clicking any template opens the existing EmailComposer pre-populated
- Templates are NOT the same as Recognition Templates (those live under Recognition)

**Settings (SmartSends):**
- Email Governor configuration
- Sandbox mode toggle + test recipient list
- SendGrid connection status
- Throttle settings
- Daily/weekly cap configuration
- Moves OUT of the main workflow nav — staff visits this occasionally, not daily

### Recognition Module Structure
**Top-level nav item.** Landing page is the Recognition homepage (not just the queue).

**Recognition homepage sections:**
- Stat cards: milestones detected this week, recognition emails sent this month, avg open rate on recognition emails
- "What's resonating": which milestone types get the best member response (volume milestones vs. anniversaries vs. designations)
- "Coming up": milestones detected but not yet approved — the queue, presented as opportunity not a task list
- "Projections": estimated milestones in next 30 days based on transaction velocity and membership tenure

**Recognition sub-nav:**
```
Recognition         [homepage as described above]
Templates           [recognition email templates by milestone type]
Performance         [same tabbed analytics pattern as SmartSends Campaigns]
Settings            [milestone types, detection rules — future self-config capability]
```

**Recognition notification system:**
- Left nav badge on Recognition item showing pending queue count
- Top nav bell/notification icon (unified inbox) — surfaces recognition queue items, failed sends, trigger errors
- Daily digest email to staff each morning: "You have 47 recognition emails ready to review — 12 volume milestones, 28 anniversaries, 7 new member welcomes. Review and approve →" Sent from a real-looking address (not noreply@). One-click link directly to the queue.

**Future capability (post-AEI):** Clients define their own recognition types and templates. Currently Membio-defined only.

### Items Removed from Navigation
- "Send Email" as nav item — replaced by + Create button
- "Drafts" as nav item — status badge within Campaigns tabs
- "SmartSends > Dashboard" — eliminated; SmartSends now lands on Campaigns
- Campaign table on SmartSends Dashboard — removed; stat cards only on home

---

## 7. MEMBER JOURNEY — ARCHITECTURE DECISION

### What Member Journey Is
A lifecycle track where a member is enrolled based on a trigger event (new member join, CE enrollment, leadership nomination) and the system walks them through a defined sequence automatically — potentially months long — with conditional gates, mandatory vs. optional steps, and staff visibility into each member's progress.

**Primary use case:** New member onboarding — welcome email → orientation invitation → orientation confirmation → reminder → follow-up → MLS training → YPN invitation → committee invitation → login instructions → member materials access → etc.

**Other use cases:** CE completion tracks, Code of Ethics/Fair Housing coursework, leadership development.

### Why It's Architecturally Distinct from Campaign Architect
Campaign Architect = staff initiates a campaign to a defined audience for a specific goal. Finite. Time-boxed.

Member Journey = member enrolls on a trigger, system walks them through a lifecycle automatically. Potentially months long. Monitors individual progress. Branches based on what each member does or doesn't do. Deep conditional logic.

Trying to build Member Journey on Campaign Architect's execution engine would be the wrong foundation.

### Build Decision
**Do NOT build Member Journey execution engine before AEI.** Timeline doesn't support it and rushing it creates technical debt.

**DO build for AEI:** Design the UI well enough to show the concept — journey map for a new member, branching logic, progress monitoring view. Live link from the + Create selector showing a preview modal/wireframe. This is a "here's what's coming" moment, not a broken feature.

**Build properly post-AEI** with a dedicated journey engine spec.

### Member Journey Engine Requirements (for spec when ready)
- Enrollment trigger (join date, CE enrollment, leadership nomination)
- Progress monitoring — staff can see where each member is at any moment
- Conditional gates — step 5 only sends if step 3 was completed
- Mandatory vs. optional steps
- Indefinite duration (new member journey might run 6 months)
- Staff visibility dashboard — "all new members and their onboarding progress right now"

---

## 8. THIS SESSION'S ACCOMPLISHMENTS (MARCH 7, 2026)

1. **Campaign Architect Hardening prompt verified deployed** — three production fixes confirmed working. Replit's post-implementation notes reviewed; items 1 (rate limiter scale) and 3 (missing event warning) added to Parking Lot.

2. **Campaign Architect Planner Intelligence Fix written and sent** — multi-event series recognition. File: `MemberSync_CampaignArchitect_PlannerFix.md`. Awaiting Replit verification.

3. **Three additional Campaign Architect fixes identified** — social proof prohibition, 3-emails-per-event minimum, conditional branching design capability. Prompt not yet written — next session.

4. **Navigation redesign fully designed and decided** — complete decision record in Section 6 above. Prompt not yet written — next session.

5. **Recognition module redesign direction established** — homepage, sub-nav, daily digest email, notification badge. Documented in Section 6 above.

6. **Member Journey architecture decision made** — distinct from Campaign Architect, build execution engine post-AEI, show UI concept at AEI. Documented in Section 7 above.

7. **Templates strategy decided** — lives under SmartSends sub-nav; starter templates by category; "Save as Template" on any sent campaign; opens existing EmailComposer.

8. **SmartSends Settings separation decided** — governor and operational controls move to Settings sub-item, out of daily workflow nav.

---

## 9. PROMPT QUEUE — CURRENT STATUS

### In Progress with Replit Now
- **Campaign Architect Planner Intelligence Fix** (`MemberSync_CampaignArchitect_PlannerFix.md`) — multi-event series recognition. Sent March 7. Verify before writing next prompt.

### Ready to Write — Next Session (in order)
1. **Campaign Architect Addendum** — social proof prohibition + 3-emails-per-event minimum + conditional branching design capability. Single focused prompt, three additions to planner system prompt and email generation prompt.

2. **Navigation Redesign** — full restructure per Section 6 decision record. Touches every page. Precise prompt required. Mostly renaming + restructuring + removing duplicate campaign table from SmartSends Dashboard.

3. **Recognition Homepage** — new landing page with stat cards, "What's resonating," "Coming up" queue, projections. Daily digest email. Left nav badge. Top nav notification bell.

### Written, Not Yet Sent
- `MemberSync_PromptC_AIDuplicateDetection.md` — send after Prompt B verified working

### On Hold (Intentionally)
- A/B Testing standalone — superseded by Campaign Architect design
- Automation Priority + Global Contact Limit — waiting for stability
- Member Journey execution engine — post-AEI

---

## 10. AEI DEMO PATH (MARCH 23–27, MINNEAPOLIS)

**16 days out. Audience: MLS executives and technical leaders.**

**Demo sequence (in order of impact):**
1. **AI Chat** — "which agents in Downers Grove closed in January with licenses expiring this year" → instant results. The "second brain" moment.
2. **Campaign Architect** — type one sentence goal, watch AI build complete campaign with year-round series strategy. The "cancel HubSpot" moment.
3. **Member Recognition** — show the queue, show AI-generated personal email with real member data, show review/approve flow.
4. **Dashboard** — Association Pulse, the 75/12 insight visualized, tier distribution.

**Demo must be narrow, stable, and locked.** No freestyle.

**Must complete before demo path is locked:**
- Planner Intelligence Fix verified ✓ (in progress)
- Campaign Architect Addendum (social proof + email count + branching design)
- Navigation Redesign (clean nav for demo)
- End-to-end run-through at least once before travel

---

## 11. KNOWN ISSUES & TECHNICAL DEBT

### Critical (AEI Risk)
- Campaign Architect planner defaults to single-event thinking when multiple events selected — **FIX IN PROGRESS**
- AI Chat UI feels empty and transactional on full Chats page — conversation history not visually prominent, no suggested starters when blank
- MAX_CAMPAIGN_RECIPIENTS = 1 — safety limit; needs bumping for demo sends

### Important (UX Quality)
- Superfluous "Change" button AND "X" in Campaign Architect audience section — Replit to fix
- Email Health metrics show 0% in sandbox mode (correct behavior — resolves when live)
- Date range picker missing from Email Archive UI (backend supports it)
- Open/click badges on Member Detail not visually confirmed

### Nav (Will Be Fixed by Nav Redesign Prompt)
- Two items called "Dashboard"
- Drafts as standalone nav item
- SmartSends Dashboard showing duplicate campaign table
- "Automations" label ambiguous
- "Recognition Queue" as nav label
- "Analytics" label doesn't match content (it's Market Stats)

### Technical Debt (Parking Lot)
- Campaign Architect rate limiter is per-process (fine for Replit, needs Redis for multi-instance)
- Missing event warning at activation when anchor event was removed before activating
- 172-member gap (dashboard vs. member type builder count)
- Revenue data uses catalog prices not actual invoiced amounts

---

## 12. STRATEGIC DECISIONS & MARKET POSITIONING

All prior decisions from March 6 Evening summary remain in effect. New decisions this session:

- **Navigation tells the product story.** SmartSends → Recognition → Engagement → Retention is the four-act structure of the platform visible in the sidebar.
- **Recognition is a first-class module**, not a sub-feature of email. Top-level nav, own homepage, own analytics.
- **Member Journey is architecturally distinct from Campaign Architect** — different execution model, different infrastructure requirements, different build timeline.
- **Campaign Architect stays simple.** Two shallow branch points (registration status, prior attendance). Resist the urge to make it a mini-journey engine.
- **Chats stays in left nav.** Not profile menu. Too important for demo and too valuable for executives to bury.
- **Templates are a SmartSends feature**, not a Recognition feature. Recognition has its own template system tied to milestone types.
- **Social proof is prohibited in all Campaign Architect emails** — safety issue, not UX preference.

---

## 13–16. [UNCHANGED FROM MARCH 6 EVENING SUMMARY]

Refer to March 6 Evening summary for: AI Cost Model, Multi-Tenant Architecture Roadmap, Strategic Roadmap, All Architectural Decisions, Standing Rules.

**New Standing Rules added this session:**
- Social proof is never used in Campaign Architect emails. No attendance numbers, no "members like you," no testimonials. Campaigns can be approved months before they send.
- Minimum 3 emails per event in any Campaign Architect sequence. Awareness + value reinforcement + urgency for every event.
- Campaign Architect branch points are shallow (registration status, prior attendance). Deep conditional logic belongs in Member Journey, not Campaign Architect.
- Recognition is a top-level nav module. Never nest it inside SmartSends.
- Nav items are destinations. Actions live in buttons.

---

## 17. KEY FILES REFERENCE

### New Files This Session
- `MemberSync_CampaignArchitect_PlannerFix.md` — Multi-event series recognition fix. **Sent to Replit March 7.**
- `MemberSync_Project_Summary_Mar7_2026.md` — This document.

### Campaign Architect Prompts (All in Project Knowledge)
- `MemberSync_CampaignArchitect_Prompt1.md` ✅ Deployed
- `MemberSync_CampaignArchitect_Prompt2.md` ✅ Deployed
- `MemberSync_CampaignArchitect_Polish_Prompt.md` ✅ Deployed
- `MemberSync_CampaignArchitect_Hardening.md` ✅ Deployed March 7
- `MemberSync_CampaignArchitect_PlannerFix.md` 🔄 In progress

### To Be Written Next Session
- Campaign Architect Addendum (social proof + email count + conditional branching)
- Navigation Redesign prompt

### Previously Deployed (Unchanged)
- `MemberSync_SchemaModularization_Prompt.md` ✅
- `MemberSync_AIChat_JuliusUpgrade_Prompt.md` ✅
- `MemberSync_QueryEngine_RetryAndCrossDomain.md` ✅
- `MemberSync_PromptA_RecognitionQueue_EmailGovernor.md` ✅ (Parts 1–8)
- `MemberSync_PromptB_EmailHealth_ImageLibrary.md` ✅
- `MemberSync_ImageLibrary_Upgrade_Prompt.md` ✅

### Written, Not Yet Sent
- `MemberSync_PromptC_AIDuplicateDetection.md`

### Planning Documents
- `MemberSync_Development_Plan.docx`
- `Membio_AI_Workflow_Playbook.docx`
- `MemberSync_CRMLS_Scaling_Roadmap.docx`
- `CLAUDE.md` — Product bible (786 lines). **Needs revision after AEI** to add: tenant_config fields, Campaign Architect architecture, Email Health, Image Library, Recognition Queue, Navigation structure.

---

## 18. PARKING LOT SUMMARY

Full detail in `MemberSync_Parking_Lot.md` (updated March 7). Key additions this session:

**Section 1 — Features to Build:**
- Member Journey engine (post-AEI, dedicated spec required)
- Recognition self-configuration (clients define own milestone types and templates)
- Recognition reporting enhancements (projections, "what's resonating")
- AI Chat UI improvements (saved conversation sidebar, suggested starters, charts)
- Templates system (Membio starter templates by category, save-as-template from sent campaigns)

**Section 2 — Technical Debt (new items):**
- Campaign Architect rate limiter → Redis when multi-instance
- Missing event warning at activation

**Navigation items to defer:**
- Chats UI redesign (full page feels empty — needs saved conversation sidebar and suggested starters)
- Recognition self-configuration UI
- Member Journey preview modal (Coming Soon state for AEI)

---

*Session date: March 7, 2026.*
*Next session: Start by verifying Campaign Architect Planner Intelligence Fix, then write Campaign Architect Addendum prompt, then write Navigation Redesign prompt.*

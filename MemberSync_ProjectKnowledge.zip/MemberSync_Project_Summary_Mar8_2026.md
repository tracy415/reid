# MemberSync — Project Summary
## March 8, 2026

This document is the authoritative state-of-the-project as of March 8, 2026. Use this to resume work in any new conversation. The March 7 summary is superseded by this one for current state.

---

## TABLE OF CONTENTS

1. Project Overview & Vision
2. Build Philosophy & Team Structure
3. Client Pipeline
4. Weekend Goal (Critical Context)
5. Complete Feature Inventory
6. Campaign Architect — Full Status
7. Navigation Redesign — Full Decision Record
8. Recognition Module — Status & Direction
9. CLAUDE.md Update — Plan & Decisions
10. Prompt Queue — Current Status
11. Known Issues & Technical Debt
12. Strategic Decisions (This Session)
13. Standing Rules (Canonical — Updated)
14. All Architectural Decisions (Canonical)
15. Key Files Reference
16. Parking Lot Summary

---

## 1. PROJECT OVERVIEW & VISION

**MemberSync** is a member engagement and retention SaaS platform built by Membio for real estate associations and MLSs. It analyzes MLS listing data and AMS data to help executives understand, engage, and retain members through AI-powered insights, smart email campaigns, member recognition, lapse prevention, and engagement scoring.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**Product philosophy:** "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

**The lightsaber:** Organized real estate is in an existential fight for survival. MLSs are going non-Realtor, removing the last transactional justification for association membership. MemberSync is the lightsaber — real, specific, actionable intelligence about their own members AND the competitive environment those members operate in.

**The 75/12 Rule:** ~75% of association and MLS members produce ~12% of real estate transaction volume, yet pay ~75% of dues and fee revenue. Foundation members are the financial backbone. MemberSync exists to serve and celebrate them.

**Member tiers (display names, always positive):**
- **Rainmaker** — 40+ sides/year (~1.4% of Mainstreet membership)
- **Builder** — 6–39 sides/year (~21%)
- **Foundation** — 0–5 sides/year (~77%)

Internal code names: `active_producer`, `occasional_producer`, `license_maintainer`. Never shown to users.

---

## 2. BUILD PHILOSOPHY & TEAM STRUCTURE

**Two-track development model:**
- **Track 1 (Tracy + Claude):** Continue building and validating features in Replit for prototype/demo
- **Track 2 (Dev team):** Build production platform using Claude Code, porting validated modules from Replit

**Claude's role:** CTO, product visionary, AI architecture expert, and strategic sparring partner.

**Handoff artifacts:**
- `CLAUDE.md` — product bible in repo root (786 lines, needs major update — see Section 9)
- `MemberSync_Parking_Lot.md` — strategic ideas backlog in project knowledge
- Per-feature Replit prompts — the spec artifacts Tracy sends to Replit Agent

**Weekend goal (critical):** Tracy and Claude are working together this weekend (March 8–9) to get the Replit prototype into the best possible shape before handing to the dev team on Monday. The goal is feature completeness and vision clarity — not AEI demo prep. The dev team takes the GitHub repo and begins the production port: tearing apart the monolith, adding multi-tenancy, removing 110+ Mainstreet references. Tracy's job is to set the vision and functionality in the prototype so the team knows exactly what they're building toward.

---

## 3. CLIENT PIPELINE

| Client | Members | Status | Special Requirements |
|---|---|---|---|
| Mainstreet REALTORS® | 18,275 | First client, prototype stage | Production platform needed |
| HGAR / Hudson Gateway | 12,800 | Onboarding | Multi-tenant, NY compliance |
| GRAR / Greater Rochester | 3,400 | Third pilot | Multi-tenant, NY compliance |
| CRMLS | 103,000+ | Major pilot prospect | SOC 2, enterprise SLA, batch email |

---

## 4. WEEKEND GOAL (CRITICAL CONTEXT)

This reframes everything. Tracy is not prepping for AEI — she is handing a prototype to a dev team on Monday. The prototype should represent the fullest possible expression of the product vision, with every major feature decision made and every significant UI pattern established. 

**Order of work this weekend:**
1. Campaign Architect Addendum — IN PROGRESS (Replit building now)
2. Navigation Redesign — write and send next (bounded, fast)
3. CLAUDE.md update — comprehensive revision after nav is verified
4. Recognition Homepage — after CLAUDE.md
5. Whatever else surfaces

**Agreed approach for CLAUDE.md:** Nav first (not a huge piece of work), then CLAUDE.md. Write CLAUDE.md with the new nav as the intended/current structure even if not yet verified in Replit — the dev team needs to know where we're headed. Note it as "in progress" if needed.

---

## 5. COMPLETE FEATURE INVENTORY

### Core Platform
- Engagement scoring with tier classification (Rainmaker/Builder/Foundation)
- Member metrics cache (daily refresh, cache-first architecture)
- Dashboard with Association Pulse cards, Activity Feed, Member Recognition sidebar
- Member Detail pages with score breakdown, open/click timestamps
- Daily membership snapshot for trend analysis

### SmartSends
- Campaign creation (AI + manual + template)
- All four audience types (AI builder, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking with open/click timestamps
- Email Governor (daily/weekly caps, sandbox mode, exempt categories)
- Recognition Queue with review/approve/send flow — Parts 1–8 complete
- Email Health Dashboard (Performance, Send Queue, Archive tabs)
- Image Library (upgraded — metadata, optimization, archive, delete/version rules)
- AI duplicate detection at Preview step
- Archive-aware AI composition
- Automations with 7 trigger types

### Campaign Architect
- Conversational AI planning interface
- Session persistence — saved to Automations center
- Audience picker (Saved, Member/Bill Type, Picklist tabs inline)
- Event multi-select with anchor-date timing
- Live plan preview panel with watch-outs
- AI parse failure retry + hardening
- Email generation, editing, A/B test suggestion, activation
- Polish pass (5 improvements)
- Hardening pass (3 production fixes)
- Planner Intelligence Fix (multi-event series recognition) — verified working

### AI Services
- AI Chat (natural language → SQL, cross-domain queries, retry loop)
- AI email composition with archive-aware context
- AI audience builder
- AI duplicate detection
- AI campaign planner (Campaign Architect)
- Schema modularization for AI context

### Analytics
- Production Analytics (Office Volume, Agent Production, Market Concentration)
- Market Stats with concentration thresholds
- Top 10 Offices and Agents

---

## 6. CAMPAIGN ARCHITECT — FULL STATUS

### All Prompts Status
- **Prompt 1** (conversation UI, planning, session persistence) ✅ Deployed
- **Prompt 2** (email generation, editing, A/B, activation) ✅ Deployed
- **Polish prompt** (5 UX improvements) ✅ Deployed
- **Hardening prompt** (3 production fixes) ✅ Deployed
- **Planner Intelligence Fix** ✅ Deployed and verified working
- **Campaign Architect Addendum** 🔄 IN PROGRESS — Replit building now

### Campaign Architect Addendum — What It Builds
File: `MemberSync_CampaignArchitect_Addendum.md` (in outputs — full rewrite completed this session)

**Fix 1 — Social proof prohibition:** Never invent testimonials, attendance numbers, or quotes. Added to planner system prompt.

**Fix 2 — Minimum 3 emails per event:** Awareness + value reinforcement + urgency for every event. 3-event series = minimum 9 emails. Added to planner system prompt.

**Fix 3 — Conditional branching (full implementation):**
- Branch emails are real, fully authored `CampaignPlanEmail` entries — not stubs
- Two branch types: `registration_skip`, `registration_alternate`, `prior_attendance`
- Schema: `branchType` and `branchParentStep` added to `CampaignPlanEmail`
- Branch routing stored in `sendCondition` as JSON in `triggeredCampaignSteps`
- Plan panel: branch emails nested under parent with violet (registration_alternate) or teal (prior_attendance) border
- "+ Add branch email" button on event-anchored primary steps — offers Skip or Alternate only
- Prior attendance branches come from AI planner conversation only — NOT from the button
- Processor: `isMemberRegisteredForEvent`, `didMemberAttendEvent`, `parseBranchCondition`, `isAlternateBranchStep`, `sendDripStepEmail` helpers added
- Existing send logic in processor refactored to use `sendDripStepEmail` after line-by-line verification
- Replit implementation plan reviewed and approved with two callouts (T002: chatMutation for alternate button; T004: non-branch regression test)

**Fix 4 — Archive bug:** Never-activated sessions (no `triggeredCampaignId`) can now be archived without error.

### Decisions Confirmed by Replit Q&A This Session
- Prior attendance: AI planner only, not the button
- Send logic: refactor to `sendDripStepEmail` helper (with line-by-line verification gate)

---

## 7. NAVIGATION REDESIGN — FULL DECISION RECORD

### Status
Prompt written (`MemberSync_NavigationRedesign.md` — in outputs). **Ready to send to Replit after Addendum is verified.**

### New Navigation Structure

**Left sidebar (top to bottom):**
```
Dashboard
SmartSends [collapsible]
  → Campaigns
  → Audiences [collapsible]
      → AI Builder
      → Picklist
      → Member/Bill Type
      → Saved
      → Upload
  → Triggers         (was: Automations)
  → Content          (was: Image Library)
  → Settings         (new — links to /smartsends/settings)
Recognition          (TOP-LEVEL — was nested under SmartSends)
  [queue badge showing pending count from /api/recognition/queue-count]
Chats
Market Stats         (was: Analytics)
  → Overview
  → Office Volume
  → Agent Production
  → Create Brief
All Members
All Offices
Compliance
──────────────
Engagement          (greyed, "Coming Soon")
Retention           (greyed, "Coming Soon")
```

### Key Navigation Decisions
- **Send Email removed from nav** — action moves to "+ Create" button
- **Drafts removed from nav** — status badge/tab within Campaigns page
- **SmartSends Dashboard sub-item removed** — SmartSends itself becomes the Campaigns landing
- **SmartSends Dashboard page:** campaign table removed, stat cards only
- **Recognition** → top-level nav item (its own module, not a SmartSends sub-item)
- **Recognition queue badge** moves from SmartSends to the Recognition nav item
- **Automations** → renamed "Triggers"
- **Analytics** → renamed "Market Stats"
- **Image Library** → renamed "Content" in nav (page title also changes)
- **Engagement + Retention** → greyed "Coming Soon" items (visible but not clickable)
- **Settings** → added as SmartSends sub-item (links to `/smartsends/settings`)
- **All URL paths unchanged** — only display labels change
- **Nav items are destinations. Actions live in buttons.** (Standing rule)

### Page Title Updates
- Analytics page → "Market Stats"
- Automations page → "Triggers"
- Image Library page → "Content"
- Recognition Queue page → "Recognition" (first-class landing page — see Section 8)

---

## 8. RECOGNITION MODULE — STATUS & DIRECTION

### Current State
- Recognition Queue with full review/approve/send flow (Parts 1–8 deployed)
- Recognition emails exempt from Email Governor (Lane 1, no cap)
- Campaign names: "Recognition: [milestone_label] — [Month Year]"
- Queue badge showing pending count

### Recognition Homepage (Next to Build — After Nav)
Recognition gets a proper landing page at `/recognition` — not just a queue. Design direction:

- **Stat cards:** Members recognized this month, Emails sent, Open rate, Upcoming milestones
- **"What's resonating"** section: which milestone types get the best engagement
- **"Coming up" queue:** next 30 days of projected recognitions
- **Daily digest email** (future): morning summary for staff
- **Left nav badge:** pending count
- **Top nav notification bell** (future): real-time milestone alerts

This is the prompt to write after CLAUDE.md is updated.

### Terminology
- Public-facing: "Recognition" (replaced "Celebration" everywhere in UI)
- Internal code variables: unchanged (no need to rename)

---

## 9. CLAUDE.md UPDATE — PLAN & DECISIONS

### Status
CLAUDE.md is currently at 786 lines, last updated March 4. It is significantly out of sync with current state.

### Approach Agreed
- Do nav prompt first (fast, bounded)
- Then do CLAUDE.md update (comprehensive)
- Write CLAUDE.md with new nav as the current/intended structure (note in-progress if needed)
- Dev team needs to know where we're headed, not just where we are today

### What Needs to Be Added (Full List)
**New sections to add entirely:**
1. Campaign Architect — architecture, how it works, branch types, standing rules
2. Recognition module — first-class module, queue, review flow, Email Governor exemption, homepage direction
3. Email Health Dashboard — what it is, three tabs, what it shows
4. Image Library (upgraded) — metadata, optimization, archive rules, delete/version rules
5. Navigation structure — the new design (canonical reference for dev team)
6. `tenant_config` complete field reference — Parking Lot explicitly calls this out as missing; currently scattered

**Sections needing meaningful updates:**
- Feature inventory — substantially more built than listed
- SmartSends section — Email Governor, Recognition Queue, duplicate detection all missing
- Standing Rules — 5 new ones from March 7 need to be added + new ones from March 8
- Production Port: Module Order — "Celebrations" → "Recognition," Campaign Architect needs its own line
- Known architectural issues — `routes.ts` is now ~9,500 lines, not 7,400
- What's Coming — several items have moved from "coming" to "built"
- Companion documents list — several new prompt files and planning docs exist
- AI Services section — Campaign Architect planner, duplicate detection not mentioned

**Sections that are accurate and need minimal changes:**
- Product vision and philosophy
- 75/12 Rule and market context
- Member tier framework
- Modular architecture and product tiers
- Tech stack
- Database architecture
- Engagement scoring system
- Volume double-counting (Membio Volume Standard)
- Compliance configuration
- Multi-tenant migration plan
- Client pipeline
- Environment variables

---

## 10. PROMPT QUEUE — CURRENT STATUS

### In Progress / Building Now
1. **Campaign Architect Addendum** — Replit building (T001–T006)

### Ready to Send (in order)
2. **Navigation Redesign** — `MemberSync_NavigationRedesign.md` in outputs — send after Addendum verified
3. **Prompt C: AI Duplicate Detection** — `MemberSync_PromptC_AIDuplicateDetection.md` in project files — send after Prompt B verified (if not already done)

### To Be Written This Weekend
4. **Recognition Homepage** — after CLAUDE.md updated
5. **CLAUDE.md update** — comprehensive revision (nav first, then this)

### On Hold (Intentionally)
- A/B Testing standalone — superseded by Campaign Architect
- Automation Priority + Global Contact Limit — waiting for stability
- Member Journey execution engine — post-AEI; architecturally distinct from Campaign Architect

---

## 11. KNOWN ISSUES & TECHNICAL DEBT

### Critical
- `routes.ts` is now ~9,500 lines (was 7,400 when CLAUDE.md was last updated) — most urgent refactoring target
- No multi-tenant data isolation — only `users` table has `client_id`
- 110+ hardcoded "MainStreet" references throughout codebase
- Illinois-specific compliance hardcoded

### Important (AEI / Demo Quality)
- AI Chat UI feels empty and transactional on full Chats page — no suggested starters, no conversation history sidebar
- MAX_CAMPAIGN_RECIPIENTS = 1 — needs bumping for demo sends
- Superfluous "Change" button AND "X" in Campaign Architect audience section
- Date range picker missing from Email Archive UI (backend supports it)
- 172-member gap (dashboard vs. member type builder count)
- Revenue data uses catalog prices not actual invoiced amounts

### Will Be Fixed by Nav Redesign Prompt
- Two items called "Dashboard"
- Drafts as standalone nav item
- SmartSends Dashboard showing duplicate campaign table
- "Automations" label
- "Recognition Queue" as nav label
- "Analytics" label doesn't match content

### Technical Debt (Parking Lot)
- Campaign Architect rate limiter is per-process (needs Redis for multi-instance)
- Missing event warning at activation when anchor event removed
- Drip Sequence Step Editor needs proper EmailComposer
- Templates system needs rework

---

## 12. STRATEGIC DECISIONS (THIS SESSION — MARCH 8)

- **Weekend goal is prototype completeness for dev team handoff, not AEI demo prep.** This reframes feature priority entirely.
- **CLAUDE.md is the most important artifact for the dev team** — more important than any single feature. Must be updated before Monday.
- **Nav first, then CLAUDE.md.** Nav is bounded and fast; CLAUDE.md update is comprehensive but should reflect the completed nav design.
- **Write CLAUDE.md with new nav as current/intended structure** — dev team needs to know where we're headed.
- **Prior attendance branches come from AI planner conversation only** — not from the "+ Add branch email" button.
- **Processor send logic refactored to `sendDripStepEmail`** — after line-by-line verification of identical behavior.

All prior decisions from March 7 summary remain in effect.

---

## 13. STANDING RULES (CANONICAL — UPDATED)

1. `member_metrics_cache` is the single source of truth for member data in the UI. Never compute on the fly what the cache already provides.
2. Every query against external AMS/MLS tables must deduplicate using DISTINCT ON / ROW_NUMBER pattern.
3. Every query against external tables must filter by ApmClientId.
4. Never SUM(ClosePrice) across listing + buyer sides without applying the volume split.
5. All client-specific values go in `clientConfig.ts` (or `tenant_config` table). No hardcoded client references anywhere else.
6. Every feature must work for multiple clients through configuration, not custom code.
7. Real data only. No fake/sample data in preview systems, demo screens, or test flows.
8. No manual schema changes in production. All changes go through versioned database migrations.
9. Cache-first architecture. If a value can be pre-computed daily, it should be.
10. One task at a time. Each PR/commit should be focused and testable.
11. Voluntary contributions (RPAC, REF) are excluded from risk scoring entirely.
12. Non-CE event attendance is a stronger engagement signal than CE attendance.
13. Office suspension is the gatekeeper for MLS/SentriLock access — when an office goes inactive, all agents lose access regardless of individual payment status.
14. Every module must be gated by `tenant_config`. A disabled module should not render in the UI, should not run background jobs, and should not consume AI budget.
15. The 5% rule. Every screen must earn its place.
16. Mobile-first, performance-always. Every UI component must be responsive. Every data view must load in under 2 seconds.
17. **Social proof is never used in Campaign Architect emails.** No attendance numbers, no "members like you," no testimonials. Campaigns can be approved months before they send. (Added March 7)
18. **Minimum 3 emails per event in any Campaign Architect sequence.** Awareness + value reinforcement + urgency for every event. (Added March 7)
19. **Campaign Architect branch points are shallow** — registration status and prior attendance only. Deep conditional logic belongs in Member Journey, not Campaign Architect. (Added March 7)
20. **Recognition is a top-level nav module.** Never nest it inside SmartSends. (Added March 7)
21. **Nav items are destinations. Actions live in buttons.** (Added March 7)
22. **Every email sent through MemberSync must be real and verifiable.** No hallucinated data, no invented member details, no fabricated statistics. (Core principle — formalized March 8)

---

## 14. ALL ARCHITECTURAL DECISIONS (CANONICAL)

From prior sessions — all still in effect:

- Single PostgreSQL database in production (two-database split is Replit-only workaround)
- Cache-first architecture — `member_metrics_cache` pre-computed daily
- Scoring engine is data-driven, not code-driven (weights from config, not if-statements)
- `tenant_config` table is the Stage 0 requirement before any multi-tenant work
- Schema modularization for AI context injection (load only relevant sections per query type)
- Recognition emails are Lane 1 — exempt from Email Governor, no cap
- Campaign names derived as "Recognition: [milestone_label] — [Month Year]"
- Webhook matching: `campaign_id` + `member_key` (existing pattern preserved)
- Branch routing stored in `sendCondition` column as JSON — no new table needed
- `sendDripStepEmail` is the canonical send helper in `triggeredCampaignProcessor.ts`
- Member Journey is architecturally distinct from Campaign Architect — different execution model, different infrastructure, different build timeline
- All URL paths for nav items unchanged — only display labels change in nav redesign
- Compliance module hidden entirely for MLS clients (not just empty)
- AI model selection: Claude Sonnet for complex queries; Claude Haiku for short-form variations

---

## 15. KEY FILES REFERENCE

### In Production (Replit)
- `server/services/aiCampaignPlannerService.ts` — Campaign Architect planner
- `client/src/pages/CampaignArchitect.tsx` — Campaign Architect UI (1,834 lines)
- `server/services/triggeredCampaignProcessor.ts` — Automation execution engine (727 lines)
- `server/routes.ts` — Monolith (~9,500 lines) — most urgent refactoring target
- `shared/schema.ts` — All tables and TypeScript types (1,217 lines)
- `client/src/components/app-sidebar.tsx` — Navigation (being redesigned)
- `server/services/clientConfig.ts` — All client-specific values (must become `tenant_config`)

### Prompt Files — Deployed
- `MemberSync_CampaignArchitect_Prompt1.md` ✅
- `MemberSync_CampaignArchitect_Prompt2.md` ✅
- `MemberSync_CampaignArchitect_Polish_Prompt.md` ✅
- `MemberSync_CampaignArchitect_Hardening.md` ✅
- `MemberSync_CampaignArchitect_PlannerFix.md` ✅ Verified working
- `MemberSync_SchemaModularization_Prompt.md` ✅
- `MemberSync_AIChat_JuliusUpgrade_Prompt.md` ✅
- `MemberSync_QueryEngine_RetryAndCrossDomain.md` ✅
- `MemberSync_PromptA_RecognitionQueue_EmailGovernor.md` ✅ (Parts 1–8)
- `MemberSync_PromptB_EmailHealth_ImageLibrary.md` ✅
- `MemberSync_ImageLibrary_Upgrade_Prompt.md` ✅

### Prompt Files — In Progress / Ready to Send
- `MemberSync_CampaignArchitect_Addendum.md` 🔄 Replit building now (in outputs)
- `MemberSync_NavigationRedesign.md` 📝 Ready to send (in outputs)

### Prompt Files — Written, Not Yet Sent
- `MemberSync_PromptC_AIDuplicateDetection.md` (in project files)

### Planning / Reference Documents
- `CLAUDE.md` — Product bible, 786 lines, last updated March 4. **Major update needed this weekend.**
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog (in project files)
- `MemberSync_Development_Plan.docx`
- `Membio_AI_Workflow_Playbook.docx`
- `MemberSync_CRMLS_Scaling_Roadmap.docx`

---

## 16. PARKING LOT SUMMARY

Full detail in `MemberSync_Parking_Lot.md`. Key items:

**Features to Build (prioritized):**
1. Proactive AI Engagement Engine (Premium tier — daily pattern detection)
2. Lapse Prevention System (Plus tier — calendar-aware risk scoring)
3. AI Chart Rendering (accelerated for CRMLS pilot)
4. Member Journey (post-AEI — architecturally distinct from Campaign Architect)
5. Competitive Intelligence Module
6. Recognition Homepage (next after CLAUDE.md this weekend)
7. Broker Module
8. AI Report Generation
9. Listing Lifecycle Automations
10. Member Preference Center

**Technical Debt (key items):**
- Campaign Architect rate limiter → Redis when multi-instance
- Missing event warning at activation
- Drip Sequence Step Editor needs proper EmailComposer
- Revenue data → actual invoiced amounts (not catalog prices)
- Date range picker in Email Archive UI

**Must Be Configured Per Client (tenant_config — full list in Parking Lot Section 4):**
- Image Library Notifications category — gate on `has_member_portal`
- Compliance module — gate on `org_type === 'association'`
- Engagement scoring weights and tier thresholds
- Illinois-specific compliance rules (HGAR needs NY)
- Office suspension model
- Mainstreet branding in email templates
- Billing calendar
- SmartSends portal-only features
- AI geographic context
- Duplicate detection threshold
- Lapse prevention billing calendar and risk thresholds
- Proactive Engagement Engine insight thresholds
- AI Chat suggested queries and available data sources
- Competitive intelligence territory boundaries
- AI Chart Rendering default chart types
- Automations event override priority

**CLAUDE.md Implication from Parking Lot:** A dedicated `tenant_config` complete field reference section is explicitly called out as missing from CLAUDE.md and must be added in the update.

---

*Session date: March 8, 2026.*
*Next: Verify Campaign Architect Addendum → Send Navigation Redesign → Write CLAUDE.md update → Write Recognition Homepage prompt.*

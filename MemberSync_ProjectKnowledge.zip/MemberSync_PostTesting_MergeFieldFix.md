# MemberSync — Post-Testing Fix: Merge Field Data Flow, Preview Reliability & UX Gaps

## Date: February 27, 2026
## Priority: CRITICAL — Milestone/celebration emails are being sent with raw {{MilestoneLabel}} tags visible to recipients. Multiple other UX gaps found during testing.

---

## REPLIT STANDING RULES

**These rules apply to this prompt and ALL future prompts for this project. Treat them as permanent.**

### Rule 1: No Parallel Systems
Before building any new UI component, service, or utility function, search the existing codebase for similar functionality. If a component already exists that does 70% or more of what's needed, extend or adapt it with configuration flags rather than creating a new version.

### Rule 2: Don't Break What Works
Before modifying any existing file, understand what it currently does. Run the app and verify the feature works before changing it. After your changes, verify the feature still works.

### Rule 3: Shared Components Over Duplicates
If two features need similar UI, they must use the same shared component — not two separate implementations.

### Rule 4: Test Your Work
After implementing changes, verify them yourself. Check both the happy path and at least one edge case.

---

## CRITICAL CONTEXT — READ FIRST

There is a **critical data flow bug** in the email sending pipeline. The `personalizeMergeFields()` function in `server/services/emailService.ts` only replaces 7 merge fields: FirstName, LastName, FullName, OfficeName, MemberKey, Email, and YearsWithMainstreet.

It does NOT replace:
- `{{MilestoneLabel}}` — e.g., "50th Career Transaction"
- `{{MilestoneDetail}}` — e.g., "with $12.5M in career volume, primarily in Downers Grove"
- `{{MilestoneValue}}` — e.g., "50"
- `{{MilestoneEmoji}}` — e.g., "🏆"
- `{{YearsAsMember}}` — anniversary years (different from YearsWithMainstreet in the data)
- `{{ClassName}}`, `{{ClassDate}}`, `{{ClassTime}}`, `{{ClassLocation}}` — event fields
- `{{CECredits}}`, `{{EventName}}`, `{{EventDate}}`, etc.

**This means every celebration/milestone email sent through the system has gone to real members with raw `{{MilestoneLabel}}` text visible in their inbox.** This is the highest priority fix in this prompt.

The celebration milestone data IS available — it's stored in the `celebrationInfo` object that gets passed from the frontend. But `celebrationInfo` is never passed to `queueEmailCampaign()`, and `personalizeMergeFields()` doesn't know how to use it even if it were.

---

## PART 1: FIX MILESTONE/CELEBRATION MERGE FIELD REPLACEMENT (CRITICAL)

### Task 1A: Extend PersonalizationData Interface

**File: `server/services/emailService.ts`**

Expand the `PersonalizationData` interface to include milestone and event fields:

```typescript
interface PersonalizationData {
  firstName?: string;
  lastName?: string;
  fullName?: string;
  officeName?: string;
  memberKey?: string;
  email?: string;
  yearsWithMainstreet?: number;
  // Milestone/celebration fields
  milestoneLabel?: string;
  milestoneDetail?: string;
  milestoneValue?: string;
  milestoneEmoji?: string;
  // Anniversary fields
  yearsAsMember?: string;
  joinDate?: string;
  memberSince?: string;
  // Event fields (for triggered campaigns)
  className?: string;
  classDate?: string;
  classTime?: string;
  classLocation?: string;
  eventName?: string;
  eventDate?: string;
  eventTime?: string;
  eventLocation?: string;
  eventDuration?: string;
  ceCredits?: string;
  // Additional dynamic fields
  extraFields?: Record<string, string>;
}
```

### Task 1B: Extend personalizeMergeFields Replacements

**File: `server/services/emailService.ts`**

Add the new merge field patterns to the `replacements` array in `personalizeMergeFields()`:

```typescript
function personalizeMergeFields(content: string, data: PersonalizationData): string {
  let result = content;
  
  const replacements: [RegExp, string][] = [
    // Existing fields
    [/\{\{(FirstName|firstName|first_name|FIRST_NAME)\}\}/g, data.firstName || ''],
    [/\{\{(LastName|lastName|last_name|LAST_NAME)\}\}/g, data.lastName || ''],
    [/\{\{(FullName|fullName|full_name|FULL_NAME)\}\}/g, data.fullName || ''],
    [/\{\{(OfficeName|officeName|office_name|OFFICE_NAME)\}\}/g, data.officeName || ''],
    [/\{\{(MemberKey|memberKey|member_key|MEMBER_KEY)\}\}/g, data.memberKey || ''],
    [/\{\{(Email|email|EMAIL)\}\}/g, data.email || ''],
    [/\{\{(YearsWithMainstreet|yearsWithMainstreet|years_with_mainstreet)\}\}/g, 
      data.yearsWithMainstreet !== undefined ? data.yearsWithMainstreet.toString() : ''],
    
    // Milestone/celebration fields
    [/\{\{(MilestoneLabel|milestoneLabel)\}\}/g, data.milestoneLabel || ''],
    [/\{\{(MilestoneDetail|milestoneDetail)\}\}/g, data.milestoneDetail || ''],
    [/\{\{(MilestoneValue|milestoneValue)\}\}/g, data.milestoneValue || ''],
    [/\{\{(MilestoneEmoji|milestoneEmoji)\}\}/g, data.milestoneEmoji || ''],
    
    // Anniversary fields
    [/\{\{(YearsAsMember|yearsAsMember)\}\}/g, data.yearsAsMember || data.yearsWithMainstreet?.toString() || ''],
    [/\{\{(JoinDate|joinDate)\}\}/g, data.joinDate || data.memberSince || ''],
    [/\{\{(MemberSince|memberSince)\}\}/g, data.memberSince || data.joinDate || ''],
    
    // Event fields
    [/\{\{(ClassName|className)\}\}/g, data.className || data.eventName || ''],
    [/\{\{(ClassDate|classDate)\}\}/g, data.classDate || data.eventDate || ''],
    [/\{\{(ClassTime|classTime)\}\}/g, data.classTime || data.eventTime || ''],
    [/\{\{(ClassLocation|classLocation)\}\}/g, data.classLocation || data.eventLocation || ''],
    [/\{\{(EventName|eventName)\}\}/g, data.eventName || data.className || ''],
    [/\{\{(EventDate|eventDate)\}\}/g, data.eventDate || data.classDate || ''],
    [/\{\{(EventTime|eventTime)\}\}/g, data.eventTime || data.classTime || ''],
    [/\{\{(EventLocation|eventLocation)\}\}/g, data.eventLocation || data.classLocation || ''],
    [/\{\{(EventDuration|eventDuration)\}\}/g, data.eventDuration || ''],
    [/\{\{(CECredits|ceCredits)\}\}/g, data.ceCredits || ''],
  ];
  
  for (const [pattern, value] of replacements) {
    result = result.replace(pattern, value);
  }
  
  // Apply any extra dynamic fields
  if (data.extraFields) {
    for (const [key, value] of Object.entries(data.extraFields)) {
      const pattern = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      result = result.replace(pattern, value || '');
    }
  }
  
  // Safety: remove any remaining unreplaced merge fields so recipients never see raw tags
  result = result.replace(/\{\{[A-Za-z_]+\}\}/g, '');
  
  return result;
}
```

**IMPORTANT:** The final safety line removes ANY remaining `{{...}}` tags so that even if we miss a field, the recipient never sees raw merge field tags. An empty string is better than `{{MilestoneLabel}}` in someone's inbox.

### Task 1C: Pass Celebration Data Through the Send Pipeline

**File: `server/routes.ts`**

Find the campaign creation endpoint `POST /api/smartsends/campaigns` (around line 4802). Currently `queueEmailCampaign` is called WITHOUT celebration data:

```typescript
// CURRENT (around line 4866):
const result = await queueEmailCampaign({
  name: parsed.name,
  subject: parsed.subject,
  body: parsed.body,
  template: parsed.template,
  recipients: resolvedRecipients!,
  sentBy: req.user!.fullName,
  audienceDescription: parsed.audienceDescription,
});
```

Change to pass celebration info:

```typescript
const result = await queueEmailCampaign({
  name: parsed.name,
  subject: parsed.subject,
  body: parsed.body,
  template: parsed.template,
  recipients: resolvedRecipients!,
  sentBy: req.user!.fullName,
  audienceDescription: parsed.audienceDescription,
  celebrationInfo: parsed.celebrationInfo || undefined,
});
```

### Task 1D: Use Celebration Data During Email Processing

**File: `server/services/emailService.ts`**

Find the `processEmailQueue` function (or wherever individual emails are assembled and sent). This is where `personalizeMergeFields` is called with the personalization data for each recipient. Currently it builds a `PersonalizationData` object with basic member info from `member_metrics_cache`.

After the existing personalization data is built, add milestone data lookup:

```typescript
// AFTER the existing personalizationData is built for a recipient (around line 413-420):
// Look up milestone data if this is a celebration campaign
const celebrationInfo = campaign.celebrationInfo; // This needs to be stored on the campaign
if (celebrationInfo?.milestones) {
  const milestone = celebrationInfo.milestones.find(
    (m: any) => m.memberKey === recipient.memberKey
  );
  if (milestone) {
    personalizationData.milestoneLabel = milestone.milestoneLabel || celebrationInfo.milestoneLabel || '';
    personalizationData.milestoneValue = milestone.milestoneValue || '';
    personalizationData.milestoneEmoji = milestone.milestoneEmoji || '';
    personalizationData.milestoneDetail = buildMilestoneDetail(
      milestone.milestoneType || celebrationInfo.milestoneType,
      milestone.contextJson || {}
    );
  }
}
```

**Add the `buildMilestoneDetail` helper** to emailService.ts:

```typescript
function buildMilestoneDetail(milestoneType: string, contextJson: Record<string, any>): string {
  if (!contextJson || Object.keys(contextJson).length === 0) return '';
  
  switch (milestoneType) {
    case 'transaction_milestone':
    case 'volume_milestone':
      const parts = [];
      if (contextJson.totalVolume) parts.push(`with ${formatVolume(contextJson.totalVolume)} in career volume`);
      if (contextJson.city) parts.push(`primarily in ${contextJson.city}`);
      if (contextJson.recentSides) parts.push(`including ${contextJson.recentSides} recent transactions`);
      return parts.join(', ');
    case 'rookie_star':
      return contextJson.recentSides 
        ? `with ${contextJson.recentSides} transactions in your first year`
        : '';
    case 'first_million':
      return contextJson.avgPrice 
        ? `averaging ${formatVolume(contextJson.avgPrice)} per transaction`
        : '';
    case 'specialization':
    case 'niche_specialist':
      const specParts = [];
      if (contextJson.city) specParts.push(`primarily in ${contextJson.city}`);
      if (contextJson.propertyType) specParts.push(`focusing on ${contextJson.propertyType}`);
      return specParts.join(', ');
    case 'luxury_entry':
      return contextJson.luxuryTransactions 
        ? `with ${contextJson.luxuryTransactions} luxury transaction${contextJson.luxuryTransactions > 1 ? 's' : ''}`
        : '';
    default:
      return '';
  }
}

function formatVolume(value: number): string {
  if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `$${Math.round(value / 1000)}K`;
  return `$${value.toFixed(0)}`;
}
```

### Task 1E: Store celebrationInfo on the Campaign Record

The `celebrationInfo` data needs to survive from the API call through to when `processEmailQueue` processes each recipient. Currently the `emailCampaigns` table doesn't have a `celebrationInfo` column.

**Option A (preferred):** Add a `celebrationInfo` JSONB column to the `emailCampaigns` table:

In `shared/schema.ts`, add to the emailCampaigns table:
```typescript
celebrationInfo: jsonb("celebration_info"),
```

In `routes.ts`, when inserting the campaign record, include:
```typescript
celebrationInfo: parsed.celebrationInfo || null,
```

In `emailService.ts` `processEmailQueue`, read it:
```typescript
const celebrationInfo = campaign.celebrationInfo as any;
```

**Option B (if schema migration is risky):** Store it in the existing `metadata` or pass it through the queue system. But Option A is cleaner.

### Verification for Part 1
- [ ] Create a "Volume Milestones" celebration email → Preview step shows "50th Career Transaction" not "{{MilestoneLabel}}"
- [ ] Send a test celebration email → the recipient's inbox shows the actual milestone name, not raw tags
- [ ] Send a regular (non-celebration) email → still works, no regressions
- [ ] Any merge field that doesn't have data shows as empty string, NEVER as raw {{tags}}

---

## PART 2: FIX AUDIENCE MEMBER PREVIEW ON SEND STEP

### Problem
The audience member preview (showing 15 names from the audience) used to appear on the Send step for all audience sizes. Now it only shows for audiences ≤20 members. For a 210-member audience like "NEW MEMBER JUMPSTART Attendees," or a 2,000-member celebration audience, the staffer sees the count but no names.

### Task 2A: Show First 15 Members for All Audience Sizes

**File: `client/src/pages/SendEmail.tsx`**

Find the audience preview section on the Send step (around line 2655). Currently:

```typescript
{selectedAudience.memberKeys && selectedAudience.memberKeys.length > 0 && selectedAudience.memberKeys.length <= 20 && (
```

Change the condition to show a preview for ALL audiences, but limit to first 15 members:

```typescript
{selectedAudience.memberKeys && selectedAudience.memberKeys.length > 0 && (
```

Then update the display to show the first 15 and indicate there are more:

```typescript
<div className="border-t pt-3 mt-2 mb-3">
  <div className="flex items-center justify-between mb-2">
    <p className="text-sm font-medium flex items-center gap-2">
      <Users className="w-4 h-4" />
      Recipients Preview
    </p>
    <Badge variant="outline" className="text-xs">
      {selectedAudience.memberKeys.length > 15 
        ? `Showing 15 of ${selectedAudience.memberKeys.length.toLocaleString()}`
        : `${selectedAudience.memberKeys.length} ${selectedAudience.memberKeys.length === 1 ? 'recipient' : 'recipients'}`
      }
    </Badge>
  </div>
  {previewMembersLoading ? (
    <div className="flex items-center justify-center py-4 text-sm text-muted-foreground">
      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
      Loading member details...
    </div>
  ) : (
    <div className="max-h-48 overflow-y-auto space-y-1">
      {(previewMembers.length > 0 ? previewMembers.slice(0, 15) : selectedAudience.memberKeys.slice(0, 15)).map((item, idx) => {
        const member = previewMembers.length > 0 ? item as any : null;
        const key = member ? member.memberKey : (item as string);
        const isEmail = typeof key === 'string' && key.includes('@');
        return (
          <div 
            key={key || idx} 
            className="flex items-center justify-between p-2 rounded bg-background border text-sm"
            data-testid={`recipient-preview-${idx}`}
          >
            <div className="flex-1 min-w-0">
              {member ? (
                <>
                  <p className="font-medium truncate">{member.memberName || 'Unknown'}</p>
                  <p className="text-xs text-muted-foreground truncate">{member.email || 'No email'}</p>
                </>
              ) : isEmail ? (
                <>
                  <p className="font-medium truncate">{key.split('@')[0]}</p>
                  <p className="text-xs text-muted-foreground truncate">{key}</p>
                </>
              ) : (
                <p className="text-muted-foreground truncate">Member ID: {key}</p>
              )}
            </div>
          </div>
        );
      })}
      {selectedAudience.memberKeys.length > 15 && (
        <p className="text-xs text-muted-foreground text-center pt-2">
          + {(selectedAudience.memberKeys.length - 15).toLocaleString()} more recipients
        </p>
      )}
    </div>
  )}
</div>
```

### Task 2B: Fetch Preview Members for Larger Audiences

**File: `client/src/pages/SendEmail.tsx`**

Find the `fetchPreviewMembers` useEffect (around line 816). Currently it only fetches member details when `memberKeys.length <= 20`. Update it to always fetch the first 15 member details for preview purposes, regardless of audience size:

```typescript
// Fetch first 15 member details for recipient preview (all audience sizes)
useEffect(() => {
  if (!selectedAudience?.memberKeys || selectedAudience.memberKeys.length === 0) {
    setPreviewMembers([]);
    return;
  }

  // For small audiences where keys are emails, resolve directly
  const firstKeys = selectedAudience.memberKeys.slice(0, 15);
  const allEmail = firstKeys.every(k => k.includes('@'));
  if (allEmail) {
    setPreviewMembers(firstKeys.map(email => ({
      memberKey: email,
      memberName: email.split('@')[0],
      email: email,
    })));
    return;
  }

  const fetchPreviewMembers = async () => {
    setPreviewMembersLoading(true);
    try {
      const response = await fetch('/api/smartsends/audiences/resolve-members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberKeys: firstKeys }),
        credentials: 'include',
      });
      if (response.ok) {
        const members = await response.json();
        setPreviewMembers(members.map((m: any) => ({
          memberKey: m.MemberKey,
          memberName: m.MemberFullName || m.MemberFirstName || 'Unknown',
          email: m.MemberEmail || 'No email',
        })));
      }
    } catch (error) {
      console.error('Error fetching member details for preview:', error);
      // Fallback to showing keys
      setPreviewMembers(firstKeys.map(key => ({
        memberKey: key,
        memberName: key.includes('@') ? key.split('@')[0] : key,
        email: key.includes('@') ? key : '',
      })));
    } finally {
      setPreviewMembersLoading(false);
    }
  };

  fetchPreviewMembers();
}, [selectedAudience?.audienceId, selectedAudience?.memberKeys?.length]);
```

**Note:** If the `/api/smartsends/audiences/resolve-members` endpoint doesn't exist, check for a similar endpoint that resolves member keys to member details. If none exists, create a lightweight one in routes.ts that takes an array of memberKeys (max 15) and returns basic member info from member_metrics_cache.

### Verification for Part 2
- [ ] Audience with 210 members → Send step shows first 15 names + "195 more recipients"
- [ ] Audience with 2,000 members → Send step shows first 15 names + "1,985 more recipients"
- [ ] Audience with 5 members → Send step shows all 5 names
- [ ] Celebration audience → shows member names in preview

---

## PART 3: FIX MULTI-EVENT AUTOMATIONS

### Problem
When two or more events are selected for an event automation, neither event name appears in the email body or subject line. The AI purpose prefill only works for single-event selection.

### Task 3A: Multi-Event AI Purpose

**File: `client/src/pages/CreateAutomation.tsx`**

Update the AI purpose prefill `useEffect` to handle multi-event scenarios. Find the purpose defaults and update:

```typescript
// For multi-event selections, list the event names in the purpose
const selectedEvents = !triggerConfig.allEvents && triggerConfig.selectedEventIds?.length > 0 && upcomingEventsData?.events
  ? triggerConfig.selectedEventIds
      .map((id: string) => upcomingEventsData.events.find((e: UpcomingEvent) => e.eventId === id))
      .filter(Boolean)
  : [];

const purposeDefaults: Record<string, string> = {
  event_registration: selectedEvents.length === 1
    ? `Write a confirmation email for someone who just registered for "${selectedEvents[0].name}" on ${new Date(selectedEvents[0].startDateTime).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`
    : selectedEvents.length > 1
    ? `Write a confirmation email for event registration. This automation covers ${selectedEvents.length} events: ${selectedEvents.map((e: any) => e.name).join(', ')}. Use the {{ClassName}} merge field to reference the specific event name.`
    : 'Write a warm confirmation email thanking the member for registering for an upcoming class or event. Use {{ClassName}} for the event name.',
  // ... similar updates for event_reminder and event_followup
};
```

### Task 3B: Multi-Event Subject Line Default

When multiple events are selected, the subject line should use the merge field `{{ClassName}}` instead of a specific event name. Update the subject line defaults in `handleCreateFromScratch`:

```typescript
const subjectDefaults: Record<string, string> = {
  event_registration: selectedEvent ? `You're registered: ${selectedEvent.name}` : "You're registered for {{ClassName}}!",
  event_reminder: selectedEvent ? `Reminder: ${selectedEvent.name} is coming up` : 'Reminder: {{ClassName}} is coming up!',
  event_followup: selectedEvent ? `Thanks for attending ${selectedEvent.name}` : 'Thanks for attending {{ClassName}}!',
  // ... existing ...
};
```

This already looks correct in the existing code — verify it's working. If the subject line is blank when two events are selected, the issue may be that `handleCreateFromScratch` isn't being called. Debug and fix.

### Task 3C: Multi-Event Email Body Pre-population

When "Create from Scratch" is chosen with multiple events selected, the pre-populated body should use merge fields ({{ClassName}}, {{ClassDate}}, etc.) instead of specific event data. Check the `getPrePopulationContent` function in `emailBlocks.ts` and ensure it handles the case where `selectedEvent` is null but the trigger is still event-based. The pre-populated body should include:

```html
<p>Hi {{FirstName}},</p>
<p>Your upcoming class:</p>
<p><strong>{{ClassName}}</strong><br/>
Date: {{ClassDate}}<br/>
Time: {{ClassTime}}<br/>
Location: {{ClassLocation}}</p>
```

### Verification for Part 3
- [ ] Select 2 events → AI purpose mentions both event names and references {{ClassName}}
- [ ] Select 2 events → "Create from Scratch" pre-populates with {{ClassName}} merge fields
- [ ] Subject line shows "You're registered for {{ClassName}}!" when multiple events selected
- [ ] Preview step shows sample data for {{ClassName}} (from EXAMPLE_MERGE_DATA)

---

## PART 4: FIX SUBJECT LINE PREVIEW

### Problem
The subject line in the Preview step shows raw merge fields (e.g., "Happy {{YearsAsMember}}-Year Anniversary!") instead of sample data.

### Task 4A: Apply replaceMergeFieldsWithSampleData to Subject Line in Preview

**File: `client/src/pages/SendEmail.tsx`**

Find the Preview step rendering. Locate where the subject line is displayed. Apply `replaceMergeFieldsWithSampleData` to it:

```typescript
// Where the subject line appears in the preview:
<p className="font-medium">{replaceMergeFieldsWithSampleData(subjectLine || emailDraft.subject)}</p>
```

Make sure `replaceMergeFieldsWithSampleData` is imported at the top of the file (it should already be).

Do the same in **CreateAutomation.tsx** — find the preview step's subject line display and wrap it.

### Verification for Part 4
- [ ] Anniversary automation preview shows "Happy 10-Year Anniversary!" not "Happy {{YearsAsMember}}-Year Anniversary!"
- [ ] Milestone email preview shows "Sarah, your 50th Career Transaction caught our attention" not "{{FirstName}}, your {{MilestoneLabel}} caught our attention"
- [ ] Event email preview shows actual class name in subject

---

## PART 5: FIX DRIP SEQUENCE — ENABLE NEXT BUTTON

### Problem
The drip sequence builder's Next button stays disabled even after two emails with content are created. This blocks the user from proceeding to Preview.

### Task 5A: Debug Step Validation

**File: `client/src/pages/CreateAutomation.tsx`**

Find the step validation logic for the compose/build-sequence step. Look for the `canProceedFromCompose` or equivalent validation that determines whether the Next button is enabled.

For multi-step automations (drip_sequence and scheduled_series), the validation should check:
1. At least one step exists
2. Each step has a subject line
3. Each step has email body content (not empty or just `<p><br></p>`)

Debug what's currently blocking. Common issues:
- The validation might be checking `emailBody` (the single-email field) instead of `dripSteps[].emailBody`
- The Quill editor might save content as `<p><br></p>` which looks empty but isn't truly empty
- The validation might require content in ALL steps, not just steps that have been edited

Fix the validation so that:
```typescript
// For multi-step automations:
const canProceedFromMultiStep = dripSteps.length > 0 && dripSteps.every(step => 
  step.subjectLine.trim() && 
  step.emailBody && 
  step.emailBody.replace(/<[^>]*>/g, '').trim().length > 5
);
```

### Task 5B: Apply Sample Data in Multi-Step Preview

Find the drip sequence Preview step. For each step's email body, apply `replaceMergeFieldsWithSampleData()` before rendering in the preview iframe. Currently the preview may be showing raw {{FirstName}} etc. in each step.

### Verification for Part 5
- [ ] Create drip sequence → add 2 steps with subject lines and body content → Next button is enabled
- [ ] Drip sequence Preview step shows sample data in each email step
- [ ] Can proceed through full flow: trigger → build sequence → preview → settings → activate

---

## PART 6: FIX AUTOMATION RE-CREATION WITH NEW EVENT

### Problem
If you create an automation for Event A, then go back to create another automation and select Event B, the AI purpose prefill doesn't update and may still show Event A's context.

### Task 6A: Reset State on New Automation

**File: `client/src/pages/CreateAutomation.tsx`**

Ensure that the AI purpose state (`composerAiPurpose`) resets when the trigger configuration changes. Find the purpose prefill `useEffect` and update the dependency to include trigger config changes:

The issue is likely that `composerAiPurpose` was set by a previous automation session and the check `if (composerAiPurpose) return;` prevents it from updating. Add a reset when the trigger config changes materially:

```typescript
// Reset AI purpose when trigger config changes (new event selected, etc.)
useEffect(() => {
  if (isEditMode) return; // Don't reset when editing existing automation
  setComposerAiPurpose(''); // Clear so the purpose prefill effect can recalculate
}, [triggerType, triggerConfig.selectedEventIds?.join(','), triggerConfig.allEvents, isEditMode]);
```

Place this BEFORE the purpose prefill useEffect so the clear happens first, then the prefill recalculates.

### Verification for Part 6
- [ ] Create automation for Event A → go back → change to Event B → compose step shows Event B in purpose
- [ ] Toggle between "All events" and specific event → purpose updates accordingly
- [ ] Editing an existing automation does NOT reset the purpose

---

## PART 7: MOBILE EMAIL PREVIEW RENDERING

### Problem
Email previews don't render properly on mobile — the preview iframe doesn't adapt to smaller screen widths.

### Task 7A: Make Preview Iframe Responsive

**Files: `client/src/pages/SendEmail.tsx` and `client/src/pages/CreateAutomation.tsx`**

Find the preview iframe rendering. Ensure:
1. The iframe has `width="100%"` and responsive styling
2. The email HTML template inside uses `max-width: 600px` with `width: 100%` on the outer table
3. On mobile viewports, the preview container doesn't overflow

Check the `getEmailPreviewHtml()` function in SendEmail. The outer table currently has `width="600"` hardcoded. Change to:

```html
<table style="max-width: 600px; width: 100%;" cellpadding="0" cellspacing="0" ...>
```

Also check the iframe container element and ensure it has responsive styling:
```typescript
<iframe 
  style={{ width: '100%', border: 'none', minHeight: '400px' }}
  // ... existing props
/>
```

Do the same for CreateAutomation's preview rendering.

### Verification for Part 7
- [ ] Email preview renders correctly on mobile-width screens (375px viewport)
- [ ] Preview doesn't overflow or require horizontal scrolling
- [ ] Preview shows the complete email including footer

---

## FILES CHANGED

**Modified:**
- `server/services/emailService.ts` — Extended PersonalizationData, added milestone/event/anniversary merge fields, added buildMilestoneDetail helper, added safety cleanup for unreplaced fields
- `server/routes.ts` — Pass celebrationInfo through to queueEmailCampaign
- `shared/schema.ts` — Add celebrationInfo column to emailCampaigns (if Option A)
- `client/src/pages/SendEmail.tsx` — Audience preview for all sizes (15 members), subject line preview with sample data, responsive preview iframe
- `client/src/pages/CreateAutomation.tsx` — Multi-event AI purpose, automation state reset, drip Next button fix, responsive preview, subject line preview with sample data
- `client/src/lib/emailBlocks.ts` — Multi-event pre-population content with merge fields

**NOT modified:**
- `server/services/aiEmailService.ts` — No changes
- `server/services/systemTemplates.ts` — Already cleaned up in previous prompt
- Any other files not listed above

---

## VERIFICATION CHECKLIST — FULL REGRESSION

### Critical: Milestone Data Flow
- [ ] Celebration email: Volume Milestones → compose → Preview shows "50th Career Transaction" in subject and body
- [ ] Celebration email: send test → recipient inbox shows real milestone label, NOT {{MilestoneLabel}}
- [ ] Regular (non-celebration) email → send works, no regressions
- [ ] Any unreplaced merge field → shows as empty string, NEVER as raw {{tags}}

### Audience Preview
- [ ] 210-member audience → Send step shows 15 names + count
- [ ] 2,000-member audience → Send step shows 15 names + count  
- [ ] 5-member audience → Send step shows all 5 names

### Multi-Event Automations
- [ ] 2 events selected → AI purpose references both + {{ClassName}}
- [ ] Subject line uses {{ClassName}} for multi-event
- [ ] Scratch pre-populates with merge fields

### Subject Line Preview
- [ ] Anniversary: "Happy 10-Year Anniversary!" shown
- [ ] Milestone: "Sarah, your 50th Career Transaction caught our attention" shown
- [ ] Event: actual class name shown via sample data

### Drip Sequence
- [ ] 2 steps with content → Next button enabled
- [ ] Preview shows sample data in each step

### Automation State
- [ ] Change event selection → purpose updates
- [ ] Edit existing automation → purpose preserved

### Mobile Preview
- [ ] Email preview readable on mobile viewport
- [ ] No horizontal scrolling in preview

### Existing Flows (No Regressions)
- [ ] Send Email: full AI flow works end to end
- [ ] Send Email: "Create from Scratch" works
- [ ] Compliance email flow: audience loads, can compose, can send
- [ ] Campaigns page: existing campaigns display correctly
- [ ] Drafts: existing drafts load correctly

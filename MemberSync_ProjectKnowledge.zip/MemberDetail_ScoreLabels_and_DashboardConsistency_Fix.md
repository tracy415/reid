# Member Detail Score Breakdown Fix + Dashboard Tier Card Consistency

## Problem 1: Member Detail Score Labels Are Wrong

The member detail page (`MemberDetail.tsx`) shows an engagement score breakdown with outdated labels and weights:

- "Transactions" â€” 4 points (should be 0-2 depending on tier)
- "Education/Events" â€” 2 points (should be 0-3 or 0-4 depending on tier)
- "Payment" â€” 3 points (should be 0-1, binary)
- "Recency Bonus" â€” 1 point (fine, but label should clarify non-transaction activity)

The tooltip also shows old tier names ("Active Producer", "Occasional Producer", "License Maintainer").

Additionally, the `EngagementScore` interface in `shared/schema.ts` uses misleading field names (`license` for recency bonus) and the backend functions `calculateTransactionScore()` and the payment calculation in `getMemberDetail()` use old weights.

## FIX 1A: Update `EngagementScore` Interface

In `shared/schema.ts`, replace:

```typescript
export interface EngagementScore {
  total: number;
  transactionActivity: number;
  educationEvents: number;
  payment: number;
  license: number;
  professionalInvestment?: number;
}
```

With:

```typescript
export interface EngagementScore {
  total: number;
  transactions: number;      // was transactionActivity
  educationEvents: number;   // education + event participation
  email: number;             // NEW â€” email open/click engagement
  payment: number;           // binary (0 or 1)
  recency: number;           // was license â€” non-transaction activity in 90 days
  designation: number;       // NEW â€” professional designations
}
```

## FIX 1B: Update `calculateTransactionScore()` in `server/storage.ts`

This function is used in `getMemberDetail()` to compute the breakdown shown on the member detail page. Replace it with a tier-aware version:

```typescript
function calculateTransactionScore(tx12mo: number, tier: string): number {
  if (tier === 'active_producer') {
    // Rainmaker: 40+ sides is baseline, 60+ gets 1, 80+ gets 2
    if (tx12mo >= 80) return 2;
    if (tx12mo >= 60) return 1;
    return 0;
  } else if (tier === 'occasional_producer') {
    // Builder: 6-39 sides, within-tier differentiation
    if (tx12mo >= 20) return 2;
    if (tx12mo >= 12) return 1;
    return 0;
  }
  // Foundation: transactions aren't part of their score
  return 0;
}
```

## FIX 1C: Update `getMemberDetail()` Engagement Score Object

In `server/storage.ts`, in the `getMemberDetail()` function (around line 1065), replace the engagement score construction:

```typescript
engagementScore: {
  total: score,
  transactionActivity: calculateTransactionScore(row.transactions_12mo, row.transactions_24mo),
  educationEvents: 0,
  payment: row.has_overdue_invoice ? 0 : 3,
  license: 0,
},
```

With:

```typescript
engagementScore: {
  total: score,
  transactions: calculateTransactionScore(row.transactions_12mo, tier),
  educationEvents: 0,  // Enriched in routes from activity_cache
  email: 0,            // Enriched in routes from email_events
  payment: row.has_overdue_invoice ? 0 : 1,  // Binary: 0 or 1
  recency: 0,          // Enriched in routes from activity data
  designation: (designations && designations.length > 0) ? 1 : 0,
},
```

Also update the `calculateTransactionScore` call to pass `tier` instead of `transactions_24mo`:

```typescript
transactions: calculateTransactionScore(row.transactions_12mo, tier),
```

## FIX 1D: Update Routes Score Enrichment

In `server/routes.ts`, the member detail route (around line 543-584) enriches the score breakdown. Update it to also compute email engagement and use the new field names:

Replace the existing enrichment block:

```typescript
// Enrich engagement score with activity data
const activity = await storage.getMemberActivity(memberKey);
const now = new Date();
const ninetyDaysAgo = new Date(now);
ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
const oneYearAgo = new Date(now);
oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

// Count activities in last 12 months
const recentActivities = activity.filter(a => {
  const activityDate = new Date(a.date);
  return activityDate >= oneYearAgo && (a.type === 'education' || a.type === 'event');
});

// Education/Events score â€” tier-aware
let educationScore = 0;
const tier = member.tier;
const eduEventCount = recentActivities.length;

if (tier === 'active_producer') {
  // Rainmaker: 0-3 points
  if (eduEventCount >= 3) educationScore = 3;
  else if (eduEventCount >= 2) educationScore = 2;
  else if (eduEventCount >= 1) educationScore = 1;
} else if (tier === 'occasional_producer') {
  // Builder: 0-3 points
  if (eduEventCount >= 4) educationScore = 3;
  else if (eduEventCount >= 2) educationScore = 2;
  else if (eduEventCount >= 1) educationScore = 1;
} else {
  // Foundation: 0-4 points
  if (eduEventCount >= 4) educationScore = 4;
  else if (eduEventCount >= 2) educationScore = 3;
  else if (eduEventCount >= 1) educationScore = 2;
}

// Email engagement score
let emailScore = 0;
try {
  const emailResult = await db.execute(sql`
    SELECT 
      BOOL_OR(event_type = 'clicked') as has_clicked,
      BOOL_OR(event_type = 'opened') as has_opened
    FROM email_events
    WHERE member_key = ${memberKey}
      AND event_timestamp >= NOW() - INTERVAL '90 days'
  `);
  const emailData = emailResult.rows[0] as any;
  if (emailData?.has_clicked) {
    emailScore = (tier === 'license_maintainer') ? 3 : 2;
  } else if (emailData?.has_opened) {
    emailScore = (tier === 'license_maintainer') ? 2 : 1;
  }
} catch {
  // Email data may not exist yet
}

// Recency bonus (0-1 point) - NON-TRANSACTION activity within last 90 days
let recencyBonus = 0;
const hasRecentNonTxActivity = activity.some(a => {
  const activityDate = new Date(a.date);
  return activityDate >= ninetyDaysAgo && (a.type === 'education' || a.type === 'event');
});
if (hasRecentNonTxActivity) {
  recencyBonus = 1;
}

// Update the engagement score breakdown for display
member.engagementScore.educationEvents = educationScore;
member.engagementScore.email = emailScore;
member.engagementScore.recency = recencyBonus;

// Recalculate total from all breakdown components
member.engagementScore.total = 
  member.engagementScore.transactions +
  member.engagementScore.educationEvents +
  member.engagementScore.email +
  member.engagementScore.payment +
  member.engagementScore.recency +
  member.engagementScore.designation;
```

Note: You'll need to add `import { db } from "./db";` and `import { sql } from "drizzle-orm";` at the top of routes.ts if they aren't already imported (they likely are).

## FIX 1E: Update `MemberDetail.tsx` Score Breakdown Display

Replace the score breakdown section (around lines 370-450) in `client/src/pages/MemberDetail.tsx`:

```tsx
<Card data-testid="card-engagement-score">
  <CardHeader>
    <CardTitle className="text-base flex items-center gap-2">
      Engagement Score
      <Tooltip>
        <TooltipTrigger asChild>
          <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" data-testid="button-engagement-score-help" />
        </TooltipTrigger>
        <TooltipContent side="right" className="max-w-xs p-4">
          <div className="space-y-3">
            <p className="text-sm">
              Scores measure how connected a member is to your organization beyond just production activity. Weights vary by tier to reflect what engagement looks like for each group.
            </p>
            <Separator />
            <div className="space-y-1 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>8-10</span>
                <span className="text-emerald-600">Highly Connected</span>
              </div>
              <div className="flex justify-between">
                <span>5-7</span>
                <span className="text-blue-600">Connected</span>
              </div>
              <div className="flex justify-between">
                <span>3-4</span>
                <span className="text-orange-600">Drifting</span>
              </div>
              <div className="flex justify-between">
                <span>0-2</span>
                <span className="text-red-600">Disconnected</span>
              </div>
            </div>
          </div>
        </TooltipContent>
      </Tooltip>
    </CardTitle>
  </CardHeader>
  <CardContent className="space-y-4">
    <div className="text-center">
      <span className="text-4xl font-bold" data-testid="text-engagement-score-total">
        {member.engagementScore.total.toFixed(1)}
      </span>
      <span className="text-muted-foreground text-lg">/10</span>
    </div>
    <Separator />
    <div className="space-y-3">
      <ScoreBreakdownRow
        label="Education & Events"
        value={member.engagementScore.educationEvents}
      />
      <ScoreBreakdownRow
        label="Email Engagement"
        value={member.engagementScore.email}
      />
      <ScoreBreakdownRow
        label="Transactions"
        value={member.engagementScore.transactions}
      />
      <ScoreBreakdownRow
        label="Payment"
        value={member.engagementScore.payment}
      />
      <ScoreBreakdownRow
        label="Recent Activity"
        value={member.engagementScore.recency}
      />
      <ScoreBreakdownRow
        label="Designations"
        value={member.engagementScore.designation}
      />
    </div>
  </CardContent>
</Card>
```

Note the ordering: Education & Events first (the biggest differentiator), then Email, then Transactions. This puts the engagement signals the user can influence at the top, and the baseline signals at the bottom. It subtly reinforces the message: "these are the levers you can pull."

## FIX 1F: Update Any Other References to Old Field Names

Search for `transactionActivity` and `license` (as a score field) across the codebase and replace:
- `engagementScore.transactionActivity` â†’ `engagementScore.transactions`
- `engagementScore.license` â†’ `engagementScore.recency`

Also add `email` and `designation` fields anywhere the EngagementScore object is constructed with defaults (search for `educationEvents: 0` to find these).

---

## Problem 2: Dashboard Tier Cards Should All Show Same Stats

Currently the three tier spotlight cards in the Membership Story section show different structures: Rainmaker shows volume and concentration, Builder shows education/events percentage, Foundation shows connection signals. This is inconsistent and makes comparison harder.

**All three cards should show the same set of information:**
1. Connected % (headline â€” already consistent)
2. Volume and market control (currently only on Rainmaker)
3. Four engagement signal indicators: Edu, Events, Email, Paid (currently only on Foundation)
4. Tier definition (already consistent)

The concentration insight ("Top X agents control Y% of volume") should show for ALL tiers, not just Rainmaker. For Builder, it might say "$2.1B volume Â· 21% of total." For Foundation, "$45M volume Â· 0.2% of total." This reinforces the story: Rainmakers produce the volume, but Foundation pays the dues.

## FIX 2A: Update Backend to Return Volume/Share for All Tiers

In the `membership-story` endpoint in `server/routes.ts`, the tier query already computes `total_volume` per tier. Add a total volume sum so we can compute each tier's share. Update the tier query:

The query already has `COALESCE(SUM(CAST(total_volume_12mo AS NUMERIC)), 0) as total_volume` per tier. After computing `tierMap`, calculate the total volume across all tiers:

```typescript
const allTiersVolume = (rainmaker.totalVolume || 0) + (builder.totalVolume || 0) + (foundation.totalVolume || 0);
```

Then include volume and share in each tier's response:

```typescript
rainmakerInsights: {
  ...existingFields,
  totalVolume: rainmaker.totalVolume,
  volumeSharePct: allTiersVolume > 0 ? Math.round((rainmaker.totalVolume / allTiersVolume) * 100) : 0,
},
builderInsights: {
  ...existingFields,
  totalVolume: builder.totalVolume,
  volumeSharePct: allTiersVolume > 0 ? Math.round((builder.totalVolume / allTiersVolume) * 100) : 0,
},
foundationInsights: {
  ...existingFields,
  totalVolume: foundation.totalVolume,
  volumeSharePct: allTiersVolume > 0 ? Math.round((foundation.totalVolume / allTiersVolume) * 100) : 0,
},
```

## FIX 2B: Update Dashboard Tier Card Component

In `MembershipStory.tsx`, make all three tier cards use the SAME structure. Each card shows:

```tsx
{/* Same structure for ALL THREE tier cards */}
<div className="border rounded-lg p-4 space-y-3">
  {/* Header: tier name + color + count */}
  <div className="flex items-center gap-2">
    <span className={`w-3 h-3 rounded-full ${tierColor}`} />
    <span className="text-sm font-semibold">{tierName}</span>
    <span className="text-xs text-muted-foreground ml-auto">{count.toLocaleString()}</span>
  </div>
  
  {/* Tier definition */}
  <p className="text-[11px] text-muted-foreground">{tierDefinition}</p>
  
  {/* Headline: Connected % */}
  <div>
    <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{connectedPercentage}%</p>
    <p className="text-xs text-muted-foreground">connected to your organization</p>
  </div>
  
  {/* Volume and market share */}
  <div className={`${tierBgColor} rounded-md p-2`}>
    <p className={`text-xs font-medium ${tierTextColor}`}>
      {formatCurrency(totalVolume)} volume Â· {volumeSharePct}% of total production
    </p>
  </div>
  
  {/* Four engagement signals â€” same for all tiers */}
  <div className="grid grid-cols-4 gap-1 text-center">
    <SignalMini icon={GraduationCap} value={withEducation} total={count} color="text-blue-500" />
    <SignalMini icon={CalendarCheck} value={withEvents} total={count} color="text-purple-500" />
    <SignalMini icon={Mail} value={withEmailEngagement} total={count} color="text-amber-500" />
    <SignalMini icon={CreditCard} value={paidOnTime} total={count} color="text-emerald-500" />
  </div>
  <div className="flex justify-between text-[10px] text-muted-foreground px-1">
    <span>Edu</span>
    <span>Events</span>
    <span>Email</span>
    <span>Paid</span>
  </div>
</div>
```

The only thing that varies between cards is the tier color, name, definition text, and the highlight box color scheme:
- **Rainmaker**: amber background, amber text. Highlight says volume + share + concentration detail
- **Builder**: blue background, blue text. Highlight says volume + share
- **Foundation**: emerald background, emerald text. Highlight says volume + share (the small number makes the point)

The concentration detail ("Top 914 agents (5%) control 49% of volume") stays ONLY on the Rainmaker card as an additional line in the highlight box, since that stat is computed from the top-5% query and is specific to overall market concentration. The other two cards just show their tier's total volume and share of production.

## FIX 2C: Update TypeScript Interfaces

Add `totalVolume` and `volumeSharePct` to `builderInsights` and `foundationInsights` in the `MembershipStoryData` interface:

```typescript
builderInsights: {
  // ...existing fields
  totalVolume: number;
  volumeSharePct: number;
};
foundationInsights: {
  // ...existing fields  
  totalVolume: number;
  volumeSharePct: number;
};
```

(`rainmakerInsights` already has `totalVolume`; add `volumeSharePct` to it as well.)

---

## Files Modified

| File | Changes |
|------|---------|
| `shared/schema.ts` | Update `EngagementScore` interface â€” new field names, add email + designation |
| `server/storage.ts` | Update `calculateTransactionScore()` to be tier-aware, update `getMemberDetail()` score construction |
| `server/routes.ts` | Update member detail enrichment with tier-aware education scoring, add email scoring, use new field names. Update membership-story endpoint to return volume/share for all tiers. |
| `client/src/pages/MemberDetail.tsx` | Update score breakdown labels, tooltip content, field references |
| `client/src/components/dashboard/MembershipStory.tsx` | Make all three tier cards identical structure with volume + signals |

## Testing Checklist

1. **Member detail page**: Score breakdown shows Education & Events, Email Engagement, Transactions, Payment, Recent Activity, Designations â€” in that order
2. **Member detail tooltip**: Shows engagement labels (Highly Connected 8-10, Connected 5-7, Drifting 3-4, Disconnected 0-2) â€” NOT old tier names
3. **Member with 40 sides, no education, no email**: Should show Transactions: 0, Education: 0, Email: 0, Payment: 1, Total: ~1-2
4. **Dashboard Membership Story**: All three tier cards show connected %, volume + share, and four signal indicators
5. **Foundation volume insight**: Should show a small dollar amount with a low share percentage (reinforces the 75% story â€” they produce little but pay the most dues)
6. **No console errors** from changed field names

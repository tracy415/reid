# MemberSync — Post-Navigation Cleanup
*Written: March 8, 2026*
*Status: READY TO SEND TO REPLIT*

---

## WHAT THIS PROMPT DOES

Surgical cleanup of dead code and stale references left behind by the navigation redesign. Three targeted fixes — no new features, no architectural changes.

**Files touched:**
- `client/src/components/layout/AppSidebar.tsx` — remove one unused import
- `client/src/pages/SmartSends.tsx` — remove stale nav links pointing to retired routes
- `client/src/App.tsx` — confirm orphaned routes are already removed (verify only)

**Do not touch:** Any other file. This is a cleanup pass only.

---

## FIX 1 — Remove Unused `Shield` Import from AppSidebar.tsx

`Shield` is imported from lucide-react on line 29 but is never used anywhere in the component. Remove it from the import block.

**In `client/src/components/layout/AppSidebar.tsx`:**

Remove `Shield,` from the lucide-react import block.

The corrected import block should contain these icons (verify the list is complete and nothing else is removed):
`LayoutDashboard, Users, ClipboardCheck, MessageSquare, Mail, ChevronRight, Image, BarChart3, Target, Sparkles, Upload, FolderOpen, TrendingUp, Building2, UserCheck, FileDown, ListChecks, Receipt, Award, PlusCircle, FileBarChart, Settings, FileText, Puzzle, Heart, Send as SendIcon`

**Acceptance:** File compiles without error. No visual change.

---

## FIX 2 — Remove Stale Nav Links from SmartSends.tsx

`SmartSends.tsx` still contains links and navigations pointing to routes that were retired or renamed in the navigation redesign. These will cause 404s if clicked.

**In `client/src/pages/SmartSends.tsx`, find and fix the following:**

### 2a — Quick Action buttons (around lines 1215–1275)
There is a section with quick action links/buttons. Remove or update these stale references:

- `<Link href="/smartsends/recognition-queue">` — **remove both occurrences** (there are two: one mobile, one desktop). Recognition Queue is now under `/recognition` — this link is no longer appropriate here.
- `<Link href="/smartsends/drafts">` — **remove this link**. Drafts is retired as a standalone page.
- `navigate('/smartsends/automations')` — **update to `navigate('/smartsends/create')`**. The Automations entry point is now through the Create page.

The remaining quick action links are fine and should stay:
- `<Link href="/smartsends/audiences">` — keep
- `<Link href="/smartsends/images">` — keep  
- `<Link href="/smartsends/send">` — keep

### 2b — Campaign list navigation (around line 1647)
```
onView={(item) => navigate(`/smartsends/campaigns/${item.id}`)}
```
This route no longer exists as a standalone page. Update to:
```
onView={(item) => navigate(`/smartsends/reporting`)}
```
(Until a proper campaign detail route exists under Reporting & Analytics, this is the correct fallback.)

### 2c — Tab navigation (around line 662–670)
There are two tab buttons at the top of SmartSends: "Dashboard" and "Email Controls". The Email Controls tab navigates to `?view=email-controls`. 

**Leave these as-is for now.** SmartSends.tsx is still the active page at `/smartsends` and its Email Controls tab content will migrate to `SmartSendsSettings.tsx` in a future prompt. Do not remove this tab yet.

**Acceptance:** No broken links in SmartSends. Quick actions all navigate to valid routes. No visual regressions.

---

## FIX 3 — Verify Orphaned Routes Are Removed from App.tsx

Check `client/src/App.tsx` and confirm the following routes are no longer present. If any are still there, remove them:

- `/smartsends/drafts`
- `/smartsends/campaigns` (the old Campaigns list page — not campaign detail)
- `/smartsends/recognition-queue`

If these routes have already been removed by the navigation prompt, no action needed — just confirm.

**Acceptance:** None of the three routes above exist in App.tsx.

---

## VERIFICATION

After all three fixes:

1. App compiles without TypeScript errors
2. Click every SmartSends quick action button — each navigates to a valid page
3. Navigate to `/smartsends` — Dashboard and Email Controls tabs both work
4. No console errors about missing routes
5. AppSidebar renders correctly — all nav items present and working

---

## NOTE ON SmartSends.tsx LIFESPAN

`SmartSends.tsx` is not fully retired by this prompt — it remains the active page at `/smartsends`. It will be superseded by `SmartSendsHome.tsx` in a future prompt. At that point, the remaining legacy content in `SmartSends.tsx` (the send email dialog, campaign list, etc.) will either migrate to dedicated pages or be removed. Do not delete `SmartSends.tsx` in this prompt.

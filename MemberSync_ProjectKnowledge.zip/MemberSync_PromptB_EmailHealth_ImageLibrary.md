# MemberSync — Prompt B: Email Health Dashboard + HTML Storage + Image Library Upgrade

## Date: March 2026
## Priority: Send after Parts 5–8 are verified

---

## STANDING RULES REMINDER

Before touching any file: search for existing components first. No parallel systems. Don't break what works. Server-side for anything touching more than 1,000 records. Full-page patterns, not modals, for multi-step tasks.

---

## OVERVIEW

This prompt covers three related things that share the same infrastructure foundation:

1. **Object storage for sent email HTML** — every sent email gets its full rendered HTML saved to object storage going forward. This powers the Email Archive.
2. **Image library upgrade** — images become first-class objects with required metadata, server-side optimization, and usage tracking.
3. **Email Health Dashboard** — a three-tab section within SmartSends Email Controls: Performance, Send Queue, and Email Archive.

These three things are one prompt because they share the same architectural moment: we are establishing object storage as the foundation for both email content and image assets. Do them together so the infrastructure is laid down once, correctly.

---

## PART 1 — OBJECT STORAGE FOR SENT EMAIL HTML

### What to build

When an email campaign is sent (status transitions to 'sent'), capture the final rendered HTML and store it in object storage. Save a reference URL back to the campaign record.

### Database change

```sql
ALTER TABLE email_campaigns ADD COLUMN rendered_html_url TEXT;
ALTER TABLE email_campaigns ADD COLUMN rendered_html_stored_at TIMESTAMPTZ;
```

Add these columns to the Drizzle schema in `schema.ts`.

### Storage pattern

Use the existing object storage infrastructure (`server/replit_integrations/` — `objectStorage.ts` and `objectAcl.ts`). Store each email's HTML at a path like:

```
emails/rendered/{campaign_id}.html
```

Set the ACL to private — these are internal records, not public URLs. Access is always through the application, never direct.

### When to store

In `emailService.ts`, in the function that finalizes a campaign send (where status is set to 'sent'), add a call to store the rendered HTML immediately after the send is confirmed. Do not block the send on storage — if storage fails, log the error and continue. The send succeeding is more important than the archive record.

The rendered HTML to store is the full email body as sent — with all merge fields already resolved to real member data, not template tags. If the campaign sends to multiple members with personalized content, store the template version (with merge fields intact) — not one copy per recipient.

### What NOT to store

- Do not store HTML for automated/triggered campaign copies (the per-member rows). Store only the parent campaign template.
- Do not store HTML for draft campaigns. Only store on confirmed send.
- Do not backfill historical campaigns. Archive starts from the day this prompt is deployed.

---

## PART 2 — IMAGE LIBRARY UPGRADE

### Current state

The existing image library (`imageService.ts`, `SmartSendsImages.tsx`) stores files in object storage and returns a URL. There is no metadata, no categorization, no usage tracking, and no size optimization. Staff can upload an image and insert it into an email — that's the full feature set.

### What to build

#### 2A — New database table

```sql
CREATE TABLE email_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('event_banner', 'headshot', 'logo', 'illustration', 'other')),
  storage_url TEXT NOT NULL,
  thumbnail_url TEXT NOT NULL,
  original_filename TEXT NOT NULL,
  file_size_bytes INTEGER NOT NULL,
  width_px INTEGER,
  height_px INTEGER,
  uploaded_by UUID REFERENCES users(id),
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  use_count INTEGER NOT NULL DEFAULT 0,
  last_used_at TIMESTAMPTZ
);
```

Add to Drizzle schema in `schema.ts`.

#### 2B — Server-side image optimization on upload

When an image is uploaded, before storing it, the server must:

1. **Validate** the file:
   - Accepted formats: JPG, PNG, WebP, GIF only. Reject SVG.
   - Max file size: 2MB. Return a clear error if exceeded.

2. **Optimize** the image using the `sharp` library (install if not present: `npm install sharp`):
   - Resize to max 1200px wide, maintaining aspect ratio. Do not upscale images smaller than 1200px.
   - Compress: JPG/WebP at quality 85, PNG with compression level 8.
   - Convert GIFs to their first frame as a static JPG (email clients handle animated GIFs inconsistently — static is safer).
   - Store the optimized version as the primary `storage_url`.

3. **Generate a thumbnail**:
   - Resize to 300px wide, same format as the optimized version.
   - Store as `thumbnail_url` at path `images/thumbnails/{id}.jpg`.

4. **Capture dimensions** (width_px, height_px) of the optimized version and store in the record.

Store the optimized image at: `images/full/{id}.{ext}`
Store the thumbnail at: `images/thumbnails/{id}.jpg`

#### 2C — Required metadata at upload

Staff cannot complete an upload without providing:
- **Name** (text, required) — a human-readable label, e.g. "Spring Conference Banner 2026"
- **Category** (required, one of five options):
  - Event Banner — wide promotional images for events and conferences
  - Headshot — member or staff photos
  - Logo — association, partner, or brokerage logos
  - Illustration — decorative graphics, icons, visual elements
  - Other — anything that doesn't fit above

The upload API endpoint must reject requests missing name or category with a 400 error and a clear message.

#### 2D — Usage tracking

When an image URL is inserted into a sent campaign, increment its `use_count` and update `last_used_at`.

The cleanest way to implement this: in `emailService.ts`, after a campaign send is confirmed, scan the rendered HTML for any image URLs that match the `images/full/` path pattern. For each match, find the corresponding `email_images` record and increment `use_count`.

This does not need to be real-time. It can run as part of the post-send cleanup, after the send is confirmed.

#### 2E — Updated upload API

Replace or update the existing image upload endpoint to:

```
POST /api/images/upload
  Body: multipart/form-data
    - file (required)
    - name (required, string)
    - category (required, one of the five values)
  
  Response: {
    id, name, category, storageUrl, thumbnailUrl,
    widthPx, heightPx, fileSizeBytes, uploadedAt
  }
```

```
GET /api/images
  Query params:
    - category (optional filter)
    - search (optional name search)
  
  Response: array of image records, ordered by uploadedAt DESC
```

```
DELETE /api/images/:id
  Only if use_count === 0. Return 409 if image is in use.
```

#### 2F — Updated image library UI (SmartSendsImages.tsx)

Replace the current UI with:

**Upload area** (top of page):
- Drag-and-drop zone or click to browse
- Required fields shown immediately when a file is selected (before upload):
  - Name field (text input, required)
  - Category dropdown (required, five options with brief descriptions)
- "Upload Image" button — disabled until both fields are filled
- Clear error messages for: wrong file type, file too large, missing fields
- Show a progress indicator during upload
- Show the optimized file size after upload ("Optimized from 1.4MB to 187KB")

**Image grid** (below upload area):
- Thumbnail grid, 4 columns on desktop, 2 on mobile
- Each card shows: thumbnail, name, category badge, dimensions, use count ("Used in 3 campaigns" or "Never used")
- Category filter tabs above the grid: All | Event Banner | Headshot | Logo | Illustration | Other
- Search input to filter by name

**Insert behavior** (when inserting into email composer):
- When staff clicks an image to insert it into an email, show a size picker:
  ```
  Insert image at:
  ○ Small   (300px wide)
  ○ Medium  (600px wide — recommended)  ← default
  ○ Full Width (100%)
  [Insert]
  ```
- The inserted HTML uses the `storage_url` with an explicit `width` attribute set to the chosen size. Never insert a raw unresized URL.
- Example output for Medium: `<img src="{storage_url}" width="600" style="max-width:100%;height:auto;" alt="{name}">`

**Delete behavior**:
- Show a delete icon on hover for each image card
- If use_count > 0, show a tooltip: "This image has been used in {n} campaign(s) and cannot be deleted"
- If use_count === 0, confirm before deleting: "Delete '{name}'? This cannot be undone."

---

## PART 3 — EMAIL HEALTH DASHBOARD

### Where it lives

This is a tab within the SmartSends Email Controls section — the same section where the Email Governor (built in Parts 5–8) lives. Add three tabs to that section:

- **Performance** (new — this prompt)
- **Send Queue** (already built — move it here from wherever it currently lives)
- **Email Archive** (new — this prompt)

### Tab 1 — Performance

Display email health metrics for the last 90 days, filterable by email category.

**Metrics to show (four cards at top):**

| Metric | Source | Warning threshold |
|--------|--------|-------------------|
| Unsubscribe Rate | unsubscribes / delivered | > 0.3% shows amber warning |
| Deliverability Rate | delivered / sent | < 95% shows amber warning |
| Open Rate | opened / delivered | informational only |
| Click Rate | clicked / opened | informational only |

**Category filter** (tabs or dropdown): All | Recognition | Engagement | Compliance | Transactional

**90-day trend chart** for each metric using Recharts (LineChart). X-axis = date (weekly buckets), Y-axis = percentage. Use existing Recharts import patterns from the codebase.

**Data source**: `email_campaigns` joined to `email_recipients`. Group by week and category. The `email_category` column (added in Prompt A) drives the category filter.

**Warning banner**: If unsubscribe rate exceeds 0.3% for any category in the last 30 days, show a prominent amber warning card at the top:
```
⚠ Unsubscribe rate for Engagement emails is 0.4% this month — above the 0.3% threshold.
  Consider reviewing recent engagement campaign content and frequency.
```

**API endpoint**:
```
GET /api/email-health/metrics
  Query params: category (optional), days (default 90)
  Response: { metrics: { unsubscribeRate, deliverabilityRate, openRate, clickRate },
              trend: [{ week, unsubscribeRate, deliverabilityRate, openRate, clickRate }],
              warnings: [{ category, metric, value, threshold }] }
```

### Tab 2 — Send Queue

This tab already exists in some form from Prompt A (the queue control panel). Move it here — do not duplicate it. The queue count badge on the SmartSends dashboard still works; this tab is the detail view.

### Tab 3 — Email Archive

A searchable, filterable history of all sent campaigns — starting from when this prompt is deployed (historical campaigns without stored HTML are shown as records but without preview).

**Table columns**: Campaign Name | Category | Sent Date | Audience Size | Open Rate | Click Rate | Preview

**Filters** (above table):
- Date range picker (default: last 90 days)
- Category filter (same five categories)
- Search by campaign name

**Preview column**: If `rendered_html_url` is not null, show a "Preview" button. Clicking it opens the stored HTML in a side panel or full-screen overlay — rendered as it appeared to members. If `rendered_html_url` is null (older campaign), show "—".

**Performance highlighting**: Campaigns with open rate in the top 25% get a subtle green highlight. This helps staff identify what works — the archive becomes a source of inspiration, not just a log.

**API endpoint**:
```
GET /api/email-archive
  Query params: category, startDate, endDate, search, page, pageSize (default 25)
  Response: { campaigns: [...], total, page, pageSize }
```

Each campaign in the response includes: id, name, category, sentAt, recipientCount, openRate, clickRate, renderedHtmlUrl (null if not stored).

**Important**: Server-side pagination. Never return all campaigns to the client at once.

---

## FILES TO MODIFY

- `server/schema.ts` — Add `rendered_html_url`, `rendered_html_stored_at` to `email_campaigns`; add `email_images` table
- `server/services/emailService.ts` — Add HTML storage on send, add image use_count tracking
- `server/services/imageService.ts` — Replace with new implementation (sharp optimization, metadata, thumbnails)
- `server/routes.ts` — Add new image endpoints, email health endpoints, email archive endpoint
- `client/src/pages/SmartSendsImages.tsx` — Upgrade UI per Part 2F spec
- `client/src/pages/SmartSends.tsx` (Email Controls section) — Add three-tab structure, Performance tab, Archive tab

## FILES NOT TO MODIFY

- `server/services/triggeredCampaignProcessor.ts` — No changes
- `server/services/emailService.ts` send logic — Only add storage call after send confirmation; do not touch existing send flow
- Any existing Automations pages or components
- `server/services/aiEmailService.ts` — No changes

---

## DEPENDENCIES

- `sharp` — Install via `npm install sharp`. Used for server-side image optimization and thumbnail generation. Verify it installs cleanly in the Replit environment before using it. If sharp fails to install, use `jimp` as a fallback (`npm install jimp`).

---

## VERIFICATION CHECKLIST

### Part 1 — HTML Storage
- [ ] `rendered_html_url` and `rendered_html_stored_at` columns exist in `email_campaigns`
- [ ] After sending a campaign, `rendered_html_url` is populated with a valid object storage path
- [ ] A failed storage operation does not prevent the email from sending
- [ ] Triggered/automated per-member campaign copies do NOT get HTML stored (only parent templates)

### Part 2 — Image Library
- [ ] Upload rejects files over 2MB with a clear error message
- [ ] Upload rejects SVG files
- [ ] Upload requires name and category — form cannot be submitted without both
- [ ] Uploaded image is optimized (check file size is smaller than original for large images)
- [ ] Thumbnail is generated and stored separately
- [ ] Image grid shows thumbnails, names, category badges, and use counts
- [ ] Category filter tabs work
- [ ] Insert size picker appears when clicking an image in the composer context
- [ ] Inserted HTML includes explicit width attribute
- [ ] Images with use_count > 0 cannot be deleted
- [ ] Delete confirmation shown before removing unused images

### Part 3 — Email Health Dashboard
- [ ] Three tabs render: Performance, Send Queue, Email Archive
- [ ] Performance metrics load for last 90 days
- [ ] Category filter changes the metrics displayed
- [ ] Unsubscribe rate warning appears when rate exceeds 0.3%
- [ ] 90-day trend chart renders without errors
- [ ] Email Archive table loads with pagination
- [ ] Archive filters by category and date range work
- [ ] Campaign name search works
- [ ] Preview button appears only for campaigns with stored HTML
- [ ] Preview renders the stored HTML correctly
- [ ] Top-performing campaigns are highlighted
- [ ] Server-side pagination confirmed (page 2 shows different results)

---

## ARCHITECTURAL NOTE FOR PRODUCTION PORT

The dev team should be aware of these decisions made in this prompt:

- **Object storage is the canonical location for rendered email HTML and image assets.** The database holds metadata and reference URLs only, never binary content.
- **Images are immutable once in use.** `use_count > 0` means no deletion. If an image needs replacing, upload a new version and update campaigns going forward.
- **Sharp is the image processing dependency.** If it needs replacing at production scale (e.g., for a managed image CDN), the interface is in `imageService.ts` only — nothing else in the codebase calls sharp directly.
- **The Email Archive starts empty.** There is no backfill of historical campaigns. This is intentional — we only store what was rendered with the current system.

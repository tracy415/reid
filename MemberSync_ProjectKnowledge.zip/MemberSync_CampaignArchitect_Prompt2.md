# MemberSync — Campaign Architect: Prompt 2
## Email Generation, Sequence Editing, A/B Testing, and Activation

*Written: March 5, 2026*
*Status: SEND AFTER PROMPT 1 IS VERIFIED WORKING*

---

## WHAT THIS PROMPT BUILDS

Prompt 1 built the planning conversation and produces a `CampaignPlan` JSON object. Prompt 2 takes that plan and turns it into a real, activatable campaign.

**Prompt 2 covers:**
- "Generate Emails" — AI writes every email in the sequence using the plan as context
- Sequence editing view — each email displayed as a card with Edit and Preview using the existing EmailComposer
- A/B test suggestion — AI's proposed test shown as a reviewable card, staff approves or skips
- Live audience enrollment model — smart re-evaluation on each processor run, snapshot for external audiences only
- Activation — writes to `triggeredCampaigns`, `triggeredCampaignSteps`, and initial `dripSequenceMembers` enrollment, advances session status
- Sequence view states — Draft, Active (with stats overlay), Paused, Completed, Archived

**Prompt 3 (after AEI) will cover:**
- Full sequence analytics — roll-up stats, per-email breakdown, member journey table

---

## CONTEXT FOR REPLIT

This prompt builds on everything in Prompt 1. Read the Prompt 1 spec and verify that:
- `campaign_architect_sessions` table exists and is working
- `aiCampaignPlannerService.ts` is running correctly
- The conversation → plan flow is verified end-to-end
- `CampaignPlan` and `CampaignPlanEmail` interfaces are exported from `shared/schema.ts`

Do not begin Prompt 2 until Prompt 1 is fully verified.

The key constraint throughout this prompt: **the existing EmailComposer is the only editor for sequence emails.** Do not build a second editor. Do not build inline editing inside the sequence cards. The Edit button on any email card opens the existing `EmailComposer` component exactly as it works today, and saving returns the staff member to the sequence view.

---

## PART 1: EMAIL GENERATION

### The "Generate Emails" Button

When staff clicks "Generate Emails" in the plan preview panel, the session status transitions to `'generating'` and email generation begins.

**Generation behavior is conditional on sequence length:**

- **4 emails or fewer:** Generate all emails in parallel (Promise.all). Show a single centered animation while all generate. All email cards appear together when complete. This is the "magic reveal" — the whole campaign appearing at once.

- **5 emails or more:** Generate sequentially, one at a time. Each email card populates as its generation completes. Show progress: "Writing Email 2 of 7..." This keeps long sequences from feeling like a frozen spinner.

The threshold is 4. At exactly 4 emails: parallel. At 5 or more: sequential.

### New API Route: POST /api/campaign-architect/sessions/:sessionId/generate

This route orchestrates email generation for the entire sequence.

```typescript
app.post("/api/campaign-architect/sessions/:sessionId/generate",
  authMiddleware, requireRole("admin", "staff"),
  async (req, res) => {
    const { sessionId } = req.params;
    
    // Load session and validate
    const [session] = await db.select()
      .from(campaignArchitectSessions)
      .where(eq(campaignArchitectSessions.sessionId, sessionId))
      .limit(1);
    
    if (!session) return res.status(404).json({ message: "Session not found" });
    if (!session.currentPlan) return res.status(400).json({ message: "No plan to generate from" });
    
    const plan = session.currentPlan as CampaignPlan;
    const { generateEmail } = await import('./services/aiEmailService');
    
    // Build generation requests for each email in the plan
    const generationRequests = plan.emails.map(email => ({
      purpose: email.purposeOneLiner,
      audience_description: session.audienceDescription || plan.audienceDescription,
      key_points: [
        email.stepRationale,
        email.toneForThisEmail,
        ...(email.anchorEventName ? [`This email promotes: ${email.anchorEventName}`] : []),
      ],
      tone: mapPlanToneToEmailTone(email.toneForThisEmail),
      context: {
        additional_info: `
          This is Email ${email.stepNumber} of ${plan.emails.length} in a sequence called "${plan.campaignName}".
          Overall campaign goal: ${plan.goal}
          This email's role: ${email.purposeOneLiner}
          Suggested subject direction: ${email.subjectLineSketch}
          Tone for this email: ${email.toneForThisEmail}
          ${email.anchorEventName ? `Anchored to event: ${email.anchorEventName} on ${email.anchorDate}` : ''}
          ${plan.emails.length > 1 ? `
            Other emails in this sequence:
            ${plan.emails
              .filter(e => e.stepNumber !== email.stepNumber)
              .map(e => `- Email ${e.stepNumber} (Day ${e.delayDays}): ${e.purposeOneLiner}`)
              .join('\n')}
            Ensure this email fits naturally within the sequence arc without repeating themes from other emails.
          ` : ''}
        `.trim()
      }
    }));
    
    const parallelThreshold = 4;
    let generatedEmails: Array<{ stepNumber: number; subject: string; body: string; previewText: string }> = [];
    
    if (plan.emails.length <= parallelThreshold) {
      // Parallel generation
      const results = await Promise.all(
        generationRequests.map(async (req, idx) => {
          const result = await generateEmail(req);
          return { stepNumber: plan.emails[idx].stepNumber, ...result };
        })
      );
      generatedEmails = results.map(r => ({
        stepNumber: r.stepNumber,
        subject: r.subject,
        body: r.body,
        previewText: r.preview_text,
      }));
    } else {
      // Sequential generation — stream results back
      // For sequential, we use SSE (Server-Sent Events) or return all results
      // after sequential completion. Use sequential with full results returned
      // at end (simpler than SSE, frontend polls or awaits full response).
      // NOTE: Frontend handles the "progressive" appearance by animating
      // cards in one by one from the returned array, not by waiting for
      // individual responses. The AI generation is sequential server-side
      // to avoid rate limits; the frontend receives all results and 
      // staggers the card animation by 300ms per card.
      for (let idx = 0; idx < generationRequests.length; idx++) {
        const result = await generateEmail(generationRequests[idx]);
        generatedEmails.push({
          stepNumber: plan.emails[idx].stepNumber,
          subject: result.subject,
          body: result.body,
          previewText: result.preview_text,
        });
      }
    }
    
    // Store generated emails in session
    await db.update(campaignArchitectSessions)
      .set({
        currentPlan: {
          ...plan,
          generatedEmails, // attach to plan object
        },
        status: 'ready_to_activate',
        updatedAt: new Date(),
      })
      .where(eq(campaignArchitectSessions.sessionId, sessionId));
    
    res.json({ generatedEmails, totalGenerated: generatedEmails.length });
  }
);

// Helper: map plan tone description to generateEmail tone param
function mapPlanToneToEmailTone(toneDescription: string): 'professional' | 'friendly' | 'urgent' {
  const lower = toneDescription.toLowerCase();
  if (lower.includes('urgent') || lower.includes('deadline') || lower.includes('last')) return 'urgent';
  if (lower.includes('warm') || lower.includes('friendly') || lower.includes('casual')) return 'friendly';
  return 'professional';
}
```

### Generation UI

When "Generate Emails" is clicked:

1. Button changes to a loading state: "Writing your campaign..."
2. For **parallel** (≤4 emails): single centered animation with sparkle + "Writing your campaign..." text. All cards appear together when done, animating in simultaneously.
3. For **sequential** (5+ emails): progress text "Writing Email 1 of 7..." updates as each completes. Cards appear one at a time with a 300ms stagger animation between them.
4. On completion: session status updates to `ready_to_activate`. The plan preview panel transitions to the **sequence editing view**.
5. On error: red toast "Email generation failed — your plan is saved. Try again." Button resets. Status reverts to `planning`.

---

## PART 2: SEQUENCE EDITING VIEW

After generation, the plan preview panel becomes the sequence editing view. This is the same panel — it transitions in place.

### Email Card Structure

Each generated email becomes a fully populated card:

```
┌──────────────────────────────────────────────────────────┐
│  📧  Email 1 — Day 0                                     │
│  ─────────────────────────────────────────────────────   │
│  Subject: "Your CE deadline is closer than you think"    │
│  Preview: "April 30 is 8 weeks away — here's your..."   │
│  Audience: CE Behind - Spring 2026 · 4,120 members       │
│                                                          │
│  [Edit]  [Preview]                                       │
└──────────────────────────────────────────────────────────┘
          │
    ⏱  Wait 10 days
          │
┌──────────────────────────────────────────────────────────┐
│  📧  Email 2 — Day 10           ⚡ A/B Test suggested    │
│  ─────────────────────────────────────────────────────   │
│  Subject: "What your colleagues are doing about CE"      │
│  Preview: "3 classes, 4 weeks, done..."                  │
│  Audience: CE Behind - Spring 2026 · 4,120 members       │
│                                                          │
│  [Edit]  [Preview]                                       │
└──────────────────────────────────────────────────────────┘
```

For date-anchored steps, show the anchor date instead of "Day X":
```
📅  Anchored: Code of Ethics · Mar 28 (sent 7 days before)
```

### Edit Button

Clicking Edit on any email card opens the existing `EmailComposer` component — the same one used in the Send Email wizard. Pass it:
- `initialSubject`: the generated subject line
- `initialBody`: the generated email body
- `audienceDescription`: from the session
- `mode`: `'sequence-edit'` (new mode that EmailComposer needs to handle — see below)

**EmailComposer changes needed for sequence editing:**

Add a `mode` prop to EmailComposer: `'send'` (existing behavior) | `'sequence-edit'` (new).

In `sequence-edit` mode:
- Header shows "Editing Email [N] of [total]" instead of the normal wizard header
- The wizard step navigation (audience, compose, preview, settings) is collapsed — staff land directly on the compose step
- "Save" button replaces "Next" / "Send" — clicking Save returns to the Campaign Architect sequence view with the updated content
- All AI generation, refinement, merge field, and preview functionality works exactly as normal
- No send, no scheduling, no audience selection — those are locked at the sequence level

On Save, update the generated email in `campaignArchitectSessions.currentPlan.generatedEmails` via PATCH.

### Preview Button

Opens a live preview modal showing the email rendered with real member data — same as the existing preview functionality in the Send wizard. Uses the first member from the audience as the preview recipient. Shows merge fields resolved with real data.

---

## PART 3: A/B TEST SUGGESTION

If the `CampaignPlan` contains an `abTestSuggestion` (and most AI-generated plans will), display it as a reviewable card between the sequence timeline and the Activate button.

### A/B Test Card

```
┌──────────────────────────────────────────────────────────┐
│  ⚡ A/B Test Suggestion                                   │
│                                                          │
│  Test two subject lines on Email 2 to find out which    │
│  approach resonates better with this audience before     │
│  committing the rest of your sends.                      │
│                                                          │
│  Version A (current):                                    │
│  "What your colleagues are doing about CE"               │
│                                                          │
│  Version B (suggested):                                  │
│  [AI-generated alternative subject line]                 │
│  ✏ Edit version B                                        │
│                                                          │
│  How it works: Half your audience gets A, half gets B.  │
│  After 48 hours, the winning subject line is used for   │
│  all remaining sends. You'll see the result right here. │
│                                                          │
│  [Approve Test]  [Skip — use Version A only]            │
└──────────────────────────────────────────────────────────┘
```

**Version B generation:**

When the session status transitions to `ready_to_activate` and an A/B test is suggested, automatically generate the Version B subject line using a lightweight Haiku call:

```typescript
// In the generate route, after emails are generated:
if (plan.abTestSuggestion !== null) {
  const abResult = await callAnthropicWithRetry(anthropic, {
    model: 'claude-haiku-4-5-20251001',
    max_tokens: 100,
    system: `You write alternative email subject lines. Return ONLY the subject line text, nothing else. No quotes, no explanation.`,
    messages: [{
      role: 'user',
      content: `Write an alternative subject line for this email.
Original: "${generatedEmails[plan.abTestSuggestion.emailIndex].subject}"
Audience: ${session.audienceDescription}
Context: ${plan.abTestSuggestion.suggestedVariantHint}
The alternative should test a meaningfully different angle — not just rewording. Under 60 characters.`
    }]
  });
  const variantB = abResult.content[0].type === 'text' ? abResult.content[0].text.trim() : '';
  // Store variantB in session plan
}
```

**Staff can edit Version B** inline before approving. Simple text input replaces the subject line text on click.

**Approve Test:** Sets `abTestApproved: true` and `subjectLineB: variantB` in the session plan. The A/B indicator on the email card updates to show both subject lines.

**Skip:** Sets `abTestApproved: false`. The card collapses. Email card A/B indicator is removed.

---

## PART 4: ACTIVATION

### New API Route: POST /api/campaign-architect/sessions/:sessionId/activate

This is the most important route in Prompt 2. It:
1. Creates the `triggeredCampaigns` record
2. Creates `triggeredCampaignSteps` records for each email
3. Performs initial audience enrollment
4. Stores audience context for live re-enrollment
5. Updates the session status to `activated`

```typescript
app.post("/api/campaign-architect/sessions/:sessionId/activate",
  authMiddleware, requireRole("admin", "staff"),
  async (req, res) => {
    const { sessionId } = req.params;
    const { sendWindowStart, sendWindowEnd, sendOnWeekends } = req.body;
    
    const [session] = await db.select()
      .from(campaignArchitectSessions)
      .where(eq(campaignArchitectSessions.sessionId, sessionId))
      .limit(1);
    
    if (!session) return res.status(404).json({ message: "Session not found" });
    if (session.status !== 'ready_to_activate') {
      return res.status(400).json({ message: "Generate emails before activating" });
    }
    
    const plan = session.currentPlan as CampaignPlan & { 
      generatedEmails: Array<{ stepNumber: number; subject: string; body: string; previewText: string }>;
      abTestApproved?: boolean;
      subjectLineB?: string;
      abTestEmailIndex?: number;
    };
    
    if (!plan.generatedEmails?.length) {
      return res.status(400).json({ message: "No generated emails found" });
    }
    
    const user = (req as any).user;
    const now = new Date();
    
    // 1. Create the triggeredCampaigns record
    // Use Email 1's subject and body as the top-level campaign fields
    // (required by schema — steps override these per-step)
    const firstEmail = plan.generatedEmails.find(e => e.stepNumber === 1)!;
    const abTestEmailIdx = plan.abTestSuggestion?.emailIndex ?? -1;
    const abTestEmail = plan.abTestApproved && abTestEmailIdx >= 0 
      ? plan.generatedEmails[abTestEmailIdx] 
      : null;
    
    const [campaign] = await db.insert(triggeredCampaigns).values({
      campaignName: plan.campaignName,
      description: plan.goal,
      triggerType: 'drip_sequence',
      triggerConfig: {
        audienceId: session.audienceId || null,
        audienceDescription: session.audienceDescription,
        isExternalAudience: false, // set below if external
        architectSessionId: sessionId,
      },
      subjectLine: firstEmail.subject,
      emailBody: firstEmail.body,
      // A/B test fields (on the step that has the test, not the campaign level)
      abTestEnabled: plan.abTestApproved || false,
      sendWindowStart: sendWindowStart || '08:00',
      sendWindowEnd: sendWindowEnd || '17:00',
      sendOnWeekends: sendOnWeekends || false,
      status: 'active',
      activatedAt: now,
      createdBy: user?.fullName || 'system',
    }).returning();
    
    // 2. Create triggeredCampaignSteps for each email
    for (const email of plan.generatedEmails) {
      const planEmail = plan.emails.find(e => e.stepNumber === email.stepNumber)!;
      const isAbTestStep = plan.abTestApproved && 
        abTestEmailIdx === (email.stepNumber - 1);
      
      await db.insert(triggeredCampaignSteps).values({
        campaignId: campaign.campaignId,
        stepNumber: email.stepNumber,
        stepName: `Email ${email.stepNumber}: ${planEmail.purposeOneLiner}`,
        delayDays: planEmail.delayDays,
        subjectLine: email.subject,
        emailBody: email.body,
        // A/B test on this step if approved
        ...(isAbTestStep && plan.subjectLineB ? {
          // Store variant B in sendCondition as a workaround until
          // triggeredCampaignSteps gets subjectLineB column in production port
          // For prototype: store in stepName metadata, handle in processor
          sendCondition: 'always',
        } : {
          sendCondition: 'always',
        }),
        sendDate: planEmail.anchorDate || null,
      });
    }
    
    // NOTE ON A/B TESTING IN STEPS:
    // The current triggeredCampaignSteps schema doesn't have subjectLineB.
    // For the prototype, store A/B variant B subject in triggerConfig on the
    // parent triggeredCampaigns record as abTestStepNumber and subjectLineB.
    // Production port will add subjectLineB to triggeredCampaignSteps properly.
    if (plan.abTestApproved && plan.subjectLineB) {
      await db.update(triggeredCampaigns)
        .set({
          subjectLineB: plan.subjectLineB,
          abTestEnabled: true,
          triggerConfig: {
            ...(campaign.triggerConfig as any),
            abTestStepNumber: plan.abTestSuggestion!.emailIndex + 1,
          }
        })
        .where(eq(triggeredCampaigns.campaignId, campaign.campaignId));
    }
    
    // 3. Resolve audience and perform initial enrollment
    const enrollmentResult = await enrollAudienceForSequence({
      campaignId: campaign.campaignId,
      session,
      firstStepDelayDays: plan.emails[0].delayDays,
      now,
    });
    
    // 4. Update session status
    await db.update(campaignArchitectSessions)
      .set({
        status: 'activated',
        triggeredCampaignId: campaign.campaignId,
        updatedAt: now,
      })
      .where(eq(campaignArchitectSessions.sessionId, sessionId));
    
    res.json({
      success: true,
      campaignId: campaign.campaignId,
      enrolled: enrollmentResult.enrolled,
      totalAudience: enrollmentResult.totalAudience,
      message: `Campaign activated. ${enrollmentResult.enrolled} members enrolled.`,
    });
  }
);
```

### Audience Enrollment Function

This replaces the snapshot model in the existing `activate-drip` endpoint. Extract it as a reusable function since the processor also needs to call it for live re-enrollment.

```typescript
async function enrollAudienceForSequence({
  campaignId,
  session,
  firstStepDelayDays,
  now,
}: {
  campaignId: string;
  session: CampaignArchitectSession;
  firstStepDelayDays: number;
  now: Date;
}): Promise<{ enrolled: number; totalAudience: number }> {
  
  const firstDueAt = new Date(now.getTime() + firstStepDelayDays * 24 * 60 * 60 * 1000);
  
  // Resolve members from audience
  let members: Array<{ memberKey: string; memberEmail: string; memberName: string }> = [];
  
  // Check if this is an external audience (CSV/non-member upload)
  if (session.audienceId) {
    const [audience] = await db.select()
      .from(savedAudiences)
      .where(eq(savedAudiences.audienceId, session.audienceId))
      .limit(1);
    
    if (audience?.isExternal) {
      // External audience: snapshot enrollment only, no live re-evaluation
      const contacts = (audience.externalContacts as any[]) || [];
      members = contacts
        .filter(c => c.email)
        .map(c => ({
          memberKey: c.email, // use email as key for external contacts
          memberEmail: c.email,
          memberName: c.fullName || c.firstName || c.email,
        }));
    } else {
      // Member audience: resolve via getAudienceMembers for live data
      const { getAudienceMembers } = await import('./services/aiAudienceService');
      const data = await getAudienceMembers(session.audienceId, { previewOnly: false });
      members = (data.members || [])
        .filter((m: any) => m.MemberEmail && m.MemberStatus === 'Active')
        .map((m: any) => ({
          memberKey: m.MemberKey,
          memberEmail: m.MemberEmail,
          memberName: m.MemberFullName || '',
        }));
    }
  }
  
  if (members.length === 0) {
    return { enrolled: 0, totalAudience: 0 };
  }
  
  // Enroll members — unique constraint prevents double-enrollment
  let enrolled = 0;
  for (const member of members) {
    try {
      await db.insert(dripSequenceMembers).values({
        campaignId,
        memberKey: member.memberKey,
        memberEmail: member.memberEmail,
        memberName: member.memberName,
        currentStep: 0,
        enrolledAt: now,
        nextStepDueAt: firstDueAt,
        status: 'active',
      });
      enrolled++;
    } catch {
      // Unique constraint = already enrolled, skip silently
    }
  }
  
  return { enrolled, totalAudience: members.length };
}
```

### Live Re-enrollment by the Processor

The `triggeredCampaignProcessor.ts` already runs daily and processes `drip_sequence` campaigns. It needs one addition: **before processing steps, check for new qualifying members and enroll them.**

Add to the `processDripSequences()` function, at the start of each campaign's processing loop:

```typescript
// For campaigns created by Campaign Architect (has architectSessionId in triggerConfig),
// check for new qualifying members and enroll them
const triggerConfig = campaign.triggerConfig as any;
if (triggerConfig?.architectSessionId && triggerConfig?.audienceId) {
  const session = await db.select()
    .from(campaignArchitectSessions)
    .where(eq(campaignArchitectSessions.sessionId, triggerConfig.architectSessionId))
    .limit(1)
    .then(r => r[0]);
  
  if (session && !session.audienceId) continue; // no audience to re-evaluate
  
  // Re-enroll any newly qualifying members
  // enrollAudienceForSequence handles the unique constraint —
  // already-enrolled members are silently skipped
  const steps = await db.select()
    .from(triggeredCampaignSteps)
    .where(eq(triggeredCampaignSteps.campaignId, campaign.campaignId))
    .orderBy(triggeredCampaignSteps.stepNumber)
    .limit(1);
  
  if (steps.length > 0) {
    await enrollAudienceForSequence({
      campaignId: campaign.campaignId,
      session,
      firstStepDelayDays: steps[0].delayDays,
      now: new Date(),
    });
  }
}
```

**IMPORTANT:** `enrollAudienceForSequence` must be exported from routes or extracted to a shared service so `triggeredCampaignProcessor.ts` can import it. Extract it to `server/services/sequenceEnrollmentService.ts`.

**Enrollment rules enforced by this model:**
- ✅ New qualifying members enrolled automatically on each processor run
- ✅ Already-enrolled members skipped (unique constraint)
- ✅ Members who complete the sequence (`status: 'completed'`) are not re-enrolled
- ✅ Members who unsubscribe are not re-enrolled (processor already checks this)
- ✅ External/CSV audiences are NOT re-evaluated (no `audienceId` linkage)
- ✅ Once enrolled, members finish their sequence regardless of current qualification status

---

## PART 5: ACTIVATION UI

### Pre-Activation Settings

A small settings section appears below the A/B test card (or below the sequence if no A/B test):

```
Send Settings
─────────────────────────────────────────
Send window:  [08:00 ▾]  to  [17:00 ▾]   (Chicago time)
Send on weekends:  [ ] Yes
─────────────────────────────────────────
```

Defaults to 8am–5pm weekdays. Staff can adjust. These map to `sendWindowStart`, `sendWindowEnd`, `sendOnWeekends` on the `triggeredCampaigns` record.

### Activate Button

```
[🚀 Activate Campaign]
```

Prominent teal button. Full width at bottom of sequence view.

On click:
1. Show confirmation modal:
   ```
   Activate "Spring CE Compliance"?
   
   This will enroll 4,120 members and begin sending
   Email 1 immediately (within today's send window).
   
   [Cancel]  [Activate →]
   ```
2. On confirm: POST to `/api/campaign-architect/sessions/:sessionId/activate`
3. Loading state: "Activating..."
4. On success: 
   - Green success toast: "Campaign activated — 4,120 members enrolled"
   - Navigate to Automations page
   - The campaign appears in the Campaign Sequences table with status "Active"
5. On error: Red toast with error message. Button resets.

---

## PART 6: SEQUENCE VIEW STATES

The Campaign Architect page (`CampaignArchitect.tsx`) shows different content in the plan preview panel depending on session status. This is the same panel — it transitions between states.

### State: `planning`
Plan preview panel shows the plan proposal (from Prompt 1). "Generate Emails" button at bottom.

### State: `generating`
Animated generation UI (parallel or sequential depending on email count). No other controls visible.

### State: `ready_to_activate`
Full sequence editing view: email cards with Edit/Preview, A/B test card, send settings, Activate button.

Email cards in this state are fully editable. Edit opens EmailComposer in sequence-edit mode.

### State: `activated` (viewing an active campaign)
The plan preview panel shows the **live sequence view** — same card layout but with performance data overlaid:

```
┌──────────────────────────────────────────────────────────┐
│  📧  Email 1 — Day 0                         ✓ Sent      │
│  ─────────────────────────────────────────────────────   │
│  Subject: "Your CE deadline is closer than you think"    │
│  Sent Mar 3 · 4,120 members                              │
│  Opens: 41%  Clicks: 12%                                 │
│                                                          │
│  [View Stats]                                            │
└──────────────────────────────────────────────────────────┘
          │
    ⏱  Wait 10 days  (sends Mar 13)
          │
┌──────────────────────────────────────────────────────────┐
│  📧  Email 2 — Day 10               📅 Scheduled Mar 13  │
│  ─────────────────────────────────────────────────────   │
│  Subject: "What your colleagues are doing about CE"      │
│  Sending to 4,120 members                                │
│                                                          │
│  [Edit]  [Preview]                                       │
└──────────────────────────────────────────────────────────┘
```

- **Sent emails:** Muted styling, lock icon, stats (opens %, clicks %). "View Stats" links to the campaign record. Not editable.
- **Scheduled/upcoming emails:** Full color, Edit + Preview buttons active.
- **Currently sending:** "Sending now..." indicator, locked.

Stats for sent emails come from a new lightweight endpoint:

```
GET /api/campaign-architect/sessions/:sessionId/stats
```

Returns per-step stats by joining `triggeredCampaignSteps` → `triggeredCampaignSends` → `email_campaigns` → aggregate open/click rates. This is a simple aggregation query — not the full analytics (that's Prompt 3).

### State: `paused`
Same as activated view but all email cards show "Paused" indicator. Future emails show "Will resume when unpaused." Pause/Resume button in header.

### State: `completed`
All email cards show sent stats. No Edit buttons. "Duplicate Campaign" button appears — creates a new Campaign Architect session pre-populated with the same plan (status: `planning`, same name + "(Copy)").

---

## PART 7: SEQUENCE CONTROLS

Add to the Campaign Architect page header (right side, next to session name):

**When status is `ready_to_activate`:** No controls yet (Activate is the primary action).

**When status is `activated`:**
- [Pause] button → PATCH session + PATCH triggered campaign status to 'paused'

**When status is `paused`:**
- [Resume] button → PATCH to 'active'
- [Archive] button → confirmation modal → PATCH to 'archived'

**When status is `completed`:**
- [Duplicate] button → creates new session as described above

**Archive behavior:**
- Sets `triggeredCampaigns.status` to 'archived' and `triggeredCampaigns.archivedAt` to now
- Sets `campaignArchitectSessions.status` to 'archived'
- No members receive further emails
- History and stats are fully preserved

**No delete for activated campaigns.** Delete is only available in the session table for `planning` status sessions that have never sent. Once a campaign has enrolled members or sent emails, archive is the only option.

---

## PART 8: EMAILCOMPOSER CHANGES

`EmailComposer.tsx` needs a `mode` prop added. This is a minimal change — do not refactor EmailComposer. Only add what's needed for sequence editing.

```typescript
// Add to EmailComposer props:
mode?: 'send' | 'sequence-edit';  // default: 'send'
sequenceContext?: {
  emailNumber: number;
  totalEmails: number;
  campaignName: string;
  onSave: (subject: string, body: string, previewText: string) => void;
};
```

In `sequence-edit` mode:
- Header text: "Editing Email [N] of [total] — [campaignName]"
- Land directly on the Compose step (skip audience step)
- Replace "Next →" / "Send" button with "Save Changes" button
- "Save Changes" calls `sequenceContext.onSave(subject, body, previewText)` and then navigates back
- All other functionality (AI generation, refinement, merge fields, preview, image picker) unchanged
- No send settings, no scheduling, no audience selection visible

---

## ACCEPTANCE CRITERIA

Prompt 2 is complete when:

1. **Generate Emails:** Clicking "Generate Emails" on a plan with ≤4 emails generates all in parallel and reveals them simultaneously. With 5+ emails, generates sequentially with "Writing Email N of M" progress and cards appearing one at a time.

2. **Email quality:** Each generated email reflects the purpose, tone, and context of its position in the sequence. Email 3 of a 3-email CE compliance sequence should feel like a final nudge, not a first introduction.

3. **Sequence editing view:** All email cards appear with subject line, preview text, audience info, Edit and Preview buttons.

4. **Edit opens EmailComposer:** Edit button on any card opens the existing EmailComposer in sequence-edit mode. Staff can generate, refine, and edit. Save returns to sequence view with updated content.

5. **Preview shows real data:** Preview button shows the email rendered with real member data (first member from audience), merge fields resolved.

6. **A/B test card:** If the plan includes an A/B test suggestion, the card appears with Version A (current subject) and AI-generated Version B. Staff can edit Version B. Approve and Skip both work correctly.

7. **Activation:** Clicking Activate creates the `triggeredCampaigns` record, all `triggeredCampaignSteps` records, and enrolls the initial audience. Session status becomes `activated`. Staff is navigated to Automations. Campaign appears in the sequences table as Active.

8. **Live enrollment:** The `triggeredCampaignProcessor.ts` re-evaluates the audience on each run and enrolls newly qualifying members. Already-enrolled members are skipped cleanly.

9. **External audience snapshot:** A campaign using an external/CSV audience enrolls at activation time only. No re-evaluation.

10. **Sequence states:** Activated campaigns show sent email stats (opens, clicks) on sent cards. Upcoming emails remain editable. Paused state shows correctly. Archive works.

11. **Pause / Resume / Archive:** All three controls work from the Campaign Architect page header.

12. **No regressions:** Existing SmartSends, Automations, and EmailComposer functionality is unchanged. EmailComposer's default `send` mode is identical to before.

13. **No fake data:** Stats on sent emails come from real `email_recipients` data. If no sends have occurred yet, show "—" not 0%.

---

## WHAT NOT TO BUILD IN THIS PROMPT

- Full sequence analytics (roll-up stats, member journey table, per-email trend charts) — that is Prompt 3
- Resend functionality — future feature
- Editing enrolled member list after activation — future feature
- Live enrollment toggle UI (always-on for member audiences, always-off for external) — behavior is automatic, no UI needed

---

## KEY DECISIONS AND STANDING RULES

- **Parallel ≤4, sequential ≥5.** No exceptions. Threshold is exactly 4.
- **Live enrollment always on for member audiences.** No toggle. Automatic.
- **External audiences snapshot only.** Detected via `savedAudiences.isExternal`.
- **Never pull enrolled members mid-sequence.** Once enrolled, they finish.
- **Same EmailComposer.** Mode prop only. No second editor.
- **No delete for activated campaigns.** Archive is the permanent record.
- **Stats show "—" not 0% when no data.** Real data or nothing.
- **Haiku for A/B variant generation.** Sonnet is for planning and email bodies.
- **`sequenceEnrollmentService.ts` is the single source of enrollment logic.** Both the activation route and the processor import from it.

---

## PARKING LOT NOTE FOR PROMPT 3

Prompt 3 (Sequence Analytics) will add:
- Roll-up stats banner: total members reached, overall open rate, overall click rate across all emails
- Per-email performance comparison chart
- Member journey table: which members opened which emails, who clicked, who is at each step
- This view overlays on the existing sequence view — not a separate page

---

*Prompt 3 (Sequence Analytics) to follow after AEI demo.*
*Drip sequence UI cleanup (removing old creation wizard) to follow after end-to-end verification.*

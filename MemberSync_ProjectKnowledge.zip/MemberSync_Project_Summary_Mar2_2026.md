# MemberSync — Project Summary
## March 2, 2026

This document captures all strategic decisions and current state through March 2, 2026. Use this to resume work in a new conversation.

---

## TABLE OF CONTENTS

1. Project Overview (Updated)
2. Strategic Pivot: Two-Track Development Model
3. Architectural Review Findings
4. Team Structure and Roles
5. Track 1: Demo & Product Vision (Tracy + Claude + Replit)
6. Track 2: Production Platform (Dev Team + Claude Code)
7. Client Pipeline and Status
8. Current Feature State
9. Parking Lot (Strategic Ideas Backlog)
10. Known Issues Still Open
11. AI Cost Model
12. Updated Strategic Roadmap
13. Key Architectural Decisions (All Prior + New)
14. Key Files Reference
15. Standing Rules

---

# 1. PROJECT OVERVIEW (UPDATED)

## What We Are Building

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs. The platform uses AI-powered analytics to help MLS and association executives retain and engage members by analyzing MLS listing data and association management system (AMS) data.

The product vision: MemberSync should be the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

## Product Model

MemberSync is a SaaS product, not a custom build. Every feature works for any association or MLS through configuration, not custom code. The long-term goal is self-service onboarding: sign up, connect APIs, go.

## Build Philosophy (UPDATED March 2, 2026)

Tracy (founder/CEO of Membio) maintains control of product vision and feature development using:
- **Claude** as CTO/product visionary/AI architecture expert/strategic sparring partner
- **Julius.AI** for SQL development against production database
- **Replit Agent** for demo/prototype feature implementation

The development team owns production readiness using:
- **Claude Code** for implementation in the production repository
- Standard development practices (Git, CI/CD, testing, staging environments)

Clean boundary: Tracy and Claude decide the "what" and "why" via specs. The team owns the "how."

## Claude's Role

Claude acts as CTO, product visionary, AI architecture expert, and strategic sparring partner. This means:
- Pressure-test every feature idea against multi-tenant scale, technical debt, and timing before speccing it
- Surface architectural risks proactively rather than waiting for discovery in production
- Translate tradeoffs into business terms, not jargon
- Push back when something doesn't make sense
- Hold the full product picture across conversations so nothing gets lost

## Product Philosophy

The core insight: 75% of association members produce only 12% of real estate volume, yet pay 75% of dues revenue. At Mainstreet (18,275 members), the top 25% control 88% of volume while 13,700 Foundation members produce minimal transactions but maintain membership for decades. MemberSync helps associations prove their value to ALL members.

All member tiers are framed positively: Foundation (0-5 sides), Builder (6-39 sides), Rainmaker (40+ sides). Engagement scoring is tier-aware — a Foundation member who takes classes, pays on time, and attends events scores 10/10 even with zero transactions. The qualitative drives the quantifiable.

---

# 2. STRATEGIC PIVOT: TWO-TRACK DEVELOPMENT MODEL

## Decision Made March 1-2, 2026

After architectural review, decided on structured port approach with two parallel tracks. Neither pure refactoring nor complete rewrite.

## Why Not Refactor the Prototype?
- Only 1 of 20+ tables has client_id
- 110+ hardcoded "MainStreet" references
- Illinois-specific compliance hardcoded
- Mainstreet branding baked into email templates
- 5,700-line monolithic routes.ts
- No migration system, no rate limiting
- Development partner called it "spaghetti code" — team won't be comfortable maintaining it

## Why Not Rewrite From Scratch?
- Hundreds of solved edge cases in existing code
- Rewrites always take longer than expected
- Email infrastructure took weeks to get right
- Would re-introduce fixed bugs

## The Port Approach
New repository with proper architecture from day one. Port working logic module by module, cleaning up as it moves. Clean architecture + proven business logic + code the team owns.

---

# 3. ARCHITECTURAL REVIEW FINDINGS

Full detail in `MemberSync_Architectural_Review.md`.

## Critical (HGAR Blockers)
1. No multi-tenant data isolation — client_id missing everywhere
2. 110+ hardcoded "MainStreet" references
3. Hardcoded Illinois compliance rules
4. Hardcoded email branding

## Important (Fix Soon After)
5. Monolithic shared database schema (37K characters)
6. MemberKey / MRD prefix inconsistency
7. No database migration system
8. 5,700-line routes.ts monolith

## Recommended Fix Order
1. Database migrations (Day 1)
2. Multi-tenant schema + tenant_config (Week 1-2)
3. Replace hardcoded references (concurrent with #2)
4. Split routes.ts (Week 2)
5. Parameterize compliance (Week 2-3)
6. Parameterize email branding (Week 2-3)
7. AI rate limiting (Week 3)
8. Modularize schema document (Week 3-4)

---

# 4. TEAM STRUCTURE AND ROLES

- **Tracy:** Product vision, feature development, client relationships
- **Backend engineer / architect:** Environments, database, AWS. Can lead data layer port.
- **DevOps engineer:** Internal. CI/CD, infrastructure.
- **Full-stack engineers (2):** Via development partner. Working other projects. Not using Claude Code. Partner skeptical.
- **VP of Product:** Can own port track project management
- **UX Designer:** Should review production frontend, not Replit prototype

## Gap: Full-Stack for Port
- Option A: Upskill partner's engineers with Claude Code (preferred)
- Option B: Contract senior full-stack developer ($25-50K for 4-6 weeks)
- Option C: Hybrid — backend engineer handles API, contractor handles React ($15-30K)

---

# 5. TRACK 1: DEMO & PRODUCT VISION

## Week 1 Priorities
1. **Proactive AI Engagement Engine** — The Community Insights cards at the bottom of the dashboard are currently hardcoded samples. This engine makes them real: a library of pattern detectors that scan member data daily, a scoring system that surfaces the 4-6 most actionable insights, and action buttons ("Connect Them," "Celebrate Them," "Send Welcome Back") that drop staff into SmartSends with the right audience and a suggested email. This is the feature that makes executives understand what MemberSync does that nothing else can. More compelling for demos than lapse prevention because it's proactive and positive rather than defensive.
2. **Lapse Prevention System** — Calendar-aware risk scoring, status tracking, automated intervention. The defensive counterpart to the engagement engine.
3. **AI Cost Controls** — Per-user rate limiting, prompt caching, usage dashboard. Required before Mainstreet starts using the product.

## Week 2 Priorities
4. A/B Testing activation
5. Drip Sequence Builder
6. Compliance Section Redesign

## Ready Replit Prompts
- Live Data Preview
- Query Engine Retry + Cross-Domain
- Post-Implementation Cleanup (8 fixes)
- AI Content Training v2
- Member Recognition Cleanup (sent)

---

# 6. TRACK 2: PRODUCTION PLATFORM

## First Sprint: Foundation
1. New repository with proper structure
2. Database migration system
3. Tenant configuration table (seeded with Mainstreet)
4. client_id on every table
5. Routes split into modules

## Port Order
1. Authentication + users → 2. Data layer (caches) → 3. Dashboard + profiles → 4. SmartSends → 5. Audiences → 6. AI Chat → 7. Analytics → 8. Automations → 9. Celebrations

## Handoff Documents Needed
1. CLAUDE.md (TO BE WRITTEN)
2. Architectural review (WRITTEN)
3. Developer port specs (per module, as features are validated)

---

# 7. CLIENT PIPELINE

| Client | Members | Status |
|--------|---------|--------|
| Mainstreet REALTORS | 18,275 | Demo only. NOT in production. |
| HGAR | 12,800 | Onboarding. Requires multi-tenant. NY compliance. |
| GRAR | 3,400 | Third pilot. NY compliance. |
| CRMLS | 103,000+ | CMO interested. Pilot at $2,500/mo × 3 months. Requires SOC 2. |

**Important:** Mainstreet is NOT live. They want to use MemberSync but it's too buggy and still on Replit. Production platform is what they'll actually use.

---

# 8. CURRENT FEATURE STATE

## Built and Working (Replit)
Dashboard, tier classification, engagement scoring, SmartSends campaigns, AI audience builder, triggered automations (7 types), AI Chat, member/office profiles, visit brief PDFs, analytics leaderboards, celebration engine, headshot sync, CSV upload, image library, SendGrid integration, secure unsubscribe

## Not Yet Built
Proactive AI Engagement Engine (Community Insights cards are hardcoded), Lapse prevention, A/B testing activation, drip sequence UI, AI chart rendering, AI cost controls, compliance redesign

---

# 9. PARKING LOT

15 items tracked in `MemberSync_ParkingLot.md` including: Behavior Analysis Engine, Listing Lifecycle Automations, Broker Module, Multi-Tenant Stages 2-3, AI Cost Pricing, Lapse Pattern Analysis, Integration Marketplace, SOC 2, and more.

---

# 10. KNOWN ISSUES

### Critical
- 75K emails in queue (needs flush)
- MAX_CAMPAIGN_RECIPIENTS = 1 (blocking test sends)
- Preview shows fake data

### Important
- Pause Before Editing dialog
- No automation delete
- Raw merge tags in subject lines
- 172-member count gap

---

# 11. AI COST MODEL

With prompt caching: $0.026-0.048 per request. CRMLS heavy usage with caching: $600-1,000/month. Three-layer defense: technical guardrails, tiered pricing, contract clauses.

---

# 12. STRATEGIC ROADMAP

**This week:** CLAUDE.md, architectural spec, proactive engagement engine prompt, lapse prevention prompt, AI cost controls prompt, team presentation
**Weeks 2-3:** Both tracks running in parallel
**Weeks 4-6:** Module port + feature completion
**Week 7+:** Mainstreet production launch, HGAR onboarding
**Q2 2026:** CRMLS pilot target

---

# 13. KEY ARCHITECTURAL DECISIONS

All prior decisions remain. New additions:
- Two-track development model with clean handoff boundary
- Structured port, not rewrite or refactor
- Multi-tenant from day one in production repository
- Database migrations mandatory
- Routes split into modules
- Compliance and branding are configuration, not code
- Port order follows stability (data layer first, UI last)
- Mainstreet stays on Replit until production reaches feature parity
- Parking lot maintained as markdown in project knowledge
- Claude's role is CTO and sparring partner

---

# 14. KEY FILES

## New Documents
- `MemberSync_ParkingLot.md` — Strategic ideas backlog
- `MemberSync_Architectural_Review.md` — Full audit with fix priorities

## From Previous Summaries
- `MemberSync_Project_Summary_Feb27_2026.md` — Technical detail reference
- `MemberSync_Product_Philosophy_Dashboard.md`
- `MemberSync_CRMLS_Scaling_Roadmap.docx`

---

# 15. STANDING RULES

All prior standing rules remain. Additionally:
- Every feature evaluated through multi-tenant lens
- Replit prompts for Track 1; port specs for Track 2
- Parking lot updated whenever new ideas surface
- Claude pushes back on architectural decisions that don't scale
- No manual schema changes in production — migrations only

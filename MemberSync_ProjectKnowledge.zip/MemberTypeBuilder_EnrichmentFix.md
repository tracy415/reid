# Member Type Builder: Fix Enrichment Query
## Replit Prompt â€” February 2026

**What went wrong:** The Member Type Builder preview and counts work correctly (18,087 members), but when the audience is SAVED and then viewed or exported, three things break:
1. The count jumps to 21,892 (includes inactive/suspended members)
2. The preview only shows 13 members instead of 15
3. All email fields are empty

**Root cause:** The enrichment query in `getAudienceMembers()` was not updated. The saved SQL now returns only MemberKey (no names, emails, or active filter), and the enrichment step is supposed to look up member details and filter to active members â€” but it doesn't filter and doesn't include email.

**This prompt fixes ONE function in ONE file.** No other changes needed.

---

## FILE: server/aiAudienceService.ts

### Find the enrichment block in `getAudienceMembers()`

Look for this code block (around line 666-693). It's inside the `if (audience.isSmart && audience.sqlQuery)` branch, in the sub-block `if (rawMembers.length > 0 && !useLocalDb && externalDb)`:

```typescript
if (rawMembers.length > 0 && !useLocalDb && externalDb) {
  const memberKeys = rawMembers.map(m => m.MemberKey || m.member_key).filter(Boolean);
  if (memberKeys.length > 0) {
    const keysArray = memberKeys.map(k => `'${k}'`).join(',');
    const enrichQuery = `
      SELECT 
        m."MemberKey",
        m."MemberFirstName",
        m."MemberLastName",
        o."OfficeName"
      FROM "AMS"."apmmember" m
      LEFT JOIN "AMS"."apmoffice" o ON m."OfficeKey" = o."OfficeKey"
      WHERE m."MemberKey" IN (${keysArray})
    `;
    const enrichResult = await externalDb.execute(sql.raw(enrichQuery));
    const enrichMap = new Map<string, any>();
    for (const row of enrichResult.rows as any[]) {
      enrichMap.set(row.MemberKey, row);
    }
    members = rawMembers.map(m => ({
      ...m,
      MemberFirstName: enrichMap.get(m.MemberKey)?.MemberFirstName || null,
      MemberLastName: enrichMap.get(m.MemberKey)?.MemberLastName || null,
      OfficeName: enrichMap.get(m.MemberKey)?.OfficeName || null,
    }));
```

### Replace the entire block with:

```typescript
if (rawMembers.length > 0 && !useLocalDb && externalDb) {
  const memberKeys = rawMembers.map(m => m.MemberKey || m.member_key).filter(Boolean);
  if (memberKeys.length > 0) {
    const keysArray = memberKeys.map(k => `'${k}'`).join(',');
    const enrichQuery = `
      SELECT DISTINCT ON (m."ApmClientId", m."MemberKey")
        m."MemberKey",
        m."MemberFullName",
        m."MemberFirstName",
        m."MemberLastName",
        m."MemberEmail",
        o."OfficeName"
      FROM "AMS"."apmmember" m
      LEFT JOIN (
        SELECT DISTINCT ON ("ApmClientId", "OfficeKey")
          "OfficeKey", "OfficeName"
        FROM "AMS"."apmoffice"
        WHERE "ApmClientId" = 'MainStreet'
        ORDER BY "ApmClientId", "OfficeKey", "ApmSourceModificationTimestamp" DESC
      ) o ON m."OfficeKey" = o."OfficeKey"
      WHERE m."MemberKey" IN (${keysArray})
        AND m."ApmClientId" = 'MainStreet'
        AND m."MemberStatus" = 'Active'
      ORDER BY m."ApmClientId", m."MemberKey", m."ApmSourceModificationTimestamp" DESC
    `;
    const enrichResult = await externalDb.execute(sql.raw(enrichQuery));
    const enrichMap = new Map<string, any>();
    for (const row of enrichResult.rows as any[]) {
      enrichMap.set(row.MemberKey, row);
    }
    // Only include members that were found as active in apmmember
    members = rawMembers
      .filter(m => enrichMap.has(m.MemberKey || m.member_key))
      .map(m => {
        const key = m.MemberKey || m.member_key;
        const enriched = enrichMap.get(key);
        return {
          ...m,
          MemberFullName: enriched?.MemberFullName || null,
          MemberFirstName: enriched?.MemberFirstName || null,
          MemberLastName: enriched?.MemberLastName || null,
          MemberEmail: enriched?.MemberEmail || null,
          OfficeName: enriched?.OfficeName || null,
        };
      });
    // Update totalCount to reflect only active, enriched members
    totalCount = members.length;
```

### What this fixes:

1. **Adds `MemberFullName` and `MemberEmail`** to the enrichment SELECT â€” these were missing, which is why emails were blank in the export and preview.

2. **Adds `AND m."MemberStatus" = 'Active'`** â€” this filters out inactive/suspended members during enrichment. The saved SQL returns all member keys from `appmemberassociation` (regardless of status), and now the enrichment step is what ensures only active members make it through. This is why the count was 21,892 â€” inactive members were being included.

3. **Adds `DISTINCT ON` deduplication** â€” `apmmember` has snapshot duplicates (same MemberKey, multiple rows with different timestamps). Without `DISTINCT ON`, the query could return duplicate rows per member. The `ORDER BY ApmSourceModificationTimestamp DESC` ensures we get the most recent record.

4. **Adds deduplication on the `apmoffice` join** â€” same snapshot issue. Without `DISTINCT ON`, joining to `apmoffice` could multiply rows.

5. **Filters `rawMembers` to only include enriched keys** â€” the old code kept ALL raw members and just added null fields for ones that didn't match. Now it filters them out entirely with `.filter(m => enrichMap.has(...))`. This means the count will match the actual number of active members.

6. **Updates `totalCount`** â€” after filtering, the totalCount is set to `members.length` so the count shown to the user matches the actual members in the list.

---

## TESTING CHECKLIST

- [ ] Save a "Select All" Member Type audience â†’ the saved audience count should be ~18,087 (matching the preview), NOT 21,892
- [ ] Open the saved audience detail â†’ members should have names, emails, and offices populated
- [ ] Export the saved audience to CSV â†’ emails should be present for members who have them
- [ ] The preview in the detail modal should show 15 members with full data (not 13)
- [ ] Existing AI-generated smart audiences should still work with full data (this fix affects ALL smart audiences)
- [ ] Send an email to a saved Member Type audience â†’ recipients should receive the email correctly with merge fields populated

## DO NOT CHANGE

- The `buildSQL()` function in `MemberBillTypeBuilder.tsx` (already correct)
- The counts endpoint (already correct â€” showing 18,087)
- The preview endpoint (already correct)  
- The Dashboard
- Any other files

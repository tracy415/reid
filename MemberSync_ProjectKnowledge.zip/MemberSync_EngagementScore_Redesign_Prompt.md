# MemberSync Engagement Score Redesign â€” Replit Prompt

## What This Changes and Why

The current engagement score punishes members who don't sell real estate. A Foundation member (no transactions in 24+ months) maxes out at 6/10 no matter how many classes they take, how many events they attend, or how reliably they pay their dues. 75% of Mainstreet's 18,275 members are Foundation members. The current system tells the association that most of their members are disengaged, which isn't true â€” they're engaged differently.

This redesign makes three changes:

1. **Tier-aware scoring**: Each tier gets its own formula weighted to the activities that matter for that tier. A Foundation member who takes classes, pays on time, and opens emails can score 10/10.

2. **New tier names**: "License Maintainer" â†’ **Foundation**. "Occasional Producer" â†’ **Builder**. "Active Producer" â†’ **Rainmaker**. Every name is positive. No member is defined by what they don't do.

3. **New engagement labels**: "Critical/High/Medium/Low risk" â†’ **Disconnected/Drifting/Connected/Highly Connected**. The language shifts from alarm to action.

The database column values for tier (`active_producer`, `occasional_producer`, `license_maintainer`) stay the same for now â€” only the display labels change. The `risk_level` column values (`critical`, `high`, `medium`, `low`) also stay the same in the database â€” only the display labels change. This means existing queries, filters, and audience builders all keep working. A future migration prompt will rename the database values to match the new labels, but that's a separate change to avoid breaking stored queries in saved audiences.

**Important: All tier labels are SINGULAR.** The badge on a member's profile says "Foundation" not "Foundations." When referring to the group, use "Foundation members" â€” but the tier name itself is always one word: Foundation, Builder, Rainmaker.

---

## CHANGE 1: New Scoring Formula in `memberMetricsCacheService.ts`

### Current Activity Query Is Too Simple

The current activity query (lines 190-200) counts ALL activities with a single `COUNT(*)`. The new scoring needs to distinguish between education courses and events, and needs counts within the last 12 months specifically. It also needs to count education hours, not just activity records.

**Replace the activity query** (lines 190-200 of `memberMetricsCacheService.ts`) with:

```typescript
const activityQuery = `
  SELECT 
    member_key,
    MAX(COALESCE(completion_date, start_datetime)) as last_activity_date,
    (ARRAY_AGG(activity_source ORDER BY COALESCE(completion_date, start_datetime) DESC NULLS LAST))[1] as source,
    COUNT(*) FILTER (
      WHERE (is_completed = true OR is_attended = true)
    ) as activity_count,
    -- New: education activities in last 12 months (CE courses)
    COUNT(*) FILTER (
      WHERE activity_source = 'member_education'
        AND is_completed = true
        AND completion_date >= NOW() - INTERVAL '12 months'
        AND course_type IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses', 'Post Lic 45-Hour Courses', 'Post Lisc Indiv. 15-HR Courses')
    ) as education_count_12mo,
    -- New: CE hours in last 12 months
    COALESCE(SUM(
      CASE 
        WHEN activity_source = 'member_education'
          AND is_completed = true
          AND completion_date >= NOW() - INTERVAL '12 months'
          AND course_type IN ('Core', '4 Hour Core Requirement', 'Elective', 'Post Lic 3-15-HR Courses', 'Post Lic 45-Hour Courses', 'Post Lisc Indiv. 15-HR Courses')
        THEN CAST(NULLIF(education_credits, '') AS NUMERIC)
        ELSE 0
      END
    ), 0) as ce_hours_12mo,
    -- New: event attendance in last 12 months (non-CE events)
    COUNT(*) FILTER (
      WHERE activity_source = 'event_registration'
        AND is_attended = true
        AND start_datetime >= NOW() - INTERVAL '12 months'
    ) as events_attended_12mo,
    -- New: any activity in last 90 days (for recency)
    COUNT(*) FILTER (
      WHERE (is_completed = true OR is_attended = true)
        AND COALESCE(completion_date, start_datetime) >= NOW() - INTERVAL '90 days'
    ) as activity_count_90d
  FROM activity_cache
  WHERE member_key = ANY($1)
    AND (is_completed = true OR is_attended = true)
  GROUP BY member_key
`;
```

**Update the activityMap** to store the richer data. Change the map type and the loop that populates it (lines 201-208):

```typescript
// Update the type at the top of the activityMap
const activityMap = new Map<string, {
  lastActivityDate: Date | null;
  source: string | null;
  activityCount: number;
  educationCount12mo: number;
  ceHours12mo: number;
  eventsAttended12mo: number;
  activityCount90d: number;
}>();

// In the loop:
for (const row of activityResult.rows) {
  activityMap.set(row.member_key, {
    lastActivityDate: row.last_activity_date ? new Date(row.last_activity_date) : null,
    source: row.source === 'member_education' ? 'education' : 'event',
    activityCount: parseInt(row.activity_count) || 0,
    educationCount12mo: parseInt(row.education_count_12mo) || 0,
    ceHours12mo: parseFloat(row.ce_hours_12mo) || 0,
    eventsAttended12mo: parseInt(row.events_attended_12mo) || 0,
    activityCount90d: parseInt(row.activity_count_90d) || 0,
  });
}
```

### Add Email Engagement Query

After the activity query block (around line 213, after `activityClient.release()`), add a new query for email engagement data:

```typescript
// Step 5b: Get email engagement data from local email_events table
console.log('[METRICS_CACHE] Fetching email engagement data...');
const emailEngagementMap = new Map<string, { hasOpened: boolean; hasClicked: boolean }>();

try {
  const emailClient = await localPool.connect();
  try {
    for (let i = 0; i < memberKeys.length; i += 1000) {
      const batchKeys = memberKeys.slice(i, i + 1000);
      const emailQuery = `
        SELECT 
          member_key,
          bool_or(event_type = 'opened') as has_opened,
          bool_or(event_type = 'clicked') as has_clicked
        FROM email_events
        WHERE member_key = ANY($1)
          AND event_timestamp >= NOW() - INTERVAL '90 days'
        GROUP BY member_key
      `;
      const emailResult = await emailClient.query(emailQuery, [batchKeys]);
      for (const row of emailResult.rows) {
        emailEngagementMap.set(row.member_key, {
          hasOpened: row.has_opened || false,
          hasClicked: row.has_clicked || false,
        });
      }
    }
  } finally {
    emailClient.release();
  }
  console.log(`[METRICS_CACHE] Retrieved email engagement for ${emailEngagementMap.size} members`);
} catch (emailErr) {
  // Email engagement is a bonus â€” don't fail the whole refresh if this query has issues
  console.warn('[METRICS_CACHE] Email engagement query failed (non-fatal):', emailErr);
}
```

**Note on email data cold start:** New clients won't have email engagement data until they start sending campaigns through SmartSends. This is fine â€” the email engagement point (0-1) simply won't be awarded, and the rest of the score works correctly. As campaigns go out and members open/click, the data accumulates naturally. No special handling is needed.

### Replace the Scoring Logic

Replace lines 240-272 (the current scoring block) with this tier-aware scoring:

```typescript
let tier = 'license_maintainer';
if (tx.tx12mo >= 2) tier = 'active_producer';
else if (tx.tx24mo >= 1) tier = 'occasional_producer';

const emailEngagement = emailEngagementMap.get(m.MemberKey) || { hasOpened: false, hasClicked: false };
const hasDesignations = m.MemberDesignations && Array.isArray(m.MemberDesignations) && m.MemberDesignations.length > 0;

let score = 0;

if (tier === 'active_producer') {
  // ===== RAINMAKER SCORING (2+ tx in 12 months) =====
  // Transaction activity: 0-3 points
  if (tx.tx12mo >= 8) score += 3;
  else if (tx.tx12mo >= 4) score += 2;
  else score += 1; // They have at least 2 (tier requirement)
  
  // Education/Events: 0-2 points
  const eduEvents = activity.educationCount12mo + activity.eventsAttended12mo;
  if (eduEvents >= 3) score += 2;
  else if (eduEvents >= 1) score += 1;
  
  // Payment: 0-2 points
  if (pay.overdueCount === 0) score += 2;
  else if (pay.overdueCount <= 2) score += 1;
  
  // Email engagement: 0-1 point
  if (emailEngagement.hasOpened || emailEngagement.hasClicked) score += 1;
  
  // Recency: 0-1 point (activity in last 90 days)
  const hasRecentActivity = 
    (tx.lastTxDate && tx.lastTxDate >= ninetyDaysAgo) || 
    activity.activityCount90d > 0;
  if (hasRecentActivity) score += 1;
  
  // Designation/Leadership: 0-1 point
  if (hasDesignations) score += 1;
  
} else if (tier === 'occasional_producer') {
  // ===== BUILDER SCORING (1+ tx in 24 months, <2 in 12) =====
  // Transaction recency: 0-2 points
  if (tx.tx12mo >= 1) score += 2;  // Had a transaction this year
  else if (tx.lastTxDate && tx.lastTxDate >= new Date(now.getTime() - 18 * 30 * 24 * 60 * 60 * 1000)) score += 1; // Within 18 months
  
  // Education/Events: 0-3 points (this is how Builders connect)
  const eduEvents = activity.educationCount12mo + activity.eventsAttended12mo;
  if (eduEvents >= 4) score += 3;
  else if (eduEvents >= 2) score += 2;
  else if (eduEvents >= 1) score += 1;
  
  // Payment: 0-2 points
  if (pay.overdueCount === 0) score += 2;
  else if (pay.overdueCount <= 2) score += 1;
  
  // Email engagement: 0-1 point
  if (emailEngagement.hasOpened || emailEngagement.hasClicked) score += 1;
  
  // Recency: 0-1 point
  const hasRecentActivity = 
    (tx.lastTxDate && tx.lastTxDate >= ninetyDaysAgo) || 
    activity.activityCount90d > 0;
  if (hasRecentActivity) score += 1;
  
  // Designation/Leadership: 0-1 point
  if (hasDesignations) score += 1;
  
} else {
  // ===== FOUNDATION SCORING (0 transactions in 24 months) =====
  // Education/Events: 0-4 points (this IS their engagement)
  const eduCount = activity.educationCount12mo;
  const eventCount = activity.eventsAttended12mo;
  const totalEduEvents = eduCount + eventCount;
  
  if (totalEduEvents >= 4) score += 4;
  else if (totalEduEvents >= 2) score += 3;
  else if (totalEduEvents >= 1) score += 2;
  else if (activity.ceHours12mo > 0) score += 1; // Some CE hours even if < 1 full course counted
  
  // Payment behavior: 0-3 points (paying on time = committed member)
  if (pay.overdueCount === 0 && pay.totalBalanceDue <= 0) score += 3;
  else if (pay.overdueCount === 0) score += 2;
  else if (pay.overdueCount <= 2) score += 1;
  
  // Email engagement: 0-1 point
  if (emailEngagement.hasOpened || emailEngagement.hasClicked) score += 1;
  
  // Recency of any activity: 0-1 point
  if (activity.activityCount90d > 0) score += 1;
  
  // Designation/Leadership: 0-1 point
  if (hasDesignations) score += 1;
}

// Cap score at 10
score = Math.min(score, 10);

// Risk level thresholds (same column values, new meaning)
// These become: Disconnected (0-2), Drifting (3-4), Connected (5-7), Highly Connected (8-10)
let risk = 'medium';
if (score >= 8) risk = 'low';        // Highly Connected
else if (score >= 5) risk = 'medium'; // Connected
else if (score >= 3) risk = 'high';   // Drifting
else risk = 'critical';               // Disconnected
```

**Important**: Add the `ninetyDaysAgo` variable BEFORE the scoring loop starts (before line 228's `for` loop). It should be computed once, not inside the loop:

```typescript
const now = new Date();
const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
```

Also update the default for the activity map fallback (around line 238):

```typescript
const activity = activityMap.get(m.MemberKey) || { 
  lastActivityDate: null, source: null, activityCount: 0, 
  educationCount12mo: 0, ceHours12mo: 0, eventsAttended12mo: 0, activityCount90d: 0 
};
```

---

## CHANGE 2: Update Display Labels (Frontend)

### ScoreBadge.tsx â€” Tier Labels and Risk Labels

In `client/src/components/shared/ScoreBadge.tsx`:

**TierBadge labels (line 95-98):** Change to:
```typescript
const labels = {
  active_producer: "Rainmaker",
  occasional_producer: "Builder",
  license_maintainer: "Foundation",
};
```

**TierBadge colors (lines 101-104):** Update colors to be warm and positive for all tiers:
```typescript
const colors = {
  active_producer: "bg-amber-500/10 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/20 dark:border-amber-500/30",
  occasional_producer: "bg-blue-500/10 dark:bg-blue-500/20 text-blue-700 dark:text-blue-300 border border-blue-500/20 dark:border-blue-500/30",
  license_maintainer: "bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 dark:border-emerald-500/30",
};
```

Note: Foundation (license_maintainer) gets green/emerald â€” the most positive color â€” because this is the largest tier and the one the product is designed to celebrate.

**RiskBadge labels (lines 63-67):** Change to engagement labels:
```typescript
const labels = {
  critical: "Disconnected",
  high: "Drifting",
  medium: "Connected",
  low: "Highly Connected",
};
```

**RiskBadge colors (lines 56-61):** Disconnected and Drifting must carry visual urgency â€” these members are at real risk of leaving. The words are more descriptive than "Critical" and "High Risk," but they need to hit just as hard visually:
```typescript
const colors = {
  critical: "bg-red-700 dark:bg-red-800 text-white",
  high: "bg-orange-500 dark:bg-orange-600 text-white",
  medium: "bg-blue-500 dark:bg-blue-600 text-white",
  low: "bg-emerald-500 dark:bg-emerald-600 text-white",
};
```

**ScoreBadge color thresholds (lines 11-14):** Update to match new score distribution:
```typescript
const getScoreColor = (score: number) => {
  if (score >= 8) return "bg-emerald-500 dark:bg-emerald-600";  // Highly Connected
  if (score >= 5) return "bg-blue-500 dark:bg-blue-600";        // Connected
  if (score >= 3) return "bg-orange-500 dark:bg-orange-600";    // Drifting
  return "bg-red-700 dark:bg-red-800";                           // Disconnected
};
```

**ScoreBadge icon colors (lines 17-21):** Match:
```typescript
const getScoreIcon = (score: number) => {
  if (score >= 8) return <Circle className="h-2 w-2 fill-emerald-500 text-emerald-500 dark:fill-emerald-400 dark:text-emerald-400" />;
  if (score >= 5) return <Circle className="h-2 w-2 fill-blue-500 text-blue-500 dark:fill-blue-400 dark:text-blue-400" />;
  if (score >= 3) return <Circle className="h-2 w-2 fill-orange-500 text-orange-500 dark:fill-orange-400 dark:text-orange-400" />;
  return <Circle className="h-2 w-2 fill-red-600 text-red-600 dark:fill-red-400 dark:text-red-400" />;
};
```

### MemberDetail.tsx â€” Tier Tooltip and Score Breakdown

In `client/src/pages/MemberDetail.tsx`, find the tooltip that shows the score breakdown (around lines 405-418). Replace the hardcoded tier names and score ranges:

```tsx
<div className="space-y-1 text-xs text-muted-foreground">
  <p className="font-medium text-foreground mb-1">Score is tier-adjusted:</p>
  <div className="flex justify-between">
    <span>ðŸŒŸ Rainmaker</span>
    <span>Weighted to transactions</span>
  </div>
  <div className="flex justify-between">
    <span>ðŸ”¨ Builder</span>
    <span>Weighted to growth activities</span>
  </div>
  <div className="flex justify-between">
    <span>ðŸ›ï¸ Foundation</span>
    <span>Weighted to education & payment</span>
  </div>
  <Separator className="my-1" />
  <div className="space-y-0.5">
    <div className="flex justify-between"><span>Highly Connected</span><span>8-10</span></div>
    <div className="flex justify-between"><span>Connected</span><span>5-7</span></div>
    <div className="flex justify-between"><span>Drifting</span><span>3-4</span></div>
    <div className="flex justify-between"><span>Disconnected</span><span>0-2</span></div>
  </div>
</div>
```

Also in MemberDetail.tsx, find every hardcoded instance of "Active Producer", "Occasional Producer", "License Maintainer" (around lines 407, 411, 415) and replace:
- "Active Producer" â†’ "Rainmaker"
- "Occasional Producer" â†’ "Builder"  
- "License Maintainer" â†’ "Foundation"

### SmartSends.tsx â€” Audience Filter Dropdowns

In `client/src/pages/SmartSends.tsx`, find the tier filter SelectItems (around lines 615-617):

```tsx
<SelectItem value="active">Rainmaker</SelectItem>
<SelectItem value="occasional">Builder</SelectItem>
<SelectItem value="license">Foundation</SelectItem>
```

Also change the "At-Risk Members" option (line 618):
```tsx
<SelectItem value="at-risk">Drifting & Disconnected</SelectItem>
```

### CampaignDetail.tsx â€” Same Filter Dropdowns

In `client/src/pages/CampaignDetail.tsx`, find the same tier filter (around lines 485-487) and make the same changes:

```tsx
<SelectItem value="active">Rainmaker</SelectItem>
<SelectItem value="occasional">Builder</SelectItem>
<SelectItem value="license">Foundation</SelectItem>
```

### Dashboard.tsx â€” Tier Labels in Metrics

In `client/src/pages/Dashboard.tsx`, find where tier labels are displayed (around line 55). Change:
- "Active Producers" â†’ "Rainmaker"
- "Occasional Producers" â†’ "Builder"
- "License Maintainers" â†’ "Foundation"

Search the entire Dashboard.tsx for any other instances of the old names.

### OfficeDetail.tsx â€” "At Risk" â†’ "Needs Attention"

In `client/src/pages/OfficeDetail.tsx`, the "Members Needing Attention" section (around line 673) already uses good language. Search for any instances of "At Risk" displayed as user-visible text and replace with "Needs Attention" â€” but keep the red/orange visual treatment. The language is more descriptive but the urgency must remain. Members who are Drifting or Disconnected are genuinely at risk of not renewing. The colors should make an executive's eye land there first.

The `atRiskCount`, `atRiskPercentage`, `atRiskAgents` variable names stay the same (they're internal). Only change what the USER sees.

---

## CHANGE 3: Update TypeScript Types

### schema.ts â€” Type Aliases and Interface Labels

In `shared/schema.ts`, update the tierLabel references in the `MemberListItem` interface. The `MemberTier` type stays the same (the DB values don't change):

```typescript
// Line 689 â€” Keep as-is (database values unchanged)
export type MemberTier = "active_producer" | "occasional_producer" | "license_maintainer";

// Line 691 â€” Keep as-is (database values unchanged)  
export type RiskLevel = "critical" | "high" | "medium" | "low";
```

Add a display label mapping constant after line 693:

```typescript
// Display label mappings (database values â†’ user-facing names)
export const TIER_LABELS: Record<MemberTier, string> = {
  active_producer: "Rainmaker",
  occasional_producer: "Builder",
  license_maintainer: "Foundation",
};

export const ENGAGEMENT_LABELS: Record<RiskLevel, string> = {
  critical: "Disconnected",
  high: "Drifting",
  medium: "Connected",
  low: "Highly Connected",
};
```

Update the `DashboardMetrics` interface (around line 809) to use the new tier names in comments but keep the property names:

```typescript
export interface DashboardMetrics {
  totalActiveMembers: {
    total: number;
    activeProducers: number;     // Rainmakers
    occasionalProducers: number; // Builders
    licenseMaintainers: number;  // Foundation
  };
  // ... rest stays the same
}
```

---

## CHANGE 4: Update Backend Label Generation

### storage.ts â€” tierLabel Strings

In `server/storage.ts`, find all places that generate `tierLabel` strings. There are several:

**Line 35 (tier label map):** 
```typescript
const tierLabels: Record<string, string> = {
  active_producer: "Rainmaker",
  occasional_producer: "Builder",
  license_maintainer: "Foundation",
};
```

**Lines 580, 628, 733:** These have inline ternary chains like:
```typescript
row.tier === 'active_producer' ? 'Active Producer' : row.tier === 'occasional_producer' ? 'Occasional Producer' : 'License Maintainer'
```

Replace each with:
```typescript
row.tier === 'active_producer' ? 'Rainmaker' : row.tier === 'occasional_producer' ? 'Builder' : 'Foundation'
```

Or better, use the `tierLabels` map if it's in scope:
```typescript
tierLabels[row.tier] || 'Foundation'
```

### sharedDatabaseSchema.ts â€” AI Prompt Context

In `server/services/sharedDatabaseSchema.ts`, find the tier descriptions (around line 545 and lines 696-698). Update:

**Line 545:**
```
- tier (text) - Classification: 'active_producer' (Rainmaker: 2+ tx/12mo), 'occasional_producer' (Builder: 1+ tx/24mo), 'license_maintainer' (Foundation: 0 tx/24mo)
```

**Lines 696-698:**
```
- Rainmakers (active_producer): 2+ closed transactions in last 12 months (full-time, producing agents)
- Builders (occasional_producer): 1+ transactions in 24 months but <2 in last 12 (growing their career)
- Foundation (license_maintainer): 0 transactions in 24 months (engaged through education, events, community)
```

Also find and update the risk_level description (around line 547):
```
- risk_level (text) - Engagement level: 'low' (Highly Connected, score 8-10), 'medium' (Connected, 5-7), 'high' (Drifting, 3-4), 'critical' (Disconnected, 0-2)
```

### memberMetricsCacheService.ts â€” tierLabel in Cache Insert

In the cache insert values (around line 315 in `memberMetricsCacheService.ts`), make sure the tierLabel that gets stored uses the new names. Search for where tier labels are computed in the insert block. If it generates a label string, update it to use:
- `active_producer` â†’ `Rainmaker`
- `occasional_producer` â†’ `Builder`
- `license_maintainer` â†’ `Foundation`

---

## CHANGE 5: Update Predefined Audience Names

### routes.ts â€” Predefined Audience Labels

In `server/routes.ts`, find the predefined audience cases (around lines 4440-4454):

**Line 4440-4443:** Change:
```typescript
case 'risk-critical':
  audienceName = 'Disconnected Members';
  description = 'Members showing no recent engagement with the association';
  query = `SELECT member_key FROM member_metrics_cache WHERE risk_level = 'critical'`;
  break;
```

**Lines 4445-4448:** Change:
```typescript
case 'risk-high':
  audienceName = 'Drifting Members';
  description = 'Members showing declining engagement â€” a good time to reach out';
  query = `SELECT member_key FROM member_metrics_cache WHERE risk_level = 'high'`;
  break;
```

**Lines 4450-4453:** Change:
```typescript
case 'risk-medium':
  audienceName = 'Connected Members';
  description = 'Members actively engaged with the association';
  query = `SELECT member_key FROM member_metrics_cache WHERE risk_level = 'medium'`;
  break;
```

---

## CHANGE 6: Update the `getHealthStatus` Function

### storage.ts â€” Office Health Status

The `getHealthStatus` function in `server/storage.ts` (line 56) uses `atRiskPercentage` which is still valid â€” it just now means "percentage of Drifting + Disconnected members." The thresholds and logic don't need to change, but the function name and comments should be updated for clarity:

```typescript
// Office health status based on engagement level composition
// "atRiskPercentage" = percentage of members who are Drifting or Disconnected
function getHealthStatus(disconnectedPercentage: number, avgScore: number): HealthStatus {
  if (disconnectedPercentage > 30 || avgScore < 5) return "at_risk";     // Office needs attention
  if (disconnectedPercentage >= 20 || avgScore < 6) return "watch";      // Office worth monitoring
  return "healthy";                                                        // Office is doing well
}
```

---

## CHANGE 7: Update HealthBadge Labels (Optional Enhancement)

The `HealthBadge` in `ScoreBadge.tsx` currently shows "Healthy", "Watch", "At Risk" for office health. These are reasonable labels and can stay, OR you can soften them:

```typescript
const labels = {
  healthy: "Thriving",
  watch: "Developing",
  at_risk: "Needs Focus",
};
```

This is optional â€” the current labels are acceptable for office-level status.

---

## CHANGE 8: Update AIChatBox Suggested Questions

In `client/src/components/ai/AIChatBox.tsx`, find the suggested questions (around line 46). Replace risk-oriented questions:

Change:
```typescript
"Which members are at risk of non-renewal?",
```

To:
```typescript
"Which Foundation members are most connected?",
```

Or add more celebration-oriented suggestions:
```typescript
"How many members completed CE courses this month?",
"Which offices have the most engaged Foundation members?",
"Show me members celebrating milestones this week",
```

---

## Files Modified Summary

| File | Changes |
|------|---------|
| `server/services/memberMetricsCacheService.ts` | New activity query (richer counts), email engagement query, tier-aware scoring formula, updated thresholds |
| `client/src/components/shared/ScoreBadge.tsx` | All label and color changes for TierBadge, RiskBadge, ScoreBadge |
| `client/src/pages/MemberDetail.tsx` | Score tooltip text, tier names |
| `client/src/pages/Dashboard.tsx` | Tier labels in metrics display |
| `client/src/pages/SmartSends.tsx` | Filter dropdown labels |
| `client/src/pages/CampaignDetail.tsx` | Filter dropdown labels |
| `client/src/pages/OfficeDetail.tsx` | User-facing "At Risk" text â†’ "Needs Attention" |
| `client/src/components/ai/AIChatBox.tsx` | Suggested question text |
| `shared/schema.ts` | Add TIER_LABELS and ENGAGEMENT_LABELS constants |
| `server/storage.ts` | tierLabel strings, getHealthStatus comments |
| `server/services/sharedDatabaseSchema.ts` | AI prompt tier and risk descriptions |
| `server/routes.ts` | Predefined audience names and descriptions |

## What Does NOT Change

- Database column names (`tier`, `risk_level`, `engagement_score`)
- Database column values (`active_producer`, `occasional_producer`, `license_maintainer`, `critical`, `high`, `medium`, `low`)
- API response field names (`tier`, `riskLevel`, `isAtRisk`)
- Filter query values (`at-risk`, `active-producers`, `occasional`, `license-maintainers`)
- Audience builder SQL queries (they use DB values, not labels)
- The `MemberTier` and `RiskLevel` TypeScript types

This means every existing saved audience, every existing email campaign, and every existing filter continues to work. The change is entirely in how scores are calculated and how labels are displayed.

---

## Testing Checklist

1. **Trigger a cache refresh** (via the admin endpoint from the stability prompt, or restart the app). Verify it completes without errors.

2. **Dashboard tier counts** should still add up to total active members (~18,275). The numbers per tier won't change â€” tier assignment criteria are the same.

3. **Score distribution will change significantly.** Foundation members who take classes and pay on time will now score 6-8+ instead of 3-5. This is correct and expected. Spot-check a few:
   - A Foundation member with 3 classes, no overdue invoices, and recent email opens â†’ should score ~8-9
   - A Foundation member with no activities, no overdue invoices â†’ should score ~3
   - A Foundation member with nothing (no activities, overdue invoices) â†’ should score 0-1
   - A Rainmaker with 5+ transactions, classes, no overdue â†’ should score 9-10
   - A Builder with 1 recent transaction, 2 classes, pays on time â†’ should score 7-8

4. **Badge colors** â€” verify that tier badges show warm colors (amber for Rainmaker, blue for Builder, emerald for Foundation) and that risk badges show the new labels (Highly Connected, Connected, Drifting, Disconnected).

5. **Member detail page** â€” click into a member and verify the score tooltip shows the new tier names and score explanations.

6. **AI Chat** â€” ask "How many Foundation members are Highly Connected?" and verify the AI understands the terminology. The sharedDatabaseSchema update teaches it the new vocabulary.

7. **Existing audiences** â€” verify saved audiences still load correctly and show proper member counts.

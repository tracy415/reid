# SmartSends: Bug Fixes and Composer Polish
## Replit Prompt — February 21, 2026

---

## CONTEXT FOR REPLIT AGENT

This prompt fixes regressions and gaps found during testing of the Send Email and Automations flows. Some are bugs introduced during the recent Email Composer Enhancements work, some are missing features that should have been implemented, and some are UX consistency issues.

**Priority order:**
1. Fix the Send button (blocking — can't send any emails)
2. Fix the Automations AI generation error (blocking — can't use AI in automations)
3. Restore Insert Event button (removed during enhancement work)
4. Implement Insert Offer and Insert Button tools
5. Fix AI-generated event formatting
6. Fix Resend Campaign to use full wizard
7. Add per-recipient engagement tracking to analytics
8. UX polish items

**CRITICAL RULES:**
- Do NOT break the existing triggered campaign processor
- Do NOT remove or modify the AI generation endpoints — they work correctly
- Test each fix individually before moving to the next

---

## FIX 1: SEND BUTTON REDIRECTS TO SCHEDULE FOR SMART AUDIENCES

**Priority: CRITICAL — users cannot send emails**

### Root Cause

In `SendEmail.tsx`, the `handleSendNow` function (around line 1721) has a fallback path for smart/dynamic audiences. When the selected audience has no `memberKeys` array and no `externalContacts`, the function assumes it can't resolve recipients inline and redirects to the Schedule dialog:

```typescript
} else {
  // Smart/dynamic audience - need to fetch recipients from predefined/AI query
  toast({
    title: "Large Audience",
    description: "For large or dynamic audiences, please use Schedule to queue for batch processing.",
  });
  setShowScheduleDialog(true);
  return;
}
```

Most audiences in MemberSync are smart audiences (SQL-based), including "Realtors, Secondary Members and DRs" with 20,261 members. This means the SEND button effectively never works for the most common audience types.

### Fix

Replace the fallback block with actual recipient resolution for smart audiences. The audience data includes an `audienceId` — use it to fetch recipients from the API, just like the scheduled email processor does:

```typescript
} else if (selectedAudience.audienceId) {
  // Smart/dynamic audience - resolve recipients from saved audience
  try {
    const response = await apiRequest('GET', `/api/smartsends/audiences/${selectedAudience.audienceId}/members`);
    const data = await response.json();
    recipients = (data.members || [])
      .filter((m: any) => m.MemberEmail)
      .map((m: any) => ({
        member_key: m.MemberKey,
        email: m.MemberEmail,
        member_name: m.MemberFullName || '',
      }));
    if (recipients.length === 0) {
      toast({
        title: "No Recipients",
        description: "This audience has no members with email addresses.",
        variant: "destructive",
      });
      return;
    }
  } catch (error) {
    toast({
      title: "Error Loading Recipients",
      description: "Could not resolve audience members. Please try again.",
      variant: "destructive",
    });
    return;
  }
} else {
  toast({
    title: "No Recipients",
    description: "Could not determine recipients for this audience.",
    variant: "destructive",
  });
  return;
}
```

**Also add the API endpoint if it doesn't exist.** Check if `GET /api/smartsends/audiences/:id/members` exists. If not, add it in `routes.ts`:

```typescript
app.get("/api/smartsends/audiences/:id/members", authMiddleware, async (req, res) => {
  try {
    const { getAudienceMembers } = await import("./services/aiAudienceService");
    const data = await getAudienceMembers(req.params.id, { previewOnly: false });
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});
```

**Show a loading indicator** while resolving a large audience — it may take a few seconds for 20K members. Update the SEND button to show "Preparing..." with a spinner during recipient resolution.

---

## FIX 2: AUTOMATIONS AI GENERATION — key_points.map ERROR

**Priority: CRITICAL — AI generation broken in automations**

### Root Cause

The automations composer passes `key_points` as a string or undefined to `/api/smartsends/emails/generate`. The backend function `generateEmail` in `aiEmailService.ts` calls `key_points.map()` (line 176), which fails when `key_points` is not an array.

### Fix (backend — `server/services/aiEmailService.ts`)

Add defensive handling at the top of `generateEmail`, right after destructuring:

```typescript
const { purpose, audience_description, key_points: rawKeyPoints, tone = 'professional', special_offer, cta = 'Learn More', context } = request;

// Normalize key_points to always be an array (or undefined)
const key_points = Array.isArray(rawKeyPoints) 
  ? rawKeyPoints 
  : (typeof rawKeyPoints === 'string' && rawKeyPoints.trim()) 
    ? [rawKeyPoints] 
    : undefined;
```

This ensures `key_points` is always an array or undefined, regardless of what the frontend sends.

### Fix (frontend — `CreateAutomation.tsx`)

Also fix the frontend to send the correct shape. When calling the generate endpoint, ensure `key_points` is either an array or omitted entirely:

```typescript
const generatePayload = {
  purpose,
  audience_description: triggerDescription, // e.g., "Members who register for events"
  tone,
  cta,
  ...(specialOffer ? { special_offer: specialOffer } : {}),
  // Do NOT send key_points as a string — either send an array or omit it
  context: {
    additional_info: automationContextString, // The trigger-type-aware context
  },
};
```

---

## FIX 3: GENERATE EMAIL BUTTON PLACEMENT IN AUTOMATIONS

In `CreateAutomation.tsx`, the "Generate Email" button is positioned on the left side below the form fields. It should be on the right side, aligned with the "Next" button. Move it into the same button row:

```
[← Back]                            [Generate Email →]
```

When clicked, it generates the email AND advances to the Quill editor view (same as Send Email's flow where clicking Next with AI selected generates and advances). The "Next" button should be hidden/replaced by "Generate Email" when the AI method is selected — there shouldn't be two competing buttons.

---

## FIX 4: RESTORE INSERT EVENT BUTTON IN SEND EMAIL COMPOSE STEP

### Problem

The "Insert Event" button was removed from the Compose step toolbar in `SendEmail.tsx` during the recent enhancement work. It used to appear alongside "Edit with AI" and "Edit Manually" in the Review & Edit card header.

### Fix

Verify the Insert Event button is present in the compose step. In the card header area (around line 2639-2668), there should be three buttons when `!isManualEditing && emailDraft`:

```tsx
<div className="flex gap-2 flex-wrap">
  <Button variant="outline" size="sm" onClick={() => setIsRefineModalOpen(true)}>
    <Wand2 className="w-4 h-4 mr-2" /> Edit with AI
  </Button>
  <Button variant="outline" size="sm" onClick={startManualEditing}>
    <Edit className="w-4 h-4 mr-2" /> Edit Manually
  </Button>
  <Button variant="outline" size="sm" onClick={() => setIsEventPickerOpen(true)}>
    <Calendar className="w-4 h-4 mr-2" /> Insert Event
  </Button>
</div>
```

**Also add the Insert Event button in manual editing mode.** When the user is manually editing (the Quill editor is active), show Insert Event in the toolbar area below the editor alongside the merge field badges. The `insertEventBlock` function already handles insertion into the Quill editor — it checks for `quillRef.current` and inserts at the cursor position.

The full toolbar below the Quill editor should show:

```
[ 📅 Insert Event ]  [ 🎁 Insert Offer ]  [ 🔗 Insert Button ]   Merge fields: [First Name] [Last Name] [Office Name] ...
```

---

## FIX 5: IMPLEMENT INSERT OFFER TOOL

Add an "Insert Offer" button in the toolbar area of both `SendEmail.tsx` and `CreateAutomation.tsx`.

### Offer Dialog

When clicked, show a dialog:

```
🎁 Insert Special Offer

Offer headline:
[Free CE Class with Your Membership]

Details (optional):
[Redeem before June 30, 2026]

Button text:
[Claim Your Offer]

Button URL:
[https://mainstreet.org/offer]

[Cancel]              [Insert Offer]
```

### Offer Block HTML

Generate and insert this HTML at the cursor position (or append if no cursor):

```html
<div style="border: 2px solid #d97706; border-radius: 12px; padding: 24px; margin: 24px 0; background-color: #fffbeb; font-family: Overpass, sans-serif; text-align: center;">
  <p style="margin: 0 0 4px 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #d97706;">🎁 Special Offer</p>
  <p style="margin: 0 0 8px 0; font-size: 20px; font-weight: 700; color: #1a202c;">${headline}</p>
  <p style="margin: 0 0 16px 0; color: #555; font-size: 14px;">${details}</p>
  <a href="${url}" style="display: inline-block; background-color: #d97706; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 16px;">${buttonText}</a>
</div>
```

Use the same insertion pattern as `insertEventBlock` — check for Quill editor and insert via `clipboard.dangerouslyPasteHTML`.

---

## FIX 6: IMPLEMENT INSERT BUTTON TOOL

Add an "Insert Button" button in the toolbar area of both flows.

### Button Dialog

```
🔗 Insert Button

Button text:
[Learn More]

Link URL:
[https://]

Style:  ● Primary (teal)  ○ Dark  ○ Outline

[Cancel]             [Insert Button]
```

### Button HTML

**Primary (teal):**
```html
<div style="text-align: center; margin: 24px 0;">
  <a href="${url}" style="display: inline-block; background-color: #3a8a8c; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 16px;">${text}</a>
</div>
```

**Dark:**
```html
<div style="text-align: center; margin: 24px 0;">
  <a href="${url}" style="display: inline-block; background-color: #1a202c; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 16px;">${text}</a>
</div>
```

**Outline:**
```html
<div style="text-align: center; margin: 24px 0;">
  <a href="${url}" style="display: inline-block; background-color: transparent; border: 2px solid #3a8a8c; color: #3a8a8c; padding: 12px 30px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 16px;">${text}</a>
</div>
```

---

## FIX 7: IMPROVE EVENT BLOCK STYLING

Update the `insertEventBlock` function to generate more visually distinct cards. This function exists in `SendEmail.tsx` (around line 1479) and should also be used in `CreateAutomation.tsx`.

**Extract into a shared utility** at `client/src/lib/emailBlocks.ts` so both pages use the same function:

```typescript
export function generateEventBlockHtml(event: {
  name: string;
  eventType: string | null;
  startDateTime: string;
  endDateTime: string | null;
  location: string | null;
  educationCredits: string | null;
  courseType: string | null;
  memberPrice: string | null;
  spotsRemaining: number | null;
  portalUrl: string;
}): string {
  // ... generate the styled HTML block
}
```

**New event block HTML:**

```html
<div style="border: 2px solid #3a8a8c; border-radius: 12px; padding: 24px; margin: 24px 0; background-color: #f0fafa; font-family: Overpass, sans-serif;">
  <p style="margin: 0 0 4px 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #3a8a8c;">
    ${event.eventType === 'class' ? 'Upcoming Class' : 'Upcoming Event'}
  </p>
  <p style="margin: 0 0 12px 0; font-size: 20px; font-weight: 700; color: #1a202c; line-height: 1.3;">
    ${event.name}
  </p>
  <p style="margin: 0 0 8px 0; color: #1a202c; font-weight: 600;">
    📅 ${formattedDate} | ${formattedTime}${endTime ? ' – ' + endTime : ''}
  </p>
  ${event.location ? `<p style="margin: 0 0 8px 0; color: #555;">📍 ${event.location}</p>` : ''}
  <div style="margin: 8px 0 16px 0;">
    ${event.educationCredits && parseFloat(event.educationCredits) > 0 ? 
      `<span style="display: inline-block; background-color: #e6f7f7; padding: 4px 12px; border-radius: 4px; font-size: 13px; color: #2d7a7c; font-weight: 600; margin-right: 8px;">${event.educationCredits} CE Credits${event.courseType ? ' (' + event.courseType + ')' : ''}</span>` : ''}
    ${event.memberPrice ? 
      `<span style="display: inline-block; background-color: #e6f7f7; padding: 4px 12px; border-radius: 4px; font-size: 13px; color: #2d7a7c; font-weight: 600;">$${event.memberPrice}</span>` : ''}
  </div>
  ${event.spotsRemaining !== null && event.spotsRemaining <= 20 ? 
    `<p style="margin: 0 0 12px 0; color: #c53030; font-weight: 600; font-size: 14px;">Only ${event.spotsRemaining} spots remaining!</p>` : ''}
  <div style="text-align: center; margin: 16px 0 4px 0;">
    <a href="${event.portalUrl}" style="display: inline-block; background-color: #3a8a8c; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 16px;">Register Now</a>
  </div>
</div>
```

Key improvements over the current block:
- Colored border and light teal background — clearly distinct from text
- "Upcoming Class" or "Upcoming Event" type label at top
- Larger, bolder event name
- CE credits and price as pill badges instead of plain text
- 24px top/bottom margins for clear separation between multiple blocks

---

## FIX 8: AI-GENERATED EVENTS SHOULD USE LINKED CARDS

### Problem

When the AI generates an email that references upcoming events (like the anniversary email with four class recommendations), it formats them as plain text bullet points with bold names. They're not clickable — there are no registration URLs.

### Root Cause

The `getUpcomingEventsContext()` function in `aiEmailService.ts` provides event names and portal URLs to the AI, but the AI prompt doesn't instruct Claude to generate clickable event cards. The AI formats them as a natural-language list.

### Fix

Update the system prompt in `generateEmail` (aiEmailService.ts, around line 136) to include explicit instructions about event formatting:

Add this to the system prompt after the existing EMAIL_STYLE_GUIDELINES:

```
IMPORTANT — EVENT FORMATTING:
When you include specific real events or classes in the email, format EACH event as a styled card block using this exact HTML pattern:

<div style="border: 2px solid #3a8a8c; border-radius: 12px; padding: 24px; margin: 24px 0; background-color: #f0fafa; font-family: Overpass, sans-serif;">
  <p style="margin: 0 0 4px 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #3a8a8c;">Upcoming Class</p>
  <p style="margin: 0 0 12px 0; font-size: 20px; font-weight: 700; color: #1a202c; line-height: 1.3;">EVENT NAME HERE</p>
  <p style="margin: 0 0 8px 0; color: #1a202c; font-weight: 600;">📅 Date and Time</p>
  <p style="margin: 0 0 8px 0; color: #555;">📍 Location</p>
  <div style="text-align: center; margin: 16px 0 4px 0;">
    <a href="PORTAL_URL_HERE" style="display: inline-block; background-color: #3a8a8c; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 16px;">Register Now</a>
  </div>
</div>

Use "Upcoming Class" for classes and "Upcoming Event" for events/mixers. ALWAYS use the exact portal registration URL provided in the event data for the Register Now button. Never list events as plain text — always use the card format with clickable registration links.

If the email purpose doesn't specifically call for event promotion, limit to 2 most relevant events maximum. If the purpose is specifically about events/classes, include up to 4.
```

This ensures any time the AI references real events, they render as the same styled cards that Insert Event produces, with working registration URLs.

---

## FIX 9: RESEND CAMPAIGN — USE FULL WIZARD INSTEAD OF MODAL

### Problem

Clicking "Resend / Edit" on a campaign detail page opens a stripped-down modal with a basic editor, a dropdown for audiences, and no AI tools. This is inconsistent with the full Send Email wizard experience.

### Fix

Replace the Resend Campaign modal in `CampaignDetail.tsx` with a navigation to the full Send Email wizard, pre-loaded with the campaign data.

**In CampaignDetail.tsx:**

Change the "Resend / Edit" button's onClick from opening the modal to navigating:

```typescript
onClick={() => {
  // Navigate to Send Email with this campaign's data pre-loaded
  navigate(`/smartsends/send?resend=${campaign.campaignId}`);
}}
```

**In SendEmail.tsx:**

On mount, check for a `resend` query parameter. If present, load the campaign data and pre-fill:

```typescript
const searchParams = new URLSearchParams(window.location.search);
const resendCampaignId = searchParams.get('resend');

useEffect(() => {
  if (resendCampaignId) {
    // Fetch original campaign data
    fetch(`/api/smartsends/campaigns/${resendCampaignId}`)
      .then(res => res.json())
      .then(data => {
        // Pre-fill with a new name
        setCampaignName(`${data.campaignName} (Copy)`);
        setSubjectLine(data.subjectLine);
        setEmailDraft({
          subject: data.subjectLine,
          body: data.emailBody,
          preview_text: '',
        });
        // Start at the audience step so user can choose recipients
        setCurrentStep('audience');
      });
  }
}, [resendCampaignId]);
```

**Remove the Resend Campaign dialog** from CampaignDetail.tsx (the `resendDialogOpen` state, the dialog component, and the `resendMutation`).

The user lands in the full wizard at the Choose Audience step, with the email content already loaded. They can change the audience, edit the content with all available tools (AI, Insert Event, etc.), preview it on the template, and send — all through the same flow they already know.

---

## FIX 10: PER-RECIPIENT ENGAGEMENT ON CAMPAIGN DETAIL

### Problem

The Campaign Detail page shows aggregate stats (total delivered, opened, clicked) but no per-recipient breakdown. Users can't see which specific members opened or clicked.

### Fix

**Backend — update the campaign detail endpoint** (in `routes.ts`, wherever `GET /api/smartsends/campaigns/:id` is defined):

Add per-recipient engagement data by joining `email_recipients` with `email_events`:

```typescript
// After fetching recipients, enrich with engagement events
const recipientEngagement = await db.select({
  memberKey: emailRecipients.memberKey,
  emailAddress: emailRecipients.emailAddress,
  status: emailRecipients.status,
  sentAt: emailRecipients.sentAt,
})
.from(emailRecipients)
.where(eq(emailRecipients.campaignId, campaignId));

// Get events for this campaign
const events = await db.select({
  memberKey: emailEvents.memberKey,
  eventType: emailEvents.eventType,
  eventTimestamp: emailEvents.eventTimestamp,
})
.from(emailEvents)
.where(eq(emailEvents.campaignId, campaignId));

// Merge into per-recipient view
const enrichedRecipients = recipientEngagement.map(r => {
  const memberEvents = events.filter(e => e.memberKey === r.memberKey);
  return {
    ...r,
    delivered: memberEvents.some(e => e.eventType === 'delivered'),
    opened: memberEvents.some(e => e.eventType === 'opened'),
    openedAt: memberEvents.find(e => e.eventType === 'opened')?.eventTimestamp || null,
    clicked: memberEvents.some(e => e.eventType === 'clicked'),
    clickedAt: memberEvents.find(e => e.eventType === 'clicked')?.eventTimestamp || null,
    bounced: memberEvents.some(e => e.eventType === 'bounced'),
  };
});
```

Include `enrichedRecipients` in the campaign detail response.

**Frontend — add Recipients table to CampaignDetail.tsx:**

Below the existing stats cards, add a "Recipients" section with a table:

```
Recipients (20,261)                           [Search: ________]  [Filter: All ▾]

| Member              | Email                    | Sent      | Opened    | Clicked   |
|---------------------|--------------------------|-----------|-----------|-----------|
| Sarah Johnson       | sarah@coldwell.com       | Feb 21    | Feb 21    | Feb 21    |
| Mike Chen           | mike@remax.com           | Feb 21    | Feb 21    | —         |
| Lisa Park           | lisa@compass.com         | Feb 21    | —         | —         |
| Tom Wright          | tom@kw.com               | Feb 21    | Bounced   | —         |
```

- Use the existing `DataTable` component for pagination
- Filter options: All, Opened, Not Opened, Clicked, Bounced
- Show member name (look up from `member_metrics_cache` by member_key if not in the recipients data)
- Opened and Clicked columns show the timestamp if yes, "—" if no, or "Bounced" in red if bounced
- Link member names to the Member Detail page

---

## FIX 11: MEMBER DETAIL — ADD OPEN/CLICK STATUS TO EMAIL HISTORY

### Problem

The Member Detail page has an Email History section that shows sent/failed status and date, but no open or click information.

### Fix

**Backend — update the email history endpoint** (`GET /api/members/:memberKey/email-history` in routes.ts, around line 4691):

The endpoint already queries `email_events` and `email_recipients` separately. Enhance the `sentEmails` query to include engagement status:

```typescript
// After fetching sentEmails, enrich with open/click events
const memberEvents = await db.select({
  campaignId: emailEvents.campaignId,
  eventType: emailEvents.eventType,
  eventTimestamp: emailEvents.eventTimestamp,
})
.from(emailEvents)
.where(eq(emailEvents.memberKey, memberKey));

const enrichedSentEmails = sentEmails.map(email => {
  const campaignEvents = memberEvents.filter(e => e.campaignId === email.campaignId);
  return {
    ...email,
    opened: campaignEvents.some(e => e.eventType === 'opened'),
    openedAt: campaignEvents.find(e => e.eventType === 'opened')?.eventTimestamp || null,
    clicked: campaignEvents.some(e => e.eventType === 'clicked'),
    clickedAt: campaignEvents.find(e => e.eventType === 'clicked')?.eventTimestamp || null,
    bounced: campaignEvents.some(e => e.eventType === 'bounced'),
  };
});
```

**Frontend — update MemberDetail.tsx Email History section** (around line 692):

Add open/click indicators to each email row. After the sent date and status badge, add:

```tsx
<div className="flex gap-1 mt-1">
  {email.opened && (
    <Badge variant="secondary" className="text-xs bg-blue-500/10 text-blue-600">
      <Eye className="h-3 w-3 mr-1" /> Opened
    </Badge>
  )}
  {email.clicked && (
    <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-600">
      <MousePointerClick className="h-3 w-3 mr-1" /> Clicked
    </Badge>
  )}
  {email.bounced && (
    <Badge variant="destructive" className="text-xs">
      Bounced
    </Badge>
  )}
</div>
```

---

## FIX 12: SPECIAL OFFER VISUAL TREATMENT IN AI-GENERATED EMAILS

### Problem

When a user checks "Include a special offer" and enters offer text during AI generation, the offer is woven into the email prose with no visual distinction. It should render as a visually distinct offer block.

### Fix

Update the AI generation prompt in `aiEmailService.ts` to include formatting instructions for special offers:

Add to the system prompt:

```
SPECIAL OFFER FORMATTING:
When the user includes a special offer, format it as a visually distinct callout block:

<div style="border: 2px solid #d97706; border-radius: 12px; padding: 24px; margin: 24px 0; background-color: #fffbeb; font-family: Overpass, sans-serif; text-align: center;">
  <p style="margin: 0 0 4px 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #d97706;">🎁 Special Offer</p>
  <p style="margin: 0 0 8px 0; font-size: 20px; font-weight: 700; color: #1a202c;">OFFER HEADLINE</p>
  <p style="margin: 0 0 16px 0; color: #555; font-size: 14px;">OFFER DETAILS</p>
  <a href="#" style="display: inline-block; background-color: #d97706; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 16px;">BUTTON TEXT</a>
</div>

Place the offer block after the main message content, before the closing/signature. The amber/gold styling makes it visually distinct from the teal event cards and CTA buttons.
```

---

## VERIFICATION CHECKLIST

**Critical Fixes:**
- [ ] SEND button works for smart/dynamic audiences (resolves recipients, shows loading state, sends)
- [ ] SEND button still works for static audiences and CSV uploads
- [ ] AI email generation works in Automations (no key_points.map error)
- [ ] Generate Email button is positioned next to Next button in Automations

**Restored/New Features:**
- [ ] Insert Event button visible in Send Email compose step (both Review & Edit mode and manual editing mode)
- [ ] Insert Event button visible in Automations compose step
- [ ] Insert Offer dialog works and inserts styled amber offer block
- [ ] Insert Button dialog works with 3 style options (teal, dark, outline)
- [ ] All three insert tools appear in both Send Email and Automations

**AI Quality:**
- [ ] AI-generated emails format events as styled card blocks with registration URLs
- [ ] AI-generated emails format special offers as styled amber callout blocks
- [ ] Events in AI emails link to correct member portal registration URLs

**UX Consistency:**
- [ ] Resend/Edit on Campaign Detail navigates to full Send Email wizard (not a modal)
- [ ] Resend pre-fills campaign name as "Original Name (Copy)", subject, and body
- [ ] Resend starts at Choose Audience step

**Analytics:**
- [ ] Campaign Detail shows per-recipient table with member name, email, sent, opened, clicked
- [ ] Campaign Detail recipients table has search and filter (All/Opened/Not Opened/Clicked/Bounced)
- [ ] Member Detail Email History shows opened/clicked badges per email

---

## FILES CHANGED

**Modified files:**
- `client/src/pages/SendEmail.tsx` — Fix smart audience sending; restore Insert Event; add Insert Offer and Insert Button; handle `resend` query param
- `client/src/pages/CreateAutomation.tsx` — Fix AI generation payload (key_points); fix Generate Email button position; add Insert Event, Insert Offer, Insert Button to compose step
- `client/src/pages/CampaignDetail.tsx` — Remove Resend modal; navigate to wizard instead; add per-recipient engagement table
- `client/src/pages/MemberDetail.tsx` — Add opened/clicked badges to Email History
- `server/services/aiEmailService.ts` — Normalize key_points to array; add event card and offer block formatting instructions to AI prompt
- `server/routes.ts` — Add `/api/smartsends/audiences/:id/members` if missing; enrich campaign detail with per-recipient engagement; enrich member email history with open/click data

**New files:**
- `client/src/lib/emailBlocks.ts` — Shared utility functions: `generateEventBlockHtml()`, `generateOfferBlockHtml()`, `generateButtonHtml()`, `insertHtmlIntoQuill()`

**NOT modified (do not touch):**
- `server/services/triggeredCampaignProcessor.ts`
- `server/services/emailService.ts`
- `server/services/scheduledEmailProcessor.ts`

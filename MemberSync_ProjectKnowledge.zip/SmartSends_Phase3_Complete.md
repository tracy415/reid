# SmartSends Phase 3: Lapse Prevention System

## Complete Replit Build Guide

Copy and paste this entire prompt into Replit Agent.

---

## CONTEXT

This is Phase 3 of SmartSends. Phase 1 delivered email sending infrastructure and tracking. Phase 2 delivered AI-powered audience building and email composition. Phase 3 adds comprehensive lapse prevention with predictive risk scoring, status change tracking, intervention management, and success analytics.

**Prerequisites from Phases 1 & 2:**
- Two database connections (production read-only, Replit read/write)
- Email sending infrastructure with background processing
- Email campaigns and tracking tables
- AI-powered audience builder and email generator
- Member and office detail pages

**Critical Context - The Lapse Problem:**

Members lapse when payment issues persist beyond 90 days. Mainstreet (via Sirius) controls member status changes:
- Active â†’ Suspended (90+ days overdue)
- Suspended â†’ Inactive (didn't pay, membership terminated)
- Recovery: Suspended/Inactive â†’ Active (paid and restored)

We get member data via ETL from Sirius every ~15 minutes. We have:
- âœ… 3 years of payment history
- âœ… 14-day rolling history table (status changes)
- âœ… Current member state at all times
- âŒ Cannot predict when Sirius will suspend members (they control that)

**Strategy:**
1. Capture status changes daily (before they fall out of 14-day window)
2. Build historical tracking going forward
3. Calculate lapse risk scores for all Active members daily
4. Trigger interventions based on risk + status changes
5. Measure success: recovery rates, revenue saved

---

## PRODUCTION DATABASE SCHEMAS (READ ONLY)

### Table: history.change_history
Parent table that auto-routes to monthly partitions.

| Column | Type | Description |
|--------|------|-------------|
| unique_id | uuid | Primary key |
| source | text | Data source |
| client_id | text | ALWAYS filter = 'MainStreet' |
| data_set | text | Dataset identifier |
| source_unique_id | text | Fallback member key |
| received_datetime | timestamptz | When change was captured |
| source_modification | timestamptz | When change occurred |
| jrecord | jsonb | Full member record as JSON |

Access member fields from jrecord:
- jrecord->>'MemberKey'
- jrecord->>'MemberStatus'
- jrecord->>'MemberFullName'
- jrecord->>'MemberEmail'
- jrecord->>'OfficeKey'
- jrecord->>'NarJoinDate'

### Table: AMS.apmmember
Already defined in Phase 1. Key fields:
- NarJoinDate (date) - when member joined Mainstreet REALTORSÂ®
- MemberDesignations (jsonb)
- MemberStateLicenseExpirationDate (date)

### Table: AMS.apmoffice

| Column | Type | Description |
|--------|------|-------------|
| OfficeKey | text | Primary key |
| OfficeName | text | Office display name |
| OfficePhone | text | Office phone |
| EmailAddress | text | Office email |
| OfficeBrokerKey | text | Links to broker member |
| OfficeManagerKey | text | Links to office manager |
| NumberOfSalespersons | text | Office size |

### Table: AMS.receipt_invoice

| Column | Type | Description |
|--------|------|-------------|
| InvoiceKey | text | Links to apmmemberdues |
| IncurredMemberKey | text | Who payment is for |
| OfficeKey | text | Which office |
| Amount | numeric(20,2) | Payment amount |
| ReceiptDate | date | When payment received |
| PaidBy | text | Who paid (member/broker/office) |

---

## PHASE 3 DELIVERABLES

1. SmartSends database tables for lapse tracking (Replit DB)
2. Daily status change capture job (6 AM)
3. Daily risk scoring job (7 AM)
4. Daily office health job (8 AM)
5. Enhanced member profile with lapse risk indicators + history timeline
6. Enhanced office profile with payment health dashboard
7. Lapse prevention dashboard
8. Smart audiences for lapse prevention
9. Email templates for interventions
10. Success tracking and analytics
11. Backend API endpoints

---

## STEP 1: DATABASE MIGRATION

Create: /server/migrations/003_lapse_prevention_tables.js

\`\`\`javascript
const replitPool = require('../config/replitDb');

async function up() {
  const client = await replitPool.connect();
  
  try {
    await client.query('BEGIN');
    
    // Table 1: member_status_tracking
    await client.query(\`
      CREATE TABLE IF NOT EXISTS member_status_tracking (
        tracking_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        member_key TEXT NOT NULL,
        member_name TEXT,
        member_email TEXT,
        office_key TEXT,
        old_status TEXT NOT NULL,
        new_status TEXT NOT NULL,
        detected_at TIMESTAMP NOT NULL,
        membership_days_at_change INTEGER,
        membership_years_at_change NUMERIC,
        days_overdue_at_change INTEGER,
        balance_due_at_change NUMERIC,
        last_transaction_date DATE,
        last_ce_date DATE,
        last_event_date DATE,
        is_recovery BOOLEAN DEFAULT false,
        recovered_from_status TEXT,
        days_in_problem_status INTEGER,
        intervention_sent BOOLEAN DEFAULT false,
        intervention_campaign_id UUID,
        intervention_sent_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT NOW(),
        CONSTRAINT unique_status_change UNIQUE (member_key, detected_at, new_status)
      )
    \`);
    
    await client.query('CREATE INDEX IF NOT EXISTS idx_status_tracking_member ON member_status_tracking(member_key)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_status_tracking_detected ON member_status_tracking(detected_at DESC)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_status_tracking_new_status ON member_status_tracking(new_status)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_status_tracking_recovery ON member_status_tracking(is_recovery) WHERE is_recovery = true');
    
    // Table 2: member_risk_scores
    await client.query(\`
      CREATE TABLE IF NOT EXISTS member_risk_scores (
        score_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        member_key TEXT NOT NULL,
        scored_at DATE DEFAULT CURRENT_DATE,
        current_status TEXT NOT NULL,
        membership_days INTEGER NOT NULL,
        membership_years NUMERIC NOT NULL,
        office_key TEXT,
        days_overdue INTEGER DEFAULT 0,
        balance_due NUMERIC DEFAULT 0,
        payment_risk_score INTEGER DEFAULT 0,
        payment_risk_factors TEXT[],
        months_since_transaction INTEGER,
        months_since_ce INTEGER,
        months_since_event INTEGER,
        engagement_risk_score INTEGER DEFAULT 0,
        engagement_risk_factors TEXT[],
        total_risk_score INTEGER DEFAULT 0,
        risk_tier TEXT,
        predicted_lapse_probability NUMERIC,
        changed_in_last_14_days BOOLEAN DEFAULT false,
        last_change_date TIMESTAMP,
        last_change_to_status TEXT,
        actually_lapsed BOOLEAN,
        lapse_date DATE,
        days_until_lapse INTEGER,
        created_at TIMESTAMP DEFAULT NOW(),
        CONSTRAINT unique_member_score_date UNIQUE (member_key, scored_at)
      )
    \`);
    
    await client.query('CREATE INDEX IF NOT EXISTS idx_risk_scores_member ON member_risk_scores(member_key)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_risk_scores_date ON member_risk_scores(scored_at DESC)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_risk_scores_tier ON member_risk_scores(risk_tier)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_risk_scores_total ON member_risk_scores(total_risk_score DESC)');
    
    // Table 3: intervention_log
    await client.query(\`
      CREATE TABLE IF NOT EXISTS intervention_log (
        intervention_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        member_key TEXT NOT NULL,
        intervention_type TEXT NOT NULL,
        trigger_reason TEXT NOT NULL,
        campaign_id UUID,
        email_subject TEXT,
        email_sent_at TIMESTAMP,
        member_status_at_intervention TEXT,
        days_overdue_at_intervention INTEGER,
        risk_score_at_intervention INTEGER,
        membership_days_at_intervention INTEGER,
        email_opened BOOLEAN DEFAULT false,
        email_opened_at TIMESTAMP,
        email_clicked BOOLEAN DEFAULT false,
        email_clicked_at TIMESTAMP,
        member_paid BOOLEAN DEFAULT false,
        member_paid_at TIMESTAMP,
        member_recovered BOOLEAN DEFAULT false,
        member_recovered_at TIMESTAMP,
        days_to_payment INTEGER,
        days_to_recovery INTEGER,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      )
    \`);
    
    await client.query('CREATE INDEX IF NOT EXISTS idx_intervention_member ON intervention_log(member_key)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_intervention_type ON intervention_log(intervention_type)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_intervention_sent ON intervention_log(email_sent_at DESC)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_intervention_outcome ON intervention_log(member_recovered) WHERE member_recovered = true');
    
    // Table 4: office_payment_health
    await client.query(\`
      CREATE TABLE IF NOT EXISTS office_payment_health (
        health_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        office_key TEXT NOT NULL,
        calculated_at DATE DEFAULT CURRENT_DATE,
        office_name TEXT,
        office_manager_key TEXT,
        total_members INTEGER,
        members_overdue INTEGER,
        members_suspended INTEGER,
        members_inactive INTEGER,
        total_overdue_balance NUMERIC,
        worst_days_overdue INTEGER,
        critical_risk_count INTEGER,
        high_risk_count INTEGER,
        moderate_risk_count INTEGER,
        low_risk_count INTEGER,
        broker_paid_members INTEGER,
        member_paid_members INTEGER,
        avg_payment_days NUMERIC,
        recoveries_last_30_days INTEGER,
        suspensions_prevented_last_30_days INTEGER,
        payment_health_score NUMERIC,
        health_tier TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        CONSTRAINT unique_office_health_date UNIQUE (office_key, calculated_at)
      )
    \`);
    
    await client.query('CREATE INDEX IF NOT EXISTS idx_office_health_office ON office_payment_health(office_key)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_office_health_date ON office_payment_health(calculated_at DESC)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_office_health_tier ON office_payment_health(health_tier)');
    
    await client.query('COMMIT');
    console.log('âœ“ Lapse prevention tables created successfully');
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Lapse prevention migration failed:', error);
    throw error;
  } finally {
    client.release();
  }
}

module.exports = { up };
\`\`\`

---

## STEP 2: DAILY STATUS CHANGE CAPTURE JOB (6 AM)

Create: /server/jobs/captureStatusChanges.js

\`\`\`javascript
const cron = require('node-cron');
const productionPool = require('../config/productionDb');
const replitPool = require('../config/replitDb');

// Run daily at 6 AM
cron.schedule('0 6 * * *', async () => {
  console.log('ðŸ” Capturing member status changes from last 24 hours...');
  
  try {
    const statusChanges = await productionPool.query(\`
      WITH status_events AS (
        SELECT
          ch.client_id AS "ApmClientId",
          COALESCE(ch.jrecord ->> 'MemberKey', ch.source_unique_id) AS "MemberKey",
          ch.jrecord ->> 'MemberStatus' AS "MemberStatus",
          ch.jrecord ->> 'MemberFullName' AS "MemberFullName",
          ch.jrecord ->> 'MemberEmail' AS "MemberEmail",
          ch.jrecord ->> 'OfficeKey' AS "OfficeKey",
          COALESCE(
            ch.source_modification,
            NULLIF(ch.jrecord ->> 'ModificationTimestamp', '')::timestamptz,
            ch.received_datetime
          ) AS status_modified_at
        FROM history.change_history ch
        WHERE ch.client_id = 'MainStreet'
          AND ch.received_datetime >= (NOW() - INTERVAL '24 hours')
          AND (ch.jrecord ->> 'MemberStatus') IS NOT NULL
      ),
      status_changes AS (
        SELECT
          se.*,
          LAG(se."MemberStatus") OVER (
            PARTITION BY se."MemberKey"
            ORDER BY se.status_modified_at
          ) AS prev_status
        FROM status_events se
      ),
      latest_member AS (
        SELECT DISTINCT ON (m."ApmClientId", m."MemberKey")
          m."ApmClientId", m."MemberKey", m."OfficeKey",
          m."NarJoinDate", m."MemberFullName", m."MemberEmail"
        FROM "AMS"."apmmember" m
        WHERE m."ApmClientId" = 'MainStreet'
        ORDER BY m."ApmClientId", m."MemberKey", m."ApmSourceModificationTimestamp" DESC
      )
      SELECT
        sc."MemberKey",
        COALESCE(sc."MemberFullName", lm."MemberFullName") as member_name,
        COALESCE(sc."MemberEmail", lm."MemberEmail") as member_email,
        COALESCE(sc."OfficeKey", lm."OfficeKey") as office_key,
        lm."NarJoinDate",
        sc.prev_status AS from_status,
        sc."MemberStatus" AS to_status,
        sc.status_modified_at AS status_change_at,
        (sc.status_modified_at::date - lm."NarJoinDate") AS membership_days_at_change
      FROM status_changes sc
      JOIN latest_member lm ON lm."ApmClientId" = sc."ApmClientId" AND lm."MemberKey" = sc."MemberKey"
      WHERE sc.prev_status IS NOT NULL
        AND sc.prev_status <> sc."MemberStatus"
        AND (
          (sc.prev_status = 'Active' AND sc."MemberStatus" = 'Suspended')
          OR (sc.prev_status = 'Suspended' AND sc."MemberStatus" = 'Inactive')
          OR (sc.prev_status = 'Active' AND sc."MemberStatus" = 'Inactive')
          OR (sc.prev_status = 'Suspended' AND sc."MemberStatus" = 'Active')
          OR (sc.prev_status = 'Inactive' AND sc."MemberStatus" = 'Active')
        )
      ORDER BY status_change_at DESC
    \`);
    
    console.log(\`Found \${statusChanges.rows.length} status changes\`);
    
    for (const change of statusChanges.rows) {
      const paymentContext = await getPaymentContext(change.MemberKey);
      const engagementContext = await getEngagementContext(change.MemberKey);
      
      let daysInProblemStatus = null;
      if (change.to_status === 'Active' && (change.from_status === 'Suspended' || change.from_status === 'Inactive')) {
        const previousChange = await replitPool.query(\`
          SELECT detected_at FROM member_status_tracking
          WHERE member_key = \$1 AND new_status = \$2
          ORDER BY detected_at DESC LIMIT 1
        \`, [change.MemberKey, change.from_status]);
        
        if (previousChange.rows.length > 0) {
          daysInProblemStatus = Math.floor(
            (new Date(change.status_change_at) - new Date(previousChange.rows[0].detected_at)) / (1000 * 60 * 60 * 24)
          );
        }
      }
      
      await replitPool.query(\`
        INSERT INTO member_status_tracking
          (member_key, member_name, member_email, office_key,
           old_status, new_status, detected_at,
           membership_days_at_change, membership_years_at_change,
           days_overdue_at_change, balance_due_at_change,
           last_transaction_date, last_ce_date, last_event_date,
           is_recovery, recovered_from_status, days_in_problem_status)
        VALUES (\$1, \$2, \$3, \$4, \$5, \$6, \$7, \$8, \$9, \$10, \$11, \$12, \$13, \$14, \$15, \$16, \$17)
        ON CONFLICT (member_key, detected_at, new_status) DO NOTHING
      \`, [
        change.MemberKey, change.member_name, change.member_email, change.office_key,
        change.from_status, change.to_status, change.status_change_at,
        change.membership_days_at_change,
        Math.round(change.membership_days_at_change / 365.25 * 10) / 10,
        paymentContext.days_overdue, paymentContext.balance_due,
        engagementContext.last_transaction, engagementContext.last_ce, engagementContext.last_event,
        (change.to_status === 'Active' && (change.from_status === 'Suspended' || change.from_status === 'Inactive')),
        (change.to_status === 'Active' ? change.from_status : null),
        daysInProblemStatus
      ]);
      
      // Trigger interventions based on status change
      if (change.from_status === 'Active' && change.to_status === 'Suspended') {
        console.log(\`âš ï¸  \${change.member_name} became SUSPENDED\`);
        await logIntervention(change.MemberKey, 'suspension_notice', 'Status changed to Suspended');
      }
      if (change.from_status === 'Suspended' && change.to_status === 'Inactive') {
        console.log(\`ðŸš¨ \${change.member_name} became INACTIVE\`);
        await logIntervention(change.MemberKey, 'win_back', 'Status changed to Inactive');
      }
      if (change.to_status === 'Active' && change.from_status === 'Suspended') {
        console.log(\`âœ… \${change.member_name} RECOVERED!\`);
        await trackRecoverySuccess(change.MemberKey, 'Suspended', daysInProblemStatus);
      }
    }
    
    console.log('âœ“ Status change capture complete');
  } catch (error) {
    console.error('âŒ Status change capture failed:', error);
  }
});

async function getPaymentContext(memberKey) {
  const result = await productionPool.query(\`
    WITH invoice_latest AS (
      SELECT DISTINCT ON (d."InvoiceKey") d.*
      FROM "AMS"."apmmemberdues" d
      WHERE d."ApmClientId" = 'MainStreet' AND d."is_pending" = false
      ORDER BY d."InvoiceKey", d."ApmSourceModificationTimestamp" DESC
    ),
    payments AS (
      SELECT "InvoiceKey", SUM("Amount") AS paid
      FROM "AMS"."receipt_invoice" WHERE "ApmClientId" = 'MainStreet' GROUP BY 1
    )
    SELECT 
      COALESCE(MAX(CURRENT_DATE - i."DueDate"), 0) as days_overdue,
      COALESCE(SUM(GREATEST(i."InvoiceTotal" - COALESCE(p.paid, 0), 0)), 0) as balance_due
    FROM invoice_latest i
    LEFT JOIN payments p ON p."InvoiceKey" = i."InvoiceKey"
    WHERE i."MemberKey" = \$1
      AND i."DueDate" < CURRENT_DATE
      AND COALESCE(i."PaidStatus", false) = false
  \`, [memberKey]);
  return result.rows[0] || { days_overdue: 0, balance_due: 0 };
}

async function getEngagementContext(memberKey) {
  const result = await productionPool.query(\`
    SELECT 
      MAX(p."CloseDate") as last_transaction,
      MAX(ed."CompletionDate") as last_ce,
      MAX(r."Completion_Date") as last_event
    FROM "AMS"."apmmember" m
    LEFT JOIN "AMS"."apmproperty" p ON (p."ListAgentMlsId" = m."MemberMlsId" OR p."BuyerAgentMlsId" = m."MemberMlsId")
    LEFT JOIN "AMS"."apmmembereducation" ed ON ed."MemberKey" = m."MemberKey"
    LEFT JOIN "AMS"."apmeventregistration" r ON r."MemberKey" = m."MemberKey"
    WHERE m."MemberKey" = \$1 AND m."ApmClientId" = 'MainStreet'
  \`, [memberKey]);
  return result.rows[0] || { last_transaction: null, last_ce: null, last_event: null };
}

async function logIntervention(memberKey, type, reason) {
  await replitPool.query(\`
    INSERT INTO intervention_log (member_key, intervention_type, trigger_reason)
    VALUES (\$1, \$2, \$3)
  \`, [memberKey, type, reason]);
}

async function trackRecoverySuccess(memberKey, fromStatus, daysInStatus) {
  await replitPool.query(\`
    UPDATE intervention_log
    SET member_recovered = true, member_recovered_at = NOW(), days_to_recovery = \$3
    WHERE member_key = \$1 AND member_status_at_intervention = \$2 AND member_recovered = false
  \`, [memberKey, fromStatus, daysInStatus]);
}

console.log('âœ“ Status change capture job scheduled (runs daily at 6 AM)');
module.exports = { getPaymentContext, getEngagementContext };
\`\`\`

---

## STEP 3: DAILY RISK SCORING JOB (7 AM)

Create: /server/jobs/calculateRiskScores.js

\`\`\`javascript
const cron = require('node-cron');
const productionPool = require('../config/productionDb');
const replitPool = require('../config/replitDb');

cron.schedule('0 7 * * *', async () => {
  console.log('ðŸ“Š Calculating lapse risk scores...');
  
  try {
    const members = await productionPool.query(\`
      SELECT DISTINCT ON (m."MemberKey")
        m."MemberKey", m."OfficeKey", m."NarJoinDate", m."MemberStatus",
        m."MemberFullName", m."MemberMlsId",
        (CURRENT_DATE - m."NarJoinDate") AS membership_days
      FROM "AMS"."apmmember" m
      WHERE m."ApmClientId" = 'MainStreet' AND m."MemberStatus" = 'Active' AND m."NarJoinDate" IS NOT NULL
      ORDER BY m."MemberKey", m."ApmSourceModificationTimestamp" DESC
    \`);
    
    let counts = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    
    for (const member of members.rows) {
      const paymentRisk = await calculatePaymentRisk(member.MemberKey);
      const engagementRisk = await calculateEngagementRisk(member.MemberKey, member.MemberMlsId);
      
      const totalRisk = paymentRisk.score + engagementRisk.score;
      const riskTier = totalRisk >= 7 ? 'Critical' : totalRisk >= 5 ? 'High' : totalRisk >= 3 ? 'Medium' : 'Low';
      counts[riskTier]++;
      
      const recentChange = await replitPool.query(\`
        SELECT detected_at, new_status FROM member_status_tracking
        WHERE member_key = \$1 AND detected_at >= CURRENT_DATE - INTERVAL '14 days'
        ORDER BY detected_at DESC LIMIT 1
      \`, [member.MemberKey]);
      
      await replitPool.query(\`
        INSERT INTO member_risk_scores
          (member_key, current_status, membership_days, membership_years, office_key,
           days_overdue, balance_due, payment_risk_score, payment_risk_factors,
           months_since_transaction, months_since_ce, months_since_event,
           engagement_risk_score, engagement_risk_factors,
           total_risk_score, risk_tier, predicted_lapse_probability,
           changed_in_last_14_days, last_change_date, last_change_to_status)
        VALUES (\$1,\$2,\$3,\$4,\$5,\$6,\$7,\$8,\$9,\$10,\$11,\$12,\$13,\$14,\$15,\$16,\$17,\$18,\$19,\$20)
        ON CONFLICT (member_key, scored_at) DO UPDATE SET
          total_risk_score = EXCLUDED.total_risk_score, risk_tier = EXCLUDED.risk_tier
      \`, [
        member.MemberKey, member.MemberStatus, member.membership_days,
        Math.round(member.membership_days / 365.25 * 10) / 10, member.OfficeKey,
        paymentRisk.days_overdue, paymentRisk.balance_due, paymentRisk.score, paymentRisk.factors,
        engagementRisk.months_since_transaction, engagementRisk.months_since_ce, engagementRisk.months_since_event,
        engagementRisk.score, engagementRisk.factors,
        totalRisk, riskTier, Math.min((totalRisk / 10) * 100, 95),
        recentChange.rows.length > 0, recentChange.rows[0]?.detected_at || null, recentChange.rows[0]?.new_status || null
      ]);
      
      // Proactive intervention for Critical risk (not yet suspended)
      if (riskTier === 'Critical' && paymentRisk.days_overdue > 0 && paymentRisk.days_overdue < 90) {
        const alreadySent = await replitPool.query(\`
          SELECT 1 FROM intervention_log
          WHERE member_key = \$1 AND intervention_type = 'proactive_critical'
            AND email_sent_at >= CURRENT_DATE - INTERVAL '7 days' LIMIT 1
        \`, [member.MemberKey]);
        
        if (alreadySent.rows.length === 0) {
          console.log(\`âš ï¸ Critical risk: \${member.MemberFullName}\`);
          await replitPool.query(\`
            INSERT INTO intervention_log (member_key, intervention_type, trigger_reason, risk_score_at_intervention, days_overdue_at_intervention)
            VALUES (\$1, 'proactive_critical', \$2, \$3, \$4)
          \`, [member.MemberKey, \`Risk score \${totalRisk}/10\`, totalRisk, paymentRisk.days_overdue]);
        }
      }
    }
    
    console.log(\`âœ“ Risk scoring complete: Critical=\${counts.Critical}, High=\${counts.High}, Medium=\${counts.Medium}, Low=\${counts.Low}\`);
  } catch (error) {
    console.error('âŒ Risk scoring failed:', error);
  }
});

async function calculatePaymentRisk(memberKey) {
  const result = await productionPool.query(\`
    WITH invoices AS (
      SELECT DISTINCT ON (d."InvoiceKey") d.*, 
        (CURRENT_DATE - d."DueDate") as days_past
      FROM "AMS"."apmmemberdues" d
      WHERE d."MemberKey" = \$1 AND d."ApmClientId" = 'MainStreet'
        AND d."DueDate" < CURRENT_DATE AND COALESCE(d."PaidStatus", false) = false
      ORDER BY d."InvoiceKey", d."ApmSourceModificationTimestamp" DESC
    )
    SELECT COALESCE(MAX(days_past), 0) as worst, COALESCE(SUM("BalanceDue"), 0) as total
    FROM invoices
  \`, [memberKey]);
  
  const { worst, total } = result.rows[0] || { worst: 0, total: 0 };
  let score = 0, factors = [];
  
  if (worst >= 75) { score += 3; factors.push('75_days_overdue'); }
  else if (worst >= 60) { score += 2; factors.push('60_days_overdue'); }
  else if (worst >= 30) { score += 1; factors.push('30_days_overdue'); }
  
  if (total > 1000) { score += 2; factors.push('high_balance'); }
  else if (total > 500) { score += 1; factors.push('moderate_balance'); }
  
  return { score, days_overdue: worst, balance_due: total, factors };
}

async function calculateEngagementRisk(memberKey, memberMlsId) {
  const result = await productionPool.query(\`
    SELECT 
      MAX(p."CloseDate") as last_tx,
      MAX(ed."CompletionDate") as last_ce,
      MAX(r."Completion_Date") as last_ev
    FROM (SELECT 1) x
    LEFT JOIN "AMS"."apmproperty" p ON (p."ListAgentMlsId" = \$2 OR p."BuyerAgentMlsId" = \$2)
    LEFT JOIN "AMS"."apmmembereducation" ed ON ed."MemberKey" = \$1
    LEFT JOIN "AMS"."apmeventregistration" r ON r."MemberKey" = \$1
  \`, [memberKey, memberMlsId]);
  
  const d = result.rows[0] || {};
  const months = (date) => date ? Math.floor((Date.now() - new Date(date)) / (1000*60*60*24*30)) : 999;
  
  const txMonths = months(d.last_tx), ceMonths = months(d.last_ce), evMonths = months(d.last_ev);
  let score = 0, factors = [];
  
  if (txMonths >= 18) { score += 2; factors.push('no_transactions_18mo'); }
  else if (txMonths >= 12) { score += 1; factors.push('no_transactions_12mo'); }
  
  if (ceMonths >= 18) { score += 2; factors.push('no_ce_18mo'); }
  else if (ceMonths >= 12) { score += 1; factors.push('no_ce_12mo'); }
  
  if (evMonths >= 12) { score += 1; factors.push('no_events_12mo'); }
  
  return {
    score, factors,
    months_since_transaction: txMonths === 999 ? null : txMonths,
    months_since_ce: ceMonths === 999 ? null : ceMonths,
    months_since_event: evMonths === 999 ? null : evMonths
  };
}

console.log('âœ“ Risk scoring job scheduled (runs daily at 7 AM)');
\`\`\`

---

## STEP 4: OFFICE HEALTH JOB (8 AM)

Create: /server/jobs/calculateOfficeHealth.js

\`\`\`javascript
const cron = require('node-cron');
const productionPool = require('../config/productionDb');
const replitPool = require('../config/replitDb');

cron.schedule('0 8 * * *', async () => {
  console.log('ðŸ¢ Calculating office payment health...');
  
  try {
    const offices = await productionPool.query(\`
      WITH member_status AS (
        SELECT DISTINCT ON ("MemberKey") "MemberKey", "OfficeKey", "MemberStatus"
        FROM "AMS"."apmmember" WHERE "ApmClientId" = 'MainStreet'
        ORDER BY "MemberKey", "ApmSourceModificationTimestamp" DESC
      ),
      invoices AS (
        SELECT DISTINCT ON (d."InvoiceKey") d.*, (CURRENT_DATE - d."DueDate") as days_past
        FROM "AMS"."apmmemberdues" d
        WHERE d."ApmClientId" = 'MainStreet' AND d."DueDate" < CURRENT_DATE AND COALESCE(d."PaidStatus", false) = false
        ORDER BY d."InvoiceKey", d."ApmSourceModificationTimestamp" DESC
      )
      SELECT 
        ms."OfficeKey",
        COUNT(DISTINCT ms."MemberKey") as total_members,
        COUNT(DISTINCT CASE WHEN i.days_past > 0 THEN ms."MemberKey" END) as members_overdue,
        COUNT(DISTINCT CASE WHEN ms."MemberStatus" = 'Suspended' THEN ms."MemberKey" END) as members_suspended,
        SUM(CASE WHEN i.days_past > 0 THEN i."BalanceDue" ELSE 0 END) as total_overdue,
        MAX(i.days_past) as worst_days,
        COUNT(DISTINCT CASE WHEN i.days_past >= 90 THEN ms."MemberKey" END) as critical_risk,
        COUNT(DISTINCT CASE WHEN i.days_past >= 60 AND i.days_past < 90 THEN ms."MemberKey" END) as high_risk,
        COUNT(DISTINCT CASE WHEN i.days_past >= 30 AND i.days_past < 60 THEN ms."MemberKey" END) as moderate_risk,
        o."OfficeName", o."OfficeManagerKey"
      FROM member_status ms
      LEFT JOIN invoices i ON i."MemberKey" = ms."MemberKey"
      LEFT JOIN (SELECT DISTINCT ON ("OfficeKey") * FROM "AMS"."apmoffice" WHERE "ApmClientId" = 'MainStreet' ORDER BY "OfficeKey", "ApmSourceModificationTimestamp" DESC) o ON o."OfficeKey" = ms."OfficeKey"
      WHERE ms."OfficeKey" IS NOT NULL
      GROUP BY ms."OfficeKey", o."OfficeName", o."OfficeManagerKey"
    \`);
    
    for (const office of offices.rows) {
      const overdueRate = office.members_overdue / Math.max(office.total_members, 1);
      const healthScore = Math.max(0, 100 - (overdueRate * 200) - (office.critical_risk * 10) - (office.high_risk * 5));
      const healthTier = healthScore >= 90 ? 'Excellent' : healthScore >= 70 ? 'Good' : healthScore >= 50 ? 'Fair' : healthScore >= 30 ? 'Poor' : 'Critical';
      
      const recoveries = await replitPool.query(\`
        SELECT COUNT(*) as cnt FROM member_status_tracking
        WHERE office_key = \$1 AND is_recovery = true AND detected_at >= CURRENT_DATE - INTERVAL '30 days'
      \`, [office.OfficeKey]);
      
      await replitPool.query(\`
        INSERT INTO office_payment_health
          (office_key, office_name, office_manager_key, total_members,
           members_overdue, members_suspended, total_overdue_balance, worst_days_overdue,
           critical_risk_count, high_risk_count, moderate_risk_count,
           recoveries_last_30_days, payment_health_score, health_tier)
        VALUES (\$1,\$2,\$3,\$4,\$5,\$6,\$7,\$8,\$9,\$10,\$11,\$12,\$13,\$14)
        ON CONFLICT (office_key, calculated_at) DO UPDATE SET
          members_overdue = EXCLUDED.members_overdue, payment_health_score = EXCLUDED.payment_health_score
      \`, [
        office.OfficeKey, office.OfficeName, office.OfficeManagerKey, office.total_members,
        office.members_overdue, office.members_suspended, office.total_overdue || 0, office.worst_days || 0,
        office.critical_risk, office.high_risk, office.moderate_risk,
        recoveries.rows[0]?.cnt || 0, Math.round(healthScore), healthTier
      ]);
    }
    
    console.log('âœ“ Office health calculation complete');
  } catch (error) {
    console.error('âŒ Office health failed:', error);
  }
});

console.log('âœ“ Office health job scheduled (runs daily at 8 AM)');
\`\`\`

---

## STEP 5: ENHANCED MEMBER PROFILE

Update the member detail page to show lapse risk indicators, history timeline, and risk score trends.

**Member Profile Header Design:**

For LOW RISK members:
\`\`\`
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Sarah Johnson                           ðŸŸ¢ 8.2 (Low Risk)  â”‚
â”‚ REALTOR Â· Active Producer Â· 11 years member                â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ LAPSE RISK: Low (Score: 2/10)                              â”‚
â”‚ âœ… Engaged, current on payments                             â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
\`\`\`

For HIGH/CRITICAL risk members:
\`\`\`
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Mike Chen                              ðŸŸ  4.3 (High Risk)  â”‚
â”‚ REALTOR Â· Occasional Producer Â· 3 years member              â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ ðŸš¨ LAPSE RISK: HIGH (Score: 7/10) - 72% probability        â”‚
â”‚                                                              â”‚
â”‚ âš ï¸ Risk Factors:                                            â”‚
â”‚ â€¢ 67 days overdue ($450)                                    â”‚
â”‚ â€¢ No transactions in 14 months                              â”‚
â”‚ â€¢ No CE classes in 16 months                                â”‚
â”‚                                                              â”‚
â”‚ INTERVENTION STATUS:                                        â”‚
â”‚ â€¢ Payment reminder sent: 5 days ago (opened âœ“)             â”‚
â”‚ â€¢ Estimated suspension: 23 days                             â”‚
â”‚                                                              â”‚
â”‚ [Send Follow-up] [Call Member] [View History]              â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
\`\`\`

For SUSPENDED members:
\`\`\`
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Bob Williams                          ðŸ”´ 2.1 (Critical)    â”‚
â”‚ Secondary Â· License Maintainer Â· 2 years member             â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ ðŸš¨ STATUS: SUSPENDED (as of 3 days ago)                    â”‚
â”‚                                                              â”‚
â”‚ Suspended on: Jan 25, 2026                                  â”‚
â”‚ Reason: 92 days overdue ($680)                              â”‚
â”‚                                                              â”‚
â”‚ INTERVENTION:                                               â”‚
â”‚ â€¢ Suspension notice sent: Jan 25 (not opened)              â”‚
â”‚ â€¢ Follow-up sent: Jan 27 (not opened)                      â”‚
â”‚                                                              â”‚
â”‚ âš¡ URGENT: Will become Inactive in ~30 days                 â”‚
â”‚                                                              â”‚
â”‚ [Send Urgent Email] [Call Now] [Record Payment]            â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
\`\`\`

For RECENTLY RECOVERED members:
\`\`\`
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Lisa Chen                              ðŸŸ¢ 6.8 (Medium)     â”‚
â”‚ REALTOR Â· Active Producer Â· 5 years member                  â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ âœ… RECENTLY RECOVERED (Jan 26, 2026)                        â”‚
â”‚                                                              â”‚
â”‚ Was suspended: 12 days (Jan 14 - Jan 26)                   â”‚
â”‚ Recovered by: Paying $380 in full                          â”‚
â”‚ Intervention successful: Payment reminder email             â”‚
â”‚                                                              â”‚
â”‚ [Send Thank You Email] [View Recovery Timeline]            â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
\`\`\`

**New Tab: Lapse History Timeline**

Show chronological timeline of:
- Status changes (Active â†’ Suspended, etc.)
- Interventions sent (emails, calls)
- Recovery events
- Risk score changes over time (chart)

---

## STEP 6: ENHANCED OFFICE PROFILE

Update the office detail page to show payment health dashboard.

**Office Profile Header:**

For offices WITH issues:
\`\`\`
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Keller Williams Downtown                                    â”‚
â”‚ Office Manager: John Smith | (630) 555-1234                â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ ðŸŸ  OFFICE PAYMENT HEALTH: MODERATE RISK                    â”‚
â”‚                                                              â”‚
â”‚ Total Members: 47                                           â”‚
â”‚ Members with Overdue Invoices: 12 (26%)                    â”‚
â”‚ Total Outstanding: $5,400                                   â”‚
â”‚ Worst Case: 89 days overdue                                â”‚
â”‚                                                              â”‚
â”‚ BREAKDOWN BY RISK:                                          â”‚
â”‚ ðŸ”´ Critical (90+ days): 1 member                           â”‚
â”‚ ðŸŸ  High (60-89 days): 3 members                            â”‚
â”‚ ðŸŸ¡ Moderate (30-59 days): 7 members                        â”‚
â”‚ ðŸŸ¢ Minor (15-29 days): 1 member                            â”‚
â”‚                                                              â”‚
â”‚ [Email Office Manager] [View All At-Risk] [Export List]    â”‚
â”‚                                                              â”‚
â”‚ AT-RISK MEMBERS:                                            â”‚
â”‚ ðŸš¨ Mike Chen - 89 days overdue ($520) [View] [Email]       â”‚
â”‚ ðŸŸ  Sarah J - 67 days overdue ($450) [View] [Email]         â”‚
â”‚ ... and 10 more                                             â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
\`\`\`

For HEALTHY offices:
\`\`\`
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Berkshire Hathaway North                                    â”‚
â”‚ Office Manager: Jane Williams | (630) 555-5678             â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ ðŸŸ¢ OFFICE PAYMENT HEALTH: EXCELLENT                         â”‚
â”‚                                                              â”‚
â”‚ Total Members: 34                                           â”‚
â”‚ Members with Overdue Invoices: 0 (0%)                      â”‚
â”‚ Payment Compliance: 100% âœ“                                  â”‚
â”‚                                                              â”‚
â”‚ ðŸ† Top Performing Office                                    â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
\`\`\`

**New Tab: Office Payment Dashboard**

Include:
- Payment trends chart (last 12 months)
- Broker-paid vs member-paid breakdown
- Intervention success metrics
- Member tenure distribution

---

## STEP 7: LAPSE PREVENTION DASHBOARD

Create: /src/pages/SmartSends/LapsePrevention.jsx

Main dashboard showing:

\`\`\`
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ ðŸŽ¯ Lapse Prevention & Retention                             â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                                                              â”‚
â”‚ MEMBER STATUS OVERVIEW                                      â”‚
â”‚ Active: 18,234  |  Suspended: 12  |  Inactive: 665         â”‚
â”‚                                                              â”‚
â”‚ LAPSE RISK DISTRIBUTION (Active Members)                    â”‚
â”‚                                                              â”‚
â”‚ ðŸ”´ Critical Risk: 89 (0.5%)        [Send Campaign]         â”‚
â”‚    Avg probability: 78%                                     â”‚
â”‚                                                              â”‚
â”‚ ðŸŸ  High Risk: 287 (1.6%)           [Send Campaign]         â”‚
â”‚    Avg probability: 52%                                     â”‚
â”‚                                                              â”‚
â”‚ ðŸŸ¡ Medium Risk: 1,234 (6.8%)                               â”‚
â”‚                                                              â”‚
â”‚ ðŸŸ¢ Low Risk: 16,624 (91.2%)                                â”‚
â”‚                                                              â”‚
â”‚ STATUS CHANGES (Last 7 Days)                                â”‚
â”‚ Became Suspended: 8                                         â”‚
â”‚ Became Inactive: 3                                          â”‚
â”‚ âœ… Recovered: 5 (63% recovery rate)                         â”‚
â”‚                                                              â”‚
â”‚ OFFICES WITH PAYMENT ISSUES                                 â”‚
â”‚ â€¢ Keller Williams Downtown - 12 overdue ($5,400)           â”‚
â”‚ â€¢ RE/MAX Premier - 8 overdue ($3,200)                      â”‚
â”‚ ... and 15 more                                             â”‚
â”‚                                                              â”‚
â”‚ CAMPAIGN PERFORMANCE (Last 30 Days)                         â”‚
â”‚ Interventions Sent: 412                                     â”‚
â”‚ Members Recovered: 187 (45%)                                â”‚
â”‚ Revenue Saved: $84,150                                      â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
\`\`\`

---

## STEP 8: BACKEND API ENDPOINTS

Create: /server/routes/lapse.js

\`\`\`javascript
const express = require('express');
const router = express.Router();
const replitPool = require('../config/replitDb');
const productionPool = require('../config/productionDb');

// Dashboard metrics
router.get('/dashboard/metrics', async (req, res) => {
  try {
    const statusCounts = await productionPool.query(\`
      SELECT "MemberStatus", COUNT(*) as count
      FROM (SELECT DISTINCT ON ("MemberKey") * FROM "AMS"."apmmember" WHERE "ApmClientId" = 'MainStreet' ORDER BY "MemberKey", "ApmSourceModificationTimestamp" DESC) m
      GROUP BY "MemberStatus"
    \`);
    
    const recoveryRate = await replitPool.query(\`
      WITH suspended AS (SELECT COUNT(*) as total FROM member_status_tracking WHERE new_status = 'Suspended' AND detected_at >= CURRENT_DATE - 30),
           recovered AS (SELECT COUNT(*) as total FROM member_status_tracking WHERE new_status = 'Active' AND old_status = 'Suspended' AND detected_at >= CURRENT_DATE - 30)
      SELECT ROUND(100.0 * recovered.total / NULLIF(suspended.total, 0)) as rate FROM suspended, recovered
    \`);
    
    res.json({
      active_members: statusCounts.rows.find(r => r.MemberStatus === 'Active')?.count || 0,
      suspended_members: statusCounts.rows.find(r => r.MemberStatus === 'Suspended')?.count || 0,
      inactive_members: statusCounts.rows.find(r => r.MemberStatus === 'Inactive')?.count || 0,
      recovery_rate: recoveryRate.rows[0]?.rate || 0
    });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Risk distribution
router.get('/dashboard/risk-distribution', async (req, res) => {
  try {
    const result = await replitPool.query(\`
      SELECT risk_tier, COUNT(*) as count, ROUND(AVG(predicted_lapse_probability)) as avg_prob
      FROM member_risk_scores WHERE scored_at = CURRENT_DATE GROUP BY risk_tier
    \`);
    const total = result.rows.reduce((sum, r) => sum + parseInt(r.count), 0);
    res.json(result.rows.map(r => ({ ...r, pct: Math.round(r.count / total * 100) })));
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Recent status changes
router.get('/dashboard/recent-changes', async (req, res) => {
  try {
    const result = await replitPool.query(\`
      SELECT * FROM member_status_tracking WHERE detected_at >= CURRENT_DATE - 7 ORDER BY detected_at DESC LIMIT 20
    \`);
    res.json({ changes: result.rows });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Offices at risk
router.get('/dashboard/offices-at-risk', async (req, res) => {
  try {
    const result = await replitPool.query(\`
      SELECT * FROM office_payment_health WHERE calculated_at = CURRENT_DATE AND members_overdue > 0 ORDER BY total_overdue_balance DESC LIMIT 10
    \`);
    res.json({ offices: result.rows });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Member lapse risk
router.get('/member/:memberKey/risk', async (req, res) => {
  try {
    const result = await replitPool.query(\`SELECT * FROM member_risk_scores WHERE member_key = \$1 ORDER BY scored_at DESC LIMIT 1\`, [req.params.memberKey]);
    res.json(result.rows[0] || null);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Member status history
router.get('/member/:memberKey/status-history', async (req, res) => {
  try {
    const result = await replitPool.query(\`SELECT * FROM member_status_tracking WHERE member_key = \$1 ORDER BY detected_at DESC LIMIT 20\`, [req.params.memberKey]);
    res.json({ history: result.rows });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Member risk history (for chart)
router.get('/member/:memberKey/risk-history', async (req, res) => {
  try {
    const result = await replitPool.query(\`
      SELECT scored_at, total_risk_score, risk_tier, predicted_lapse_probability
      FROM member_risk_scores WHERE member_key = \$1 AND scored_at >= CURRENT_DATE - 90 ORDER BY scored_at ASC
    \`, [req.params.memberKey]);
    res.json({ history: result.rows });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Member interventions
router.get('/member/:memberKey/interventions', async (req, res) => {
  try {
    const result = await replitPool.query(\`SELECT * FROM intervention_log WHERE member_key = \$1 ORDER BY created_at DESC LIMIT 10\`, [req.params.memberKey]);
    res.json({ interventions: result.rows });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Office payment health
router.get('/office/:officeKey/payment-health', async (req, res) => {
  try {
    const result = await replitPool.query(\`SELECT * FROM office_payment_health WHERE office_key = \$1 ORDER BY calculated_at DESC LIMIT 1\`, [req.params.officeKey]);
    res.json(result.rows[0] || null);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// Office at-risk members
router.get('/office/:officeKey/at-risk-members', async (req, res) => {
  try {
    const result = await replitPool.query(\`
      SELECT r.member_key, r.current_status, r.days_overdue, r.balance_due, r.risk_tier, r.total_risk_score
      FROM member_risk_scores r WHERE r.office_key = \$1 AND r.scored_at = CURRENT_DATE AND r.days_overdue > 0 ORDER BY r.days_overdue DESC
    \`, [req.params.officeKey]);
    res.json({ members: result.rows });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

module.exports = router;
\`\`\`

Add to main server: \`app.use('/api/lapse', require('./routes/lapse'));\`

---

## STEP 9: LAPSE PREVENTION EMAIL TEMPLATES

Add these system templates to seed file:

| Template Name | Type | Trigger |
|---------------|------|---------|
| Payment Reminder - 30 Days | lapse_30_days | 30+ days overdue |
| Payment Reminder - 60 Days | lapse_60_days | 60+ days overdue |
| Final Notice - 75 Days | lapse_75_days | 75+ days overdue |
| Account Suspended | lapse_suspended | Status â†’ Suspended |
| Win-Back | lapse_winback | Status â†’ Inactive |
| Recovery Thank You | lapse_recovery | Recovered |
| Proactive Intervention | lapse_proactive | Critical risk score |
| Office Manager Alert | lapse_office_alert | Office has 5+ overdue |

Each template should include merge fields:
- {{FirstName}}, {{LastName}}, {{Amount}}, {{DaysOverdue}}
- {{YearsWithMainstreet}}, {{PaymentLink}}, {{PortalLink}}
- For office: {{OfficeName}}, {{OfficeOverdueCount}}, {{OfficeTotalOverdue}}

---

## STEP 10: SMART AUDIENCES FOR LAPSE PREVENTION

Create pre-built audiences in the audience builder:

| Audience Name | Description | Filter |
|---------------|-------------|--------|
| Critical Risk - Active | Risk score 7+ | risk_tier = 'Critical' AND current_status = 'Active' |
| High Risk - Active | Risk score 5-6 | risk_tier = 'High' AND current_status = 'Active' |
| 30+ Days Overdue | Not yet suspended | days_overdue >= 30 AND days_overdue < 60 |
| 60+ Days Overdue | Suspension imminent | days_overdue >= 60 AND days_overdue < 90 |
| Recently Suspended | Last 7 days | new_status = 'Suspended' AND detected_at >= -7 days |
| Recently Inactive | Last 30 days | new_status = 'Inactive' AND detected_at >= -30 days |
| Recently Recovered | Success stories | is_recovery = true AND detected_at >= -30 days |

---

## STEP 11: NAVIGATION UPDATES

Add to SmartSends navigation:

\`\`\`javascript
{
  label: 'ðŸ“§ SmartSends',
  items: [
    { label: 'Dashboard', path: '/smartsends' },
    { label: 'ðŸŽ¯ Lapse Prevention', path: '/smartsends/lapse-prevention', badge: 'NEW' },
    { label: 'Send Email', path: '/smartsends/send' },
    { label: 'Audiences', path: '/smartsends/audiences' },
    { label: 'Templates', path: '/smartsends/templates' },
    { label: 'Campaigns', path: '/smartsends/campaigns' }
  ]
}
\`\`\`

---

## TESTING CHECKLIST

Before considering Phase 3 complete:

**Database:**
- [ ] All 4 lapse prevention tables created in Replit DB
- [ ] All indexes created
- [ ] Lapse prevention email templates seeded

**Daily Jobs:**
- [ ] Status change capture job runs at 6 AM
- [ ] Risk scoring job runs at 7 AM
- [ ] Office health job runs at 8 AM
- [ ] Jobs can be manually triggered for testing

**Status Change Detection:**
- [ ] Detects Active â†’ Suspended transitions
- [ ] Detects Suspended â†’ Inactive transitions
- [ ] Detects recovery events (Suspended â†’ Active)
- [ ] Stores context at time of change
- [ ] Triggers appropriate interventions

**Risk Scoring:**
- [ ] Scores all Active members daily
- [ ] Payment risk calculated (0-5 points)
- [ ] Engagement risk calculated (0-5 points)
- [ ] Risk tiers assigned: Critical (7+), High (5-6), Medium (3-4), Low (0-2)

**Member Profile:**
- [ ] Shows tenure in header (X years member)
- [ ] Shows risk tier badge with color
- [ ] Shows lapse risk score and probability
- [ ] Shows risk factors for High/Critical
- [ ] Shows intervention history
- [ ] Lapse History tab with timeline
- [ ] Risk score trend chart (90 days)

**Office Profile:**
- [ ] Shows payment health tier
- [ ] Shows member counts by status
- [ ] Shows overdue breakdown by risk level
- [ ] Lists at-risk members
- [ ] Office Payment Dashboard tab

**Lapse Prevention Dashboard:**
- [ ] Member status overview
- [ ] Risk distribution with counts
- [ ] Recent status changes
- [ ] Offices at risk list
- [ ] Campaign performance metrics

**Smart Audiences:**
- [ ] All 7 lapse prevention audiences work
- [ ] Can send campaigns from audience

---

## IMPLEMENTATION ORDER

1. Database migrations (30 min)
2. Seed email templates (15 min)
3. Status change capture job (2-3 hours)
4. Risk scoring job (2-3 hours)
5. Office health job (1-2 hours)
6. Backend API endpoints (2-3 hours)
7. Enhanced member profile UI (3-4 hours)
8. Enhanced office profile UI (2-3 hours)
9. Lapse prevention dashboard (2-3 hours)
10. Smart audiences (1 hour)
11. Navigation updates (30 min)
12. Testing and polish (2-3 hours)

**Total: 18-26 hours Replit Agent work**

---

## SUCCESS CRITERIA

After Phase 3, SmartSends can:

âœ… Capture member status changes daily  
âœ… Build historical tracking going forward  
âœ… Calculate lapse risk scores for all Active members  
âœ… Identify Critical/High risk members before suspension  
âœ… Trigger proactive interventions automatically  
âœ… Track intervention effectiveness  
âœ… Show enhanced member profiles with risk indicators  
âœ… Show office payment health dashboards  
âœ… Provide pre-built audiences for lapse prevention  
âœ… Measure success: recovery rate, revenue saved  

---

**START BUILDING PHASE 3!**

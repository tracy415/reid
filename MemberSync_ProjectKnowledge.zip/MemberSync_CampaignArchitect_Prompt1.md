# MemberSync — Campaign Architect: Prompt 1
## Conversation, AI Planning, and Session Persistence

*Written: March 5, 2026*
*Status: READY TO SEND TO REPLIT*

---

## WHAT THIS PROMPT BUILDS

Campaign Architect is the replacement for the drip sequence builder. It is a conversational AI planning interface that transforms a natural language goal into a complete multi-email campaign structure — no blank canvas, no node graph, no form wizard.

This is the centerpiece of the AEI demo (March 23–27, Minneapolis). It must be polished, fast, and feel genuinely intelligent.

**Prompt 1 covers:**
- New `campaign_architect_sessions` database table
- New API routes for session management and AI planning
- New `aiCampaignPlannerService.ts` — the AI that runs the planning conversation
- Frontend: the Campaign Architect conversation UI with live plan preview
- Session persistence: planning conversations saved and accessible from Automations center
- Audience picker, event multi-select, and saved session management

**Prompt 2 (next session) will cover:**
- Email generation (calling `generateEmail` per step)
- Email editing in the sequence (same EmailComposer)
- A/B test suggestion and approval
- Activation (writing to `triggeredCampaigns` and `triggeredCampaignSteps`)

**Prompt 3 (after AEI) will cover:**
- Sequence analytics view (roll-up + per-email breakdown + member journey)

---

## CONTEXT FOR REPLIT

You are adding the Campaign Architect feature to MemberSync. This is a new section of the Automations area that replaces the current drip sequence builder UI with a conversational AI planning experience.

The existing drip sequence infrastructure (`triggeredCampaigns`, `triggeredCampaignSteps`, `dripSequenceMembers`, `/api/triggered-campaigns/:id/activate-drip`) is what runs campaigns once they're activated. **Do not modify the execution infrastructure.** Campaign Architect is a new front-end to that same backend — a smarter way to create the data that the existing processor already knows how to run.

Read all existing code carefully before writing anything. This feature touches:
- `shared/schema.ts` (new table)
- `server/routes.ts` (new API routes)
- New service file: `server/services/aiCampaignPlannerService.ts`
- `client/src/pages/` (new page: `CampaignArchitect.tsx`)
- `client/src/App.tsx` or router (new route)
- `client/src/pages/SmartSends.tsx` or Automations page (entry point)

---

## PART 1: DATABASE — NEW TABLE

Add to `shared/schema.ts`:

```typescript
export const campaignArchitectSessions = pgTable("campaign_architect_sessions", {
  sessionId: uuid("session_id").primaryKey().default(sql`gen_random_uuid()`),
  
  // Identity
  sessionName: text("session_name").notNull(), // AI-generated default, staff can rename
  
  // Conversation history — array of {role: 'user'|'assistant', content: string}
  messages: jsonb("messages").notNull().default([]),
  
  // Current plan — the AI's latest structured proposal
  // null until AI has made its first proposal
  currentPlan: jsonb("current_plan"),
  
  // Audience context — what the staff selected
  audienceId: uuid("audience_id"),             // if a saved audience was selected
  audienceDescription: text("audience_description"), // human-readable, always present
  estimatedRecipientCount: integer("estimated_recipient_count"),
  
  // Event context — events selected from the picker
  selectedEventIds: text("selected_event_ids").array().default(sql`ARRAY[]::text[]`),
  selectedEventsJson: jsonb("selected_events_json").default([]), // full event data at time of selection
  
  // Status
  status: text("status").notNull().default("planning"), 
  // 'planning' | 'generating' | 'ready_to_activate' | 'activated' | 'abandoned'
  
  // Link to the campaign this session produced (set on activation)
  triggeredCampaignId: uuid("triggered_campaign_id"),
  
  // Ownership
  createdBy: text("created_by").notNull(),
  createdByUserId: uuid("created_by_user_id"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type CampaignArchitectSession = typeof campaignArchitectSessions.$inferSelect;
export const insertCampaignArchitectSessionSchema = createInsertSchema(campaignArchitectSessions).omit({
  sessionId: true,
  createdAt: true,
  updatedAt: true,
});
```

Run `npm run db:push` to sync.

---

## PART 2: THE AI PLANNER SERVICE

Create `server/services/aiCampaignPlannerService.ts`.

This is the most important file in this build. Read it carefully before implementing.

### The AI's Personality and Approach

The Campaign Architect AI is not a form processor. It is the smartest marketing colleague the staffer has ever had — someone who knows association members deeply, understands what works in email campaigns, and can meet the user wherever they are. A front-desk coordinator who's never written a campaign and a CMO who has managed email programs for 20 years should both feel like this AI is speaking directly to them.

**Concretely, this means:**

- **It reads the register of the user's message and matches it.** Short, informal message → warm, conversational reply. Sophisticated, detailed prompt → efficient, peer-level response. It never talks down. It never explains things the user clearly already knows.

- **It explains its reasoning like a colleague, not a system.** When it proposes spacing emails 10 days apart, it says why — "CE compliance emails sent too close together tend to feel like nagging, and I can see your members are already getting a good volume of communication from you this month." Not just what, but why it matters for *this* organization and *these* members.

- **It anticipates the next problem.** After proposing a plan, it flags what to watch out for without being asked. Calendar conflicts, governor limits, audience size concerns, timing relative to event dates — it notices these and mentions them naturally.

- **It asks at most one clarifying question per response, and only when it genuinely needs the answer.** It never interrogates. If it can make a reasonable inference, it makes it and says so. "I'm assuming you want to reach members who haven't completed their CE hours yet — if that's wrong, just let me know and I'll adjust."

- **It never says "Certainly!", "Great question!", "Absolutely!", or any hollow affirmation.** It just responds. Warm, confident, direct.

- **It knows when to stop talking.** When the plan is clear and the user is clearly satisfied, it says so and tells them what the next step is. It doesn't pad.

- **It uses audience language the staff would recognize.** NEVER internal tier labels like "Foundation members" or "Rainmakers." Always use the audience name or description the staff created: "your 4,120 members who haven't attended a class this year" or "the CE compliance audience you selected."

### The Plan JSON Structure

When the AI is ready to propose a plan, it must return a structured JSON object alongside its conversational response. This plan drives the live preview panel on the right side of the screen.

```typescript
export interface CampaignPlan {
  campaignName: string;          // AI-suggested name, staff can rename
  goal: string;                  // One sentence summary of what this campaign accomplishes
  audienceDescription: string;   // Human-readable audience description
  estimatedRecipientCount: number | null;
  totalDurationDays: number;     // From Email 1 to final email
  tone: 'professional' | 'friendly' | 'urgent' | 'mixed'; // 'mixed' = varies across sequence
  
  emails: CampaignPlanEmail[];
  
  abTestSuggestion: {
    emailIndex: number;          // 0-based index of which email to test
    rationale: string;           // Plain English: why this email, what we're testing
    suggestedVariantHint: string; // "Try a more personal subject line for Email 1"
  } | null;
  
  planRationale: string;         // 2-3 sentences explaining the overall structure
  watchOuts: string[];           // Proactive flags: timing conflicts, audience size, etc.
}

export interface CampaignPlanEmail {
  stepNumber: number;            // 1-based
  delayDays: number;             // Days after campaign start (Email 1 = 0)
  anchorDate: string | null;     // ISO date string if anchored to a specific event date
  anchorEventName: string | null; // Event name if date-anchored
  subjectLineSketch: string;     // Not final — a direction for the email
  purposeOneLiner: string;       // What this email does in the sequence
  toneForThisEmail: string;      // e.g. "warm awareness", "social proof", "clear deadline urgency"
  stepRationale: string;         // Why this email at this point — the "colleague reasoning"
}
```

### The System Prompt

```typescript
export const CAMPAIGN_PLANNER_SYSTEM_PROMPT = `
You are the Campaign Architect for MemberSync — an AI campaign strategist built specifically for real estate associations and MLSs. Your job is to help association staff build multi-email sequences that genuinely engage their members.

${MAINSTREET_BRIEFING}

YOUR ROLE IN THIS CONVERSATION:
You are the smartest marketing colleague the staffer has ever worked with. You know real estate association members deeply. You know what works in email campaigns. You can meet users wherever they are — from someone who has never written an email campaign to a CMO who manages sophisticated programs. Both should feel like you're speaking directly to them.

CONVERSATION PRINCIPLES:
- Read the register of the user's message and match it. Short, casual message → warm, conversational reply. Sophisticated, detailed prompt → efficient, peer-level response.
- Explain your reasoning like a colleague, not a system. When you propose spacing emails 10 days apart, say why it matters for this audience. Not just what, but why.
- Anticipate the next problem. After proposing a plan, flag timing conflicts, governor limits, or audience concerns without being asked.
- Ask at most ONE clarifying question per response, and only when you genuinely need the answer to build a good plan. If you can make a reasonable inference, make it and say so.
- Never say "Certainly!", "Great question!", "Absolutely!", "Of course!", or any hollow affirmation. Just respond.
- Never use internal tier labels like "Foundation members" or "Rainmakers" — always use the audience description the staff created.
- Know when to stop talking. When the plan is good and the user seems satisfied, say so and tell them the next step.

WHAT YOU KNOW ABOUT THE AUDIENCE:
When audience data is provided, use it. Reflect back the audience in the staff's own language — the name they gave it, the description they wrote. If audience size is provided, reason about it: a sequence to 40 members should feel different from one to 4,000.

WHAT YOU KNOW ABOUT EVENTS:
When events are selected, anchor the campaign timeline to those real dates. Work backward from event dates to build natural timing: awareness → interest → urgency. When multiple related events are selected (like Code of Ethics + Fair Housing), recognize the compliance storyline and build a narrative arc around it.

CAMPAIGN STRUCTURE PRINCIPLES:
- Most effective sequences for association members: 2–4 emails. More than 4 requires strong justification.
- Foundation/occasional producers respond better to education-focused and community framing than production metrics.
- Non-CE event attendance is a stronger engagement signal than CE (members choose it). Reference this when framing event emails.
- CE compliance emails: space them for urgency without feeling like nagging. 10–14 days between emails works well. Final email 5–7 days before deadline.
- Re-engagement sequences: slower cadence (14–21 days), warmer tone, never make members feel they've done something wrong.
- Anniversary/milestone emails: single email or 2-part maximum. More than that feels opportunistic.
- Tone should vary across a sequence when it makes sense: awareness (friendly/informative) → social proof (warm) → action (professional + urgency).

PLAN PROPOSAL FORMAT:
When you are ready to propose a plan — either because you have enough information or after at most 1–2 exchanges — you MUST return your response in this exact format:

CONVERSATIONAL_RESPONSE: [Your message to the staff — warm, confident, explaining the plan and your reasoning]

PLAN_JSON: [The complete CampaignPlan JSON object]

The conversational response and the JSON are both required when proposing or updating a plan. The JSON drives the live preview panel — it must always be valid and complete.

When you are still gathering context (first message or follow-up clarification), respond conversationally only — no JSON yet.

WHEN TO PROPOSE:
- If the staff's message contains a clear goal + some audience context → propose immediately, noting any assumptions you made
- If the goal is clear but audience is completely unspecified → ask ONE question about audience before proposing
- If goal is vague → ask ONE question to clarify, then propose
- Never ask more than 2 questions total before proposing something. A good plan with stated assumptions is better than endless clarification.

AFTER THE PLAN IS PROPOSED:
The staff may ask to adjust. Treat every adjustment as a conversational exchange. Update the plan and return both a response and updated PLAN_JSON. Examples:
- "Make it 4 emails" → add a step, explain where and why, return updated plan
- "Make it more urgent" → adjust tone and subject line sketches, return updated plan  
- "Start sooner" → compress timing, flag if that creates any concerns, return updated plan
- "Focus on the Fair Housing class more" → restructure rationale, return updated plan

WATCH-OUTS TO SURFACE PROACTIVELY:
- Governor limits: if this audience is also receiving other active campaigns, note it
- Timing: if the sequence end date is very close to or past a key deadline, flag it
- Audience size: if fewer than 50 members, suggest a more personal approach
- Overlapping events: if selected events are very close together, address how the sequence handles that
- April 30, 2026 is the Illinois CE deadline — if CE is mentioned, this date is always relevant

NEVER:
- Invent event names, dates, or locations not in the provided event data
- Reference dues amounts or membership costs
- Use corporate language ("leverage synergies", "best-in-class", "utilize")
- Reference internal system names (member_metrics_cache, triggeredCampaigns, etc.)
- Suggest more than one A/B test per campaign
`;
```

### Service Functions

```typescript
import Anthropic from '@anthropic-ai/sdk';
import { callAnthropicWithRetry } from './aiAudienceService';
import { MAINSTREET_BRIEFING } from './aiEmailService';

const anthropic = new Anthropic();

export interface PlannerMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface PlannerTurn {
  conversationalResponse: string;
  plan: CampaignPlan | null;  // null if still gathering context
  sessionName: string | null; // AI-suggested name when plan first appears
}

export async function runPlannerTurn(
  messages: PlannerMessage[],
  context: {
    audienceDescription?: string;
    estimatedRecipientCount?: number;
    selectedEvents?: Array<{
      eventId: string;
      name: string;
      type: string;
      startDateTime: string;
      location: string;
      educationCredits: string;
      registrationUrl: string;
    }>;
  }
): Promise<PlannerTurn> {
  
  // Build context injection for this turn
  let contextBlock = '';
  
  if (context.audienceDescription) {
    contextBlock += `\nSELECTED AUDIENCE: ${context.audienceDescription}`;
    if (context.estimatedRecipientCount) {
      contextBlock += ` (${context.estimatedRecipientCount.toLocaleString()} members)`;
    }
  }
  
  if (context.selectedEvents && context.selectedEvents.length > 0) {
    contextBlock += `\n\nSELECTED EVENTS FOR THIS CAMPAIGN:\n`;
    for (const event of context.selectedEvents) {
      const date = new Date(event.startDateTime).toLocaleDateString('en-US', {
        weekday: 'long', month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit'
      });
      contextBlock += `- ${event.name} | ${date} | ${event.location} | ${event.educationCredits} CE credits | Registration: ${event.registrationUrl}\n`;
    }
    contextBlock += `\nBuild the campaign timeline anchored to these real event dates.`;
  }

  const systemPrompt = CAMPAIGN_PLANNER_SYSTEM_PROMPT + 
    (contextBlock ? `\n\nCONTEXT FOR THIS SESSION:\n${contextBlock}` : '');

  const response = await callAnthropicWithRetry(anthropic, {
    model: 'claude-sonnet-4-20250514',
    max_tokens: 3000,
    system: systemPrompt,
    messages: messages.map(m => ({ role: m.role, content: m.content })),
  });

  const rawText = response.content[0].type === 'text' ? response.content[0].text : '';
  
  // Parse the response — may contain PLAN_JSON or may be conversational only
  return parsePlannerResponse(rawText);
}

function parsePlannerResponse(raw: string): PlannerTurn {
  const planMarker = 'PLAN_JSON:';
  const responseMarker = 'CONVERSATIONAL_RESPONSE:';
  
  if (raw.includes(planMarker)) {
    // Extract conversational response
    let conversationalResponse = raw;
    if (raw.includes(responseMarker)) {
      const afterMarker = raw.indexOf(responseMarker) + responseMarker.length;
      const beforePlan = raw.indexOf(planMarker);
      conversationalResponse = raw.slice(afterMarker, beforePlan).trim();
    } else {
      conversationalResponse = raw.slice(0, raw.indexOf(planMarker)).trim();
    }
    
    // Extract and parse JSON
    const jsonStart = raw.indexOf(planMarker) + planMarker.length;
    const jsonText = raw.slice(jsonStart).trim()
      .replace(/```json\n?/g, '')
      .replace(/```\n?/g, '')
      .trim();
    
    try {
      const plan: CampaignPlan = JSON.parse(jsonText);
      return {
        conversationalResponse,
        plan,
        sessionName: plan.campaignName || null,
      };
    } catch {
      // JSON parse failed — return conversational only, log warning
      console.warn('Campaign planner returned invalid plan JSON, falling back to conversational');
      return { conversationalResponse: raw, plan: null, sessionName: null };
    }
  }
  
  // No plan yet — pure conversational response
  return { conversationalResponse: raw, plan: null, sessionName: null };
}
```

---

## PART 3: API ROUTES

Add these routes to `server/routes.ts` in the SmartSends / Automations section.

```
// ============================================================
// CAMPAIGN ARCHITECT API
// ============================================================
```

### GET /api/campaign-architect/sessions
Returns all non-abandoned sessions for the current client, ordered by updatedAt DESC.

```typescript
app.get("/api/campaign-architect/sessions", authMiddleware, async (req, res) => {
  const sessions = await db.select()
    .from(campaignArchitectSessions)
    .where(ne(campaignArchitectSessions.status, 'abandoned'))
    .orderBy(desc(campaignArchitectSessions.updatedAt));
  res.json(sessions);
});
```

### POST /api/campaign-architect/sessions
Creates a new planning session.

Body: `{ sessionName?, audienceId?, audienceDescription?, estimatedRecipientCount?, selectedEventIds?, selectedEventsJson? }`

Returns the new session record.

### GET /api/campaign-architect/sessions/:sessionId
Returns a single session by ID including full message history and current plan.

### PATCH /api/campaign-architect/sessions/:sessionId
Updates session fields. Allowed: `sessionName`, `audienceId`, `audienceDescription`, `estimatedRecipientCount`, `selectedEventIds`, `selectedEventsJson`, `status`, `currentPlan`, `messages`.

Always update `updatedAt`.

### POST /api/campaign-architect/sessions/:sessionId/chat
The core route — processes one conversational turn.

```typescript
app.post("/api/campaign-architect/sessions/:sessionId/chat", 
  authMiddleware, requireRole("admin", "staff"), 
  async (req, res) => {
    const { sessionId } = req.params;
    const { message } = req.body;  // The user's latest message
    
    if (!message?.trim()) {
      return res.status(400).json({ message: "Message is required" });
    }
    
    // Load session
    const [session] = await db.select()
      .from(campaignArchitectSessions)
      .where(eq(campaignArchitectSessions.sessionId, sessionId))
      .limit(1);
    
    if (!session) return res.status(404).json({ message: "Session not found" });
    
    // Append user message to history
    const updatedMessages: PlannerMessage[] = [
      ...((session.messages as PlannerMessage[]) || []),
      { role: 'user', content: message }
    ];
    
    // Build context from session
    const context = {
      audienceDescription: session.audienceDescription || undefined,
      estimatedRecipientCount: session.estimatedRecipientCount || undefined,
      selectedEvents: (session.selectedEventsJson as any[]) || [],
    };
    
    // Run the AI planner
    const { runPlannerTurn } = await import('./services/aiCampaignPlannerService');
    const result = await runPlannerTurn(updatedMessages, context);
    
    // Append assistant response to history
    const finalMessages: PlannerMessage[] = [
      ...updatedMessages,
      { role: 'assistant', content: result.conversationalResponse }
    ];
    
    // Build update payload
    const updatePayload: any = {
      messages: finalMessages,
      updatedAt: new Date(),
    };
    
    if (result.plan) {
      updatePayload.currentPlan = result.plan;
      // Auto-name the session if it still has a generic name and AI suggested one
      if (result.sessionName && session.sessionName === 'New Campaign') {
        updatePayload.sessionName = result.sessionName;
      }
      // Advance status to ready_to_generate if still in planning
      if (session.status === 'planning') {
        updatePayload.status = 'planning'; // stays planning until staff explicitly proceeds
      }
    }
    
    await db.update(campaignArchitectSessions)
      .set(updatePayload)
      .where(eq(campaignArchitectSessions.sessionId, sessionId));
    
    res.json({
      response: result.conversationalResponse,
      plan: result.plan,
      sessionName: result.sessionName,
    });
  }
);
```

### GET /api/campaign-architect/events
Returns upcoming events for the event picker. Reuses the existing `getUpcomingEventsContext` logic but returns structured JSON instead of a formatted string.

```typescript
app.get("/api/campaign-architect/events", authMiddleware, async (req, res) => {
  // Query the same events as getUpcomingEventsContext() but return structured array
  // 60-day lookahead, ordered by StartDateTime ASC
  // Each event: { eventId, name, type, courseType, startDateTime, location, 
  //               memberPrice, educationCredits, instructor, registrationUrl }
  // registrationUrl: use buildEventPortalUrl(eventId)
});
```

### DELETE /api/campaign-architect/sessions/:sessionId
Sets status to 'abandoned'. Does not delete the record.

---

## PART 4: FRONTEND — CampaignArchitect.tsx

Create `client/src/pages/CampaignArchitect.tsx`.

This is a full-page experience. Route: `/smartsends/campaign-architect/:sessionId` and `/smartsends/campaign-architect/new`.

### Layout

Two-panel layout on desktop. Single panel (conversation only) on mobile with a "View Plan" toggle button.

```
┌─────────────────────────────────────────────────────────────────┐
│  ← Automations    Campaign Architect    [Rename] [session name] │
├────────────────────────────┬────────────────────────────────────┤
│                            │                                    │
│  CONVERSATION PANEL        │  PLAN PREVIEW PANEL                │
│  (left, ~45% width)        │  (right, ~55% width)               │
│                            │                                    │
│  [Audience selector]       │  [Live plan — updates as AI        │
│  [Event picker]            │   responds with proposals]         │
│                            │                                    │
│  Chat messages             │                                    │
│  (scrollable)              │                                    │
│                            │                                    │
│  [Text input + Send]       │  [Generate Emails button]          │
│                            │  (enabled when plan exists)        │
└────────────────────────────┴────────────────────────────────────┘
```

### Conversation Panel

**Header area (above chat):**

Two optional inputs that give the AI more to work with. Neither is required — staff can skip both and just type their goal.

**Audience selector:**
```
Who should receive this campaign?
[Use a saved audience ▾]  [Let AI suggest]
```
- "Use a saved audience" opens a dropdown/modal with saved audiences from `/api/smartsends/audiences`. Shows audience name, description, and member count.
- "Let AI suggest" dismisses the selector and includes "audience not yet selected" in the context — AI will ask or infer.
- When an audience is selected, show a small chip: "📋 CE Behind - Spring 2026 · 4,120 members [×]"

**Event picker:**
```
Add specific events (optional)
[+ Pick events from calendar ▾]
```
- Opens a panel listing upcoming events from `/api/campaign-architect/events`
- Staff can select multiple events via checkboxes
- Selected events show as chips: "📅 Code of Ethics · Mar 28" [×] "📅 Fair Housing · Apr 12" [×]
- When events are selected, the AI receives the full event data including dates and registration URLs

**Chat area:**

Standard chat message thread. User messages right-aligned (light teal background). AI messages left-aligned (white with subtle border).

The very first AI message in a new session is pre-populated automatically — not waiting for the user to type. It appears as soon as the page loads for a new session:

> "Tell me about the campaign you want to build. What are you trying to accomplish — and for who? The more context you give me, the more useful my plan will be, but even a sentence is enough to get started."

This is hardcoded as the welcome message, not an AI call. It sets the tone immediately.

**Input area:**
Single-line text input that expands to multi-line. Send button (teal). Enter to send (Shift+Enter for newline). Shows "AI is thinking..." with a subtle pulse animation while waiting for response.

Streaming is not required — show the full response when it arrives.

### Plan Preview Panel

This panel is empty with a placeholder when no plan exists yet:
```
         ✦
   Your campaign plan
   will appear here as
   we talk it through.
```

When the AI returns a plan, the panel animates in with the full sequence view. **This transition should feel good — it's the demo moment.**

**Plan header:**
```
[Campaign name — editable inline]
[Goal: one sentence summary]
[Audience: description · N members]
[Duration: X days total]
```

**Sequence timeline:**

```
  ┌──────────────────────────────────────┐
  │ 📧  Email 1 — Day 0                  │
  │     Subject sketch: "..."            │
  │     Tone: warm awareness             │
  │     [rationale line]                 │
  └──────────────────────────────────────┘
           │
     ⏱  Wait 10 days
           │
  ┌──────────────────────────────────────┐
  │ 📧  Email 2 — Day 10                 │
  │     Subject sketch: "..."            │
  │     Tone: social proof               │
  │     [rationale line]                 │
  └──────────────────────────────────────┘
           │
     ⏱  Wait 11 days  (April 17 — 13 days before deadline)
           │
  ┌──────────────────────────────────────┐
  │ 📧  Email 3 — Day 21  ⚡ A/B Test    │
  │     Subject sketch: "..."            │
  │     Tone: clear deadline urgency     │
  │     [rationale line]                 │
  │     A/B: [rationale for test]        │
  └──────────────────────────────────────┘
```

When a step is anchored to an event date (not delay-based), show:
```
📅  Anchored to: Code of Ethics · Mar 28  (8 days before event)
```

**Watch-outs section** (if AI returned any):
```
⚠  Things to keep in mind
   • [watch-out 1]
   • [watch-out 2]
```
Subtle styling — amber text, not alarming.

**Action area at bottom of plan panel:**

```
[Generate Emails →]
```

Teal button. Disabled (greyed out) until a plan exists. This button will be wired in Prompt 2.

For Prompt 1, clicking it shows a toast: "Email generation coming soon — plan is saved."

### Session Naming

The session name appears in the header, editable inline. Click to edit, Enter or blur to save. Calls `PATCH /api/campaign-architect/sessions/:sessionId` with `{ sessionName }`.

When the AI first proposes a plan, if the session is still named "New Campaign", automatically update the name to the AI's suggested `campaignName`. The staff can always rename it.

### Loading and Error States

- AI response loading: pulse animation on the chat input area, "AI is thinking..." text
- Network error: red toast "Something went wrong — your conversation is saved, try again"
- Session load error: redirect to Automations with error toast

---

## PART 5: AUTOMATIONS PAGE LAYOUT

The existing Automations page layout is good and should be preserved. Do not redesign it. The change is additive: insert a Campaign Sequences section at the top of the page, above the existing stat cards and grouped automation lists.

### New Page Structure

```
Automations                                         [+ New Automation]
Set up triggered campaigns that send automatically based on member activity

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✦ Campaign Sequences                                [+ New Sequence]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[Status: All ▾]  [Search sequences...]

[Campaign Sequences table — paginated, 10 rows per page]

[pagination controls]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[1 Active]  [4 Paused]  [6 Drafts]  [75,390 Total Sent]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ACTIVE
[existing automation rows — unchanged]

PAUSED
[existing automation rows — unchanged]

DRAFTS
[existing automation rows — unchanged]
```

The stat cards (Active / Paused / Drafts / Total Sent) act as a natural visual divider between the two sections. They refer to the trigger-based automations below them, not to Campaign Sequences above.

The existing "+ New Automation" button in the top-right header remains and continues to open the existing automation wizard for trigger-based automations (event registration, anniversary, milestone, etc.).

The new "+ New Sequence" button in the Campaign Sequences header is specific to Campaign Architect.

"+ New Sequence" button behavior:
1. Creates a new session via `POST /api/campaign-architect/sessions` with `{ sessionName: 'New Campaign', createdBy: user.fullName }`
2. Navigates to `/smartsends/campaign-architect/:newSessionId`

### Campaign Sequences Table

A standard table. Same visual language as the existing automation rows — do not introduce new design patterns.

**Columns:**

| Name | Status | Audience | Sequence | Last Activity | Created By | Actions |
|------|--------|----------|----------|---------------|------------|---------|

- **Name** — clickable link, navigates to `/smartsends/campaign-architect/:sessionId`. Full name, not truncated.
- **Status** — color-coded pill matching existing automation pill style:
  - Planning → blue
  - Ready to Activate → teal
  - Active → green (same as existing "active" pill)
  - Paused → amber (same as existing "paused" pill)
  - Completed → grey
  - Archived → light grey (hidden by default — see filter note below)
- **Audience** — audience description, truncated at ~40 chars with full text on hover tooltip
- **Sequence** — e.g. "3 emails · 21 days" or "2 of 3 sent" when active
- **Last Activity** — relative time: "Updated 2h ago" (planning), "Email 2 sent yesterday" (active), "Completed Mar 15" (completed)
- **Created By** — staff member name
- **Actions** — contextual per status:
  - Planning / Ready to Activate: [Continue] [···]
  - Active: [View] [Pause] [···]
  - Paused: [View] [Resume] [···]
  - Completed: [View] [Duplicate] [···]
  - [···] menu always contains: Rename, Archive. For Planning/Draft only: Delete.

**Filtering:**
- Status filter dropdown: All / Planning / Active / Paused / Completed. Archived hidden by default.
- "Show archived" toggle at bottom of table reveals archived sessions when clicked.
- Search filters by session name.

**Empty state** (no sessions yet):
```
        ✦
  No campaign sequences yet.
  Build your first one — just describe what you want to accomplish.

        [+ New Sequence]
```

**Pagination:**
- 10 rows per page
- Standard controls at bottom: [← Prev]  1  2  3  [Next →]
- "Showing 1–10 of 24 sequences" count above pagination controls

### Existing Automations Section — No Changes

Everything below the stat cards (Active / Paused / Drafts grouped lists and their rows) remains exactly as it is today. Do not modify the existing automation rows, their actions, or their grouping logic.

The existing automations list also needs pagination — 25 rows per group per page. Add it in this prompt if straightforward; defer to a follow-up prompt if it risks scope creep.

---

## PART 6: ROUTING

Add to the app router:
- `/smartsends/campaign-architect/:sessionId` → `CampaignArchitect.tsx`

No separate "all sessions" page is needed — the full table is always visible on the Automations page. There is no `/smartsends/campaign-architect` list route.

The existing "Create Automation" button for `drip_sequence` type in the Automations wizard should be replaced or redirected to Campaign Architect. Other trigger types (event registration, anniversary, milestone, etc.) continue to use the existing wizard. Only `drip_sequence` goes through Campaign Architect.

---

## ACCEPTANCE CRITERIA

Prompt 1 is complete when:

1. **Schema:** `campaign_architect_sessions` table exists in the database, app starts without errors.

2. **New session:** Clicking "+ New Campaign" from Automations creates a session and navigates to the conversation page.

3. **Welcome message:** On page load for a new session, the AI's opening message appears immediately (hardcoded, no API call).

4. **Audience selector:** Staff can select a saved audience. The chip appears. The selected audience is saved to the session.

5. **Event picker:** Staff can select one or more upcoming events. Event chips appear. Selected events are saved to the session.

6. **Conversation:** Staff types a message and sends it. The AI responds conversationally. The exchange appears in the chat thread.

7. **Plan proposal:** When the AI proposes a plan, the plan preview panel populates with the full sequence view — campaign name, goal, email cards with subject sketch and rationale, wait connectors, A/B test indicator if applicable, watch-outs if any.

8. **Plan updates:** If staff sends a follow-up adjustment ("make it 4 emails"), the AI responds and the plan panel updates to reflect the new structure.

9. **Session naming:** When AI first proposes a plan, the session name in the header updates to the AI's suggested campaign name. Staff can click the name to rename it. Rename saves on Enter or blur.

10. **Persistence:** Refreshing the page restores the full conversation history and current plan. Coming back to the session the next day shows everything as it was left.

11. **Session table:** The Automations page shows the Campaign Sequences section at the top with the full paginated table. Status filter and search work. Empty state shows when no sessions exist. Existing automations below the stat cards are unchanged.

12. **Generate Emails button:** Appears in plan panel, disabled until plan exists, shows "coming soon" toast when clicked (Prompt 2 will wire this).

13. **No regressions:** Existing Automations functionality (event registration, anniversary, milestone triggers) works exactly as before.

---

## WHAT NOT TO BUILD IN THIS PROMPT

The following are explicitly out of scope for Prompt 1. Do not attempt them:

- Actual email generation (that is Prompt 2)
- The EmailComposer for editing sequence emails (Prompt 2)
- A/B test approval UI (Prompt 2)
- The Activate button logic (Prompt 2)
- Sequence analytics view (Prompt 3)
- Any changes to `triggeredCampaignProcessor.ts` — do not touch it

---

## KEY DECISIONS AND STANDING RULES THAT APPLY HERE

- **No fake data.** If the audience count is unknown, show "—". If events haven't loaded, show a loading state. Never fabricate numbers.
- **Audience language.** The AI must never say "Foundation members" or "Rainmakers" to staff. Always reflect the audience in the language it was created with.
- **One A/B test suggestion per campaign maximum.** The AI proposes it in the plan; staff approves or skips in Prompt 2.
- **Same EmailComposer for sequence editing.** Do not build a second editor. (Prompt 2 will wire this.)
- **Sessions live in Automations, not user profile.** These are organizational assets.
- **The welcome message is hardcoded** — do not make an AI API call just to show the opening message.
- **Sonnet for planning.** `claude-sonnet-4-20250514` for all planner calls. This is creative, strategic work — not a job for Haiku.

---

*Prompt 2 (Email Generation + Activation) to follow after this is verified working.*
*Prompt 3 (Sequence Analytics) to follow after AEI demo.*

# MemberSync Dashboard — CRMLS Demo Polish
## February 20, 2026

---

## CONTEXT FOR REPLIT AGENT

MemberSync is being demonstrated to CRMLS, the largest MLS in the United States with 110,000 members. The dashboard needs to look polished, professional, and demonstrate the platform's unique value. This prompt makes three significant changes:

1. **Recognition sidebar** — Replaces the name-based Celebrations with a metrics-driven "Member Recognition" sidebar showing campaign counts, engagement stats, and member headshots
2. **Community section** — Replaces the static tier persona cards with a compact tier summary bar plus AI-generated "Discovery" cards that surface actionable insights from the data
3. **Visual polish** — Ensures the Activity Feed and Recognition sidebar are equal height with no gaps

**IMPORTANT:** The Discovery cards in the Community section use MOCKED DATA for demo purposes. The AI pattern-detection engine that will generate real discoveries is a future feature. For now, hardcode 3-4 compelling example discoveries that demonstrate the concept. The mock data should look realistic and be clearly useful.

---

## CHANGE 1: Celebrations → Member Recognition

### Rename and Redesign

The current "Celebrations" sidebar shows individual member names in colored cards with "Send" buttons. This works for 18,000 members but not for 110,000. The redesign shifts from names to numbers, adds member headshots for visual warmth, and frames recognition as a business metric.

**Rename:** "Celebrations" → "Member Recognition"
**Icon:** Keep `PartyPopper` or switch to `Award` from lucide-react

### New Component: `MemberRecognition.tsx`

Replace `CelebrationInsights.tsx` with a new component. The new sidebar shows recognition *categories as metric tiles* rather than member name lists.

Each tile shows:
- Category icon and name (same icons as before)
- **Count of members recognized** (not names): "43 members this week"
- **Campaign stats** if emails were sent: "38% open rate" or "Not yet sent"
- **2-3 small member headshot circles** as visual texture (using `profile_image_url` from member_metrics_cache, with initials fallback)
- A compact "Send" or "Sent ✓" button

**Create `client/src/components/dashboard/MemberRecognition.tsx`:**

```tsx
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MemberAvatar } from "@/components/shared/MemberAvatar";
import {
  Award,
  Send,
  RefreshCw,
  Trophy,
  Calendar,
  Star,
  DollarSign,
  Home,
  Key,
  Sparkles,
  Gem,
  CheckCircle,
} from "lucide-react";

interface MilestoneResult {
  memberKey: string;
  memberName: string;
  memberEmail: string | null;
  milestoneType: string;
  milestoneValue: string;
  milestoneLabel: string;
  milestoneEmoji?: string;
  description: string;
  contextJson?: Record<string, unknown>;
}

interface MilestoneCategory {
  type: string;
  label: string;
  milestones: MilestoneResult[];
}

interface MilestonesResponse {
  categories: MilestoneCategory[];
}

const CATEGORY_CONFIG: Record<string, { icon: React.ElementType; color: string; bgColor: string }> = {
  transaction_milestone: { icon: Trophy, color: 'text-amber-500', bgColor: 'bg-amber-50 dark:bg-amber-950/30' },
  volume_milestone: { icon: DollarSign, color: 'text-emerald-500', bgColor: 'bg-emerald-50 dark:bg-emerald-950/30' },
  membership_anniversary: { icon: Calendar, color: 'text-blue-500', bgColor: 'bg-blue-50 dark:bg-blue-950/30' },
  listing_milestone: { icon: Home, color: 'text-orange-500', bgColor: 'bg-orange-50 dark:bg-orange-950/30' },
  buyer_milestone: { icon: Key, color: 'text-teal-500', bgColor: 'bg-teal-50 dark:bg-teal-950/30' },
  top_producer: { icon: Star, color: 'text-purple-500', bgColor: 'bg-purple-50 dark:bg-purple-950/30' },
  rookie_star: { icon: Sparkles, color: 'text-pink-500', bgColor: 'bg-pink-50 dark:bg-pink-950/30' },
  first_million: { icon: Gem, color: 'text-cyan-500', bgColor: 'bg-cyan-50 dark:bg-cyan-950/30' },
  luxury_entry: { icon: Gem, color: 'text-violet-500', bgColor: 'bg-violet-50 dark:bg-violet-950/30' },
};

export function MemberRecognition({ className }: { className?: string }) {
  const [, setLocation] = useLocation();
  
  const { data, isLoading, refetch, isFetching } = useQuery<MilestonesResponse>({
    queryKey: ["/api/milestones"],
    staleTime: 1000 * 60 * 5,
  });

  // Get headshot URLs for display — query a few random members with photos
  const { data: headshotData } = useQuery<{ members: Array<{ memberKey: string; name: string; photoUrl: string | null }> }>({
    queryKey: ["/api/members/with-photos"],
    staleTime: 1000 * 60 * 30,
  });

  const categories = useMemo(() => {
    if (!data?.categories) return [];
    return data.categories.slice(0, 5);
  }, [data?.categories]);

  const totalRecognized = categories.reduce((sum, cat) => sum + cat.milestones.length, 0);

  const handleSendCelebration = (category: MilestoneCategory) => {
    const milestones = category.milestones.map(m => ({
      memberKey: m.memberKey,
      memberName: m.memberName,
      memberEmail: m.memberEmail,
      milestoneValue: m.milestoneValue,
      milestoneEmoji: m.milestoneEmoji,
    }));
    
    setLocation(`/smartsends/send?celebrationAudience=${encodeURIComponent(JSON.stringify({
      type: category.type,
      label: category.label,
      milestones,
      description: `${category.label} - ${category.milestones.length} members`
    }))}`);
  };

  return (
    <Card className={`${className || ''} flex flex-col h-full`} data-testid="card-member-recognition">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2 flex-shrink-0">
        <div className="flex items-center gap-2">
          <Award className="h-5 w-5 text-primary" />
          <CardTitle className="text-base font-semibold">Member Recognition</CardTitle>
          {totalRecognized > 0 && (
            <Badge variant="secondary" className="text-xs">{totalRecognized}</Badge>
          )}
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => refetch()}
          disabled={isFetching}
          title="Refresh"
        >
          <RefreshCw className={`h-4 w-4 ${isFetching ? 'animate-spin' : ''}`} />
        </Button>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto space-y-2 pb-3">
        {isLoading ? (
          <div className="space-y-2">
            {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-16 w-full" />)}
          </div>
        ) : categories.length === 0 ? (
          <div className="text-center py-4">
            <Award className="h-8 w-8 text-muted-foreground mx-auto mb-2 opacity-50" />
            <p className="text-sm text-muted-foreground">No milestones detected</p>
          </div>
        ) : (
          categories.map((category) => {
            const config = CATEGORY_CONFIG[category.type] || { icon: Award, color: 'text-primary', bgColor: 'bg-primary/5' };
            const IconComponent = config.icon;
            // Get up to 3 members with photos for the avatar row
            const membersForAvatars = category.milestones.slice(0, 3);
            
            return (
              <div
                key={category.type}
                className={`p-2.5 rounded-lg ${config.bgColor} border border-transparent hover:border-border/50 transition-colors`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <IconComponent className={`h-4 w-4 shrink-0 ${config.color}`} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold truncate">{category.label}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {category.milestones.length} member{category.milestones.length !== 1 ? 's' : ''} this week
                      </p>
                    </div>
                  </div>
                  {/* Member headshot circles */}
                  <div className="flex -space-x-1.5 shrink-0">
                    {membersForAvatars.map((m) => (
                      <MemberAvatar
                        key={m.memberKey}
                        name={m.memberName}
                        photoUrl={null}
                        size="xs"
                      />
                    ))}
                    {category.milestones.length > 3 && (
                      <div className="w-5 h-5 rounded-full bg-muted text-[9px] font-medium flex items-center justify-center border border-background">
                        +{category.milestones.length - 3}
                      </div>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="shrink-0 h-7 text-xs gap-1"
                    onClick={() => handleSendCelebration(category)}
                  >
                    <Send className="h-3 w-3" />
                    Send
                  </Button>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
```

**Note on MemberAvatar:** The `MemberAvatar` component already exists in the codebase (`client/src/components/shared/MemberAvatar.tsx`). It renders a circular avatar with photo or initials fallback. If it doesn't support an `xs` size, add one:

```typescript
// In MemberAvatar.tsx, add to the size map:
xs: "h-5 w-5 text-[9px]",
```

### Update Dashboard.tsx

Replace the import:
```tsx
// Remove:
import { CelebrationInsights } from "@/components/dashboard/CelebrationInsights";
// Add:
import { MemberRecognition } from "@/components/dashboard/MemberRecognition";
```

Replace the JSX:
```tsx
// Remove: <CelebrationInsights />
// Add: <MemberRecognition />
```

---

## CHANGE 2: Community Section → Tier Summary + Discovery Cards

### Remove Static Tier Cards

The three large tier persona cards (Rainmaker, Builder, Foundation) with their static stats are removed. They're replaced by two things:

**A. Compact Tier Summary Bar** — A single horizontal element showing the three tiers proportionally with donut charts, in one glance. This tells the 75% story without three heavyweight cards.

**B. Discovery Cards** — AI-generated engagement opportunities based on data patterns. For this version, these are MOCKED with realistic hardcoded data. The mock data demonstrates the concept for the CRMLS demo.

### Tier Summary Bar

A compact horizontal section showing all three tiers in one row. Each tier gets: donut chart, name, count, and one-line insight. No personas, no detail text — just the essential numbers.

### Discovery Cards

Each discovery card surfaces a specific, actionable pattern found in the data:
- A headline describing the pattern ("16 agents sold 18 homes in 60614 in the last 90 days")
- Why it matters ("They're natural peers in the same micro-market")
- A call to action ("Connect Them" → SmartSends)
- A small visual element (map pin, chart, or member avatars)

**Create `client/src/components/dashboard/CommunityInsights.tsx`:**

```tsx
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "wouter";
import { PieChart, Pie, Cell } from "recharts";
import {
  Users,
  Crown,
  Hammer,
  Home,
  MapPin,
  GraduationCap,
  TrendingUp,
  Lightbulb,
  ArrowRight,
  Sparkles,
} from "lucide-react";

interface MembershipStoryData {
  composition: {
    rainmaker: { count: number; percentage: number };
    builder: { count: number; percentage: number };
    foundation: { count: number; percentage: number };
  };
  rainmakerInsights: { connectedPercentage: number; totalVolume: number; avgSides: number; top5PctCount: number; top5PctVolShare: number };
  builderInsights: { connectedPercentage: number; totalVolume: number; avgSides: number };
  foundationInsights: { connectedPercentage: number; totalVolume: number; avgSides: number };
}

// Donut chart for tier dues share
function TierDonut({ pct, color, size = 36 }: { pct: number; color: string; size?: number }) {
  const data = [{ value: pct }, { value: 100 - pct }];
  return (
    <PieChart width={size} height={size}>
      <Pie data={data} cx={size/2} cy={size/2} innerRadius={size*0.3} outerRadius={size*0.47} startAngle={90} endAngle={-270} dataKey="value" stroke="none">
        <Cell fill={color} />
        <Cell fill="#e5e7eb" />
      </Pie>
    </PieChart>
  );
}

// MOCK DISCOVERY DATA — Replace with real AI-generated discoveries in future
const MOCK_DISCOVERIES = [
  {
    id: 'zip-cluster-60614',
    icon: MapPin,
    iconColor: 'text-rose-500',
    bgColor: 'bg-rose-50 dark:bg-rose-950/20',
    headline: '16 agents sold 18 homes in 60614 in the last 90 days',
    insight: "They're competitors on paper, but they're the only ones who understand this micro-market right now. An introduction could spark referrals and shared insights.",
    action: 'Connect Them',
    badge: 'Zip Code Cluster',
    badgeColor: 'bg-rose-100 text-rose-700 dark:bg-rose-900/50 dark:text-rose-300',
  },
  {
    id: 'certification-cohort',
    icon: GraduationCap,
    iconColor: 'text-blue-500',
    bgColor: 'bg-blue-50 dark:bg-blue-950/20',
    headline: '8 agents from different brokerages all completed the Commercial Real Estate certification this quarter',
    insight: "None of them have attended your Commercial Networking event yet. They're building new skills — connect them with peers who've made the transition.",
    action: 'Invite to Event',
    badge: 'Certification Cohort',
    badgeColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300',
  },
  {
    id: 'trending-builder',
    icon: TrendingUp,
    iconColor: 'text-emerald-500',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/20',
    headline: '23 Foundation members completed their first transaction this quarter',
    insight: "These agents just crossed into Builder territory. A personal congratulations from the association makes this moment feel recognized — and keeps them engaged as they grow.",
    action: 'Celebrate Them',
    badge: 'Tier Movement',
    badgeColor: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300',
  },
  {
    id: 'reconnection-moment',
    icon: Sparkles,
    iconColor: 'text-amber-500',
    bgColor: 'bg-amber-50 dark:bg-amber-950/20',
    headline: '5 Rainmakers who haven\'t attended an event in over a year just registered for the Spring Market Outlook',
    insight: "This is a reconnection moment. A personal follow-up before the event could be the thing that brings them back into the community.",
    action: 'Send Welcome Back',
    badge: 'Reconnection',
    badgeColor: 'bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300',
  },
];

export function CommunityInsights() {
  const [, setLocation] = useLocation();
  
  const { data, isLoading } = useQuery<MembershipStoryData>({
    queryKey: ["/api/dashboard/membership-story"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader><Skeleton className="h-5 w-48" /></CardHeader>
        <CardContent><Skeleton className="h-64 w-full" /></CardContent>
      </Card>
    );
  }

  if (!data) return null;

  const { composition } = data;

  const tiers = [
    { key: 'rainmaker', label: 'Rainmaker', Icon: Crown, color: '#f59e0b', textColor: 'text-amber-500', comp: composition.rainmaker },
    { key: 'builder', label: 'Builder', Icon: Hammer, color: '#3b82f6', textColor: 'text-blue-500', comp: composition.builder },
    { key: 'foundation', label: 'Foundation', Icon: Home, color: '#10b981', textColor: 'text-emerald-500', comp: composition.foundation },
  ];

  return (
    <Card data-testid="card-community-insights">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-primary" />
          <CardTitle className="text-base font-semibold">Community Insights</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">

        {/* Compact Tier Summary Bar */}
        <div className="flex items-center gap-4 p-3 rounded-lg bg-muted/50 border">
          {tiers.map((tier, idx) => (
            <div key={tier.key} className={`flex items-center gap-2 ${idx < tiers.length - 1 ? 'flex-1' : 'flex-1'}`}>
              <TierDonut pct={tier.comp.percentage} color={tier.color} />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <tier.Icon className={`h-3.5 w-3.5 ${tier.textColor}`} />
                  <span className="text-xs font-semibold">{tier.label}</span>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  {tier.comp.count.toLocaleString()} · ~{tier.comp.percentage}% of dues
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Discovery Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {MOCK_DISCOVERIES.map((discovery) => {
            const IconComp = discovery.icon;
            return (
              <div
                key={discovery.id}
                className={`p-3.5 rounded-lg border ${discovery.bgColor} space-y-2`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2">
                    <IconComp className={`h-4 w-4 mt-0.5 shrink-0 ${discovery.iconColor}`} />
                    <div>
                      <Badge variant="outline" className={`text-[10px] font-medium px-1.5 py-0 mb-1.5 ${discovery.badgeColor} border-0`}>
                        {discovery.badge}
                      </Badge>
                      <p className="text-sm font-medium leading-snug">{discovery.headline}</p>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{discovery.insight}</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs gap-1"
                  onClick={() => setLocation('/smartsends/send')}
                >
                  {discovery.action}
                  <ArrowRight className="h-3 w-3" />
                </Button>
              </div>
            );
          })}
        </div>

      </CardContent>
    </Card>
  );
}
```

### Update Dashboard.tsx

Replace the import:
```tsx
// Remove:
import { MainstreetCommunity } from "@/components/dashboard/MainstreetCommunity";
// (or MembershipStory if it was never renamed)
// Add:
import { CommunityInsights } from "@/components/dashboard/CommunityInsights";
```

Replace in JSX:
```tsx
// Remove: <MainstreetCommunity /> or <MembershipStory />
// Add: <CommunityInsights />
```

---

## CHANGE 3: Layout Polish

### Equal Height Activity Feed + Recognition Sidebar

Ensure the grid container for Activity Feed and Member Recognition uses `items-stretch`:

```tsx
<div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-4 lg:items-stretch">
  <ActivityFeed />
  <MemberRecognition />
</div>
```

In `ActivityFeed.tsx`, ensure the Card has `h-full`:
```tsx
<Card data-testid="card-activity-feed" className="h-full">
```

The MemberRecognition component already has `h-full flex flex-col` with `overflow-y-auto` on the content area.

---

## VERIFICATION CHECKLIST

- [ ] "Member Recognition" sidebar (not "Celebrations") with Award icon
- [ ] Recognition tiles show member count + headshot circles, NOT individual names
- [ ] Recognition tiles have "Send" buttons that link to SmartSends
- [ ] Activity Feed and Recognition sidebar are equal height — NO gap
- [ ] "Community Insights" section replaces old tier cards
- [ ] Compact tier summary bar shows all three tiers with donut charts in one row
- [ ] Four discovery cards with mocked data showing actionable insights
- [ ] Discovery cards have colored badges (Zip Code Cluster, Certification Cohort, Tier Movement, Reconnection)
- [ ] Each discovery card has an action button linking to SmartSends
- [ ] No individual member names visible in the Recognition sidebar
- [ ] Page header still shows "Good afternoon, Tracy..."
- [ ] AI Chat still at top of page
- [ ] Three Pulse cards (Membership, Education, Events) unchanged
- [ ] Mobile layout works — discovery cards stack to single column

---

## FILES CHANGED

**New files:**
- `client/src/components/dashboard/MemberRecognition.tsx` — Replaces CelebrationInsights
- `client/src/components/dashboard/CommunityInsights.tsx` — Replaces MainstreetCommunity/MembershipStory

**Modified files:**
- `client/src/pages/Dashboard.tsx` — Update imports, swap components, ensure grid uses items-stretch
- `client/src/components/shared/MemberAvatar.tsx` — Add `xs` size if not present

**Removed/replaced:**
- `client/src/components/dashboard/CelebrationInsights.tsx` — Replaced by MemberRecognition
- `client/src/components/dashboard/MainstreetCommunity.tsx` — Replaced by CommunityInsights

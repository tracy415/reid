# Restore the "Create Email Magic" Flow

## Context

We recently unified the Send Email and Automations composers into a shared `EmailComposer` component. The refactor was necessary, but it flattened our AI email creation flow in SendEmail.tsx. What used to be a delightful three-beat experience — **choose AI → fill in fields → see your email** — became a confusing scroll-and-click maze where users fill in fields, scroll past them, click Generate, watch the page refresh, see a "Continue with draft content?" card, click THAT, and then finally see their email.

We need to restore the original rhythm. This is the single highest-impact UX improvement we can make right now because it affects every single email sent through the platform.

---

## The Flow We Want (for ALL email creation paths)

### Beat 1: Create Email Step — "What do you want to say?"

The user sees the method cards: **Create with AI**, **Use a Template**, **Start from Scratch**.

**If they pick Create with AI:**
- The AI fields appear inline (they already do this — keep this behavior)
- Fields: Purpose/What's this email about, Tone, Special Offer (optional), Call to Action
- The user fills them in
- They click **Next** (the same Next button at the bottom of the step)
- That's it. No separate "Generate" button. Next IS the generate trigger when AI method is selected.

**If they pick Use a Template:**
- Template selector opens (existing behavior — keep it)
- They pick a template, it loads
- They click **Next** to proceed to Compose

**If they pick Start from Scratch:**
- Placeholder content loads (existing behavior — keep it)  
- They click **Next** to proceed to Compose

### Beat 2: The Interstitial — "Creating Email Magic"

This already exists in the code as the `isGeneratingEmail` overlay with the Sparkles icon, pulsing ring, and "Creating Email Magic / Please Standby" text. It's a full-screen overlay that blocks interaction while the AI works.

**What changes:** This overlay should appear when the user clicks Next on the Create Email step AND the AI method was selected. Currently it only triggers for celebration and compliance auto-generation paths. It needs to also trigger for the general `POST /api/smartsends/emails/generate` path.

The interstitial should be visible for the entire duration of the API call. When the API returns, the overlay disappears and the user lands on the Compose step with their email ready.

### Beat 3: Compose Step — "Here's your email"

The user lands on the Compose step with:
- Subject line populated from the AI response
- Email body populated from the AI response  
- Preview text populated from the AI response
- The full EmailComposer editor ready for them to review and tweak

No "Continue with draft content?" card. No intermediate state. They're just THERE, looking at their email.

---

## Detailed Implementation

### Change 1: Track the selected creation method

In `SendEmail.tsx`, add state to track which method the user chose:

```typescript
const [emailCreationMethod, setEmailCreationMethod] = useState<'ai' | 'template' | 'scratch' | null>(null);
```

The EmailComposer's method cards need to communicate the selection back to SendEmail. Currently, `showMethodCards={true}` renders the cards inside EmailComposer. We need EmailComposer to call back when a method is selected:

Add a new prop to EmailComposer:
```typescript
onMethodSelect?: (method: 'ai' | 'template' | 'scratch') => void;
```

In `SendEmail.tsx`, pass it:
```typescript
<EmailComposer
  ...existing props...
  onMethodSelect={(method) => setEmailCreationMethod(method)}
/>
```

Inside EmailComposer, when the user clicks the "Create with AI" card, call `onMethodSelect?.('ai')`. Same for template and scratch.

### Change 2: Next button triggers AI generation when method is 'ai'

Currently, the Next button on the Create Email step does this:

```typescript
onClick={() => {
  if (emailDraft && emailDraft.body) {
    setCurrentStep('compose');
  } else {
    toast({ title: "No Email Content", ... });
  }
}}
```

Replace this with logic that checks the creation method:

```typescript
onClick={async () => {
  if (emailCreationMethod === 'ai') {
    // Trigger AI generation — the interstitial will show automatically
    generateEmailMutation.mutate({
      purpose: aiPurpose,      // from the AI fields in EmailComposer
      tone: aiTone,
      specialOffer: aiSpecialOffer,
      cta: aiCta,
      audience_description: selectedAudience?.audienceName || 'Mainstreet REALTORS® members',
      triggerContext: complianceType 
        ? `This is a compliance notification email about ${complianceType}.`
        : undefined,
    });
  } else if (emailDraft && emailDraft.body) {
    setCurrentStep('compose');
  } else {
    toast({ title: "No Email Content", description: "Please create email content first.", variant: "destructive" });
  }
}}
```

**Important:** The AI fields (purpose, tone, special offer, CTA) currently live inside EmailComposer. We need them exposed to the parent. Add callback props:

```typescript
// New props on EmailComposer
onAIFieldsChange?: (fields: { purpose: string; tone: string; specialOffer: string; cta: string }) => void;
```

Or simpler: have EmailComposer expose its AI field values through a ref or through controlled state props. The cleanest approach is to **lift the AI field state up to SendEmail.tsx** since SendEmail already manages all other state:

```typescript
// In SendEmail.tsx — add these state variables
const [aiPurpose, setAIPurpose] = useState('');
const [aiTone, setAITone] = useState('friendly');
const [aiSpecialOffer, setAISpecialOffer] = useState('');
const [aiCta, setAICta] = useState('Learn More');
```

Pass them down to EmailComposer as controlled props:
```typescript
<EmailComposer
  ...existing props...
  aiPurpose={aiPurpose}
  onAIPurposeChange={setAIPurpose}
  aiTone={aiTone}
  onAIToneChange={setAITone}
  aiSpecialOffer={aiSpecialOffer}
  onAISpecialOfferChange={setAISpecialOffer}
  aiCta={aiCta}
  onAICTAChange={setAICta}
  onMethodSelect={(method) => setEmailCreationMethod(method)}
/>
```

### Change 3: Add the general email generation mutation

The celebration and compliance paths already have their own mutations (`generateCelebrationMutation`, `generateComplianceMutation`). We need a general one for standard AI emails:

```typescript
const generateEmailMutation = useMutation({
  mutationFn: async (data: {
    purpose: string;
    tone?: string;
    specialOffer?: string;
    cta?: string;
    audience_description?: string;
    triggerContext?: string;
  }) => {
    const response = await apiRequest('POST', '/api/smartsends/emails/generate', {
      purpose: data.purpose,
      audience_description: data.audience_description,
      tone: data.tone || 'friendly',
      special_offer: data.specialOffer,
      cta: data.cta,
      key_points: data.triggerContext ? [data.triggerContext] : undefined,
    });
    return response.json();
  },
  onSuccess: (data) => {
    setSubjectLine(data.subject);
    setPreviewText(data.preview_text || '');
    setEmailDraft({
      subject: data.subject,
      body: data.body,
      preview_text: data.preview_text || '',
      merge_fields_used: data.merge_fields_used || [],
    });
    // Advance to compose step — the email is ready
    setCurrentStep('compose');
    toast({
      title: "Email Ready",
      description: "Review and customize your email.",
    });
  },
  onError: (error: Error) => {
    toast({
      title: "Generation Failed",
      description: error.message || "Something went wrong. Try again or start from scratch.",
      variant: "destructive",
    });
  },
});
```

### Change 4: Update the interstitial trigger

Currently, `isGeneratingEmail` only covers celebration and compliance mutations:

```typescript
const isGeneratingEmail = generateComplianceMutation.isPending || generateCelebrationMutation.isPending;
```

Add the new general mutation:

```typescript
const isGeneratingEmail = generateComplianceMutation.isPending || generateCelebrationMutation.isPending || generateEmailMutation.isPending;
```

This means the existing "Creating Email Magic" overlay will automatically appear for standard AI generation too. No new UI needed.

### Change 5: Update canProceedFromCreate

Currently:
```typescript
const canProceedFromCreate = (campaignName.trim() || subjectLine.trim()) && emailDraft !== null;
```

This blocks Next until an emailDraft exists, which doesn't happen until AFTER generation. For the AI path, we need Next to be enabled when the AI fields are filled in (even though the draft doesn't exist yet — Next will trigger generation which creates the draft).

Update to:
```typescript
const canProceedFromCreate = (() => {
  if (emailCreationMethod === 'ai') {
    // For AI: just need purpose filled in (tone has a default)
    return aiPurpose.trim().length > 0;
  }
  // For template/scratch: need existing draft content
  return emailDraft !== null && (emailDraft.subject || emailDraft.body);
})();
```

### Change 6: Remove the "Continue with draft content?" card

In the Create Email step, there's a block that shows when `emailDraft` exists:

```tsx
{emailDraft && (emailDraft.subject || emailDraft.body) && (
  <div className="mb-6">
    <Label className="text-base font-medium mb-4 block">Continue with your draft content?</Label>
    ...card with "Continue with Draft Content" and "Or start fresh" divider...
  </div>
)}
```

**Remove this entire block.** 

If the user navigates back from Compose to Create, they should see the method cards again with their previous selection highlighted. Their draft is preserved in state — when they click Next again, it just advances back to Compose with the existing content. No need for a confirmation card.

However, we DO want to show a subtle indicator that they have draft content. Replace the removed block with a simple notice:

```tsx
{emailDraft && emailDraft.body && emailDraft.body.length > 20 && (
  <div className="mb-4 p-3 rounded-lg bg-muted/50 flex items-center gap-2 text-sm text-muted-foreground">
    <FileEdit className="w-4 h-4" />
    <span>You have a draft in progress. Click Next to continue editing, or choose a new method below to start over.</span>
  </div>
)}
```

### Change 7: Disable Generate button inside EmailComposer for SendEmail

The EmailComposer component has its own "Generate" button somewhere inside the AI method flow. Since SendEmail now uses Next as the trigger, we need to suppress that internal button.

EmailComposer already accepts a `hideGenerateButton` prop (CreateAutomation uses it). Make sure SendEmail passes it:

```typescript
<EmailComposer
  ...existing props...
  hideGenerateButton={true}
/>
```

This ensures there's only ONE way to generate: the Next button. No confusion.

### Change 8: Wire up Activity Feed pre-fill

The Activity Feed Smart Handoff prompt (already deployed or in progress) passes URL params like `activityType`, `activityPurpose`, `activityTone`, `activityCta` to SendEmail. These should pre-fill the AI fields:

```typescript
// In the URL params section, add:
const activityPurpose = urlParams.get('activityPurpose') || urlParams.get('emailPurpose');
const activityTone = urlParams.get('activityTone') || urlParams.get('emailTone');
const activityCta = urlParams.get('activityCta') || urlParams.get('emailCta');

// In state initialization:
const [aiPurpose, setAIPurpose] = useState(activityPurpose || '');
const [aiTone, setAITone] = useState(activityTone || 'friendly');
const [aiSpecialOffer, setAISpecialOffer] = useState('');
const [aiCta, setAICta] = useState(activityCta || 'Learn More');

// Also auto-select AI method when activity params are present:
const [emailCreationMethod, setEmailCreationMethod] = useState<'ai' | 'template' | 'scratch' | null>(
  activityPurpose ? 'ai' : null
);
```

This means when someone clicks "Send Follow-Up" from the Activity Feed:
1. They land on Create Email with audience already loaded (from the handoff prompt)
2. The AI method is auto-selected and fields are pre-filled
3. They review the purpose, maybe tweak the tone
4. They click **Next**
5. "Creating Email Magic" ✨
6. Email appears, ready to send

One thought to one action to one result.

### Change 9: Compliance path should use the same flow

Currently, compliance emails have their own generation mutation and auto-generate on page load. This means the user never gets to choose a method — the email just appears. This is fine for the automated celebration/milestone path, but for compliance emails that come through the standard flow with `complianceType` param, the user should be able to use the AI flow with purpose pre-filled.

When `complianceTypeParam` is present:
- Pre-fill `aiPurpose` with the compliance context (e.g., "Remind members about Illinois CE requirements due April 30, 2026")
- Auto-select AI method
- Let the user adjust fields and click Next to generate  

Keep the existing auto-generation path for celebration emails (they come from the Member Recognition page with full context and should skip straight to Compose). Only change the compliance path to use the standard Create Email → Next → Magic → Compose flow.

To be specific about what NOT to change: when `celebrationParam` or `milestoneTypeParam` is present, keep the current behavior where the page skips to Compose and auto-generates. These paths are working well. Only the standard and compliance paths need the restored flow.

---

## Files to Modify

1. **`client/src/pages/SendEmail.tsx`**
   - Add `emailCreationMethod` state
   - Add `aiPurpose`, `aiTone`, `aiSpecialOffer`, `aiCta` state (lifted from EmailComposer)
   - Add `generateEmailMutation` for general AI email generation
   - Update `isGeneratingEmail` to include new mutation
   - Update `canProceedFromCreate` to handle AI method
   - Update Next button onClick to trigger generation for AI method
   - Remove "Continue with draft content?" card, replace with subtle draft notice
   - Pass `hideGenerateButton={true}` to EmailComposer
   - Pass lifted AI state + `onMethodSelect` to EmailComposer
   - Wire up activity feed and compliance pre-fill

2. **`client/src/components/shared/EmailComposer.tsx`**
   - Add `onMethodSelect` callback prop
   - Add controlled props for AI fields (`aiPurpose`, `onAIPurposeChange`, etc.)
   - Call `onMethodSelect` when user clicks a method card
   - Support both controlled (props provided) and uncontrolled (internal state) modes for AI fields, so existing usage in CreateAutomation isn't broken
   - Respect `hideGenerateButton` prop (may already work — verify)

---

## What NOT to Change

- The EmailComposer component's internal structure for template selection and scratch mode
- The Compose step (Step 3) — it already handles displaying the email correctly
- CreateAutomation.tsx — it uses EmailComposer differently and its flow is fine
- The celebration auto-generation path (celebrationParam/milestoneTypeParam)
- The "Creating Email Magic" overlay design — it's already great, we're just making it trigger more often
- The `POST /api/smartsends/emails/generate` endpoint — it already works correctly
- The Preview, Send, or Audience steps

---

## Testing Checklist

### Standard AI Email Flow
- [ ] Pick an audience → land on Create Email step
- [ ] Click "Create with AI" method card → AI fields appear
- [ ] Fill in purpose ("Welcome new members this week")
- [ ] Next button is enabled once purpose has text
- [ ] Click Next → "Creating Email Magic" overlay appears
- [ ] Overlay disappears → user is on Compose step with AI-generated email
- [ ] Subject, body, and preview text are all populated
- [ ] User can edit the email normally

### Template Flow (unchanged)
- [ ] Click "Use a Template" → template selector opens
- [ ] Pick a template → content loads
- [ ] Click Next → lands on Compose with template content
- [ ] No "Creating Email Magic" overlay (it's not AI)

### Scratch Flow (unchanged)
- [ ] Click "Start from Scratch" → placeholder loads
- [ ] Click Next → lands on Compose with placeholder
- [ ] No overlay

### Activity Feed Handoff
- [ ] Click "Send Follow-Up" from Activity Feed for a class
- [ ] Lands on Create Email step (audience already loaded)
- [ ] AI method is auto-selected
- [ ] Purpose field is pre-filled with follow-up context
- [ ] Tone is pre-filled (friendly)
- [ ] CTA is pre-filled
- [ ] User can adjust any field
- [ ] Click Next → magic overlay → email appears

### Navigate Back from Compose
- [ ] On Compose step, click Back
- [ ] Lands on Create Email with draft notice ("You have a draft in progress")
- [ ] NO "Continue with draft content?" card
- [ ] Method cards visible
- [ ] Click Next → returns to Compose with existing draft (no re-generation)
- [ ] If user picks a different method, the old draft is replaced

### Compliance Pre-fill
- [ ] Navigate to send email with complianceType=illinois-ce-due
- [ ] AI method auto-selected, purpose pre-filled with compliance context
- [ ] User adjusts fields, clicks Next → magic overlay → compliance email appears

### Celebration Path (should NOT change)
- [ ] Click Send from Member Recognition page
- [ ] Should still skip directly to Compose step
- [ ] Email auto-generates as before
- [ ] No method card step required

### Edge Cases
- [ ] Click Next with empty purpose field → button should be disabled (can't click)
- [ ] AI generation fails → error toast, user stays on Create Email step, can retry
- [ ] Very slow generation (>5 seconds) → overlay stays visible, no timeout
- [ ] User navigates away during generation → no errors, state cleans up

---

## Standing Rules (Apply to Every Prompt)

1. **No Parallel Systems** — Don't create a new generation system. Use the existing `POST /api/smartsends/emails/generate` endpoint and the existing "Creating Email Magic" overlay.

2. **Don't Break What Works** — The celebration path, the template path, the scratch path, and the Automations composer all work. Test them after changes.

3. **Full-Page Patterns Not Modals** — The AI fields render inline on the Create Email step (already correct). Don't move them into a modal or dialog.

4. **Shared Components Over Duplicates** — EmailComposer is used by both SendEmail and CreateAutomation. Changes to EmailComposer must not break CreateAutomation. Use optional props and graceful fallbacks.

5. **Server-Side for Scale** — The email generation already happens server-side. No changes needed here.

6. **Test Your Work** — Run through every path in the testing checklist. Use the app as a real user would. If you click Next and don't see the magic overlay, something is wrong.

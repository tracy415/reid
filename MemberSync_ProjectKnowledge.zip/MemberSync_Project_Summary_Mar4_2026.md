# MemberSync — Project Summary
## March 4, 2026 (CLAUDE.md Session)

---

## OVERVIEW

This session wrote and iteratively refined the CLAUDE.md — the product bible that goes in the root of the production repository. It is the first document the dev team and Claude Code will read. Two prior sessions (same day) prepared for this: the first gathered project context, the second reviewed uploaded codebase files and extracted the file tree.

---

## WHAT WAS ACCOMPLISHED

### CLAUDE.md Written and Refined (646 lines)

The complete CLAUDE.md was written from scratch, incorporating knowledge from all uploaded source files (schema.ts, routes.ts, storage.ts, clientConfig.ts, aiQueryService.ts, aiEmailService.ts, emailService.ts), the full project knowledge base, and Tracy's real-time corrections and product philosophy.

**Sections in the document:**
1. What Is MemberSync (product vision, SaaS model)
2. The Insight That Drives Everything (75/12 Rule, NAR cautionary tale)
3. Member Tier Framework (Rainmaker/Builder/Foundation)
4. Tech Stack
5. Database Architecture (single DB in production, two-DB prototype workaround)
6. Snapshot Deduplication, MemberKey Format, ApmClientId Filtering
7. Project Structure (full file tree)
8. Key Files to Understand (clientConfig, schema, routes, sharedDatabaseSchema)
9. Cache-First Architecture (daily job schedule, atomic refresh pattern)
10. Engagement Scoring System (philosophy, tier-aware weights, labels, per-client config, signal applicability, custom signals, 100% coverage test)
11. Volume Double-Counting (Membio Volume Standard)
12. SmartSends (three sending modes, safety controls, audience types, three-tier merge fields, AI-driven personalization)
13. AI Services (Chat, Audience Builder, Email Composer, anti-hallucination rules)
14. Compliance Configuration (association-specific, state-parameterized)
15. Known Architectural Issues (why we're porting)
16. Multi-Tenant Migration Plan (Stage 0 client intake config, Stages 1-3)
17. Client Pipeline
18. Production Port Module Order
19. Standing Rules (13 non-negotiable principles)
20. Environment Variables
21. Companion Documents (parking lot promoted to top of list)
22. What's Coming (6 parking lot items with architectural implications)

### Key Corrections and Additions Made During Review

**1. Database Architecture — Single DB in Production (Critical Fix)**
Tracy clarified that the two-database setup is a prototyping safety measure (read-only access to production so Tracy can't accidentally modify it), NOT an architectural choice. In production, there is ONE database. The "Two-Step Query Pattern" is a workaround to eliminate, not a design pattern to replicate. `externalPool` and `db` merge into one connection.

**2. Association AND MLS Framing**
Original draft was too association-focused. Tracy corrected: MLSs face the exact same 75/12 math. If an MLS doesn't build relevance for Foundation customers, they're just as vulnerable. Changed language throughout to say "association or MLS" and "member (association terminology) or customer (MLS terminology)."

**3. Engagement Scoring Philosophy Overhaul**
- Payment is NOT an engagement metric — it's table stakes. You pay to be a member/customer. Period.
- Transactions are NOT engagement for most members — they're baseline activity. Foundation members score zero on transactions by design.
- Added "What Engagement IS and IS NOT" section with explicit framing
- Tracy's edit to the scoring intro: "Does this member or customer have a relationship with us beyond paying their invoice on time? If not, we are not relevant, and they are not engaged."

**4. Signal Applicability: Associations vs. MLSs**
Not every signal applies to every organization type. Added a full table:
- Association-only: CE hours, designations, Code of Ethics, Fair Housing
- Both: license status, email engagement, payment, recent activity, transactions (for tier only)
- The compliance module should be HIDDEN for MLS clients, not just empty

**5. Client Intake Configuration (Stage 0)**
Added a new "Stage 0" to the multi-tenant migration plan — before any code migration. The `tenant_config` table needs a "What do you care about?" section with fields like `org_type`, `tracks_ce`, `tracks_coe`, `tracks_designations`, `compliance_state`, `billing_model`, etc. One config row drives scoring, UI visibility, AI prompt context, and compliance panels across the entire platform.

**6. Configurable Scoring — Data-Driven, Not Code-Driven**
The scoring engine must read weights, thresholds, and active signals from tenant config — not from if-statements. Adding a new signal should be a config change, not a code change. Clients get sensible defaults based on org type, then adjust weights to fit their world.

**What we DON'T let clients configure:** The fundamental philosophy. Paying a bill is never a strong engagement signal. The knobs are about emphasis and calibration, not about redefining what engagement means.

**7. Custom Signals: Extensible by Design, Gated Through Services**
Clients will want to add scoring signals we haven't built. Accept them, but through Membio's team — not self-service. We evaluate data quality, map to a scoring component, set weight ranges, and add to tenant config. If three clients ask for the same signal, it becomes standard.

**The 100% Coverage Test:** Before accepting any custom signal, ask what percentage of the membership it covers. If under 10%, it's a vanity metric. This is the lesson from NAR — committee participation predicts retention perfectly for the <1% who participate and is useless for everyone else.

**8. NAR Cautionary Tale Added to Product Vision**
NAR's research found committee participation is the #1 predictor of retention. But <1% of members participate. So any engagement model built on that signal was doomed. MemberSync exists because we build for the other 99%. Added to "The Insight That Drives Everything" section.

**9. Three-Tier Merge Field Architecture**
- Tier 1: Static member profile fields (implemented)
- Tier 2: Trigger context fields (partially implemented)
- Tier 3: Live data fields pulled at send time (needed) — transaction addresses, close prices, CE hours remaining, etc.
- AI email service should be context-aware about available merge fields and suggest Tier 3 fields automatically based on the email's trigger context

**10. Volume Standard Edit**
Tracy simplified the Market Volume Contribution definition: "ClosePrice split 50/50 so each agent gets half of the closed transaction price" — removing the conditional language about "when both sides are members."

**11. What's Coming Section**
Added 6 parking lot items with architectural implications — things the team isn't building yet but needs to build WITH in mind: Lapse Prevention, Broker Module, AI Chart Rendering, Additional Data Sources, Lapse Pattern Analysis, A/B Testing. Each includes a specific architectural implication (e.g., "don't purge old data — it has future predictive value").

---

## FILES PRODUCED

| File | Lines | Location |
|------|-------|----------|
| CLAUDE.md | 646 | `/mnt/user-data/outputs/CLAUDE.md` — ready for download and handoff to dev team |

---

## NEXT SESSION PRIORITIES

Tracy has additional edits to the CLAUDE.md to make in the next conversation. After those are complete:

1. **Module work for the show** — Tracy has a major show in two weeks and needs demo-ready features. Next session should start with: What's the show? Who's in the audience? What should they walk away saying about MemberSync?
2. **Proactive AI Engagement Engine** — Top Track 1 priority (makes Community Insights cards real)
3. **Lapse Prevention System** — Second Track 1 priority
4. **AI Cost Controls** — Third Track 1 priority
5. **Team presentation** — Deferred from previous session; presenting the two-track model

---

## KEY DECISIONS MADE

| Decision | Rationale |
|----------|-----------|
| Production = single database | Two-DB setup is a prototyping safety measure, not architecture |
| Two-Step Query Pattern is a workaround to eliminate | In production, use normal JOINs |
| Payment is table stakes, not engagement | Paying a bill is the cost of membership, not a connection signal |
| Transactions are baseline, not engagement | Selling real estate is what agents do, not how they connect with their org |
| All scoring signals must be client-configurable | Different orgs weight engagement differently |
| Custom signals accepted through Membio, not self-service | Quality control on data before it enters the scoring engine |
| 100% Coverage Test for new signals | If <10% of membership is covered, it's a vanity metric |
| Compliance module is association-only | MLSs don't enforce CE, COE, designations, or Fair Housing |
| Stage 0 client intake config before any code migration | org_type and feature flags drive the entire platform's behavior |
| Merge fields need three tiers including live data | Tier 3 (transaction addresses, prices) is what makes emails feel personal |
| AI should suggest contextual merge fields | The composer should know what data is available and use it |
| Parking lot ideas bridge to CLAUDE.md via "What's Coming" | Architectural implications flagged without speccing the features |

---

## STANDING RULES (ALL PRIOR RULES REMAIN, PLUS)

- The CLAUDE.md is the single source of truth for the production repository. If it conflicts with code comments, the CLAUDE.md wins.
- Every scoring signal must pass the 100% Coverage Test before inclusion.
- The scoring engine is data-driven (config), not code-driven (if-statements).
- Compliance panels are hidden for organization types where they don't apply.
- Merge field resolution is pluggable — triggers provide context, the engine resolves available fields.
- The AI email service receives the list of available merge fields for the current email context.

---

*This summary covers the March 4, 2026 CLAUDE.md writing session. Tracy has additional edits pending for the next conversation, followed by module work targeting a show in approximately two weeks.*

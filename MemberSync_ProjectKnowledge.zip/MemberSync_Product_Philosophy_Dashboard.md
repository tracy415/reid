# MemberSync: Product Philosophy & Dashboard Specification
## The Engagement Platform for the 75%

**Membio Inc. | February 2026**
**Author: Tracy (with Claude)**

---

## PART 1: WHY THIS PRODUCT EXISTS

### The 75% Problem

Real estate associations are subscription businesses that don't think of themselves as subscription businesses.

At Mainstreet REALTORSÂ®, 18,275 active members pay annual dues. Of those, the top 25% (approximately 4,569 agents) control 88% of all closed residential volume. The top 1% â€” just 183 agents â€” control 23% of volume. The remaining 75% â€” approximately 13,700 members â€” produce only 12% of volume. More than 7,300 of them have had zero transactions in the past 12 months.

And yet, they keep paying dues. Year after year. For decades.

This pattern is not unique to Mainstreet. Membio's original research across five large US MLS systems found that the top 25% of producing agents consistently control 69-71% of closed volume and units. The 75% is an industry-wide phenomenon.

### Why the 75% Stay

The conventional wisdom is that members stay for MLS access. That's partially true for the top 25%, who need MLS access to do business. But for the 75% â€” the members who rarely or never transact â€” MLS access alone doesn't explain decades of loyal membership.

Membio's motivation research (2023) found that the 75% stay because of a different set of needs:

- **Autonomy**: Real estate agents value doing things their own way. This is the common motivator across all members.
- **Connection**: The 75% uniquely value being connected to other people â€” peers, mentors, their professional community. This is the key differentiator from the top 25%, who are more driven by competence and mastery.
- **Identity**: Being a REALTORÂ® is a professional identity that matters to people even when they aren't actively selling. The badge, the designation, the belonging.
- **Purpose**: People are more motivated when they feel what they do matters and that they can have an impact on the outcome.

In short: the top 25% are members because they need to be. The 75% are members because they want to be. The association's job is to make sure they keep wanting to be.

### The Existential Threat

The rules are changing. MLSs across the country are going non-Realtor, meaning any licensed agent can access MLS data without being a member of a REALTORÂ® association. For the top 25%, this means they can negotiate â€” why pay association dues when they can access the MLS directly? For the 75%, this removes the last transactional justification for membership. If the association hasn't built a relationship with these members â€” if it hasn't given them a reason to belong beyond MLS access â€” they will do the math and leave.

An association that loses 75% of its membership loses 75% of its dues revenue. The remaining 25% of top producers, with their leverage, will demand lower rates. The association collapses.

The associations that survive will be the ones that act like what they are: subscription businesses. They will actively engage their members, measure that engagement, celebrate connection, and intervene before members drift away. They will be marketing-forward, data-driven, and obsessed with making every member feel like their organization knows them, values them, and serves them.

That is what MemberSync is for. That is what Membio does.

### Courted: The Parallel

Courted.io proved that real estate professionals will pay for a platform that turns MLS data into retention intelligence. Courted does this for brokerages â€” helping them recruit agents by celebrating achievements, spotting risk early, and enabling personalized outreach. They use the same data Membio uses (MLS production, agent profiles) to solve the same fundamental problem (retention) for a different customer (the broker, not the association).

MemberSync takes Courted's insight and applies it at a much larger scale. Brokerages retain individual agents. Associations retain entire memberships. The data foundation is the same; the impact is orders of magnitude larger.

But there's a critical difference: Courted's metrics are almost entirely production-based. Agent volume, transaction count, market share. This works for brokerages because production IS the relationship. For associations, production is only the relationship for 25% of members. MemberSync must measure what matters for all 100% â€” and especially for the 75% whose connection to the association is built on education, events, payment behavior, and the sense of belonging.

---

## PART 2: PRODUCT PHILOSOPHY

### Principle 1: Engagement Is Not Production

Production (transactions, volume, sides) is one form of engagement, relevant to approximately 25% of the membership. For the 75%, engagement means:

- Did they register for a class or event?
- Did they attend?
- Did they complete continuing education?
- Did they open and click on emails from the association?
- Did they pay their dues on time â€” or early?
- Did they renew without being chased?
- Did they earn or renew a professional designation?

These are the signals that someone feels connected to the organization. When these signals weaken â€” a member who always attended events stops showing up, a member who always paid on time is suddenly late â€” that's a retention risk. Not because of production, but because of disengagement.

### Principle 2: Celebrate Connection, Not Just Achievement

The current dashboard is built around alarm: at-risk members, compliance alerts, overdue invoices. It tells the association executive what's wrong. But associations don't retain members by fixing problems â€” they retain members by making them feel valued.

MemberSync should lead with celebration:
- "47 members registered for next week's ABR class"
- "Maria Gonzalez just completed her 10th year as a member"
- "Your renewal rate is tracking 3% ahead of last year"
- "The Ethics Masterclass is 80% full â€” 3 days left to promote"

When the dashboard makes the executive feel good about their organization, they use the product. When it makes them feel anxious, they avoid it.

### Principle 3: Every Member Dollar Is Equal

The top 1% produce 23% of volume. But the 75% produce 75% of dues revenue. An association that loses a top producer loses one member. An association that fails to engage the 75% loses the financial foundation of the entire organization.

The dashboard must never inadvertently signal that non-producing members are less important. Engagement scores, risk indicators, and success metrics must be calibrated to treat a License Maintainer who takes classes, pays on time, and attends networking events as a fully engaged member â€” not a "6 out of 10" because they didn't close a deal.

### Principle 4: Measure What Matters for Subscription Businesses

Associations should see the metrics that every SaaS company obsesses over, translated to their world:

| SaaS Metric | Association Equivalent | Data Source |
|---|---|---|
| Monthly Active Users | Members with meaningful activity in last 30 days | Events, education, email engagement, payments |
| Churn Rate | Lapse rate (Active â†’ Inactive) | Status change tracking |
| Net Revenue Retention | Renewal rate + dues collected vs. prior year | Invoice/payment data |
| Customer Health Score | Engagement score (tier-appropriate) | Composite of all activity |
| NPS / Satisfaction | Email engagement rate + event participation rate | Campaign analytics + registration data |
| Time to Value | Days from joining to first meaningful engagement | Join date vs. first event/class/email open |

### Principle 5: The AI Should Think Like a Membership Director

The AI assistant, the dashboard, the audience builder, and the campaign tools should all embody the mindset of a great membership director â€” someone who knows every member's story, notices when something changes, and reaches out proactively with relevance and warmth. Not "Dear Member, your dues are overdue" but "Hi Sarah, we noticed you haven't been to an event in a while â€” here's one we think you'd love based on what you've attended before."

---

## PART 3: DASHBOARD SPECIFICATION

### Design Philosophy

The dashboard answers one question every morning: **"Is our organization becoming more or less relevant to our members?"**

It is organized as a morning briefing with three sections, designed to be glanced at over coffee in 30 seconds and explored in depth when time allows.

### Section 1: The Pulse (Top of Page)

Four metric cards, always visible. Each shows a current number, a comparison (prior period or target), and a trend direction. Color-coded: green = good, amber = watch, no red unless something requires immediate action.

**Card 1: Total Active Members**
- Current count (from member_metrics_cache)
- Net change this month (new joins minus lapses)
- Comparison: same month prior year (if historical data is reliable)
- Drill-down: clicking shows new members, lapses, and reinstated members this month

**Card 2: Member Engagement Rate**
- Percentage of active members with at least one meaningful activity in the last 90 days
- "Meaningful activity" = attended an event, completed education, opened a campaign email, or made a payment
- Trend arrow vs. prior quarter
- Drill-down: breakdown by activity type (education, events, email, payments)

**Card 3: Upcoming Renewal Health** (contextual â€” shows during billing cycle)
- During annual billing (July-January): percentage of members who have paid vs. outstanding
- Off-cycle: shows "Members paid current" as a percentage
- Countdown to next billing deadline
- Drill-down: payment funnel (paid early â†’ paid on time â†’ outstanding â†’ overdue â†’ grace period)

**Card 4: Campaign Effectiveness**
- Average open rate across campaigns sent in the last 30 days
- Average click rate
- Total members reached
- Drill-down: list of recent campaigns with individual performance

### Section 2: Today's Activity (Middle of Page)

A compact activity feed showing what happened recently. Each item is clickable and actionable. Think of it as a news feed for the association.

Categories of activity items:
- **New Members**: "3 new members joined today" â†’ click to see who they are and send a welcome campaign
- **Event Registrations**: "12 registrations for Ethics Masterclass this week" â†’ click to see the event and promote it
- **Classes Filling Up**: "ABR Designation course is 80% full" â†’ click to send a reminder campaign to eligible members
- **Campaign Performance**: "Your February newsletter had a 34% open rate" â†’ click to see full analytics
- **Milestones & Celebrations**: "8 members are celebrating membership anniversaries this week" â†’ click to send congratulations
- **Status Changes**: "4 members moved to Suspended status this week" â†’ click to see who and take action (once lapse prevention is built)

Activity items are sourced from:
- `apmeventregistration` (registrations)
- `apmevent` (upcoming events, capacity)
- `email_campaigns` / `email_sends` (campaign performance)
- `milestoneDetectionService` (celebrations)
- `member_metrics_cache` (new member detection via join date)
- Status change capture (once lapse prevention is built)

### Section 3: The 75% Report (Bottom of Page)

This is the section that makes MemberSync unique. It takes the 75% research and makes it operational.

**Membership Composition Donut Chart**
- Three segments: Rainmakers (2+ transactions/12mo), Builders (1+ transactions/24mo), Foundation (0 transactions)
- Shows both count and percentage for each segment
- Clicking a segment filters the activity data below to that tier

**Engagement by Tier**
- For each tier, show: average engagement score, percentage with activity in last 90 days, top engagement activities
- The key insight: a Foundation member with a score of 6/10 should be shown as "Highly Engaged" because for their tier, that IS highly engaged. The current system shows them as "medium" which is misleading.

**Connection Signals for the Foundation (the 75%)**
- Education: How many Foundation members completed CE or attended a class in the last 90 days?
- Events: How many attended a networking event or committee meeting?
- Email: What's the open rate for campaigns targeted at non-producers?
- Payment: What percentage paid on time or early?
- These four metrics, trended over time, tell the association whether their 75% is staying connected or drifting away.

### Celebrations: Making Members Feel Seen

The current celebrations feature recognizes milestone anniversaries (5, 10, 15 years) and major production achievements. This is a good start but misses the moments that make people feel personally noticed. Most members will never hit a 5-year milestone or a production record â€” but every member does something worth recognizing.

**Expand celebrations to include frequent, personal moments:**

- **Early-career milestones**: 1st anniversary, 2nd anniversary, 6 months as a member â€” not just the big round numbers
- **Personal bests**: "Your best closing ever â€” $425K in Elmhurst!" or "Your first listing in a new city!"
- **Education momentum**: "You just completed your 3rd class this year" or "You've earned 12 CE credits this quarter"
- **Consistency recognition**: "You've attended 5 events this year â€” you're one of our most active members"
- **Payment recognition**: "Thank you for renewing early â€” you're one of the first 500 members to renew for 2027"
- **Designation achievements**: "Congratulations on earning your ABR designation!"

**Use member headshots in celebration widgets.** The dashboard should show real faces â€” a grid of smiling member photos alongside their achievements. This transforms the dashboard from a data tool into something that feels like a community. The headshot infrastructure already exists via `agentHeadshotService`.

**Celebrations should be the first thing the executive sees when they open MemberSync.** Not alerts, not risk scores â€” achievements. "Here's what your members accomplished today." This sets the tone for the entire product experience.

### What to Remove from the Current Dashboard

- **Compliance Alerts card** (32,252): Move to the existing Compliance page. It's not a daily dashboard metric â€” it's a specialized report. The number is misleading and scary without context.
- **At-Risk Members breakdown** (Critical/High/Medium): Replace with the tier-aware engagement view. "5,983 at-risk members" means nothing actionable. "73% of your License Maintainers had no activity in the last 90 days" is actionable.
- **Licenses Expiring in 30 Days**: Move to Compliance page.

### What to Keep

- **Total Active Members**: Keep, enhance with net change and trend
- **Celebration Insights sidebar**: Keep and elevate â€” this is the most valuable widget on the current dashboard
- **Office-level metrics**: Keep but move to Analytics. The dashboard should be about the membership as a whole, not individual offices.

---

## PART 4: ENGAGEMENT SCORE REDESIGN

### Current Scoring (Needs Revision)

The current engagement score (0-10) is weighted:
- Transaction activity: 0-4 points
- Education/Events: 0-2 points
- Payment: 0-3 points
- Recency bonus: 0-1 point

This means a License Maintainer's maximum possible score is 6/10 â€” they can never achieve "highly engaged" no matter how active they are in education, events, and payments. This is philosophically wrong.

### Proposed Tier-Aware Scoring

The three tiers are renamed to reflect their value to the organization:

| Old Name | New Name | Definition |
|---|---|---|
| Active Producer | **Rainmaker** | 2+ transactions in last 12 months |
| Occasional Producer | **Builder** | 1+ transactions in last 24 months |
| License Maintainer | **Foundation** | No transactions in 24+ months |

The names matter. "Foundation" members are the financial and community foundation of the association. "Builder" members are actively growing their careers. "Rainmaker" is self-explanatory. Every tier name is positive. No member is defined by what they don't do.

Each tier has its own scoring model, all on a 0-10 scale, weighted to the activities that matter for that tier:

**Rainmakers (2+ transactions/12mo):**
- Transaction activity: 0-3 points (still important, but not dominant)
- Education/Events: 0-2 points
- Payment: 0-2 points
- Email engagement: 0-1 point
- Recency: 0-1 point
- Designation/Leadership: 0-1 point

**Builders (1+ transactions/24mo):**
- Transaction recency: 0-2 points
- Education/Events: 0-3 points (more important â€” this is how they connect)
- Payment: 0-2 points
- Email engagement: 0-1 point
- Recency: 0-1 point
- Designation/Leadership: 0-1 point

**Foundation (0 transactions/24mo):**
- Education/Events: 0-4 points (this IS their engagement)
- Payment behavior: 0-3 points (paying on time = committed member)
- Email engagement: 0-1 point
- Recency of any activity: 0-1 point
- Designation/Leadership: 0-1 point

This means a Foundation member who takes 3 classes, pays on time, opens emails, and renewed a designation can score 10/10. They ARE fully engaged â€” just not through production.

### Engagement Labels

Replace the current risk-oriented labels with engagement-oriented labels:

| Score | Current Label | Proposed Label |
|---|---|---|
| 8-10 | Low risk | Highly Connected |
| 5-7 | Medium risk | Connected |
| 3-4 | High risk | Drifting |
| 0-2 | Critical risk | Disconnected |

"Drifting" is the key label. It means: this member used to be connected but is showing signs of disengagement. It's not alarming â€” it's actionable. "We should reach out."

---

## PART 5: IMPLEMENTATION NOTES

### What Can Be Built Now (Data Exists)

1. **Membership Composition chart** â€” tier data is in `member_metrics_cache`
2. **New members today/this month** â€” `nar_join_date` in `apmmember`
3. **Event registrations** â€” `apmeventregistration` with `RegistrationDate`
4. **Class capacity** â€” `apmevent` with `TotalRegisteredAttendees` and `MaxAttendees`
5. **Campaign performance** â€” `email_campaigns` and `email_sends`
6. **Celebrations/Milestones** â€” `milestoneDetectionService` already built
7. **Payment behavior** â€” `apmmemberdues` with invoice dates and payment status
8. **Email engagement rate** â€” campaign analytics already tracked
9. **Engagement rate (activity in last 90 days)** â€” computable from events, education, payments, email data

### What Requires New Infrastructure

1. **Net membership change** â€” requires the status change capture job from Phase 3 (lapse prevention). Can show "coming soon" placeholder or use join date data for new members only.
2. **Daily engagement score snapshots** â€” need a new table to store daily tier distribution for trending. Currently the cache is refreshed daily but overwrites; need to append to a history table.
3. **Email engagement as scoring input** â€” need to connect `email_sends` open/click data back to member keys in the engagement score calculation.
4. **Renewal funnel** â€” requires billing calendar awareness to show contextual payment status during billing cycles.
5. **Tier-aware engagement scoring** â€” requires updating `memberMetricsCacheService.ts` scoring formula.

### Implementation Priority

1. **Engagement score redesign** (tier-aware scoring) â€” this changes the foundation everything else is built on
2. **Dashboard Section 1: The Pulse** â€” four metric cards with the new scoring
3. **Dashboard Section 3: The 75% Report** â€” composition chart and tier engagement view
4. **Dashboard Section 2: Today's Activity** â€” activity feed
5. **Daily snapshot table** â€” for trending over time
6. **Remove compliance/risk widgets** â€” move to their dedicated pages

---

## PART 6: HOW THIS DOCUMENT SHOULD BE USED

This document serves three purposes:

1. **Product Foundation**: Every feature in MemberSync should be evaluated against the principles in Part 2. Does it celebrate connection? Does it treat every member dollar as equal? Does it measure what matters for a subscription business?

2. **Replit Prompts**: Parts 3-5 can be broken into Replit prompts for implementation. Start with the engagement score redesign, then the dashboard sections.

3. **Sales Narrative**: Parts 1-2 are the story you tell prospective clients. "Your association has 18,000 members. 75% of them produce little or no real estate. But they pay 75% of your dues. Do you know if they're connected to your organization? Do you know if they'll renew next year? MemberSync tells you â€” and helps you make sure they do."

---

*"The thing I hate about our industry is its data. Membio makes it useful."*
*â€” Tracy, Founder*

# MemberSync — SmartSends Reporting & Analytics + Create Flow Fix
## Replit Prompt

*Written: March 8, 2026*
*Status: READY TO SEND*

---

## WHAT THIS PROMPT FIXES

Four distinct problems, addressed in order of dependency. Read all sections before writing any code.

1. **The campaign list is broken** — triggered automations create thousands of individual rows instead of rolling up to one row per automation.
2. **The Reporting & Analytics page is the wrong model** — it should be the single command center for all SmartSends outbound activity, with the right behavior for each campaign type when opened.
3. **The Create flow is missing Automations** — there are only 4 tiles on the Create page and 4 options in the Create button dropdown. Automations is missing from both.
4. **The orphaned Automations page** — now that analytics are in Reporting & Analytics and creation is in the Create flow, the standalone Automations page and its nav item are retired. Its content is absorbed.

**What does NOT change:** Recognition and Compliance sends are not part of SmartSends Reporting & Analytics. They are separate modules with their own performance pages. They do not appear in the SmartSends campaign list at any time, under any filter.

---

## ARCHITECTURAL CONTEXT — READ BEFORE WRITING ANY CODE

### How triggered campaigns work (do not change this)

When an automation fires, it calls `queueEmailCampaign()` once per qualifying member. Each call creates one row in `email_campaigns`. These are the audit trail — do not delete them.

The **`triggered_campaigns`** table is the source of truth for the automation config. One row = one automation.

The **`triggered_campaign_sends`** table is the dedup and history log. One row per member per trigger event. Each row has an `email_campaign_id` linking to the individual `email_campaigns` row that processor created.

**Do NOT modify `triggeredCampaignProcessor.ts` for any reason. Do NOT modify `sequenceEnrollmentService.ts` for any reason.**

### Campaign type ownership

| Source | Type | Belongs in SmartSends? |
|---|---|---|
| `email_campaigns` — user created | Email | Yes |
| `triggered_campaigns` — `event_registration`, `event_reminder`, `event_followup` | Trigger | Yes |
| `triggered_campaigns` — `drip_sequence` | Sequence | Yes |
| `triggered_campaigns` — `membership_anniversary`, `production_milestone` | Recognition | No — Recognition module only |
| `triggered_campaigns` — `compliance` | Compliance | No — Compliance module only |

---

## FIX 1 — REPORTING & ANALYTICS: UNIFIED COMMAND CENTER

### The model

Reporting & Analytics at `/smartsends/reporting` is the single place where staff find, monitor, and act on every SmartSends outbound communication. It is not a read-only archive. What you can do when you open a campaign depends on its status and type — described in detail below.

### Backend: unified campaign list endpoint

The endpoint serving this page must combine two data sources and exclude processor-generated noise.

**Source A — Manual and scheduled campaigns:**
```sql
SELECT
  ec.campaign_id AS id,
  ec.name,
  ec.status,
  ec.created_at,
  ec.scheduled_send_at AS send_date,
  'email' AS campaign_type
FROM email_campaigns ec
WHERE NOT EXISTS (
  SELECT 1 FROM triggered_campaign_sends tcs
  WHERE tcs.email_campaign_id = ec.campaign_id
)
```

**Source B — Triggered automations and sequences (rolled up, one row each):**
```sql
SELECT
  tc.campaign_id AS id,
  tc.campaign_name AS name,
  tc.status,
  tc.created_at,
  tc.last_sent_at AS send_date,
  tc.total_sent,
  CASE tc.trigger_type
    WHEN 'drip_sequence' THEN 'sequence'
    ELSE 'trigger'
  END AS campaign_type
FROM triggered_campaigns tc
WHERE tc.trigger_type IN (
  'event_registration',
  'event_reminder',
  'event_followup',
  'drip_sequence'
)
```

Merge both sources. Sort by send_date DESC. Apply filters. Paginate at SQL level — do not fetch all rows and slice in JavaScript.

**Stats for triggered rows** — aggregate from `triggered_campaign_sends` in a single GROUP BY query:
- Recipients: COUNT with status IN ('sent', 'queued', 'pending')
- Sent: COUNT with status = 'sent'
- Open Rate / Click Rate: join to linked `email_campaigns` rows via `email_campaign_id`, aggregate opens and clicks. Return "—" if no data yet.

Never loop and query one row at a time.

### Filters and search

**Type dropdown:** All Types / Email / Trigger / Sequence
*(Recognition and Compliance are not options — they do not belong here)*

**Status dropdown:** All / Draft / Scheduled / Active / Sent / Paused / Archived

**Search:** campaign name, case-insensitive.

Drafts appear in this list with status = Draft. There is no separate Drafts nav item.

### Each row displays

| Column | Notes |
|---|---|
| Campaign name | Clickable |
| Type badge | Email (blue) / Trigger (purple) / Sequence (teal) — color-coded |
| Status badge | Draft / Scheduled / Active / Sent / Paused / Archived |
| Send date | last_sent_at for triggered; sent_at or scheduled_send_at for emails |
| Recipients | Total for that campaign or automation |
| Open Rate | Percentage or "—" |
| Click Rate | Percentage or "—" |

**The list must never show a row with recipient count of 1 and a "[Triggered]" suffix.** If that pattern appears, the rollup is not working.

### What opening a row does — by status and type

**Sent email campaign:**
Opens a detail view showing: performance stats (recipients, delivered, open rate, click rate, unsubscribed), the email content preview, and the full member-level activity table (see Member Drill-Down section below). Read-only. One action available: **Resend** — which creates a new draft copy of this campaign and opens it in the email composer. The original sent record is unchanged.

**Scheduled email campaign:**
Opens the email composer pre-loaded with this campaign's content and schedule. Staff can edit the email, change the send time, or cancel the send.

**Draft email campaign:**
Opens the email composer. Fully editable.

**Active automation (trigger type):**
Opens a detail view showing: performance stats, send history (member-level activity table), trigger configuration summary, and current status. Two actions: **Edit** (opens trigger config editor to change email content, trigger rules, or send window — must pause first if active) and **Pause/Resume** toggle.

**Active sequence (drip_sequence type):**
Opens a detail view showing: sequence plan summary, per-step performance stats, member enrollment table, and overall stats. Two actions: **Edit** (opens Campaign Architect session for this sequence) and **Pause/Resume** toggle.

**Paused or archived automation/sequence:**
Same detail view, but Edit is available without requiring a pause step.

### Member-level drill-down — REQUIRED ON ALL SENT CAMPAIGNS

This is a standing product rule. Every email that MemberSync sends must be traceable to the individual member level. No exceptions.

On every sent campaign detail view — whether it's a manual email, a triggered automation send, or a step in a sequence — there must be a member activity table with the following columns:

| Column | Value |
|---|---|
| Member Name | Full name, linked to member profile |
| Email Address | The address it was sent to |
| Status | Delivered / Opened / Clicked / Bounced / Unsubscribed / Skipped |
| Timestamp | Date and time of the most recent status event |
| Details | For Skipped: show skip reason (e.g. "Sandbox mode", "Opted out", "Governor limit") |

This table must be:
- Sortable by status and timestamp
- Searchable by member name or email
- Paginated if more than 50 rows
- Readable on mobile (responsive layout)

For triggered automations, this table shows all members contacted across all sends for that automation, not just the most recent batch. If the staff member wants to filter by date or batch, they can use the date filter.

**Source for this data:**
- For manual email campaigns: `email_recipients` table joined to `email_events` for open/click/bounce/unsubscribe events
- For triggered automation sends: `triggered_campaign_sends` joined to the linked `email_campaigns`/`email_recipients`/`email_events` rows via `email_campaign_id`

---

## FIX 2 — CREATE FLOW: ADD AUTOMATIONS

### The Create page (`/smartsends/create`)

Currently has 4 tiles. Add a fifth: **Create Automation**.

**Five tiles, in order:**

1. **Send an Email**
   - Icon: envelope
   - Description: "Compose and send a one-time email to a targeted audience. Perfect for announcements, updates, and event promotions."
   - Button: "Start Composing" → opens email composer

2. **Build a Sequence**
   - Icon: layers/stack
   - Description: "Design a multi-step email sequence with AI assistance. Great for onboarding flows, drip campaigns, and nurture series."
   - Button: "Open Architect" → opens Campaign Architect

3. **Create Automation** ← NEW TILE
   - Icon: lightning bolt or gear
   - Description: "Set up a triggered campaign that fires automatically based on member activity — event registrations, reminders, and follow-ups."
   - Button: "Create Automation" → opens trigger configuration flow (the existing trigger creation UI currently accessible only from the orphaned Automations page)

4. **Set Up a Trigger**
   - *Wait — see note below*

5. **Member Journey**
   - Icon: path/route
   - Description: "Build visual, multi-path member journeys with conditional branching and personalized touchpoints."
   - Button: "Coming Soon" (greyed, inert)

**Note on "Set Up a Trigger" vs "Create Automation":** These appear to be the same thing. Review the existing code. If "Set Up a Trigger" and "Create Automation" both lead to the same trigger configuration flow, consolidate them into one tile called "Create Automation" and remove the redundant tile. If they are genuinely different flows, keep both and clarify the description text so the difference is obvious. Do not have two tiles that do the same thing.

### The Create Campaign button (top-right, visible on all SmartSends pages)

This button currently navigates directly to the Create page. Change it to a **dropdown** with the same five options:

- Send an Email → email composer
- Build a Sequence → Campaign Architect
- Create Automation → trigger configuration flow
- Member Journey → Coming Soon (greyed, show tooltip "Coming soon")

Clicking the button label itself (not the dropdown arrow) navigates to `/smartsends/create` as a fallback.

---

## FIX 3 — DELETE THE STANDALONE AUTOMATIONS PAGE

The Automations page at `/smartsends/automations` is fully superseded and must be deleted. Its two functions have been absorbed:
- **Viewing and managing automations** → Reporting & Analytics (rolled-up rows)
- **Creating a new automation** → Create page tile + Create button dropdown

**What to do:**
- Delete the Automations page component file entirely
- Remove its route from `App.tsx`
- Remove "Automations" from the SmartSends sidebar nav if present
- Remove any imports, links, or references to it anywhere in the codebase

No redirect. No stub. Gone.

---

## FIX 4 — RECOGNITION AND COMPLIANCE PERFORMANCE PAGES

These are separate from SmartSends entirely. Build them as real pages — not "Coming soon" stubs.

### Recognition → Performance (`/recognition/performance`)

**Data source:** `triggered_campaigns` WHERE `trigger_type` IN ('membership_anniversary', 'production_milestone'), joined to `triggered_campaign_sends` for counts, joined to linked `email_campaigns` rows for open/click stats.

**Summary cards:**
- Recognition Emails Sent — All Time
- Sent This Month
- Average Open Rate
- Members Reached This Month

**Automation table:** One row per recognition automation.
Columns: Name | Type (Anniversary / Milestone) | Status badge | Total Sent | Open Rate | Last Sent

**Clicking a row** → detail view with the full member-level activity table (same drill-down standard as SmartSends — member name, status, timestamp, for every send that automation has ever made).

**Empty state:** "No recognition automations are active yet."

### Compliance → Performance (`/compliance/performance`)

Same pattern. Data source: `triggered_campaigns` WHERE `trigger_type` = 'compliance', plus any `email_campaigns` rows with `category = 'compliance'`.

Same summary cards and table structure.

**Empty state:** "No compliance communications have been sent yet. Configure one under Compliance → Communications."

---

## STANDING RULES FOR THIS PROMPT

- **Do not modify `triggeredCampaignProcessor.ts`.**
- **Do not modify `sequenceEnrollmentService.ts`.**
- **No fake data.** "—" for missing stats. Never invent numbers.
- **Recognition and Compliance sends never appear in SmartSends Reporting & Analytics.** Not as a filter option. Not in the "All Types" view. Not anywhere. This is a product architecture decision.
- **Member-level drill-down is required on every sent campaign, no exceptions.** This is a standing product rule.
- **Resend creates a draft.** It does not re-send immediately. It copies the campaign content into a new draft and opens the composer.
- **Pagination at SQL level.** Never fetch all rows and slice in JavaScript.
- **The list must never show "[Triggered]" rows with recipient count of 1.** That pattern means the rollup is broken.

---

## VERIFICATION CHECKLIST — COMPLETE IN ORDER

**Fix 1 — Unified campaign list:**
- [ ] App compiles without TypeScript errors
- [ ] No "[Triggered]" rows with recipient count of 1
- [ ] Each automation appears once with correct total send count
- [ ] Recognition and Compliance automations absent from list
- [ ] Manual and scheduled campaigns display correctly
- [ ] Drafts appear with status = Draft
- [ ] Type filter: Email / Trigger / Sequence options only (no Recognition, no Compliance)
- [ ] Status filter: all statuses work correctly
- [ ] Search works by campaign name
- [ ] Charts render or show graceful empty state
- [ ] Pagination works — page 2 shows different results than page 1

**Fix 1 — Campaign detail / actions:**
- [ ] Sent email: opens read-only detail with member drill-down table + Resend button
- [ ] Resend: creates a draft copy and opens composer — original record unchanged
- [ ] Scheduled email: opens composer, editable
- [ ] Draft email: opens composer, editable
- [ ] Active automation: opens detail with stats + member table + Edit + Pause buttons
- [ ] Active sequence: opens detail with plan + per-step stats + Edit (→ Campaign Architect) + Pause buttons
- [ ] Member drill-down table: name, email, status, timestamp, skip reason — on every sent campaign
- [ ] Member drill-down: sortable, searchable, paginated at 50 rows, mobile responsive

**Fix 2 — Create flow:**
- [ ] Create page has 5 tiles (or 4 if Trigger and Automation were duplicates and consolidated)
- [ ] Create Automation tile present and navigates to trigger configuration flow
- [ ] Member Journey tile present and greyed as Coming Soon
- [ ] Create Campaign button is a dropdown with matching options
- [ ] All dropdown options navigate to correct destinations
- [ ] Coming Soon items in dropdown are greyed and show tooltip

**Fix 3 — Automations page deleted:**
- [ ] Automations page component file deleted
- [ ] Route removed from `App.tsx`
- [ ] "Automations" not present anywhere in sidebar nav
- [ ] No remaining imports or references to the deleted component

**Fix 4 — Module performance pages:**
- [ ] Recognition → Performance loads with real summary cards and automation table
- [ ] Clicking a recognition automation row shows member drill-down
- [ ] Compliance → Performance loads without errors
- [ ] Both pages show correct empty state when no data exists

**No regressions:**
- [ ] SmartSends home page unaffected
- [ ] Campaign Architect unaffected
- [ ] Recognition queue (existing) unaffected
- [ ] All other nav items load correctly
- [ ] Email composer opens correctly from all entry points

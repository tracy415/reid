# MemberSync — Project Summary
## March 4, 2026 (Evening Session — Product Architecture, CLAUDE.md v2, Replit Prompts)

---

## OVERVIEW

This session was the most architecturally significant since the two-track model decision. It covered four major areas: (1) the full Membio product ecosystem was mapped for the first time, revealing MemberSync's position within a four-product suite; (2) a modular framework architecture was defined that goes beyond multi-tenancy; (3) the CLAUDE.md was substantially upgraded to version 2 (786 lines); and (4) two Replit prompts were written to improve the AI Chat before team handoff tomorrow.

**RESO Conference context:** Tracy has a speaking proposal submitted for RESO in Minneapolis, March 23–27. Three weeks to prepare. The demo path needs to be stable and compelling for MLS executives and technical leaders.

---

## THE MEMBIO PRODUCT ECOSYSTEM (Newly Documented)

MemberSync is the fourth product in Membio's suite. Understanding the full ecosystem is critical for architecture decisions:

1. **Member Portal** — Member-facing SSO environment (listings, documents, benefits, portal notifications). Members see their value here.
2. **Enterprise Websites** — AMS-integrated public sites (Duda CMS). Public-facing presence.
3. **Property Search** — Hyper-local consumer portals.
4. **MemberSync** — Staff-facing engagement intelligence platform. Staff *create* the value that members experience in the portal.

**The strategic relationship:** MemberSync's AI brain eventually feeds personalized content into the Member Portal dynamically. For now they are separate but complementary — not competing.

**Current clients with portal:** Mainstreet (has portal), HGAR (onboarding, has portal). GRAR and CRMLS do not yet have portals.

### Admin Portal (Separate Codebase — Content Management Side)
Tracy shared screenshots of the existing Membio Admin Portal. Multiple features will eventually migrate into MemberSync:

- **SmartSends** (three types: Smart Message/email, Banner/portal notification bar, Recommendation/portal content card)
- **Member Pages** (134 pages for Mainstreet, organized by section, permissioned by member type)
- **Education** (Courses, Classes, Instructors, Events, Speakers, Sponsors — 90 classes, 30 events, 31 instructors, 239 speakers, 390 sponsors for Mainstreet)
- **Documents** (Most-used section in the member portal. Permissioned by member type, categorized)
- **Affiliates** (see below — important strategic opportunity)

**Migration principle:** Admin Portal = content management. MemberSync = intelligence layer. Eventually intelligence drives content delivery across all channels. Portal-only features (Banner, Recommendation) must be hidden for non-portal clients — not just empty, hidden.

### Affiliates — Strategic Opportunity
Affiliate members are aligned businesses (title companies, lenders, attorneys, inspectors, etc.) that join associations to access REALTOR® members. Key facts:
- Same Office > Agent structure as regular members in most AMSs
- NOT REALTOR® members — do not appear in agent roster, no MLS access
- DO appear in member portal and enterprise website in their own directory
- Chronically dissatisfied: feel they only get "a table in the back of the room"
- 148 affiliate companies, 143 affiliate members at Mainstreet
- **MemberSync opportunity:** Surface introduction opportunities between affiliates and relevant agents, track affiliate ROI from membership, help affiliates present meaningful content to members. Affiliates are a separate dues revenue stream that associations universally struggle to retain.
- Enabled via `has_affiliates` flag in tenant_config

---

## MODULAR FRAMEWORK ARCHITECTURE (New — Core Decision)

**The key distinction from multi-tenancy:** Multi-tenancy means every client gets the same product with their own data. Modularity means different clients get different *capabilities* based on what Membio products they have and what tier they're on. Both must be true simultaneously.

**The principle:** Every client gets the Core. Modules are enabled/disabled per client via `tenant_config`. A disabled module must not appear in the UI, must not run background jobs, and must not consume AI budget.

### Core (Always On — All Clients)
- AI Chat
- AI Audience Builder
- AI Email Composer
- Email Analytics
- Agent Profiles
- Office Profiles

### Modules (Conditionally Enabled)
| Module | Enabled When |
|---|---|
| SmartSends Automations | Plus tier+ |
| Lapse Prevention | Plus tier+ |
| Configurable Engagement Scores | Plus tier+ |
| Live Activity Feed | Plus tier+ |
| AI Chat with Charts | Premium tier |
| Proactive Engagement Engine | Premium tier |
| Market Analytics | Premium tier |
| Office Intelligence Briefs | Premium tier |
| Compliance Module | Association clients only |
| Portal Channels (Banner + Recommendation) | has_member_portal = true |
| Education & Events | has_website or has_member_portal = true |
| Affiliates | has_affiliates = true |
| Broker Module | Future — all clients |

**New tenant_config fields added:** `has_member_portal`, `has_website`, `has_affiliates`, `product_tier`

**New Standing Rule #14:** Every module must be gated by tenant_config.
**New Standing Rule #15:** The 5% rule — every screen must earn its place.
**New Standing Rule #16:** Mobile-first, performance-always. Every UI must be responsive and usable on mobile. Every data view must load in under 2 seconds.

---

## PRODUCT TIERS (Defined)

### Core
AI Chat, AI Audience Builder, AI Email Composer, Email Analytics, Agent Profiles, Office Profiles

### Plus
Everything in Core + SmartSends Automations (drip/sequence/A/B testing), Configurable Lapse Prevention, Customizable Engagement Scores, Live Activity Feed

### Premium
Everything in Plus + AI Chat with Recharts Visualizations, Proactive Engagement Engine, Market Analytics, Office Intelligence Briefs

### Pricing Philosophy
**Per-member pricing is wrong for this product.** It commoditizes MemberSync and puts it in the same mental bucket as infrastructure (AMS, MLS software, website). The right conversation is ROI: "What does one lapsed member cost you?" At $500–600/year dues, retaining 1% of a 3,400-member org pays for the product in year one.

**Flat annual fee scaled by membership band:**
| Band | Members | Core | Plus | Premium |
|---|---|---|---|---|
| Small | Under 5,000 | ~$12K/yr | ~$18K/yr | ~$28K/yr |
| Large | 5,000–20,000 | ~$18K/yr | ~$28K/yr | ~$42K/yr |
| Enterprise | 50,000+ | Custom | Custom | Custom |

**GRAR data point:** $20,000/year for 3,400 members — fits Small Plus. They said the industry thinks in per-member pricing (~$0.49/member/month) but Tracy correctly identified this frames it as infrastructure, not strategy.

**HubSpot displacement story:** Clients want drip sequences + contact segmentation + email analytics. That's what they actually use HubSpot for. MemberSync already does segmentation better (real MLS/AMS data). Nail drip sequences + A/B testing = legitimate "cancel HubSpot" story.

---

## MEMBIO SUPER-ADMIN & AI COST CONTROLS (New — Documented in CLAUDE.md)

### Three Access Levels
| Level | Who | What They See |
|---|---|---|
| Membio Super-Admin | Membio staff only | All clients, all usage, all config. Can impersonate any client. |
| Client Admin | Association/MLS admin staff | Their org only. Manages users within Membio-set bounds. |
| Client Staff User | Day-to-day users | Uses the product. Subject to rate limits. |

### Super-Admin Panel (To Be Built — Stage 2 / CRMLS target)
- Per-client AI usage (calls, estimated cost, % of budget)
- Per-client email volume and deliverability
- Module on/off per client
- Tenant config editor
- System health (cache refresh, job queue, errors)
- Usage alerts at 80% of monthly AI budget

### API Key Architecture
**One Anthropic API key for all clients.** Never give clients their own key. Membio controls all usage, cost visibility, and rate limits through a single server-side key.

### AI Rate Limits
| Feature | Limit |
|---|---|
| AI Chat | 50 queries/user/day |
| Audience Builder | 20 builds/user/day |
| Email Composer | Unlimited |
| Proactive Engine | System-level batch job, not per-user |

**Cost optimization:** Prompt caching for `sharedDatabaseSchema.ts` content (large, static, injected into every call). Use Claude Haiku for simple tasks (subject line suggestions), Sonnet for complex queries.

---

## COMPLIANCE MODULE (Substantially Updated)

**Previous state:** Compliance described as "association-specific only." MLSs mentioned briefly.

**Updated understanding:** Both associations AND MLSs have compliance requirements, but they are fundamentally different.

### MLS Compliance
MLSs enforce compliance around data accuracy, listing timeliness, and participant behavior. Key violation categories:
- **Category 1:** Listing information errors — warning or fine up to $500 (1st offense), up to $2,000 (repeat)
- **Category 2:** IDX/VOW display violations — letter of reprimand or fine up to $2,000, up to $10,000 + 3-month suspension (repeat)
- **Category 3:** Cooperation violations, mandatory submission failures — reprimand or fine up to $10,000 + suspension up to 90 days; up to $15,000 + 6-month suspension or 1–3 year termination (repeat)
- **NAR Settlement violations (post-August 2024):** Offering buyer agent compensation on MLS ($250–$2,500), displaying compensation on IDX/VOW (can result in 1-year termination of data access)
- MLSs NEVER enforce CE, COE, Fair Housing, or NAR designations

### Association Compliance
Two domains:
1. **Licensure/Education:** CE hours (varies by state), specific required courses, renewal deadlines
2. **Practice Standards/Code of Ethics:** NAR's national triennial COE cycle, Fair Housing, arbitration compliance

### Illinois Rules (Current — Mainstreet)
- CE: 12 hours every 2 years (biennial, even years). Next deadline: April 30, 2026. Includes 6-hour Core + 1 hour Sexual Harassment Prevention + 5 hours electives.
- COE: Every 3 years via NAR. Current cycle: Jan 1, 2025 – Dec 31, 2027. 2.5+ hours required.
- Illinois quirk: All real estate professionals hold "broker" license. No separate "agent" license.

**Architectural principle (unchanged):** Compliance must be configuration, not code. Every state has different CE requirements and course types.

**New companion document flagged:** `MemberSync_Compliance_Reference.md` — detailed compliance rules, fine structures, and enforcement workflows for both associations and MLSs. Does not exist yet but is documented as a companion doc in CLAUDE.md.

---

## PRODUCT PHILOSOPHY (Added to CLAUDE.md)

**"MemberSync is the 5% of software that people actually use."**

This is Tracy's line that resonates immediately with prospects — they nod and laugh because they recognize it. Added to the product vision section of CLAUDE.md.

Three pillars:
- **Zero Training Required** — Intuitive by design, staff adopt in hours not weeks
- **AI Co-Pilot** — Natural language queries surface insights instantly, no data team required
- **Decision-First UX** — Every view surfaces a recommended action, not just data

---

## AI CHAT IMPROVEMENTS (Two Replit Prompts Written)

### Background: The Julius.AI Insight
Tracy observed that Julius.AI (the SQL/data analysis tool used for query development) has a qualitatively different interaction model than MemberSync's current AI Chat. Julius:
- Asks clarifying questions before running analysis
- Notices what's interesting or surprising in the data
- Suggests ways to combine datasets for better answers
- Explains what data *means*, not just what it *says*
- Maintains a pleasant, supportive, slightly enthusiastic tone

The gap is entirely in the system prompt — Claude can do all of this today. It just needs to be instructed to behave this way.

### Prompt 1: sharedDatabaseSchema Modularization
**File:** `MemberSync_SchemaModularization_Prompt.md`
**Run this FIRST before the Julius upgrade**

The `sharedDatabaseSchema.ts` file is ~37,000 characters injected into every AI call. This is wasteful — a member query doesn't need compliance table schema; an email generation call needs no schema at all.

**What it does:**
1. Reads existing named schema sections in `sharedDatabaseSchema.ts` (they already exist as named constants — `AMS_MEMBER_SCHEMA`, `MLS_MEMBER_SCHEMA`, etc.)
2. Adds two new exported functions alongside the existing `getSharedDatabaseSchema()`:
   - `getSchemaForQueryType(queryType)` — returns only relevant schema sections
   - `detectQueryType(question)` — auto-detects query type from natural language
3. Wires `aiQueryService.ts` to use auto-detected focused schema
4. Wires `aiAudienceService.ts` to always use AUDIENCE schema type
5. Removes schema injection from `aiEmailService.ts` entirely (email generation doesn't need database schema)

**Expected result:** 60–75% reduction in tokens per AI call. Faster responses, lower cost, sharper AI focus.

**Safe fallback:** Replace `getSchemaForQueryType(queryType)` with `getSharedDatabaseSchema()` to instantly revert. The change is additive, not destructive.

**Console logging added for verification:** `[AIQueryService] Query type: member, schema size: X chars` — remove after confirming.

### Prompt 2: Julius-Style AI Chat Upgrade + Follow-Up Fix
**File:** `MemberSync_AIChat_JuliusUpgrade_Prompt.md`
**Run this SECOND, after schema modularization passes its tests**

**Part 1 — Upgrade system prompt in `aiQueryService.ts`:**
Adds instructions requiring the AI to:
- Notice what's interesting/surprising in the data (not just return rows)
- Suggest one specific, actionable follow-up question
- Identify when combining with another dataset would improve the answer
- Explain what the data means in plain language
- Handle zero-result queries helpfully (not just "No results found")
- Maintain a pleasant, supportive, slightly enthusiastic tone

**Part 2 — Fix follow-up question failures (50% error rate):**
Root cause: Follow-up questions clicked in the UI are being sent without full conversation history — the AI doesn't know what "those members" refers to.

Two fixes:
1. Click handler must submit follow-up through the same code path as manually typed messages (full conversation history included)
2. AI must generate self-contained follow-up questions that include the specific subject — "Break down the 47 members with expiring licenses by office" not "Break that down by office"

---

## CLAUDE.md v2 — WHAT CHANGED (786 lines, up from 646)

The updated CLAUDE.md is in `/mnt/user-data/outputs/CLAUDE.md` and should be used in the next session. Key additions vs. v1:

1. **Product Philosophy section** — "5% of software" line, three pillars
2. **Modular Architecture section** — Core vs. modules, full module table with enable conditions, architectural rule
3. **Product Tiers section** — Core/Plus/Premium definitions, ROI framing, reference pricing bands
4. **Membio Super-Admin & AI Cost Controls section** — three access levels, super-admin panel spec, single API key rule, rate limits, caching/model selection guidance
5. **AI Response Design Philosophy** — Julius standard with before/after example, architectural note that this is a prompt change
6. **sharedDatabaseSchema full section** — What it is, why 37K chars is a problem, complete modular schema solution with routing table, explicit instruction not to port the monolith
7. **Compliance section rewritten** — Both association AND MLS compliance, your cleaned-up language, companion doc note
8. **Standing Rules 14, 15, 16** — Module gating, 5% rule, mobile-first/performance-always
9. **What's Coming additions** — Portal Channels, Education & Events, Affiliates modules
10. **New tenant_config fields** — has_member_portal, has_website, has_affiliates, product_tier
11. **ANTHROPIC_API_KEY comment** — "Single key for all clients — never expose to clients"
12. **75/12 Rule** — Editing artifacts cleaned up, single clean version

---

## FILES PRODUCED THIS SESSION

| File | Purpose | Location |
|---|---|---|
| `CLAUDE.md` (v2) | Updated product bible — 786 lines | `/mnt/user-data/outputs/CLAUDE.md` |
| `MemberSync_SchemaModularization_Prompt.md` | Replit prompt — run first tonight | `/mnt/user-data/outputs/MemberSync_SchemaModularization_Prompt.md` |
| `MemberSync_AIChat_JuliusUpgrade_Prompt.md` | Replit prompt — run second tonight | `/mnt/user-data/outputs/MemberSync_AIChat_JuliusUpgrade_Prompt.md` |

---

## DECISIONS MADE THIS SESSION

| Decision | Rationale |
|---|---|
| Modular framework (not just multi-tenant) | Modules swap in/out based on Membio products + tier, not just client isolation |
| One Anthropic API key for all clients | Membio controls all cost visibility and rate limits centrally |
| Per-member pricing is wrong | Commoditizes the product; flat annual fee by band preserves strategic positioning |
| Schema modularization in prototype now, not just Track 2 | Improves demo performance, reduces cost, worth doing before RESO |
| Schema split before Julius upgrade | Foundation must be right before building on top of it |
| MLS compliance is a real module, not an afterthought | MLSs have extensive violation/fine structures that MemberSync can help manage |
| Affiliates are a retention opportunity, not just a directory | They're dissatisfied, they want engagement, MemberSync can deliver that |
| Admin Portal features migrate to MemberSync over time | Portal = content management side; MemberSync = intelligence side |
| Portal-only features hidden (not empty) for non-portal clients | Hidden means not rendered at all, not just grayed out |

---

## REPLIT RUN ORDER TONIGHT

1. **`MemberSync_SchemaModularization_Prompt.md`** — Run first. Verify via console logs that query types are being detected and schema sizes are dropping.
2. **`MemberSync_AIChat_JuliusUpgrade_Prompt.md`** — Run second. Verify via actual queries that responses are more analytical and follow-ups work reliably.

Both prompts have explicit "What NOT to Change" sections and safe fallback instructions.

---

## NEXT SESSION PRIORITIES

The team is on the East Coast and will be ready tomorrow. Before handing off:

1. **Confirm Replit prompts ran successfully** — AI Chat should feel noticeably different and more analytical. Follow-up questions should work reliably.
2. **Drip/Sequence Automations spec and Replit prompt** — Clients are demanding this. The goal is to clean up the UI and hand it to the team ready to implement properly. This is the "cancel HubSpot" feature.
3. **RESO demo flow lockdown** — Three weeks out. Need a specific screen sequence, no freestyle. Narrow and stable beats wide and crashy.
4. **AI cost controls implementation** — CFO and ops manager need numbers. The framework is documented; the code guardrails need to be built.
5. **Team presentation** — Two-track model and architectural situation. Present before they start touching the production port.

### Parking Lot (Carry Forward)
- Proactive Engagement Engine (Top Track 1 priority — more compelling for demos than lapse prevention)
- Lapse Prevention System (Second Track 1 priority)
- SOC 2 compliance preparation (Required for CRMLS pilot)
- Membio Super-Admin panel (Stage 2 — target CRMLS)
- MemberSync_Compliance_Reference.md (companion document to write)
- A/B testing activation (Week 2 Track 1)

---

## STANDING RULES (COMPLETE CURRENT LIST)

1. `member_metrics_cache` is the single source of truth for member data in the UI
2. Every query against external AMS/MLS tables must deduplicate (ROW_NUMBER pattern)
3. Every query against external tables must filter by ApmClientId
4. Never SUM(ClosePrice) across listing + buyer sides without applying volume split
5. All client-specific values go in `clientConfig.ts` (or tenant_config table)
6. Every feature must work for multiple clients through configuration, not custom code
7. Real data only — no fake/sample data in previews, demos, or test flows
8. No manual schema changes in production — versioned migrations only
9. Cache-first architecture — pre-compute daily if possible
10. One task at a time — focused, testable PRs/commits
11. Voluntary contributions (RPAC, REF) excluded from risk scoring entirely
12. Non-CE event attendance is a stronger engagement signal than CE attendance
13. Office suspension is the gatekeeper for Mainstreet Advantage fees
14. Every module must be gated by tenant_config — disabled modules don't render, don't run, don't consume AI budget
15. The 5% rule — every screen must earn its place; build what clients asked for or dreamed about
16. Mobile-first, performance-always — responsive UI, under 2 seconds load time

---

## CONTEXT FOR NEXT CHAT

**Start the next session by:**
1. Confirming the updated CLAUDE.md (v2, 786 lines) is in the project knowledge
2. Confirming Tracy's Replit results from the two prompts run tonight
3. Moving to the drip/sequence automations spec

**The CLAUDE.md in project knowledge should be the v2 version (786 lines) produced tonight.** If it shows 646 lines, it is the old version — ask Tracy to upload the new one.

**Tracy's context:** CEO of Membio, 30+ years in proptech, builds exclusively with AI tools (Claude for strategy/specs, Julius.AI for SQL, Replit Agent for prototype). Non-technical founder but deeply product-literate. Speaks fluent product strategy. Claude's role is CTO, product visionary, architectural sparring partner.

---

*Session date: March 4, 2026 (evening). Next session: March 5, 2026.*

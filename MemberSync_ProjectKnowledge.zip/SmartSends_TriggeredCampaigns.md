# SmartSends: Triggered Campaign Engine
## Replit Prompt â€” February 2026

This prompt adds a **triggered campaign system** to SmartSends â€” automated emails that send when specific conditions are met in the data. Unlike the existing one-shot scheduled campaigns (which send once at a specific date/time), triggered campaigns run continuously, watching for qualifying members and sending emails automatically.

**Examples:** Class registration confirmations, pre-event reminders, membership anniversary congratulations, new member welcome sequences, milestone celebrations.

**CRITICAL: Do NOT modify or break the existing email sending infrastructure.** The existing `queueEmailCampaign()` function, `scheduledEmailProcessor`, email templates, email campaigns table, and email recipients table all stay exactly as they are. Triggered campaigns use the existing send infrastructure â€” they just automate the decision of *when* and *who* to send to.

---

## EXISTING CODE CONTEXT

### How Emails Send Today

1. Staff creates an email (subject, body, audience) through the Send Email flow
2. They either send immediately or schedule for a specific date/time
3. `queueEmailCampaign()` in `emailService.ts` creates campaign + recipient records
4. The send processor picks up queued recipients and sends via SendGrid
5. `scheduledEmailProcessor.ts` checks every 60 seconds for scheduled campaigns whose time has come

### Key Functions We'll Reuse

- `queueEmailCampaign(data)` â€” Creates campaign record, checks opt-outs, queues recipients. We call this from the triggered campaign processor.
- `buildEmailTemplate(bodyContent, logoUrl, options)` â€” Wraps email body in Mainstreet-branded template
- `personalizeMergeFields(content, data)` â€” Replaces `{{FirstName}}`, `{{OfficeName}}`, etc.
- `getAudienceMembers(audienceId)` â€” Retrieves members for any saved audience

### Existing Celebration Engine (Overlaps with Triggers #8 and #9)

The `milestoneDetectionService.ts` already detects membership anniversaries and production milestones daily and stores them in the `member_milestones` table. The triggered campaign system should be able to use milestone detection as a trigger source rather than re-implementing that logic.

---

## PART 1: DATA MODEL

### New Table: `triggered_campaigns`

This is the main configuration table. Each row defines a triggered campaign â€” what triggers it, what email(s) to send, and when.

```sql
CREATE TABLE triggered_campaigns (
  campaign_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Campaign identity
  campaign_name TEXT NOT NULL,
  description TEXT,
  
  -- Trigger configuration
  trigger_type TEXT NOT NULL,
  -- Possible values (Phase A - build now):
  --   'event_registration'    â€” Member registers for an event/class
  --   'event_reminder'        â€” X days/hours before an event starts
  --   'event_followup'        â€” X days after event ends
  --   'membership_anniversary' â€” Annual membership date
  --   'production_milestone'  â€” Transaction/volume milestones
  -- Future trigger types (Phase B/C - architecture supports but don't build yet):
  --   'new_member'            â€” New member joins or reactivates
  --   'membership_expiring'   â€” X days before membership expires
  --   'member_lapsed'         â€” Status changes to inactive/lapsed
  --   'low_engagement'        â€” No activity for X days
  --   'profile_incomplete'    â€” Missing required profile fields
  
  trigger_config JSONB NOT NULL DEFAULT '{}',
  -- Stores trigger-specific parameters, e.g.:
  -- For event_registration: { "eventTypes": ["class", "event"], "includeVirtual": true }
  -- For event_reminder: { "daysBefore": 1 }
  -- For event_followup: { "daysAfter": 1 }
  -- For membership_anniversary: { "years": [1, 5, 10, 15, 20, 25, 30] }
  -- For production_milestone: { "milestoneTypes": ["transaction_milestone", "volume_milestone"] }
  
  -- Email content
  subject_line TEXT NOT NULL,
  email_body TEXT NOT NULL,
  
  -- Send window (when emails are allowed to go out)
  send_window_start TIME DEFAULT '08:00',  -- Earliest time to send (local time)
  send_window_end TIME DEFAULT '17:00',    -- Latest time to send (local time)
  send_window_timezone TEXT DEFAULT 'America/Chicago',  -- Mainstreet is in Central time
  send_on_weekends BOOLEAN DEFAULT false,
  
  -- Status and lifecycle
  status TEXT NOT NULL DEFAULT 'draft',
  -- 'draft'    â€” Being configured, not yet active
  -- 'active'   â€” Running, processor evaluates this campaign
  -- 'paused'   â€” Temporarily stopped, can be resumed
  -- 'archived' â€” Permanently stopped, hidden from active list
  
  -- Auto-stop configuration
  auto_stop_date TIMESTAMP,              -- Stop processing after this date (optional)
  auto_stop_on_event_passed BOOLEAN DEFAULT true,  -- For event triggers: stop after event date passes
  
  -- Metadata
  created_by UUID NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  activated_at TIMESTAMP,                -- When first activated
  paused_at TIMESTAMP,
  archived_at TIMESTAMP,
  
  -- Stats (updated by processor)
  total_sent INTEGER DEFAULT 0,
  last_processed_at TIMESTAMP,
  last_sent_at TIMESTAMP
);
```

### New Table: `triggered_campaign_steps`

For **sequence campaigns** (multi-step drip series like a welcome flow), each step is a separate row. Single-email triggered campaigns have just one step.

```sql
CREATE TABLE triggered_campaign_steps (
  step_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID NOT NULL REFERENCES triggered_campaigns(campaign_id) ON DELETE CASCADE,
  
  -- Step ordering
  step_number INTEGER NOT NULL DEFAULT 1,  -- 1 = first email, 2 = second, etc.
  step_name TEXT,                           -- e.g., "Welcome Email", "7-Day Follow-up"
  
  -- Timing relative to trigger
  delay_amount INTEGER NOT NULL DEFAULT 0,  -- How long to wait
  delay_unit TEXT NOT NULL DEFAULT 'hours', -- 'minutes', 'hours', 'days'
  -- Step 1 with delay 0 = send immediately when triggered
  -- Step 2 with delay 7 days = send 7 days after step 1
  -- For event_reminder: delay is BEFORE the event (e.g., 1 day before)
  
  -- Email content (overrides campaign-level if provided)
  subject_line TEXT,
  email_body TEXT,
  
  -- Step-specific conditions (optional)
  -- e.g., "only send step 3 if member didn't open step 2"
  skip_if_opened_previous BOOLEAN DEFAULT false,
  skip_if_clicked_previous BOOLEAN DEFAULT false,
  
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT unique_campaign_step UNIQUE (campaign_id, step_number)
);
```

### New Table: `triggered_campaign_sends`

Tracks every individual send from a triggered campaign. This is the deduplication table â€” it ensures nobody gets the same triggered email twice.

```sql
CREATE TABLE triggered_campaign_sends (
  send_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID NOT NULL REFERENCES triggered_campaigns(campaign_id),
  step_id UUID REFERENCES triggered_campaign_steps(step_id),
  
  -- Who received it
  member_key TEXT NOT NULL,
  member_email TEXT,
  member_name TEXT,
  
  -- What triggered it
  trigger_reference TEXT,  -- Reference to the triggering data, e.g.:
  -- For event_registration: the EventId
  -- For membership_anniversary: "2026-anniversary-10yr"
  -- For production_milestone: "transaction_milestone_100"
  
  -- Send status
  status TEXT NOT NULL DEFAULT 'pending',
  -- 'pending'    â€” Qualified, waiting for send window
  -- 'queued'     â€” Passed to queueEmailCampaign
  -- 'sent'       â€” Confirmed sent
  -- 'skipped'    â€” Skipped (opted out, condition not met, event passed, etc.)
  -- 'failed'     â€” Send attempt failed
  
  skip_reason TEXT,         -- Why it was skipped, if applicable
  
  -- Timing
  trigger_detected_at TIMESTAMP DEFAULT NOW(),
  scheduled_send_at TIMESTAMP,    -- When it should actually send (after delay + send window)
  queued_at TIMESTAMP,
  sent_at TIMESTAMP,
  
  -- Link to the actual email campaign record (created by queueEmailCampaign)
  email_campaign_id UUID,
  
  created_at TIMESTAMP DEFAULT NOW(),
  
  -- Deduplication: prevent same member from getting same step for same trigger
  CONSTRAINT unique_triggered_send UNIQUE (campaign_id, step_id, member_key, trigger_reference)
);

-- Index for processor queries
CREATE INDEX idx_triggered_sends_pending ON triggered_campaign_sends(status, scheduled_send_at)
  WHERE status IN ('pending', 'queued');
CREATE INDEX idx_triggered_sends_campaign ON triggered_campaign_sends(campaign_id, member_key);
```

### Schema Definition (schema.ts)

Add these three tables to `schema.ts`:

```typescript
// ============================================
// TRIGGERED CAMPAIGN TABLES
// ============================================

export const triggeredCampaigns = pgTable("triggered_campaigns", {
  campaignId: uuid("campaign_id").primaryKey().default(sql`gen_random_uuid()`),
  campaignName: text("campaign_name").notNull(),
  description: text("description"),
  triggerType: text("trigger_type").notNull(),
  triggerConfig: jsonb("trigger_config").notNull().default({}),
  subjectLine: text("subject_line").notNull(),
  emailBody: text("email_body").notNull(),
  sendWindowStart: text("send_window_start").default("08:00"),
  sendWindowEnd: text("send_window_end").default("17:00"),
  sendWindowTimezone: text("send_window_timezone").default("America/Chicago"),
  sendOnWeekends: boolean("send_on_weekends").default(false),
  status: text("status").notNull().default("draft"),
  autoStopDate: timestamp("auto_stop_date"),
  autoStopOnEventPassed: boolean("auto_stop_on_event_passed").default(true),
  createdBy: uuid("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  activatedAt: timestamp("activated_at"),
  pausedAt: timestamp("paused_at"),
  archivedAt: timestamp("archived_at"),
  totalSent: integer("total_sent").default(0),
  lastProcessedAt: timestamp("last_processed_at"),
  lastSentAt: timestamp("last_sent_at"),
});

export const triggeredCampaignSteps = pgTable("triggered_campaign_steps", {
  stepId: uuid("step_id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").notNull(),
  stepNumber: integer("step_number").notNull().default(1),
  stepName: text("step_name"),
  delayAmount: integer("delay_amount").notNull().default(0),
  delayUnit: text("delay_unit").notNull().default("hours"),
  subjectLine: text("subject_line"),
  emailBody: text("email_body"),
  skipIfOpenedPrevious: boolean("skip_if_opened_previous").default(false),
  skipIfClickedPrevious: boolean("skip_if_clicked_previous").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const triggeredCampaignSends = pgTable("triggered_campaign_sends", {
  sendId: uuid("send_id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").notNull(),
  stepId: uuid("step_id"),
  memberKey: text("member_key").notNull(),
  memberEmail: text("member_email"),
  memberName: text("member_name"),
  triggerReference: text("trigger_reference"),
  status: text("status").notNull().default("pending"),
  skipReason: text("skip_reason"),
  triggerDetectedAt: timestamp("trigger_detected_at").defaultNow(),
  scheduledSendAt: timestamp("scheduled_send_at"),
  queuedAt: timestamp("queued_at"),
  sentAt: timestamp("sent_at"),
  emailCampaignId: uuid("email_campaign_id"),
  createdAt: timestamp("created_at").defaultNow(),
});
```

Add insert schemas, types, etc. following the same pattern as existing tables.

---

## PART 2: TRIGGER EVALUATION ENGINE

### New Service: `triggeredCampaignProcessor.ts`

This is the heart of the system. It runs on a schedule, evaluates all active triggered campaigns, finds qualifying members, and queues sends.

**Processing loop (runs every 15 minutes):**

```typescript
import cron from 'node-cron';

// Run every 15 minutes
cron.schedule('*/15 * * * *', async () => {
  await processTriggeredCampaigns();
});
```

**Main processing function:**

```typescript
async function processTriggeredCampaigns() {
  console.log('[TRIGGERED] Starting triggered campaign processing...');
  
  // 1. Get all active triggered campaigns
  const activeCampaigns = await db.select()
    .from(triggeredCampaigns)
    .where(eq(triggeredCampaigns.status, 'active'));
  
  for (const campaign of activeCampaigns) {
    try {
      // 2. Check auto-stop conditions
      if (shouldAutoStop(campaign)) {
        await archiveCampaign(campaign.campaignId, 'Auto-stopped: condition met');
        continue;
      }
      
      // 3. Get the campaign's steps (ordered)
      const steps = await db.select()
        .from(triggeredCampaignSteps)
        .where(eq(triggeredCampaignSteps.campaignId, campaign.campaignId))
        .orderBy(triggeredCampaignSteps.stepNumber);
      
      // If no steps defined, use campaign-level email as a single step
      const effectiveSteps = steps.length > 0 ? steps : [{
        stepId: null,
        stepNumber: 1,
        delayAmount: 0,
        delayUnit: 'hours',
        subjectLine: campaign.subjectLine,
        emailBody: campaign.emailBody,
        skipIfOpenedPrevious: false,
        skipIfClickedPrevious: false,
      }];
      
      // 4. Evaluate trigger to find qualifying members
      const qualifyingMembers = await evaluateTrigger(campaign);
      
      // 5. For each qualifying member, check each step
      for (const member of qualifyingMembers) {
        for (const step of effectiveSteps) {
          await processStepForMember(campaign, step, member);
        }
      }
      
      // 6. Update campaign last_processed_at
      await db.update(triggeredCampaigns)
        .set({ lastProcessedAt: new Date() })
        .where(eq(triggeredCampaigns.campaignId, campaign.campaignId));
        
    } catch (error) {
      console.error(`[TRIGGERED] Error processing campaign ${campaign.campaignId}:`, error);
    }
  }
  
  // 7. Process pending sends that are within their send window
  await processPendingSends();
  
  console.log('[TRIGGERED] Processing complete.');
}
```

**Trigger evaluation â€” returns qualifying members with their trigger context:**

```typescript
interface QualifyingMember {
  memberKey: string;
  memberName: string;
  memberEmail: string;
  triggerReference: string;    // Unique reference for deduplication
  triggerDate: Date;           // When the trigger event occurred/will occur
  mergeData?: Record<string, string>;  // Extra data for email personalization
}

async function evaluateTrigger(campaign: TriggeredCampaign): Promise<QualifyingMember[]> {
  switch (campaign.triggerType) {
    case 'event_registration':
      return evaluateEventRegistrationTrigger(campaign);
    case 'event_reminder':
      return evaluateEventReminderTrigger(campaign);
    case 'event_followup':
      return evaluateEventFollowupTrigger(campaign);
    case 'membership_anniversary':
      return evaluateMembershipAnniversaryTrigger(campaign);
    case 'production_milestone':
      return evaluateProductionMilestoneTrigger(campaign);
    default:
      console.warn(`[TRIGGERED] Unknown trigger type: ${campaign.triggerType}`);
      return [];
  }
}
```

**Step processing â€” handles dedup, delay calculation, and send window:**

```typescript
async function processStepForMember(campaign, step, member: QualifyingMember) {
  const stepId = step.stepId || null;
  const triggerRef = member.triggerReference;
  
  // Check if already sent/pending for this member + step + trigger
  const existing = await db.select()
    .from(triggeredCampaignSends)
    .where(and(
      eq(triggeredCampaignSends.campaignId, campaign.campaignId),
      stepId ? eq(triggeredCampaignSends.stepId, stepId) : isNull(triggeredCampaignSends.stepId),
      eq(triggeredCampaignSends.memberKey, member.memberKey),
      eq(triggeredCampaignSends.triggerReference, triggerRef)
    ))
    .limit(1);
  
  if (existing.length > 0) {
    return; // Already processed â€” dedup prevents double sends
  }
  
  // For multi-step: check if previous step was completed
  if (step.stepNumber > 1) {
    const previousStepSent = await checkPreviousStepSent(campaign.campaignId, step.stepNumber - 1, member.memberKey, triggerRef);
    if (!previousStepSent) return; // Previous step hasn't sent yet
    
    // Check skip conditions
    if (step.skipIfOpenedPrevious) {
      const opened = await checkPreviousStepOpened(campaign.campaignId, step.stepNumber - 1, member.memberKey);
      if (opened) return; // Skip because they opened the previous email
    }
  }
  
  // Calculate when to send
  const sendAt = calculateSendTime(member.triggerDate, step, campaign);
  
  // If send time is in the past and this is a time-sensitive trigger (event reminder),
  // check if the event has already passed
  if (campaign.autoStopOnEventPassed && sendAt < new Date()) {
    // For event reminders, skip if the event already happened
    if (['event_reminder', 'event_followup'].includes(campaign.triggerType)) {
      // Still create the record so we don't re-evaluate, but mark as skipped
      await createSendRecord(campaign, step, member, sendAt, 'skipped', 'Event already passed');
      return;
    }
  }
  
  // Create pending send record
  await createSendRecord(campaign, step, member, sendAt, 'pending');
}
```

**Send window enforcement:**

```typescript
function calculateSendTime(triggerDate: Date, step, campaign): Date {
  // Calculate base send time from trigger date + delay
  let sendAt = new Date(triggerDate);
  
  if (campaign.triggerType === 'event_reminder') {
    // For reminders, delay is BEFORE the event
    switch (step.delayUnit) {
      case 'days': sendAt.setDate(sendAt.getDate() - step.delayAmount); break;
      case 'hours': sendAt.setHours(sendAt.getHours() - step.delayAmount); break;
    }
  } else {
    // For everything else, delay is AFTER the trigger
    switch (step.delayUnit) {
      case 'days': sendAt.setDate(sendAt.getDate() + step.delayAmount); break;
      case 'hours': sendAt.setHours(sendAt.getHours() + step.delayAmount); break;
      case 'minutes': sendAt.setMinutes(sendAt.getMinutes() + step.delayAmount); break;
    }
  }
  
  // Enforce send window
  sendAt = adjustToSendWindow(sendAt, campaign);
  
  return sendAt;
}

function adjustToSendWindow(sendAt: Date, campaign): Date {
  // Convert to campaign timezone for window check
  const tz = campaign.sendWindowTimezone || 'America/Chicago';
  const [startHour, startMin] = (campaign.sendWindowStart || '08:00').split(':').map(Number);
  const [endHour, endMin] = (campaign.sendWindowEnd || '17:00').split(':').map(Number);
  
  // Use Intl.DateTimeFormat to get the hour in the target timezone
  const formatter = new Intl.DateTimeFormat('en-US', { timeZone: tz, hour: 'numeric', hour12: false });
  const localHour = parseInt(formatter.format(sendAt));
  const dayOfWeek = new Date(sendAt.toLocaleString('en-US', { timeZone: tz })).getDay();
  
  // Check weekend restriction
  if (!campaign.sendOnWeekends && (dayOfWeek === 0 || dayOfWeek === 6)) {
    // Move to next Monday at start of send window
    const daysToMonday = dayOfWeek === 0 ? 1 : 2;
    sendAt.setDate(sendAt.getDate() + daysToMonday);
    sendAt.setHours(startHour, startMin, 0, 0);
    return sendAt;
  }
  
  // Check time window
  if (localHour < startHour) {
    // Too early â€” move to start of window today
    sendAt.setHours(startHour, startMin, 0, 0);
  } else if (localHour >= endHour) {
    // Too late â€” move to start of window tomorrow (or Monday)
    sendAt.setDate(sendAt.getDate() + 1);
    sendAt.setHours(startHour, startMin, 0, 0);
    // Re-check weekends
    if (!campaign.sendOnWeekends) {
      const newDay = sendAt.getDay();
      if (newDay === 0) sendAt.setDate(sendAt.getDate() + 1);
      if (newDay === 6) sendAt.setDate(sendAt.getDate() + 2);
    }
  }
  
  return sendAt;
}
```

**Pending sends processor â€” actually sends the emails:**

```typescript
async function processPendingSends() {
  const now = new Date();
  
  // Find all pending sends whose scheduled time has arrived
  const pendingSends = await db.select()
    .from(triggeredCampaignSends)
    .where(and(
      eq(triggeredCampaignSends.status, 'pending'),
      lte(triggeredCampaignSends.scheduledSendAt, now)
    ))
    .limit(100); // Process in batches
  
  for (const send of pendingSends) {
    try {
      // Get the campaign for email content
      const [campaign] = await db.select()
        .from(triggeredCampaigns)
        .where(eq(triggeredCampaigns.campaignId, send.campaignId));
      
      if (!campaign || campaign.status !== 'active') {
        await markSendSkipped(send.sendId, 'Campaign no longer active');
        continue;
      }
      
      // Get step content (if multi-step)
      let subject = campaign.subjectLine;
      let body = campaign.emailBody;
      
      if (send.stepId) {
        const [step] = await db.select()
          .from(triggeredCampaignSteps)
          .where(eq(triggeredCampaignSteps.stepId, send.stepId));
        if (step?.subjectLine) subject = step.subjectLine;
        if (step?.emailBody) body = step.emailBody;
      }
      
      // Send via existing infrastructure
      const result = await queueEmailCampaign({
        name: `[Auto] ${campaign.campaignName} - ${send.memberName || send.memberKey}`,
        subject,
        body,
        recipients: [{ member_key: send.memberKey, email: send.memberEmail || '' }],
        sentBy: 'triggered-campaign-system',
        audienceDescription: `Triggered: ${campaign.triggerType}`,
      });
      
      // Update send record
      await db.update(triggeredCampaignSends)
        .set({
          status: 'sent',
          sentAt: now,
          queuedAt: now,
          emailCampaignId: result.campaign_id,
        })
        .where(eq(triggeredCampaignSends.sendId, send.sendId));
      
      // Update campaign stats
      await db.update(triggeredCampaigns)
        .set({
          totalSent: sql`total_sent + 1`,
          lastSentAt: now,
        })
        .where(eq(triggeredCampaigns.campaignId, send.campaignId));
        
    } catch (error) {
      console.error(`[TRIGGERED] Error sending ${send.sendId}:`, error);
      await db.update(triggeredCampaignSends)
        .set({ status: 'failed', skipReason: (error as Error).message })
        .where(eq(triggeredCampaignSends.sendId, send.sendId));
    }
  }
}
```

---

## PART 3: PHASE A TRIGGER IMPLEMENTATIONS

### Trigger: event_registration

**What it detects:** Members who have registered for an event or class.

**Data source:** `activity_cache` table (local, already refreshed daily from `apmeventregistration`).

**triggerConfig options:**
```json
{
  "eventTypes": ["class", "event"],  // Filter by event type, or empty for all
  "eventIds": [],                     // Filter to specific events, or empty for all
  "lookbackDays": 7                   // How far back to look for new registrations
}
```

```typescript
async function evaluateEventRegistrationTrigger(campaign): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const lookbackDays = config.lookbackDays || 7;
  
  // Find recent registrations from activity_cache
  let query = `
    SELECT DISTINCT a.member_key,
      m.member_name, m.member_email, m.office_name,
      a.activity_name, a.event_id, a.start_datetime, a.event_type
    FROM activity_cache a
    JOIN member_metrics_cache m ON a.member_key = m.member_key
    WHERE m.member_status = 'Active'
      AND a.cached_at >= NOW() - INTERVAL '${lookbackDays} days'
  `;
  
  if (config.eventTypes?.length > 0) {
    query += ` AND a.event_type = ANY($1)`;
  }
  
  const result = await localPool.query(query, 
    config.eventTypes?.length > 0 ? [config.eventTypes] : []);
  
  return result.rows.map(row => ({
    memberKey: row.member_key,
    memberName: row.member_name,
    memberEmail: row.member_email,
    triggerReference: `event_reg_${row.event_id}`,
    triggerDate: new Date(row.cached_at || Date.now()),
    mergeData: {
      ClassName: row.activity_name || '',
      ClassDate: row.start_datetime ? new Date(row.start_datetime).toLocaleDateString() : '',
      ClassTime: row.start_datetime ? new Date(row.start_datetime).toLocaleTimeString() : '',
      EventType: row.event_type || '',
      OfficeName: row.office_name || '',
    },
  }));
}
```

### Trigger: event_reminder

**What it detects:** Members registered for events happening within the configured timeframe.

**triggerConfig options:**
```json
{
  "daysBefore": 1,                   // Send X days before event
  "eventTypes": ["class", "event"],  // Optional filter
  "eventIds": []                      // Optional specific events
}
```

```typescript
async function evaluateEventReminderTrigger(campaign): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const daysBefore = config.daysBefore || 1;
  
  // Find members registered for events happening in daysBefore days
  const query = `
    SELECT DISTINCT a.member_key,
      m.member_name, m.member_email, m.office_name,
      a.activity_name, a.event_id, a.start_datetime, a.event_type
    FROM activity_cache a
    JOIN member_metrics_cache m ON a.member_key = m.member_key
    WHERE m.member_status = 'Active'
      AND a.start_datetime IS NOT NULL
      AND a.start_datetime > NOW()
      AND a.start_datetime <= NOW() + INTERVAL '${daysBefore + 1} days'
      AND a.start_datetime > NOW() + INTERVAL '${Math.max(0, daysBefore - 1)} days'
  `;
  
  const result = await localPool.query(query);
  
  return result.rows.map(row => ({
    memberKey: row.member_key,
    memberName: row.member_name,
    memberEmail: row.member_email,
    triggerReference: `event_reminder_${row.event_id}`,
    triggerDate: new Date(row.start_datetime),  // Trigger date is the EVENT date
    mergeData: {
      ClassName: row.activity_name || '',
      ClassDate: new Date(row.start_datetime).toLocaleDateString(),
      ClassTime: new Date(row.start_datetime).toLocaleTimeString(),
      EventType: row.event_type || '',
    },
  }));
}
```

### Trigger: event_followup

**What it detects:** Members who attended events that ended within the configured timeframe.

**triggerConfig options:**
```json
{
  "daysAfter": 1,                    // Send X days after event
  "requireAttendance": true,          // Only send to attendees (vs all registrants)
  "eventTypes": ["class", "event"]
}
```

```typescript
async function evaluateEventFollowupTrigger(campaign): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const daysAfter = config.daysAfter || 1;
  const requireAttendance = config.requireAttendance !== false;
  
  const query = `
    SELECT DISTINCT a.member_key,
      m.member_name, m.member_email, m.office_name,
      a.activity_name, a.event_id, a.start_datetime,
      a.is_completed, a.is_attended, a.education_credits
    FROM activity_cache a
    JOIN member_metrics_cache m ON a.member_key = m.member_key
    WHERE m.member_status = 'Active'
      AND a.start_datetime IS NOT NULL
      AND a.start_datetime < NOW()
      AND a.start_datetime >= NOW() - INTERVAL '${daysAfter + 7} days'
      ${requireAttendance ? "AND (a.is_attended = true OR a.is_completed = true)" : ""}
  `;
  
  const result = await localPool.query(query);
  
  return result.rows.map(row => ({
    memberKey: row.member_key,
    memberName: row.member_name,
    memberEmail: row.member_email,
    triggerReference: `event_followup_${row.event_id}`,
    triggerDate: new Date(row.start_datetime),
    mergeData: {
      ClassName: row.activity_name || '',
      ClassDate: new Date(row.start_datetime).toLocaleDateString(),
      CECredits: row.education_credits || '0',
    },
  }));
}
```

### Trigger: membership_anniversary

**What it detects:** Members whose Mainstreet join anniversary is today (or within the processing window).

**Leverages the existing celebration engine** â€” the `member_milestones` table already stores detected anniversaries.

**triggerConfig options:**
```json
{
  "years": [1, 5, 10, 15, 20, 25, 30],  // Which anniversaries to trigger on
  "allYears": false                        // Or true to send every year
}
```

```typescript
async function evaluateMembershipAnniversaryTrigger(campaign): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const targetYears = config.years || [1, 5, 10, 15, 20, 25, 30];
  const allYears = config.allYears || false;
  
  // Use member_metrics_cache for NarJoinDate (already has this data)
  const query = `
    SELECT m.member_key, m.member_name, m.member_email, m.office_name,
      m.nar_join_date,
      EXTRACT(YEAR FROM AGE(CURRENT_DATE, m.nar_join_date))::integer as years_member
    FROM member_metrics_cache m
    WHERE m.member_status = 'Active'
      AND m.nar_join_date IS NOT NULL
      AND EXTRACT(MONTH FROM m.nar_join_date) = EXTRACT(MONTH FROM CURRENT_DATE)
      AND EXTRACT(DAY FROM m.nar_join_date) = EXTRACT(DAY FROM CURRENT_DATE)
  `;
  
  const result = await localPool.query(query);
  
  return result.rows
    .filter(row => allYears || targetYears.includes(row.years_member))
    .map(row => ({
      memberKey: row.member_key,
      memberName: row.member_name,
      memberEmail: row.member_email,
      triggerReference: `anniversary_${new Date().getFullYear()}_${row.years_member}yr`,
      triggerDate: new Date(),
      mergeData: {
        YearsAsMember: String(row.years_member),
        JoinDate: row.nar_join_date ? new Date(row.nar_join_date).toLocaleDateString() : '',
        OfficeName: row.office_name || '',
      },
    }));
}
```

### Trigger: production_milestone

**What it detects:** Members who hit transaction or volume milestones. Leverages the existing `member_milestones` table populated by `milestoneDetectionService.ts`.

**triggerConfig options:**
```json
{
  "milestoneTypes": ["transaction_milestone", "volume_milestone", "first_million", "rookie_star"],
  "lookbackDays": 7
}
```

```typescript
async function evaluateProductionMilestoneTrigger(campaign): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const types = config.milestoneTypes || ['transaction_milestone', 'volume_milestone'];
  const lookbackDays = config.lookbackDays || 7;
  
  // Query milestones detected by the celebration engine
  const query = `
    SELECT mm.member_key, mm.member_name, mm.member_email,
      mm.milestone_type, mm.milestone_value, mm.milestone_label, mm.milestone_emoji,
      mm.detected_at,
      m.office_name
    FROM member_milestones mm
    JOIN member_metrics_cache m ON mm.member_key = m.member_key
    WHERE mm.milestone_type = ANY($1)
      AND mm.detected_at >= NOW() - INTERVAL '${lookbackDays} days'
      AND mm.is_dismissed = false
  `;
  
  const result = await localPool.query(query, [types]);
  
  return result.rows.map(row => ({
    memberKey: row.member_key,
    memberName: row.member_name,
    memberEmail: row.member_email,
    triggerReference: `milestone_${row.milestone_type}_${row.milestone_value}`,
    triggerDate: new Date(row.detected_at),
    mergeData: {
      MilestoneLabel: row.milestone_label || '',
      MilestoneEmoji: row.milestone_emoji || '',
      MilestoneValue: String(row.milestone_value || ''),
      OfficeName: row.office_name || '',
    },
  }));
}
```

---

## PART 4: ENHANCED MERGE FIELDS

Triggered campaigns need additional merge fields beyond the standard `{{FirstName}}`, `{{OfficeName}}`, etc. The trigger evaluation functions return `mergeData` with trigger-specific values.

**Update `personalizeMergeFields()` in `emailService.ts`** to accept and apply dynamic merge fields:

```typescript
// Add to the existing function signature:
function personalizeMergeFields(
  content: string, 
  data: PersonalizationData,
  extraFields?: Record<string, string>  // NEW parameter
): string {
  let result = content;
  
  // ... existing replacements ...
  
  // Apply trigger-specific merge fields
  if (extraFields) {
    for (const [key, value] of Object.entries(extraFields)) {
      const pattern = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      result = result.replace(pattern, value || '');
    }
  }
  
  return result;
}
```

Available merge fields for triggered campaigns (document these in the email composer UI):

| Field | Available In | Description |
|-------|-------------|-------------|
| `{{ClassName}}` | Event triggers | Name of the class/event |
| `{{ClassDate}}` | Event triggers | Date of the class/event |
| `{{ClassTime}}` | Event triggers | Start time |
| `{{CECredits}}` | Event followup | CE credits earned |
| `{{YearsAsMember}}` | Anniversary | Number of years |
| `{{JoinDate}}` | Anniversary | Original join date |
| `{{MilestoneLabel}}` | Milestones | e.g., "100th Transaction" |
| `{{MilestoneEmoji}}` | Milestones | e.g., "ðŸ†" |
| `{{MilestoneValue}}` | Milestones | The numeric value |

---

## PART 5: UI â€” TRIGGERED CAMPAIGNS MANAGEMENT

### New Left Nav Item

Add "Automations" under SmartSends:

```
SmartSends
  â”œâ”€â”€ Dashboard
  â”œâ”€â”€ Send Email
  â”œâ”€â”€ Campaigns
  â”œâ”€â”€ Automations          â† NEW
  â”œâ”€â”€ Audiences â–¾
  â”œâ”€â”€ Templates
  â”œâ”€â”€ Drafts
  â””â”€â”€ Image Library
```

### Automations Page

```
SmartSends > Automations

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  âš¡ Automations                                              â”‚
â”‚  Set up emails that send automatically when conditions       â”‚
â”‚  are met.                                  [+ New Automation]â”‚
â”‚                                                              â”‚
â”‚  â”Œâ”€ Active (3) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  ðŸ“§ Class Registration Confirmation                      â”‚ â”‚
â”‚  â”‚  Trigger: Event Registration â€¢ Sent: 1,247               â”‚ â”‚
â”‚  â”‚  Last sent: 2 hours ago          [Pause] [Edit] [Â·Â·Â·]   â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  ðŸ“§ 1-Day Class Reminder                                 â”‚ â”‚
â”‚  â”‚  Trigger: Event Reminder (1 day before)  â€¢ Sent: 892     â”‚ â”‚
â”‚  â”‚  Last sent: yesterday            [Pause] [Edit] [Â·Â·Â·]   â”‚ â”‚
â”‚  â”‚                                                          â”‚ â”‚
â”‚  â”‚  ðŸ“§ Membership Anniversary                               â”‚ â”‚
â”‚  â”‚  Trigger: Anniversary (1, 5, 10, 15, 20, 25yr)          â”‚ â”‚
â”‚  â”‚  Sent: 58  Last sent: today      [Pause] [Edit] [Â·Â·Â·]   â”‚ â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â”‚                                                              â”‚
â”‚  â”Œâ”€ Paused (1) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â”‚  ðŸ“§ Post-Class Follow-up                                 â”‚ â”‚
â”‚  â”‚  Trigger: Event Followup (1 day after) â€¢ Sent: 203       â”‚ â”‚
â”‚  â”‚  Paused since: Feb 10            [Resume] [Edit] [Â·Â·Â·]  â”‚ â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â”‚                                                              â”‚
â”‚  â”Œâ”€ Drafts (0) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

The [Â·Â·Â·] menu contains: View Send History, Duplicate, Archive.

### Create/Edit Automation Flow

When clicking "+ New Automation" or "Edit", show a form with these sections:

**Section 1: Trigger Selection**

```
What triggers this email?

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ â—‹ Event Registration             â”‚  Someone registers for a class or event
â”‚ â—‹ Event Reminder                 â”‚  Before an upcoming event
â”‚ â—‹ Post-Event Follow-up           â”‚  After an event ends
â”‚ â—‹ Membership Anniversary         â”‚  Annual membership date
â”‚ â—‹ Production Milestone           â”‚  Transaction or volume achievement
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜

(More triggers coming soon: New Member Welcome, 
 Membership Expiring, Win-Back, and more)
```

**Section 2: Trigger Settings (changes based on selection)**

For "Event Reminder":
```
Send reminder:  [1] [days â–¾] before the event

Event types:    â˜‘ Classes  â˜‘ Events

Specific events only (optional):
[Search for event... â–¾]
```

For "Membership Anniversary":
```
Send on these anniversary years:
â˜‘ 1 year    â˜‘ 5 years    â˜‘ 10 years
â˜‘ 15 years  â˜‘ 20 years   â˜‘ 25 years
â˜ 30 years  â˜ Every year
```

For "Production Milestone":
```
Milestone types:
â˜‘ Transaction milestones (10, 25, 50, 100...)
â˜‘ Volume milestones ($1M, $5M, $10M...)
â˜ Rookie star
â˜ Comeback
â˜ First million
```

**Section 3: Email Content**

Use the same email composer used in the Send Email flow. Show a panel with available merge fields based on the selected trigger type:

```
Available merge fields for this trigger:
{{FirstName}} {{LastName}} {{FullName}} {{OfficeName}}
{{ClassName}} {{ClassDate}} {{ClassTime}} {{EventType}}

Tip: These will be automatically filled in for each recipient.
```

**Section 4: Send Window**

```
Send emails between: [8:00 AM â–¾] and [5:00 PM â–¾]  Central Time
â˜ Send on weekends

Auto-stop: 
â˜‘ Stop after event/occasion passes
â˜ Stop on specific date: [___________]
```

**Section 5: Activate**

```
[Save as Draft]     [Activate Automation]
```

"Activate Automation" sets status to 'active' and the processor begins evaluating it on its next run.

### Send History Page

Accessible from the [Â·Â·Â·] menu â†’ "View Send History". Shows a table of all sends from this triggered campaign:

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  Send History: Class Registration Confirmation           â”‚
â”‚  Total sent: 1,247 since Feb 1, 2026                    â”‚
â”‚                                                          â”‚
â”‚  Member          â”‚ Event          â”‚ Sent        â”‚ Status â”‚
â”‚  Sarah Johnson   â”‚ Fair Housing CEâ”‚ 2 hours ago â”‚ âœ“ Sent â”‚
â”‚  Mike Brown      â”‚ Ethics CE      â”‚ 5 hours ago â”‚ âœ“ Sent â”‚
â”‚  Lisa Chen       â”‚ Fair Housing CEâ”‚ yesterday   â”‚ âœ“ Sent â”‚
â”‚  ...                                                     â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

## PART 6: API ENDPOINTS

### CRUD for Triggered Campaigns

```
GET    /api/smartsends/automations              â€” List all (with status filter)
POST   /api/smartsends/automations              â€” Create new
GET    /api/smartsends/automations/:id          â€” Get details
PUT    /api/smartsends/automations/:id          â€” Update
POST   /api/smartsends/automations/:id/activate â€” Set status to 'active'
POST   /api/smartsends/automations/:id/pause    â€” Set status to 'paused'
POST   /api/smartsends/automations/:id/resume   â€” Set status to 'active' (from paused)
POST   /api/smartsends/automations/:id/archive  â€” Set status to 'archived'
POST   /api/smartsends/automations/:id/duplicate â€” Copy campaign as new draft

GET    /api/smartsends/automations/:id/history  â€” Get send history (paginated)
GET    /api/smartsends/automations/:id/stats    â€” Get send stats (total, by day, by status)
```

### Steps Management

```
GET    /api/smartsends/automations/:id/steps       â€” Get all steps
POST   /api/smartsends/automations/:id/steps       â€” Add step
PUT    /api/smartsends/automations/:id/steps/:stepId â€” Update step
DELETE /api/smartsends/automations/:id/steps/:stepId â€” Delete step
```

---

## PART 7: START THE PROCESSOR

In the main server file, import and start the triggered campaign processor alongside the existing scheduled jobs:

```typescript
import { startTriggeredCampaignProcessor } from './services/triggeredCampaignProcessor';

// ... existing startup code ...

// Start triggered campaign processor (runs every 15 minutes)
startTriggeredCampaignProcessor();
```

The processor schedule: every 15 minutes (`*/15 * * * *`). This balances responsiveness (a registration confirmation goes out within 15 minutes) with not overloading the system. The send window enforcement ensures nothing goes out at odd hours regardless of when the processor runs.

---

## PART 8: FUTURE-PROOFING

The engine architecture supports these future trigger types without structural changes. When ready, just add new `evaluateXxxTrigger()` functions and a new case to the switch statement:

| Trigger Type | Data Source | Phase |
|-------------|-------------|-------|
| `new_member` | Watch for new MemberKey in member_metrics_cache | B |
| `membership_expiring` | apmmemberdues due dates + billing_calendar | B |
| `member_lapsed` | member_status_tracking (from lapse prevention) | B |
| `low_engagement` | engagement_score + email_events (opens/clicks) | C |
| `interest_based` | Future member preferences table | C |
| `profile_incomplete` | Check for null fields in member data | C |

Each new trigger type only requires:
1. A new `evaluateXxxTrigger()` function
2. Adding the type to the trigger selection UI
3. Adding trigger-specific config fields to the UI

No changes to the processing engine, send logic, dedup, or send window enforcement.

---

## IMPLEMENTATION ORDER

1. **Database tables** â€” Create `triggered_campaigns`, `triggered_campaign_steps`, `triggered_campaign_sends` + indexes
2. **Schema definitions** â€” Add to `schema.ts` with insert schemas and types
3. **Trigger evaluation functions** â€” Implement the 5 Phase A triggers
4. **Processing engine** â€” `triggeredCampaignProcessor.ts` with main loop, dedup, send window
5. **Merge field enhancement** â€” Update `personalizeMergeFields()` to accept extra fields
6. **API endpoints** â€” CRUD, activate/pause/archive, history, stats
7. **UI: Automations list page** â€” Active/paused/draft sections
8. **UI: Create/edit automation** â€” Trigger selection, config, email composer, send window
9. **UI: Send history** â€” Per-campaign send log
10. **Wire up processor** â€” Start in main server file

---

## TESTING CHECKLIST

- [ ] Creating a triggered campaign saves correctly with all fields
- [ ] Activating a campaign sets status to 'active' and activatedAt
- [ ] Pausing a campaign stops it from processing; resuming restarts it
- [ ] Archiving a campaign removes it from the active list permanently
- [ ] Event registration trigger detects new registrations from activity_cache
- [ ] Event reminder trigger finds members with upcoming events
- [ ] Event followup trigger finds members who attended recent events
- [ ] Anniversary trigger finds today's membership anniversaries for configured years
- [ ] Milestone trigger picks up recent milestones from member_milestones table
- [ ] Deduplication works: same member + same trigger reference = only one send per step
- [ ] Multi-step sequences: step 2 only sends after step 1 is complete
- [ ] Send window enforcement: emails don't go out before 8 AM or after 5 PM Central
- [ ] Weekend restriction: emails queue for Monday if send_on_weekends is false
- [ ] Auto-stop: event reminders don't send after the event has passed
- [ ] Trigger-specific merge fields ({{ClassName}}, {{YearsAsMember}}, etc.) are replaced correctly
- [ ] Send history page shows all sends with status and trigger details
- [ ] Stats show total sent, sends per day, sends by status
- [ ] Existing email infrastructure (campaigns, recipients, events tables) still works unchanged
- [ ] Existing scheduled campaigns still work unchanged
- [ ] Processor runs every 15 minutes without errors even when no campaigns are active

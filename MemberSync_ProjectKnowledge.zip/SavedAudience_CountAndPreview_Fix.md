# Fix: Saved Audience Count and Preview Display
## Replit Prompt â€” February 2026

**Context:** The enrichment fix is working â€” CSV export shows 18,092 members with emails. But two display issues remain:

1. The Saved Audiences table shows "~21,892" for the audience count
2. The audience preview modal shows "13 members" and emails show as "-"

These are likely caused by stale data from the old audience saved BEFORE the enrichment fix, AND a separate issue with how the preview modal fetches/displays data.

---

## FIX 1: Stale Audience Count

The `saved_audiences` table stores a `member_count` column that was set when the audience was first saved. For audiences saved before the enrichment fix, this count is wrong (21,892 instead of ~18,092).

**Solution:** When an existing Bill Type audience is opened or previewed, refresh its count from the actual query results. 

Find the code that handles the audience detail/preview endpoint (the one that powers the modal when you click on an audience in the Saved Audiences table). After `getAudienceMembers()` returns, update the stored count if it differs significantly:

```typescript
// After getAudienceMembers returns:
if (result.totalCount !== audience.memberCount) {
  // Update the stored count to match the actual count
  await db.update(savedAudiences)
    .set({ memberCount: result.totalCount })
    .where(eq(savedAudiences.audienceId, audienceId));
}
```

Also, for the Saved Audiences LIST endpoint (the table view), if an audience is smart (`isSmart = true`), display the count with a note that it's dynamic. But the most important thing is that clicking on the audience triggers a count refresh.

**Additionally:** Add a "Refresh Count" button or auto-refresh smart audience counts when the Saved Audiences page loads. The `refreshAllSmartAudienceCounts()` function already exists in `aiAudienceService.ts` â€” wire it to run when the Saved Audiences page mounts, or add a manual refresh button.

---

## FIX 2: Preview Modal Shows Wrong Count and Missing Emails

The preview modal is showing "13 members" and "-" for emails. This means the preview modal is NOT using the same code path as the CSV export. 

Look at how the preview modal fetches data. It likely calls `getAudienceMembers()` with `previewOnly: true`. The issue is:

**A) The previewOnly path may be applying LIMIT 15 to the raw SQL BEFORE enrichment.** This means only 15 member keys go through enrichment, and after filtering to active-only, you get ~13. The `totalCount` should still come from the COUNT query (which runs without LIMIT), but it may be showing the old stored `memberCount` from the database instead of the fresh count.

Check the audience detail/preview endpoint. It probably does something like:
```typescript
const result = await getAudienceMembers(audienceId, { previewOnly: true });
```

Make sure the response returns `result.totalCount` (the fresh count from the COUNT query) and NOT `audience.memberCount` (the stale stored count).

**B) Emails showing as "-":** The preview modal may be reading from a different field than the CSV export. Check the frontend component that renders the preview modal (likely in `SavedAudiences.tsx` or `AudiencePreviewModal.tsx`). It may be looking for `MemberEmail` but the enrichment is returning it under a different key, or the preview path isn't running the enrichment at all.

Check: does `getAudienceMembers()` with `previewOnly: true` still run the enrichment block? The enrichment block has this condition:
```typescript
if (rawMembers.length > 0 && !useLocalDb && externalDb) {
```

If `previewOnly` somehow changes the code path (e.g., using `createPreviewQuery` which might route differently), the enrichment might be skipped.

**Debug steps:**
1. Add a `console.log` at the start of the enrichment block: `console.log('[ENRICH] Running enrichment for', rawMembers.length, 'members');`
2. Add a `console.log` after enrichment: `console.log('[ENRICH] Enriched members sample:', members[0]);`
3. Open the preview modal and check the console â€” is enrichment running? What fields are on the enriched members?

---

## FIX 3: Force Count Refresh for This Specific Audience

As an immediate fix, the simplest thing is to **delete the old "All Mainstreet Members" audience and recreate it** from the Member Type Builder page. The new audience will be saved with the correct count from the enrichment-aware code path.

But to prevent this from happening to future users: after the enrichment runs in `getAudienceMembers()`, always update the stored count:

In `getAudienceMembers()`, near the end (around where it returns the result), add:

```typescript
// Update stored member count if it changed (smart audiences refresh on each access)
if (audience.isSmart && totalCount > 0 && totalCount !== audience.memberCount) {
  try {
    await db.update(savedAudiences)
      .set({ memberCount: totalCount, lastUsed: new Date() })
      .where(eq(savedAudiences.audienceId, audienceId));
  } catch (e) {
    console.error('[getAudienceMembers] Failed to update stored count:', e);
  }
}
```

This way, every time a smart audience is opened, its count self-corrects.

---

## TESTING

1. Delete the existing "All Mainstreet Members" audience
2. Go to Member Type Builder â†’ Select All â†’ Generate Preview (should show ~18,087)
3. Save as "All Mainstreet Members" 
4. Go to Saved Audiences â†’ the count should show ~18,087 (not 21,892)
5. Click on the audience â†’ preview modal should show members with names, emails, and offices
6. Export CSV â†’ should have ~18,092 rows with emails populated

## DO NOT CHANGE
- The enrichment query (just fixed, working correctly for CSV export)
- The counts endpoint (working correctly, showing 18,087)  
- The preview endpoint on the Member Type Builder page (working correctly)
- Dashboard, AI services, or any other features

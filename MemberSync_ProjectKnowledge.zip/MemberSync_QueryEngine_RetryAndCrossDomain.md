# MemberSync — AI Query Engine: Retry Loop, Cross-Domain Queries & Location Intelligence

## Date: February 27, 2026
## Priority: High — Query engine returns "I can't answer that" for legitimate cross-domain questions. Critical for CRMLS demo and daily Mainstreet use.

---

## REPLIT STANDING RULES

**These rules apply to this prompt and ALL future prompts for this project.**

### Rule 1: No Parallel Systems
Before building any new component, search for existing functionality. Extend rather than duplicate.

### Rule 2: Don't Break What Works
Existing query patterns must continue to work after these changes. Test with known-good queries.

### Rule 3: Test Your Work
After implementing, test with at least 5 different queries: one simple, one cross-domain, one that should trigger a retry, one aggregate, and one that genuinely can't be answered.

---

## CONTEXT

The AI query engine (Chats) currently generates SQL from natural language questions. It works well for single-domain questions ("top 10 agents," "how many active members") but fails on cross-domain questions that combine data from multiple tables or schemas.

**Example failure:** "Show me all agents in Downers Grove IL who closed a home in January 2026 whose IL license will expire in 2026."

This requires:
1. MLS property data (closed transactions in Downers Grove, January 2026)
2. MLS member data (agent identity from ListAgentKey)
3. AMS member data (license expiration date)

The schema documentation covers all three data sources and the join patterns between them. But the AI either doesn't attempt the cross-schema join or attempts it incorrectly and gives up.

**Root causes:**
1. No retry loop — if Claude generates bad SQL or gives up, the user gets a dead end
2. No cross-domain example queries — all examples are single-domain or two-table
3. The "HANDLING VAGUE QUESTIONS" instruction is too aggressive — Claude bails to "please rephrase" when it should attempt the query
4. Location-based queries (by city, zip, neighborhood) are extremely common for associations but underrepresented in examples

---

## PART 1: ADD SQL RETRY LOOP

### Task 1A: Implement Retry on SQL Execution Failure

**File: `server/services/aiQueryService.ts`**

Find the `executeQuery` method (around line 912). Currently, when the generated SQL fails to execute, the error goes straight to the user:

```typescript
} catch (error) {
  console.error('[AIQueryService] Query execution error:', error);
  return {
    success: false,
    sql,
    error: `Query failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
  };
}
```

Replace this with a retry mechanism that sends the failed SQL and the Postgres error back to Claude for correction:

```typescript
} catch (error) {
  const errorMessage = error instanceof Error ? error.message : 'Unknown error';
  console.error('[AIQueryService] Query execution error:', errorMessage);
  console.log('[AIQueryService] Attempting SQL fix via AI...');
  
  // Ask Claude to fix the SQL based on the error
  try {
    const fixedResult = await this.fixAndRetryQuery(sql, errorMessage, question);
    if (fixedResult) {
      return fixedResult;
    }
  } catch (retryError) {
    console.error('[AIQueryService] Retry also failed:', retryError);
  }
  
  // If retry also failed, return a helpful error
  return {
    success: false,
    sql,
    error: `I tried to answer your question but ran into a database issue. Could you try rephrasing slightly? For example, if you asked about a specific city, try including "IL" or the full city name.`,
  };
}
```

### Task 1B: Implement the fixAndRetryQuery Method

Add this new method to the `AIQueryService` class:

```typescript
private async fixAndRetryQuery(
  failedSql: string, 
  errorMessage: string, 
  originalQuestion: string
): Promise<QueryResult | null> {
  try {
    const client = this.getClient();
    
    const fixPrompt = `You generated this SQL query to answer: "${originalQuestion}"

The query was:
${failedSql}

It failed with this PostgreSQL error:
${errorMessage}

CRITICAL REMINDERS:
- Schema names are case-sensitive: "AMS"."tablename" and "MLS"."tablename" (both schema AND table must be double-quoted)
- AMS member keys have NO MRD prefix. MLS member keys and agent keys HAVE MRD prefix.
- To join AMS members to MLS transactions: 'MRD' || m."MemberKey" = p."ListAgentMlsId"
- NEVER mix local cache tables (member_metrics_cache, activity_cache) with external tables ("AMS"."apmmember") in the same query
- Column names with mixed case MUST be double-quoted: "MemberFullName", "CloseDate", "StandardStatus"
- Always filter "ApmClientId" = 'MainStreet' on external tables

Fix the SQL query. Return ONLY the corrected SQL, nothing else. No explanation, no markdown.`;

    const response = await client.messages.create({
      model: this.model,
      max_tokens: 4096,
      system: `You are a PostgreSQL expert. Fix the SQL query based on the error message. Return ONLY the corrected SQL query with no explanation or formatting.`,
      messages: [{ role: "user", content: fixPrompt }],
    });

    const textContent = response.content.find(block => block.type === "text");
    if (!textContent || textContent.type !== "text") return null;

    let fixedSql = textContent.text.trim()
      .replace(/^```sql\n?/i, '')
      .replace(/^```\n?/i, '')
      .replace(/\n?```$/i, '')
      .trim();
    
    // Apply schema quoting fixes
    fixedSql = this.fixSchemaQuoting(fixedSql);
    
    // Validate the fixed SQL
    const validation = this.validateSql(fixedSql);
    if (!validation.valid) {
      console.log('[AIQueryService] Fixed SQL failed validation:', validation.error);
      return null;
    }
    
    // Determine database and execute
    const isLocalQuery = this.isLocalCacheQuery(fixedSql);
    const pool = isLocalQuery ? localPool : externalPool;
    
    if (!pool) return null;
    
    console.log('[AIQueryService] Executing FIXED query:', fixedSql.substring(0, 200) + '...');
    const result = await pool.query(fixedSql);
    console.log('[AIQueryService] Fixed query returned', result.rowCount, 'rows');
    
    const isAggregate = this.isAggregateResult(result.rows, fixedSql);
    
    return {
      success: true,
      sql: fixedSql,
      data: result.rows,
      rowCount: result.rowCount || 0,
      responsePhrase: undefined, // We lost the phrase during retry, that's OK
      suggestions: [],
      isAggregate,
    };
  } catch (error) {
    console.error('[AIQueryService] Fix attempt failed:', error);
    return null;
  }
}
```

### Task 1C: Retry on AI-Generated ERROR Responses

Currently, when Claude returns `ERROR:` instead of SQL, the system immediately gives up. Add a retry path for this case too.

Find the section in `generateSql` where ERROR responses are handled. Currently it looks something like:

```typescript
if (cleanSql.startsWith('ERROR:') || cleanSql.startsWith('Error:')) {
  return { sql: null, error: cleanSql.replace(/^ERROR:\s*/i, '') };
}
```

Add a rephrase-and-retry before giving up:

```typescript
if (cleanSql.startsWith('ERROR:') || cleanSql.startsWith('Error:')) {
  const aiError = cleanSql.replace(/^ERROR:\s*/i, '');
  
  // If this is already a retry, don't loop
  if (retryCount >= MAX_RETRIES) {
    return { sql: null, error: aiError };
  }
  
  // Try rephrasing the question to be more specific
  console.log('[AIQueryService] AI returned ERROR, attempting rephrased query...');
  try {
    const client = this.getClient();
    const rephraseResponse = await client.messages.create({
      model: this.model,
      max_tokens: 4096,
      system: this.getSqlGenerationPrompt(),
      messages: [
        { role: "user", content: question },
        { role: "assistant", content: `ERROR: ${aiError}` },
        { role: "user", content: `I understand the question might be broad. Please attempt your best interpretation and generate a SQL query. If you need to make assumptions, make reasonable ones and note them in the PHRASE. The user would rather get approximate results than no results.` },
      ],
    });
    
    const retryContent = rephraseResponse.content.find(block => block.type === "text");
    if (retryContent && retryContent.type === "text") {
      const retryText = retryContent.text.trim();
      // Parse the retry response for SQL
      const retrySqlMatch = retryText.match(/SQL:\s*/i);
      if (retrySqlMatch && retrySqlMatch.index !== undefined) {
        let retrySql = retryText.substring(retrySqlMatch.index + retrySqlMatch[0].length).trim()
          .replace(/^```sql\n?/i, '')
          .replace(/^```\n?/i, '')
          .replace(/\n?```$/i, '')
          .trim();
        
        retrySql = this.fixSchemaQuoting(retrySql);
        const retryValidation = this.validateSql(retrySql);
        
        if (retryValidation.valid) {
          // Extract phrase and suggestions from retry
          let retryPhrase = undefined;
          let retrySuggestions: string[] = [];
          const phraseMatch = retryText.match(/PHRASE:\s*(.+?)(?=\nSUGGESTIONS:|$)/is);
          if (phraseMatch) retryPhrase = phraseMatch[1].trim();
          const sugMatch = retryText.match(/SUGGESTIONS:\s*(.+?)(?=\nSQL:|$)/is);
          if (sugMatch) retrySuggestions = sugMatch[1].split('|').map(s => s.trim()).filter(Boolean);
          
          return { sql: retrySql, responsePhrase: retryPhrase, suggestions: retrySuggestions };
        }
      }
    }
  } catch (retryError) {
    console.error('[AIQueryService] Rephrase retry failed:', retryError);
  }
  
  return { sql: null, error: aiError };
}
```

---

## PART 2: ADD CROSS-DOMAIN & LOCATION EXAMPLE QUERIES

### Task 2A: Add Cross-Domain Examples to aiQueryService.ts

**File: `server/services/aiQueryService.ts`**

Find the example queries section in `getSqlGenerationPrompt()` (the section after `=== QUERY-SPECIFIC PRODUCTION PATTERNS ===`). Add the following cross-domain examples BEFORE the existing cache example queries:

```typescript
=== CROSS-DOMAIN QUERIES (combining MLS transactions with AMS member data) ===

These are the most valuable queries for associations — they combine transaction data (where, when, how much) with member attributes (license, designations, join date, compliance).

CRITICAL JOIN PATTERN: AMS member keys have NO MRD prefix. MLS/property keys HAVE MRD prefix.
To connect AMS members to their transactions: 'MRD' || m."MemberKey" = p."ListAgentMlsId"

Q: 'agents in Downers Grove who closed in January 2026 with licenses expiring in 2026'
A: WITH ams_member AS (
  SELECT DISTINCT ON ("ApmClientId", "MemberKey")
    "MemberKey", "MemberFullName", "MemberEmail", 
    "MemberStateLicenseExpirationDate", "OfficeKey"
  FROM "AMS"."apmmember"
  WHERE "ApmClientId" = 'MainStreet' AND "MemberStatus" = 'Active'
  ORDER BY "ApmClientId", "MemberKey", "ApmSourceModificationTimestamp" DESC
),
dg_agents AS (
  SELECT DISTINCT p."ListAgentMlsId" as agent_mls_id
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet' 
    AND p."StandardStatus" = 'Closed'
    AND p."City" ILIKE '%Downers Grove%'
    AND p."CloseDate" >= '2026-01-01' AND p."CloseDate" < '2026-02-01'
  UNION
  SELECT DISTINCT p."BuyerAgentMlsId"
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet'
    AND p."StandardStatus" = 'Closed'
    AND p."City" ILIKE '%Downers Grove%'
    AND p."CloseDate" >= '2026-01-01' AND p."CloseDate" < '2026-02-01'
)
SELECT m."MemberFullName", m."MemberEmail", m."MemberStateLicenseExpirationDate"
FROM ams_member m
WHERE 'MRD' || m."MemberKey" IN (SELECT agent_mls_id FROM dg_agents)
  AND EXTRACT(YEAR FROM m."MemberStateLicenseExpirationDate") = 2026
ORDER BY m."MemberStateLicenseExpirationDate"
LIMIT 500

Q: 'agents who speak Spanish and sell in Oak Park'
A: WITH ams_member AS (
  SELECT DISTINCT ON ("ApmClientId", "MemberKey")
    "MemberKey", "MemberFullName", "MemberEmail", "MemberLanguages"
  FROM "AMS"."apmmember"
  WHERE "ApmClientId" = 'MainStreet' AND "MemberStatus" = 'Active'
    AND "MemberLanguages" ILIKE '%Spanish%'
  ORDER BY "ApmClientId", "MemberKey", "ApmSourceModificationTimestamp" DESC
),
oak_park_agents AS (
  SELECT DISTINCT p."ListAgentMlsId" as agent_mls_id
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
    AND p."City" ILIKE '%Oak Park%'
    AND p."CloseDate" >= CURRENT_DATE - INTERVAL '24 months'
  UNION
  SELECT DISTINCT p."BuyerAgentMlsId"
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
    AND p."City" ILIKE '%Oak Park%'
    AND p."CloseDate" >= CURRENT_DATE - INTERVAL '24 months'
)
SELECT m."MemberFullName", m."MemberEmail"
FROM ams_member m
WHERE 'MRD' || m."MemberKey" IN (SELECT agent_mls_id FROM oak_park_agents)
LIMIT 500

Q: 'top producers in Naperville with CRS designation'
A: WITH ams_member AS (
  SELECT DISTINCT ON ("ApmClientId", "MemberKey")
    "MemberKey", "MemberFullName", "MemberEmail", "MemberDesignations"
  FROM "AMS"."apmmember"
  WHERE "ApmClientId" = 'MainStreet' AND "MemberStatus" = 'Active'
    AND "MemberDesignations"::text ILIKE '%CRS%'
  ORDER BY "ApmClientId", "MemberKey", "ApmSourceModificationTimestamp" DESC
),
naperville_production AS (
  SELECT p."ListAgentMlsId" as agent_mls_id, 
    COUNT(*) as sides, SUM(p."ClosePrice") as volume
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
    AND p."City" ILIKE '%Naperville%'
    AND p."CloseDate" >= CURRENT_DATE - INTERVAL '12 months'
  GROUP BY p."ListAgentMlsId"
)
SELECT m."MemberFullName", m."MemberEmail", np.sides, 
  TO_CHAR(np.volume, 'FM$999,999,999') as volume
FROM ams_member m
JOIN naperville_production np ON 'MRD' || m."MemberKey" = np.agent_mls_id
ORDER BY np.volume DESC
LIMIT 20

Q: 'which cities do our agents sell the most homes in'
A: SELECT p."City", COUNT(*) as closed_transactions, 
  TO_CHAR(SUM(p."ClosePrice"), 'FM$999,999,999,999') as total_volume,
  TO_CHAR(ROUND(AVG(p."ClosePrice")::numeric, 0), 'FM$999,999,999') as avg_price
FROM "MLS"."apmproperty" p
WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
  AND p."CloseDate" >= CURRENT_DATE - INTERVAL '12 months'
  AND p."City" IS NOT NULL AND p."City" != ''
GROUP BY p."City"
ORDER BY closed_transactions DESC
LIMIT 30

Q: 'market activity in zip code 60515' or 'transactions in a specific zip'
A: SELECT p."City", p."PostalCode", COUNT(*) as transactions,
  TO_CHAR(SUM(p."ClosePrice"), 'FM$999,999,999,999') as total_volume,
  TO_CHAR(ROUND(AVG(p."ClosePrice")::numeric, 0), 'FM$999,999,999') as avg_price,
  TO_CHAR(ROUND(AVG(p."DaysOnMarket")::numeric, 0), 'FM999') as avg_dom
FROM "MLS"."apmproperty" p
WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
  AND p."PostalCode" = '60515'
  AND p."CloseDate" >= CURRENT_DATE - INTERVAL '12 months'
GROUP BY p."City", p."PostalCode"

Q: 'agents who sold luxury homes and attended a CE class this year'
A: WITH luxury_agents AS (
  SELECT DISTINCT p."ListAgentMlsId" as agent_mls_id
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
    AND p."ClosePrice" >= 1000000
    AND p."CloseDate" >= CURRENT_DATE - INTERVAL '12 months'
),
ce_attendees AS (
  SELECT DISTINCT a.member_key
  FROM activity_cache a
  JOIN member_metrics_cache m ON a.member_key = m.member_key
  WHERE m.member_status = 'Active'
    AND a.activity_source = 'education'
    AND a.is_completed = true
    AND a.completion_date >= DATE_TRUNC('year', CURRENT_DATE)
)
SELECT m.member_name, m.member_email, m.office_name
FROM member_metrics_cache m
WHERE m.member_status = 'Active'
  AND 'MRD' || m.member_key IN (SELECT agent_mls_id FROM luxury_agents)
  AND m.member_key IN (SELECT member_key FROM ce_attendees)
ORDER BY m.member_name
LIMIT 200

IMPORTANT: The luxury_agents subquery uses an external table (MLS.apmproperty), but we extract just the IDs and use them to filter the local cache. This is the correct pattern — extract IDs from one database, use them as a filter in the other. BUT this specific query won't work as a single SQL statement across databases. Instead, use the all-local-cache approach when possible:

CORRECTED VERSION (all local tables):
SELECT m.member_name, m.member_email, m.office_name
FROM member_metrics_cache m
JOIN agent_production_cache a ON 'MRD' || m.member_key = a.member_key
JOIN activity_cache ac ON m.member_key = ac.member_key
WHERE m.member_status = 'Active'
  AND a.luxury_transactions > 0
  AND ac.activity_source = 'education'
  AND ac.is_completed = true
  AND ac.completion_date >= DATE_TRUNC('year', CURRENT_DATE)
ORDER BY a.production_volume DESC
LIMIT 200

Q: 'offices near Libertyville' or 'agents in the north suburbs'
A: This requires knowing the cities that are "near Libertyville" or considered "north suburbs." For geographic proximity queries, use known city lists:
North suburbs include: Libertyville, Lake Forest, Highland Park, Deerfield, Northbrook, Glenview, Wilmette, Winnetka, Kenilworth, Lake Bluff, Lake Zurich, Mundelein, Vernon Hills, Lincolnshire, Buffalo Grove
West suburbs include: Downers Grove, Naperville, Wheaton, Glen Ellyn, Lombard, Elmhurst, Oak Brook, Hinsdale, Clarendon Hills, Western Springs, La Grange, Westmont
South suburbs include: Tinley Park, Orland Park, Mokena, Frankfort, New Lenox, Homer Glen, Palos Heights, Oak Lawn

SELECT m.member_name, m.office_name, m.member_email
FROM member_metrics_cache m
WHERE m.member_status = 'Active'
  AND m.office_name IN (
    SELECT DISTINCT a.office_name FROM agent_production_cache a
    WHERE a.primary_city IN ('Libertyville', 'Lake Forest', 'Highland Park', 'Deerfield', 'Northbrook', 'Glenview', 'Vernon Hills', 'Lincolnshire', 'Buffalo Grove', 'Mundelein', 'Lake Zurich')
  )
ORDER BY m.office_name, m.member_name
LIMIT 500
```

### Task 2B: Update the Confidence Instruction

**File: `server/services/aiQueryService.ts`**

Find the `HANDLING VAGUE QUESTIONS` section in `getSqlGenerationPrompt()` (around line 137). Replace it with a more balanced approach:

```typescript
HANDLING QUESTIONS:

ATTEMPT FIRST, ASK SECOND. If you can make a reasonable interpretation of the question, generate the SQL query. Only return ERROR if the question is truly unanswerable with the available data.

FOR COMPLEX CROSS-DOMAIN QUESTIONS:
- Break the problem into parts: which tables have the data? What are the join keys?
- Remember the MRD prefix rule: AMS keys have NO prefix, MLS keys HAVE prefix
- Use CTEs (WITH clauses) to keep complex queries readable
- When combining MLS transaction data with AMS member attributes, the join is always through the MemberKey with the MRD prefix: 'MRD' || ams_member."MemberKey" = mls_property."ListAgentMlsId"

FOR BROAD QUESTIONS (still attempt a reasonable interpretation):
- "analyze our members" → Show tier distribution: SELECT tier, COUNT(*) FROM member_metrics_cache WHERE member_status = 'Active' GROUP BY tier
- "how are we doing" → Show key metrics: member count, transaction volume, avg engagement score
- "tell me about our market" → Top cities by transaction volume in last 12 months

ONLY return ERROR when:
- The question asks about data that genuinely doesn't exist in any table (e.g., "social media followers")
- The question requires UPDATE/DELETE/INSERT operations
- The question references a specific entity that can't be identified (e.g., "that agent I was talking about")

When you DO return an error, always suggest 2-3 specific alternative questions the user could ask.
```

---

## PART 3: ADD LOCATION INTELLIGENCE TO SCHEMA

### Task 3A: Add Geographic Context to sharedDatabaseSchema.ts

**File: `server/services/sharedDatabaseSchema.ts`**

Add a new section after `ANNIVERSARY_QUERIES`. This gives Claude geographic awareness for the Mainstreet service area:

```typescript
export const GEOGRAPHIC_CONTEXT = `
=== GEOGRAPHIC CONTEXT — MAINSTREET SERVICE AREA ===

Mainstreet REALTORS® serves 200+ municipalities across Chicagoland. Members, offices, and transactions span Cook, DuPage, Lake, Will, Kane, and McHenry counties.

CAMPUS REGIONS (Mainstreet has 4 physical offices):
- Downers Grove (HQ): Serves west/southwest suburbs — DuPage County, western Cook County
- Libertyville: Serves north suburbs — Lake County
- Rolling Meadows: Serves northwest suburbs — northwest Cook County, eastern Kane/McHenry
- Tinley Park: Serves south suburbs — Will County, south Cook County

LOCATION FIELDS IN THE DATA:
- MLS Properties: "City", "PostalCode", "CountyOrParish", "StateOrProvince"
- Agent Production Cache: primary_city (most common city where agent closes deals)
- Offices: Physical office address is in AMS.apmoffice but not consistently normalized

COMMON LOCATION QUERIES:
- "agents in [city]" → Use agent_production_cache.primary_city or join MLS transactions by city
- "transactions in [zip]" → Use MLS.apmproperty."PostalCode"
- "market stats for [city]" → Aggregate MLS.apmproperty by "City"
- "offices in [area]" → Use member_metrics_cache office_name with city context

CITY NAME MATCHING:
Always use ILIKE with wildcards for city names to handle variations:
- 'Downers Grove' vs 'DOWNERS GROVE' → ILIKE '%Downers Grove%'
- Some listings may have abbreviated city names
`;
```

Add `GEOGRAPHIC_CONTEXT` to the `getSharedDatabaseSchema()` function's array:

```typescript
export function getSharedDatabaseSchema(): string {
  return [
    SHARED_DATABASE_OVERVIEW,
    AMS_MEMBER_SCHEMA,
    MLS_MEMBER_SCHEMA,
    OFFICE_SCHEMA,
    LISTINGS_SCHEMA,
    INVOICES_SCHEMA,
    EVENTS_EDUCATION_SCHEMA,
    REFERENCE_DATA_SCHEMA,
    MEMBER_ASSOCIATION_SCHEMA,
    CACHE_TABLES_SCHEMA,
    KEY_FORMAT_RULES,
    CANONICAL_STATS,
    OFFICE_SWITCHING,
    BUSINESS_INTELLIGENCE,
    CACHE_VS_RAW_GUIDANCE,
    DATABASE_ROUTING_RULE,
    ANNIVERSARY_QUERIES,
    GEOGRAPHIC_CONTEXT,  // NEW
  ].join('\n');
}
```

---

## PART 4: IMPROVE ERROR MESSAGES

### Task 4A: User-Friendly Error Messages

**File: `server/services/aiQueryService.ts`**

Currently, SQL execution errors return the raw Postgres error message to the user. After the retry loop (Part 1), if both attempts fail, the error message should be helpful, not technical.

In the `executeQuery` method, after both the initial attempt and the retry have failed, return:

```typescript
return {
  success: false,
  sql,
  error: `I wasn't able to pull that data together. This kind of question combines multiple data sources which can be tricky. Try breaking it into smaller questions — for example, first ask "which agents closed in Downers Grove in January?" and then "which of those have licenses expiring in 2026?"`,
  suggestions: [
    'Show me agents who closed in Downers Grove recently',
    'Which members have licenses expiring in 2026?',
    'Top producing agents by city',
  ],
};
```

The key insight: if a complex query fails, suggest the user break it into parts. This is actually what the staffer would do naturally in conversation — and each individual part is likely to succeed.

---

## PART 5: LOG FAILURES FOR DEBUGGING

### Task 5A: Log Failed Queries for Analysis

**File: `server/services/aiQueryService.ts`**

Add logging so you can review what's failing and improve the system over time. In the `executeQuery` method, after a failed query (both initial and retry), log the failure:

```typescript
// Log the failure for later analysis
console.log('[AIQueryService] === QUERY FAILURE LOG ===');
console.log('[AIQueryService] Question:', question);
console.log('[AIQueryService] Generated SQL:', sql);
console.log('[AIQueryService] Error:', errorMessage);
if (fixedSql) {
  console.log('[AIQueryService] Retry SQL:', fixedSql);
  console.log('[AIQueryService] Retry Error:', retryErrorMessage);
}
console.log('[AIQueryService] === END FAILURE LOG ===');
```

This lets you (Tracy) review the Replit console logs to see exactly what queries are failing and why, which informs future prompt improvements.

---

## VERIFICATION CHECKLIST

### Retry Loop
- [ ] Ask a question that generates SQL with a typo/wrong column → first attempt fails, retry fixes it, user gets results
- [ ] Ask a question that Claude initially returns ERROR for → retry attempts with encouragement, generates SQL
- [ ] Ask a genuinely unanswerable question ("show me members' Instagram followers") → still returns a helpful error with suggestions

### Cross-Domain Queries
- [ ] "Show me agents in Downers Grove who closed in January 2026 with licenses expiring in 2026" → returns results (not "please rephrase")
- [ ] "Agents who speak Spanish and sell in Oak Park" → returns results
- [ ] "Top producers in Naperville with CRS designation" → returns results
- [ ] "Which cities do our agents sell the most in" → returns city breakdown

### Location Intelligence
- [ ] "Market stats for zip 60515" → returns transaction data
- [ ] "Transactions in Tinley Park last year" → returns results
- [ ] "Which agents sell the most in the north suburbs" → attempts reasonable interpretation

### Existing Queries Still Work
- [ ] "How many active members do we have" → still works
- [ ] "Top 10 agents by volume" → still works
- [ ] "Members with overdue invoices" → still works
- [ ] "Offices with most members" → still works
- [ ] "Upcoming events" → still works

### Error Messages
- [ ] Failed complex query → user sees helpful suggestion to break into parts, not a Postgres error
- [ ] Console logs show the failure details for debugging

---

## FILES CHANGED

**Modified:**
- `server/services/aiQueryService.ts` — Added fixAndRetryQuery method, retry on ERROR responses, cross-domain example queries, updated confidence instructions, improved error messages, failure logging
- `server/services/sharedDatabaseSchema.ts` — Added GEOGRAPHIC_CONTEXT section

**NOT modified:**
- Any frontend files
- Any other backend services
- Schema/database tables

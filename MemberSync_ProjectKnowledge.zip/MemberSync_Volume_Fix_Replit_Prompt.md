# Volume Double-Counting Fix â€” Replit Prompt
## MemberSync â€” February 2026

---

## CONTEXT

We discovered that every volume calculation in MemberSync is double-counting dollar amounts. When a $500K home sells, both the listing agent and buyer agent get credited with the full $500K in volume. When these are summed for office totals, tier breakdowns, or market statistics, the dollar amounts are inflated by exactly 2x.

**Sides are correct.** Agent side counts are fine â€” each agent legitimately earns one side per transaction. Do NOT change any side counts or transaction counts anywhere in the app.

**Volume is the problem.** The ClosePrice is being counted twice per property whenever both the listing agent and buyer agent are Mainstreet members (which is nearly every transaction â€” validation confirmed a clean 2.0x inflation multiplier).

This prompt fixes the volume calculations across the codebase by establishing two distinct volume concepts as the Membio standard.

---

## THE MEMBIO VOLUME STANDARD

### Personal Production Volume (agent vanity metric)
Each agent gets the full ClosePrice for every side they represent. An agent who lists a $500K home claims $500K in personal production, and the buyer's agent also claims $500K. This is how the real estate industry reports individual production.

**Used for:** Agent profile page "Personal Production" display, individual agent rankings in leaderboards.

### Market Volume Contribution (the real number)
Each property's ClosePrice is counted exactly once across the entire association. When both sides are association members, each agent gets HALF the ClosePrice. When only one side is a member, that agent gets the full ClosePrice.

**Used for:** Everything that rolls up to a total â€” office volume, tier volume, market share, concentration stats, association-level reporting, and the `total_volume_12mo` / `total_volume_24mo` fields in `member_metrics_cache`.

### The Split Rule
For each closed property:
- If `BuyerAgentKey IS NOT NULL AND BuyerOfficeKey IS NOT NULL AND BuyerOfficeKey <> 'MRDNONMEMBER'` â†’ both sides are members â†’ ClosePrice Ã— 0.5 for each side
- Otherwise â†’ only one side is a member â†’ ClosePrice Ã— 1.0 for that side

---

## CHANGE 1: Schema â€” Add personal_volume columns

### File: `shared/schema.ts`

In the `memberMetricsCache` table definition, add two new columns after `buyerSideCount`:

```typescript
// Find this line (approximately line 115):
  buyerSideCount: integer("buyer_side_count").default(0),

// Add immediately after it:
  personalVolume12mo: numeric("personal_volume_12mo").default("0"),
  personalVolume24mo: numeric("personal_volume_24mo").default("0"),
```

**Important:** The existing `totalVolume12mo` and `totalVolume24mo` columns stay in place. Their MEANING changes (they will now store market volume contribution instead of double-counted volume), but the column names and types don't change. This means every downstream query that reads `total_volume_12mo` automatically gets the correct market volume with zero code changes.

In the `officeMetricsCache` table definition, add one new column after `totalVolume12mo`:

```typescript
// Find this line (approximately line 168):
  totalVolume12mo: numeric("total_volume_12mo").default("0"),

// Add immediately after it:
  personalVolume12mo: numeric("personal_volume_12mo").default("0"),
```

### Database Migration

Run this migration to add the new columns to the existing tables:

```sql
-- Add personal volume columns to member_metrics_cache
ALTER TABLE member_metrics_cache
  ADD COLUMN IF NOT EXISTS personal_volume_12mo NUMERIC DEFAULT 0,
  ADD COLUMN IF NOT EXISTS personal_volume_24mo NUMERIC DEFAULT 0;

-- Add personal volume column to office_metrics_cache
ALTER TABLE office_metrics_cache
  ADD COLUMN IF NOT EXISTS personal_volume_12mo NUMERIC DEFAULT 0;

-- Also add to the temp table used during atomic refresh
ALTER TABLE member_metrics_cache_new
  ADD COLUMN IF NOT EXISTS personal_volume_12mo NUMERIC DEFAULT 0,
  ADD COLUMN IF NOT EXISTS personal_volume_24mo NUMERIC DEFAULT 0;
```

---

## CHANGE 2: Member Metrics Cache Service â€” Fix the transaction query

### File: `server/services/memberMetricsCacheService.ts`

This is the most critical change. The daily cache refresh queries the external MLS database for each agent's transaction data. The current query uses `UNION ALL` of listing and buyer sides with full `ClosePrice`, which double-counts volume.

#### Step 2a: Update the transactionMap type (around line 92)

Replace the current type definition:

```typescript
// REPLACE this block (lines ~92-101):
    const transactionMap = new Map<string, {
      tx12mo: number;
      tx24mo: number;
      vol12mo: number;
      vol24mo: number;
      avgPrice12mo: number;
      listingCount: number;
      buyerCount: number;
      lastTxDate: Date | null;
    }>();

// WITH this (adds personal volume fields):
    const transactionMap = new Map<string, {
      tx12mo: number;
      tx24mo: number;
      vol12mo: number;        // now stores MARKET volume contribution
      vol24mo: number;        // now stores MARKET volume contribution
      personalVol12mo: number; // NEW: personal production volume
      personalVol24mo: number; // NEW: personal production volume
      avgPrice12mo: number;
      listingCount: number;
      buyerCount: number;
      lastTxDate: Date | null;
    }>();
```

#### Step 2b: Replace the transaction SQL query (around lines 106-130)

Replace the entire `txQuery` string with this corrected version that computes both volume types:

```typescript
        const txQuery = `
          WITH prop_dedup AS (
            SELECT p.*,
                   ROW_NUMBER() OVER (
                     PARTITION BY p."ApmClientId", p."ApmSourceUniqueRecordId"
                     ORDER BY p."ApmSourceModificationTimestamp" DESC
                   ) AS rn
            FROM "MLS"."apmproperty" p
            WHERE p."ApmClientId" = 'MainStreet'
              AND p."StandardStatus" = 'Closed'
              AND p."CloseDate" IS NOT NULL
              AND p."ClosePrice" IS NOT NULL
          ),
          props AS (
            SELECT * FROM prop_dedup WHERE rn = 1
          ),
          sides AS (
            SELECT
              p."ListAgentMlsId" AS agent_mls_id,
              p."CloseDate" AS close_date,
              p."ClosePrice" AS close_price,
              'listing' AS side,
              -- Market volume: split when both sides exist
              p."ClosePrice" * CASE
                WHEN p."BuyerAgentKey" IS NOT NULL
                  AND p."BuyerOfficeKey" IS NOT NULL
                  AND p."BuyerOfficeKey" <> 'MRDNONMEMBER'
                THEN 0.5 ELSE 1.0
              END AS market_volume_contribution
            FROM props p
            WHERE p."ListAgentMlsId" = ANY($1)

            UNION ALL

            SELECT
              p."BuyerAgentMlsId" AS agent_mls_id,
              p."CloseDate" AS close_date,
              p."ClosePrice" AS close_price,
              'buyer' AS side,
              p."ClosePrice" * CASE
                WHEN p."ListAgentKey" IS NOT NULL
                THEN 0.5 ELSE 1.0
              END AS market_volume_contribution
            FROM props p
            WHERE p."BuyerAgentMlsId" = ANY($1)
              AND p."BuyerOfficeKey" IS NOT NULL
              AND p."BuyerOfficeKey" <> 'MRDNONMEMBER'
          ),
          agent_transactions AS (
            SELECT
              agent_mls_id,
              COUNT(CASE WHEN close_date >= NOW() - INTERVAL '12 months' THEN 1 END) AS tx_12mo,
              COUNT(CASE WHEN close_date >= NOW() - INTERVAL '24 months' THEN 1 END) AS tx_24mo,
              -- Market volume (deduplicated - for cache total_volume fields)
              COALESCE(SUM(CASE WHEN close_date >= NOW() - INTERVAL '12 months' THEN market_volume_contribution ELSE 0 END), 0) AS vol_12mo,
              COALESCE(SUM(CASE WHEN close_date >= NOW() - INTERVAL '24 months' THEN market_volume_contribution ELSE 0 END), 0) AS vol_24mo,
              -- Personal production volume (full ClosePrice per side - agent vanity metric)
              COALESCE(SUM(CASE WHEN close_date >= NOW() - INTERVAL '12 months' THEN close_price ELSE 0 END), 0) AS personal_vol_12mo,
              COALESCE(SUM(CASE WHEN close_date >= NOW() - INTERVAL '24 months' THEN close_price ELSE 0 END), 0) AS personal_vol_24mo,
              -- Average price uses full ClosePrice (what homes are worth, not the split)
              COALESCE(AVG(CASE WHEN close_date >= NOW() - INTERVAL '12 months' THEN close_price END), 0) AS avg_price_12mo,
              COUNT(CASE WHEN side = 'listing' AND close_date >= NOW() - INTERVAL '12 months' THEN 1 END) AS listing_count,
              COUNT(CASE WHEN side = 'buyer' AND close_date >= NOW() - INTERVAL '12 months' THEN 1 END) AS buyer_count,
              MAX(close_date) AS last_tx_date
            FROM sides
            GROUP BY agent_mls_id
          )
          SELECT * FROM agent_transactions
        `;
```

#### Step 2c: Update the transactionMap population (around lines 132-145)

Replace the result processing to include personal volume:

```typescript
        const txResult = await externalClient.query(txQuery, [batchIds]);
        for (const row of txResult.rows) {
          const originalMlsId = row.agent_mls_id.replace(/^MRD/, '');
          transactionMap.set(originalMlsId, {
            tx12mo: parseInt(row.tx_12mo) || 0,
            tx24mo: parseInt(row.tx_24mo) || 0,
            vol12mo: parseFloat(row.vol_12mo) || 0,         // market volume
            vol24mo: parseFloat(row.vol_24mo) || 0,         // market volume
            personalVol12mo: parseFloat(row.personal_vol_12mo) || 0,  // personal production
            personalVol24mo: parseFloat(row.personal_vol_24mo) || 0,  // personal production
            avgPrice12mo: parseFloat(row.avg_price_12mo) || 0,
            listingCount: parseInt(row.listing_count) || 0,
            buyerCount: parseInt(row.buyer_count) || 0,
            lastTxDate: row.last_tx_date ? new Date(row.last_tx_date) : null,
          });
        }
```

#### Step 2d: Update the default transaction object (around line 300 area where `tx` is set from the map)

Find where the code creates a default `tx` object for members not found in the transaction map. It will look something like:

```typescript
        const tx = transactionMap.get(mlsId) || {
          tx12mo: 0, tx24mo: 0, vol12mo: 0, vol24mo: 0,
          avgPrice12mo: 0, listingCount: 0, buyerCount: 0, lastTxDate: null
        };
```

Add the new fields to the default:

```typescript
        const tx = transactionMap.get(mlsId) || {
          tx12mo: 0, tx24mo: 0, vol12mo: 0, vol24mo: 0,
          personalVol12mo: 0, personalVol24mo: 0,
          avgPrice12mo: 0, listingCount: 0, buyerCount: 0, lastTxDate: null
        };
```

#### Step 2e: Update the INSERT statement and values.push (around lines 454-449)

The INSERT column list needs two new columns. Add `personal_volume_12mo` and `personal_volume_24mo` after `buyer_side_count`:

```typescript
        const insertQuery = `
          INSERT INTO member_metrics_cache_new (
            member_key, member_mls_id, member_name, member_first_name, member_last_name,
            member_email, member_mobile_phone, member_direct_phone, office_key, office_name,
            member_status, member_type, member_state_license, member_state_license_expiration_date,
            nar_join_date, member_designations,
            transactions_12mo, transactions_24mo, total_volume_12mo, total_volume_24mo,
            avg_price_12mo, listing_side_count, buyer_side_count,
            personal_volume_12mo, personal_volume_24mo,
            tier, engagement_score, risk_level, has_overdue_invoice,
            last_activity_date, last_activity_source, profile_image_url,
            cached_at, metrics_calculated_at
          ) VALUES ${values.join(',\n')}
        `;
```

The `values.push` template needs two more `$${paramIndex++}` placeholders (for 32 total params + NOW(), NOW()):

```typescript
        values.push(`($${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, NOW(), NOW())`);
```

And the `params.push` needs the two new personal volume values inserted after `tx.buyerCount`:

```typescript
        params.push(
          m.MemberKey,
          m.MemberMlsId || null,
          m.MemberFullName || '',
          m.MemberFirstName || null,
          m.MemberLastName || null,
          m.MemberEmail || null,
          m.MemberMobilePhone || null,
          m.MemberDirectPhone || null,
          m.OfficeKey || null,
          officeName,
          m.MemberStatus || 'Active',
          m.MemberType || 'REALTOR',
          m.MemberStateLicense || null,
          m.MemberStateLicenseExpirationDate || null,
          m.NarJoinDate || null,
          m.MemberDesignations ? JSON.stringify(m.MemberDesignations) : null,
          tx.tx12mo,
          tx.tx24mo,
          tx.vol12mo,          // market volume contribution (was double-counted, now correct)
          tx.vol24mo,          // market volume contribution (was double-counted, now correct)
          tx.avgPrice12mo,
          tx.listingCount,
          tx.buyerCount,
          tx.personalVol12mo,  // NEW: personal production volume
          tx.personalVol24mo,  // NEW: personal production volume
          tier,
          score,
          risk,
          pay.totalBalanceDue > 0,
          lastActivityDate,
          lastActivitySource,
          profileImageUrl
        );
```

**CRITICAL: Count verification.** The INSERT has 34 columns. The values template must have 32 `$${paramIndex++}` placeholders plus `NOW(), NOW()` = 34. The params.push must have exactly 32 values. Count carefully â€” a mismatch will silently corrupt data or crash the cache refresh.

---

## CHANGE 3: Analytics Production Cache Service â€” Fix office and agent volume

### File: `server/services/analyticsProductionCacheService.ts`

This file has multiple volume calculations that need the same split treatment. The changes follow the same pattern: wherever there's a `UNION ALL` of listing and buyer sides followed by `SUM(close_price)`, apply the market volume split.

#### Step 3a: Office Volume (around lines 136-145)

The existing `list_office_volume` CTE currently counts volume only via the listing office. Replace it with the split approach that credits both offices:

Find the `list_office_volume` CTE (approximately line 136):

```sql
      /* 2) Non-inflated production volume: count each closing ONCE (listing office only) */
      list_office_volume AS (
        SELECT
          p."ListOfficeKey" AS office_key,
          SUM(p."ClosePrice") AS production_volume,
          COUNT(*) AS closings
        FROM props p
        WHERE p."ListOfficeKey" IS NOT NULL
        GROUP BY 1
      ),
```

Replace with:

```sql
      /* 2) Market volume contribution: split when both offices are members */
      office_market_volume AS (
        SELECT office_key, SUM(market_vol) AS production_volume, SUM(closings) AS closings
        FROM (
          SELECT
            p."ListOfficeKey" AS office_key,
            SUM(p."ClosePrice" * CASE
              WHEN p."BuyerOfficeKey" IS NOT NULL
                AND p."BuyerOfficeKey" <> 'MRDNONMEMBER'
              THEN 0.5 ELSE 1.0
            END) AS market_vol,
            COUNT(*) AS closings
          FROM props p
          WHERE p."ListOfficeKey" IS NOT NULL
          GROUP BY 1
          UNION ALL
          SELECT
            p."BuyerOfficeKey" AS office_key,
            SUM(p."ClosePrice" * CASE
              WHEN p."ListOfficeKey" IS NOT NULL
              THEN 0.5 ELSE 1.0
            END) AS market_vol,
            0 AS closings
          FROM props p
          WHERE p."BuyerOfficeKey" IS NOT NULL
            AND p."BuyerOfficeKey" <> 'MRDNONMEMBER'
          GROUP BY 1
        ) combined
        GROUP BY office_key
      ),
```

Update any references from `list_office_volume` to `office_market_volume` in the downstream CTEs and JOINs within the same query.

#### Step 3b: Agent Production Volume (around lines 330-390)

In the `currentYearQuery`, find the `agent_rollup` CTE where it does `SUM(swm.close_price) AS total_volume`. This needs to compute both volume types:

Replace:
```sql
          SUM(swm.close_price) AS total_volume,
```

With:
```sql
          SUM(swm.close_price * CASE
            WHEN swm.has_other_side THEN 0.5 ELSE 1.0
          END) AS total_volume,
          SUM(swm.close_price) AS personal_production_volume,
```

To make `has_other_side` available, add it to the `sides` CTE:

In the listing side of the UNION ALL, add:
```sql
          CASE WHEN p."BuyerAgentKey" IS NOT NULL
            AND p."BuyerOfficeKey" IS NOT NULL
            AND p."BuyerOfficeKey" <> 'MRDNONMEMBER'
          THEN TRUE ELSE FALSE END AS has_other_side
```

In the buyer side of the UNION ALL, add:
```sql
          CASE WHEN p."ListAgentKey" IS NOT NULL
          THEN TRUE ELSE FALSE END AS has_other_side
```

Apply the same pattern to the `priorYearQuery` (around lines 395-430) and the career volume query (around lines 450-470).

#### Step 3c: Office INSERT â€” Add personal_volume_12mo

The office cache INSERT statement needs the new `personal_volume_12mo` column added. Ensure the column is included in the INSERT column list and the corresponding value is pushed into the params array. Verify the placeholder count matches.

---

## CHANGE 4: AI Query Service â€” Fix example queries that teach Claude AI

### File: `server/services/aiQueryService.ts`

The example queries embedded in this file teach the AI how to write SQL. If the examples double-count volume, every AI-generated query about volume will also double-count. Replace the three volume-related examples.

#### Example 1: Top offices by volume (around line 439)

Find the example query for "top 20 offices by volume" or similar. Replace the SQL with:

```sql
WITH prop_dedup AS (
  SELECT p.*, ROW_NUMBER() OVER (
    PARTITION BY p."ApmSourceUniqueRecordId"
    ORDER BY p."ApmSourceModificationTimestamp" DESC
  ) AS rn
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
    AND p."CloseDate" >= CURRENT_DATE - INTERVAL '12 months'
    AND p."ClosePrice" IS NOT NULL
),
props AS (SELECT * FROM prop_dedup WHERE rn = 1),
office_contrib AS (
  SELECT p."ListOfficeKey" AS office_key,
    SUM(p."ClosePrice" * CASE WHEN p."BuyerOfficeKey" IS NOT NULL THEN 0.5 ELSE 1 END) AS market_volume,
    COUNT(*) AS listing_sides
  FROM props p WHERE p."ListOfficeKey" IS NOT NULL GROUP BY 1
  UNION ALL
  SELECT p."BuyerOfficeKey" AS office_key,
    SUM(p."ClosePrice" * CASE WHEN p."ListOfficeKey" IS NOT NULL THEN 0.5 ELSE 1 END) AS market_volume,
    COUNT(*) AS buyer_sides
  FROM props p WHERE p."BuyerOfficeKey" IS NOT NULL GROUP BY 1
),
office_final AS (
  SELECT office_key, SUM(market_volume) AS market_volume FROM office_contrib GROUP BY 1
),
latest_office AS (
  SELECT DISTINCT ON (o."ApmClientId", o."OfficeKey") o."OfficeKey", o."OfficeName"
  FROM "AMS"."apmoffice" o WHERE o."ApmClientId" = 'MainStreet'
  ORDER BY o."ApmClientId", o."OfficeKey", o."ApmSourceModificationTimestamp" DESC
)
SELECT o."OfficeName", f.market_volume
FROM office_final f
JOIN latest_office o ON o."OfficeKey" = f.office_key
ORDER BY f.market_volume DESC
LIMIT 20
```

#### Example 2: Top agents by volume (around line 458)

Find the example query for "top 10 agents by volume" or "top producers". Replace the SQL with:

```sql
WITH prop_dedup AS (
  SELECT p.*, ROW_NUMBER() OVER (
    PARTITION BY p."ApmSourceUniqueRecordId"
    ORDER BY p."ApmSourceModificationTimestamp" DESC
  ) AS rn
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
    AND p."CloseDate" >= CURRENT_DATE - INTERVAL '12 months'
    AND p."ClosePrice" IS NOT NULL
),
props AS (SELECT * FROM prop_dedup WHERE rn = 1),
mls_member AS (
  SELECT DISTINCT ON (m."ApmClientId", m."MemberKey") m."MemberKey", m."MemberFullName"
  FROM "MLS"."apmmember" m WHERE m."ApmClientId" = 'MainStreet' AND m."MemberStatus" = 'Active'
  ORDER BY m."ApmClientId", m."MemberKey", m."ApmSourceModificationTimestamp" DESC
),
agent_contrib AS (
  SELECT p."ListAgentKey" AS member_key,
    SUM(p."ClosePrice" * CASE WHEN p."BuyerAgentKey" IS NOT NULL THEN 0.5 ELSE 1 END) AS market_volume,
    COUNT(*) AS sides
  FROM props p WHERE p."ListAgentKey" IS NOT NULL GROUP BY 1
  UNION ALL
  SELECT p."BuyerAgentKey" AS member_key,
    SUM(p."ClosePrice" * CASE WHEN p."ListAgentKey" IS NOT NULL THEN 0.5 ELSE 1 END) AS market_volume,
    COUNT(*) AS sides
  FROM props p WHERE p."BuyerAgentKey" IS NOT NULL GROUP BY 1
),
agent_final AS (
  SELECT member_key, SUM(market_volume) AS market_volume, SUM(sides) AS total_sides
  FROM agent_contrib GROUP BY 1
)
SELECT m."MemberFullName", f.total_sides, f.market_volume
FROM agent_final f
JOIN mls_member m ON m."MemberKey" = f.member_key
ORDER BY f.market_volume DESC
LIMIT 10
```

#### Example 3: Property type volume (around line 492)

Find the example query for property type analysis. Replace the SQL with:

```sql
WITH prop_dedup AS (
  SELECT p.*, ROW_NUMBER() OVER (
    PARTITION BY p."ApmSourceUniqueRecordId"
    ORDER BY p."ApmSourceModificationTimestamp" DESC
  ) AS rn
  FROM "MLS"."apmproperty" p
  WHERE p."ApmClientId" = 'MainStreet' AND p."StandardStatus" = 'Closed'
    AND p."CloseDate" >= CURRENT_DATE - INTERVAL '12 months'
    AND p."ClosePrice" IS NOT NULL
),
props AS (SELECT * FROM prop_dedup WHERE rn = 1)
SELECT "PropertyType",
  COUNT(*) AS transaction_count,
  SUM("ClosePrice") AS market_volume,
  ROUND(AVG("ClosePrice")::numeric, 0) AS avg_price
FROM props
WHERE "PropertyType" IS NOT NULL
GROUP BY "PropertyType"
ORDER BY transaction_count DESC
LIMIT 10
```

Note: The property type query is simpler because it counts at the property level (no UNION ALL of sides), so there's no double-counting. Each property row appears once. This is the correct pattern for property-level aggregates.

---

## CHANGE 5: AI Schema Documentation â€” Explain the two volume concepts

### File: `server/services/sharedDatabaseSchema.ts`

Find the documentation section that describes ClosePrice and the production cache fields. Add this explanation:

```
IMPORTANT â€” Volume Concepts in MemberSync:
The platform tracks two types of volume:
1. "Personal Production" (personal_volume_12mo) = full ClosePrice per side. Used for individual agent stats.
2. "Market Volume" (total_volume_12mo) = ClosePrice split 50/50 when both sides are association members.
   Used for all aggregates: office totals, tier totals, market share, concentration stats.
When a user asks about "total volume," "market volume," or office/tier volume, use total_volume_12mo (market volume).
When a user asks about an individual agent's production, use personal_volume_12mo.
Never SUM(ClosePrice) across a UNION ALL of listing + buyer sides for market-level stats â€” this double-counts.
```

---

## CHANGE 6: Agent Profile Page â€” Show both volume types

### File: `client/src/pages/MemberDetail.tsx`

On the agent profile/member detail page, find where the agent's production volume is displayed. It currently reads `total_volume_12mo` from the cache. Update the display to show both numbers:

- **Personal Production:** Read from the new `personal_volume_12mo` field. Display as the larger, primary number since this is what agents are used to seeing.
- **Market Volume Contribution:** Read from `total_volume_12mo`. Display as a secondary number with a tooltip: "Market Volume splits the sale price between both agents when both are association members, ensuring accurate market totals."

This can be a simple addition to the existing production stats section â€” show Personal Production prominently, then show Market Volume Contribution below it in a smaller or muted style with the tooltip icon.

---

## WHAT NOT TO CHANGE

- **Side counts** â€” all transaction_12mo, transaction_24mo, listing_side_count, buyer_side_count values are correct
- **Tier thresholds** â€” Rainmaker 40+, Builder 6-39, Foundation 0-5 sides. These are based on sides, not volume
- **Member detail transaction list** (storage.ts ~lines 1286-1322) â€” individual transaction display should show the actual sale price
- **Engagement scoring** â€” the scoring formula in memberMetricsCacheService.ts does not use volume, only side counts and activity signals
- **The atomic cache refresh pattern** â€” keep the temp table â†’ truncate â†’ insert swap mechanism exactly as it is

---

## VERIFICATION AFTER DEPLOYMENT

After the cache refresh runs with the new code:

1. **Total market volume should be approximately half the old value.** The validation query showed the old inflated total was ~$38B and the corrected market total is ~$19B (a clean 2.0x reduction).

2. **Tier volumes should sum to approximately the total market volume.** Rainmaker volume + Builder volume + Foundation volume â‰ˆ total market volume. If they don't add up, something is still double-counting.

3. **Individual agent side counts should be unchanged.** Compare a sample of agents before and after â€” their transaction_12mo and listing/buyer counts should be identical.

4. **The new `personal_volume_12mo` should approximately equal the old `total_volume_12mo`** for any given agent (since the old value was the double-counted personal production number).

5. **Office leaderboard rankings** should be mostly the same (relative order preserved since the inflation was uniform at 2x), but the dollar amounts will be halved.

---

## BUILD AND DEPLOY SEQUENCE

1. Add the schema columns (Change 1) â€” this is safe to do first, new columns default to 0
2. Update the member metrics cache service (Change 2) â€” the next cache refresh will populate correct values
3. Update the analytics production cache service (Change 3) â€” the next analytics cache refresh will populate correct values
4. Update the AI query examples (Change 4) â€” so new AI-generated queries use the correct pattern
5. Update the AI schema documentation (Change 5) â€” so the AI understands the two volume concepts
6. Update the agent profile page (Change 6) â€” to display both volume types
7. Trigger a manual cache refresh to populate the new data immediately rather than waiting for the scheduled 4 AM run

**Do NOT combine this with any other feature work.** This is a data integrity fix that should be deployed and verified on its own.

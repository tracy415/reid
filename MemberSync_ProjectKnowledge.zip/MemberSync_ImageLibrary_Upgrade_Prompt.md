# MemberSync — Image Library Upgrade: Metadata, Edit, Grid/List View, Upload Guidance

## Date: March 2026
## Priority: Send after image insert fix is verified

---

## STANDING RULES REMINDER

Before touching any file: search for existing components first. No parallel systems. Don't break what works. Scope is limited to the image library only — do not touch email composition, send flow, or any other feature.

---

## OVERVIEW

Four improvements to the Image Library in a single prompt:

1. **Additional metadata fields** — Add Alt Text (required) and Tags (optional) to upload and edit
2. **Edit capability** — Staff can edit image metadata after upload
3. **Grid/List view toggle** — Staff can switch between visual grid and compact list
4. **Upload guidance** — Category-specific size, ratio, and format guidance shown at upload time, with a soft warning if the uploaded image doesn't meet recommendations

---

## PART 1 — ADDITIONAL METADATA FIELDS

### Database changes

```sql
ALTER TABLE email_images ADD COLUMN alt_text TEXT NOT NULL DEFAULT '';
ALTER TABLE email_images ADD COLUMN tags TEXT;
```

Update the Drizzle schema in `schema.ts` accordingly.

**Note:** The `DEFAULT ''` on `alt_text` is for the migration only — new uploads must provide alt text (enforced at the API level). Existing images get an empty string which staff can fill in via the new edit capability.

### Upload form changes

Add two fields to the upload form, below Category:

**Alt Text** (required)
- Label: "Alt text *"
- Placeholder: "Describe this image, e.g. 'Spring conference banner with teal background'"
- Helper text: "Used by screen readers and AI to understand the image"
- Required — Upload button stays disabled until filled
- Max 200 characters

**Tags** (optional)
- Label: "Tags"
- Placeholder: "e.g. spring, conference, 2026"
- Helper text: "Comma-separated keywords for searching"
- Store as plain text, display as gray pills on the image card

### API changes

Update `POST /api/images/upload` to:
- Require `altText` — return 400 with message "Alt text is required" if missing or empty
- Accept optional `tags` string
- Store both in the new columns

Update `GET /api/images` response to include `altText` and `tags` per image.

---

## PART 2 — EDIT CAPABILITY

### What to build

Add an Edit button (pencil icon) to each image card. It appears on hover, alongside the existing delete icon.

Clicking Edit transforms the card into an inline edit form — **not a modal**. The card expands to show all four editable fields pre-populated with current values:

- Name (required)
- Category (required dropdown)
- Alt Text (required)
- Tags (optional)

Two buttons at the bottom of the expanded card:
- **Save** — calls `PATCH /api/images/:id`, collapses back to card view on success, shows brief success toast
- **Cancel** — collapses back to card view without saving

### API endpoint

```
PATCH /api/images/:id
  Body: { name?, category?, altText?, tags? }
  Validation: name and altText must not be empty if provided
  Response: updated image record
```

### List view edit

In list view (see Part 3), the Edit button opens the same inline expansion — the row expands to show the edit fields below it.

---

## PART 3 — GRID/LIST VIEW TOGGLE

### Toggle button

Add a view toggle in the top-right of the image library page, next to the search input:

```
[⊞ Grid]  [≡ List]
```

Default is Grid. Selection persists in localStorage so staff's preference is remembered across sessions.

### Grid view (existing, with enhancements)

The existing thumbnail grid — 4 columns desktop, 2 mobile. Each card shows:
- Thumbnail image
- Name
- Category badge (colored per category)
- Dimensions (e.g. "1200×400")
- Tags as small gray pills (if any)
- Use count ("Used in 3 campaigns" or "Never used" in gray)
- Edit icon and Delete icon on hover

### List view (new)

Compact table with columns:

| Thumbnail | Name | Category | Dimensions | Tags | Used | Uploaded | Actions |
|-----------|------|----------|------------|------|------|----------|---------|
| 48×48px thumb | Name | Badge | 1200×400 | pills | "3×" or "—" | Mar 1 | Edit · Delete |

- Thumbnail is small (48×48px), cropped square
- Rows are compact — designed for scanning and managing, not browsing
- Same Edit and Delete actions as grid view
- Sortable by Name, Category, Uploaded date, Use count (click column header)
- Default sort: Uploaded date descending (newest first)

---

## PART 4 — UPLOAD GUIDANCE AND RATIO WARNING

### Category guidance

When a category is selected in the upload form dropdown, show a helper line immediately below it with the recommended upload specifications for that category:

| Category | Guidance text |
|----------|---------------|
| Event Banner | Suggested upload: 1200×400px (3:1 ratio) · JPG or PNG |
| Headshot | Suggested upload: 300×300px (1:1 ratio) · JPG or PNG |
| Logo | Suggested upload: 400×160px (5:2 ratio) · PNG recommended for transparency |
| Illustration | Suggested upload: 1200×800px (3:2 ratio) · JPG or PNG |
| Notifications | Suggested upload: 500×600px (5:6 ratio) · JPG or PNG |
| Other | Suggested upload: 1200px wide maximum · JPG or PNG |

Display this as a small gray helper line directly below the Category dropdown — same style as the existing helper text on Alt Text and Tags. It appears immediately when a category is selected and updates if the category changes.

### Soft warning on upload

After a file is selected (before upload is submitted), check the image dimensions using the browser's `Image` object:

```javascript
const img = new Image();
img.onload = () => {
  const { width, height } = img;
  // Check against recommended dimensions for selected category
  // Show warning if significantly undersized or wrong ratio
};
img.src = URL.createObjectURL(file);
```

For each category, check two things:
1. **Dimensions** — is width or height less than 80% of the recommended upload size?
2. **Ratio** — is the actual ratio significantly different from the recommended ratio? Use a 25% tolerance. For example, Event Banner expects 3:1 — warn if actual ratio is outside 2.25:1 to 3.75:1.

If either check fails, show a soft amber warning below the file selector:

```
⚠ This image is 400×350px with a roughly 1:1 ratio.
  Event Banners work best at 1200×400px (3:1 ratio — wide and short).
  It may appear cropped or distorted in emails.
```

This is a warning only — staff can still upload. Do not block the upload.

If both checks pass, show nothing. Do not show a "looks good" confirmation.

**Ratio descriptions by category** (use these in warning messages):
- Event Banner: "wide and short"
- Headshot: "square"
- Logo: "wide and short"
- Illustration: "landscape rectangle"
- Notifications: "portrait rectangle"
- Other: no ratio warning

### Notifications category — portal clients only

The Notifications category is only relevant for clients with a member portal. For now, include it in the category list for all users (Mainstreet has a portal). Add a code comment:

```typescript
// TODO: Gate 'notifications' category on tenant_config.has_member_portal
// when multi-tenant config is implemented
```

---

## FILES TO MODIFY

- `server/schema.ts` — Add `alt_text`, `tags` columns to `email_images`
- `server/routes.ts` — Update upload endpoint (require altText), add PATCH endpoint
- `client/src/pages/SmartSendsImages.tsx` — All UI changes: new fields, edit, toggle, guidance, warning

## FILES NOT TO MODIFY

- `server/services/imageService.ts` — No changes to optimization logic
- `server/services/emailService.ts` — No changes
- `client/src/pages/SendEmail.tsx` — No changes
- Any other file not listed above

---

## VERIFICATION CHECKLIST

### Part 1 — Metadata fields
- [ ] Upload form shows Alt Text (required) and Tags (optional) fields
- [ ] Upload fails with clear error if Alt Text is empty
- [ ] Tags display as gray pills on image cards
- [ ] Alt text and tags returned in GET /api/images response

### Part 2 — Edit capability
- [ ] Edit icon appears on hover for every image card
- [ ] Clicking Edit expands the card inline (no modal)
- [ ] All four fields pre-populated with current values
- [ ] Save updates the record and collapses the card
- [ ] Cancel collapses without saving
- [ ] Edit works in both grid and list view

### Part 3 — Grid/List toggle
- [ ] Toggle buttons appear top-right of page
- [ ] Grid view shows thumbnails in 4-column layout
- [ ] List view shows compact table with all columns
- [ ] List view is sortable by Name, Category, Uploaded, Use count
- [ ] View preference persists across page refreshes (localStorage)
- [ ] Both views show Edit and Delete actions

### Part 4 — Upload guidance
- [ ] Selecting a category shows the guidance helper text immediately
- [ ] Guidance text updates when category changes
- [ ] Soft warning appears for undersized images
- [ ] Soft warning appears for wrong ratio images
- [ ] Warning message includes the specific recommended size and ratio description
- [ ] Upload is NOT blocked by warnings — staff can proceed
- [ ] No warning shown when image meets recommendations

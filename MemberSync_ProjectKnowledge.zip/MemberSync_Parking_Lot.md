# MemberSync Parking Lot
## Strategic Ideas Backlog

*Last updated: March 6, 2026 (afternoon)*

This file is the canonical location for sidelined strategic ideas — things that are real, valuable, and intentionally deferred. Claude adds to this file as ideas surface in conversation. Review before each major planning session.

---

## SECTION 1: FEATURES TO BUILD (Prioritized)

### Campaign Architect ⭐ HIGH PRIORITY — AEI Demo
Replace the current drip sequence builder entirely with an AI-first campaign creation flow. Staff types one goal sentence; AI diagnoses the goal, proposes a complete multi-email structure with reasoning, writes all emails using real member data, and suggests one A/B test before activation. Staff says yes or no at each step — never stares at a blank canvas.

**Demo path (3 minutes):** Show competitor node canvas → switch to MemberSync → type one sentence → watch AI build complete campaign → activate.

**Architectural implication:** New frontend interaction pattern in `CreateAutomation.tsx` for drip_sequence type. New AI system prompt for campaign planning. Reuses existing triggered campaign execution infrastructure. `ai_campaign_decisions` table needed for outcome tracking.

---

### Proactive AI Engagement Engine
Makes Community Insights cards real. Pattern detectors run daily against member data, score insights, and connect to SmartSends actions. Positive and proactive — celebrates opportunity rather than flagging problems. More compelling for demos than lapse prevention.

**Architectural implication:** Daily job that evaluates pattern detectors against `member_metrics_cache`. Scoring system for insight priority. Connection to SmartSends audience creation.

---

### Lapse Prevention System
Calendar-aware risk scoring and automated intervention. Members don't lapse overnight — they drift for months. MemberSync tracks the trajectory and intervenes before it's too late.

**Architectural implication:** `member_metrics_cache` needs historical scoring (trend over time). `membership_daily_snapshot` is the first step already in place. New tables: `member_status_tracking`, `member_risk_scores`, `intervention_log`, `billing_calendar`.

---

### AI Chart Rendering ⭐ ACCELERATED for CRMLS Pilot
AI Chat detects when results should be visualized and renders Recharts components inline. Download-as-image button. This is the feature that creates operational dependency — a CEO who gets a board-ready chart in 10 seconds never gives it up.

**Architectural implication:** AI query service response format needs a `visualization` field alongside `data` and `insights`. Estimated 3–5 Replit prompts.

---

### AI Learning / Network Effect Engine
Cross-client campaign performance learning. AI recommendations improve as more associations use the platform. The 100th association gets a smarter AI than the first one did.

**Concretely:** Campaign performance outcomes stored against AI decisions (structure, timing, audience). Cross-client pattern detection feeds back into Campaign Architect recommendations. Association-specific learning layer on top.

**Architectural implication:** `ai_campaign_decisions` table with outcome tracking. Campaign outcome tracking (open rate, click rate) linked to AI recommendation metadata. Cross-client aggregate learning respects tenant isolation.

---

### Broker Module
Office payment health, agent roster visibility, broker liability (DR Formula) tracking, suspension impact analysis. Brokers in Illinois have legal liability for their agents' dues status.

**Architectural implication:** Email functionality stays in SmartSends. Broker Module handles dashboards and reporting only. Keep `brokerResolutionService.ts` clean and well-tested.

---

### Lapse Pattern Analysis
Predictive models built from member behavior in the 24 months before lapse. What does a member do (or stop doing) before they leave? This becomes the early warning system.

**Architectural implication:** Don't purge old data. Historical engagement scores and activity patterns have future predictive value. `membership_daily_snapshot` accumulation is the foundation.

---

### Competitive Intelligence Module
Outward-facing analytics helping association/MLS executives understand competitive threats. Who's selling where, territory patterns, member drift signals. Surfaces in AI Chat and potentially as a dashboard section.

**Architectural implication:** New query patterns in `aiQueryService.ts` for cross-association analysis. Careful multi-tenant scoping — Client A cannot see Client B's data, but can see aggregated patterns and their own members' market activity. Geographic intelligence already added to AI Chat is the foundation.

---

### Member Preference Center
Members choose which email categories they receive (compliance always, engagement optional). Reduces unsubscribes by letting members opt down instead of opt out entirely. Staff sees preference data per member.

**Architectural implication:** `member_email_preferences` table already exists. Needs UI for member-facing preference management and staff-facing visibility.

---

### Listing Lifecycle Automations
Triggered communications based on listing events: new listing congratulations, price reduction encouragement, just sold celebration. Data comes from MLS listing feed already in the database.

**Architectural implication:** New trigger types in `triggeredCampaignProcessor.ts`. New evaluator functions for listing events. Merge fields for listing address, price, days on market.

---

### Automations Polish Round 2
- Delete/discard capability for automations
- Audience visibility and estimated reach on trigger config
- Automation-specific analytics (rolling performance timeline, cumulative stats)
- Event override priority system (specific event automation overrides "all events" automation)

---

### AI Report Generation
Multi-section board reports from natural language. "Give me a board meeting summary for March" → formatted report with member stats, campaign performance, top milestones, compliance status.

**Architectural implication:** Multi-chart dashboards as Stage 4. Full presentation generation as Stage 5 (the operational dependency play).

---

### Exportable Charts
PDF/PNG export from AI Chat charts. Copy to clipboard. Download as image.

---

### A/B Testing Activation
Currently on hold — superseded by Campaign Architect design. When Campaign Architect is built, A/B testing is built into it (AI proposes one test, staff approves or skips). The standalone A/B testing prompt (`SmartSends_ABTesting_Part2.md`) is superseded.

---

### Compliance Section Redesign
The current compliance flow is a shortcut — it creates an audience from the compliance widget and drops staff into the standard Send Email wizard. This needs to be rethought as a proper workflow. Deferred until after AEI demo.

---

## SECTION 2: TECHNICAL DEBT & POLISH

### Image Library — Future Improvements
- **Async image optimization:** Move Sharp processing to a background job when batch upload is added. Currently synchronous — fine for single uploads.
- **CDN-proof image URL tracking:** `trackImageUsageInHtml` uses regex pattern matching for `/api/images/file/` URLs. Update to use stored image IDs when CDN is introduced.
- **In-app image cropping:** Canvas-based cropping for uploaded images. Deferred — staff should prepare images before upload. Revisit when a client specifically requests it.
- **70% duplicate detection threshold:** Should eventually be configurable per client in `tenant_config`.

### Email Archive
- **Date range picker:** Backend supports `startDate`/`endDate` filters; frontend only has search and category. Small follow-up UI addition.

### Recognition Queue
- **Dedicated count endpoint:** Currently fetches full list to count pending items. Add `/api/recognition-queue/count` when queue volume grows.
- **Stale detail cache:** Detail panel uses cached list data briefly before detail query resolves. Imperceptible in normal use but worth polishing.

### Email Governor
- **Backend cap validation:** PATCH endpoint doesn't validate daily cap 1–10, weekly cap 1–21 ranges. Three-line fix — low risk since only admins access it.
- **Configurable exempt categories:** Currently hardcoded in `canSendToMember`. Move to `exempt_categories` column in `email_governor_config` when UI configurability is needed.

### Drip Sequence Step Editor
Each step needs a proper EmailComposer with visual preview. Currently functional but not polished enough for production.

### Templates System
Functional but not useful enough. Future rework: past campaigns as templates, smart suggestions based on context.

### Revenue Data
Currently uses catalog prices, not actual invoiced amounts. Fix: map charge codes to pull from `apmmemberdues` actual invoiced revenue.

---

## SECTION 3: INFRASTRUCTURE & SCALE

### SOC 2 Certification
Most required controls (access management, encryption, logging) already in place. Target SOC 2 Type I before CRMLS pilot launches. Type II (requires 3–6 months of operational evidence) follows. Competitive differentiator — most association tech vendors lack formal certifications.

### Prompt Caching
90% reduction on AI input costs. High-value architectural improvement before CRMLS scale.

### Batch Email Sending
Rate-limited queue for CRMLS scale (103,000+ members). Current send architecture handles Mainstreet fine; CRMLS requires proper batching.

### Multi-Tenant Stage 2 — Admin Provisioning Dashboard
After Stage 1 (database-driven config) is complete. Staff-facing dashboard to provision new clients without engineering involvement.

### Multi-Tenant Stage 3 — Self-Service Onboarding
Credit card, connect APIs, go. Only automate steps already validated manually with real clients.

### Integration Marketplace
Zendesk (HGAR), Google Analytics, LMS connectors, lockbox access logs, benefits usage data.

### Query Engine Phase 2 — Query Planning Architecture
Split planner and generator for data source scaling. Current single-prompt approach works for Mainstreet; multi-source queries at CRMLS scale need proper planning layer.

---

## SECTION 4: THINGS THAT MUST BE CONFIGURED PER CLIENT

These are features or behaviors that work differently depending on the client and must be controlled by `tenant_config` in the production platform. They are currently hardcoded for Mainstreet in the prototype.

### Image Library — Notifications Category
The "Notifications" image category is only relevant for clients with a member portal (currently Mainstreet and HGAR). Gate on `tenant_config.has_member_portal`. Code comment already added in image library: `// TODO: Gate 'notifications' category on tenant_config.has_member_portal`.

### Compliance Module
Compliance tracking, CE requirements, Code of Ethics enforcement, and Fair Housing rules are association-specific. MLSs do not use this module. Gate on `tenant_config.org_type === 'association'`. All compliance panels hidden for MLS clients.

### Engagement Scoring Weights
Different organizations weight engagement signals differently. Tier thresholds (Rainmaker/Builder/Foundation cutoffs) and signal weights (education, events, email, transactions) are client-configurable via `tenant_config`. Currently hardcoded for Mainstreet.

### Illinois-Specific Compliance Rules
CE deadlines, COE renewal cycles, Fair Housing requirements, and billing calendar dates are Illinois/Mainstreet-specific. HGAR (New York) has different rules. All compliance logic is parameterized by state in `tenant_config`.

### Office Suspension as Gatekeeper
The rule that office suspension removes ALL agents' MLS/SentriLock access (not individual suspension) is Mainstreet Advantage-specific. Other clients may have different suspension models. Gate on `tenant_config.office_suspension_model`.

### Mainstreet Branding in Email Templates
All hardcoded "Mainstreet REALTORS®" references in email templates, system messages, and UI copy. 110+ instances in the prototype. Production platform uses `tenant_config.org_name`, `tenant_config.brand_color`, `tenant_config.logo_url`.

### Billing Calendar
Annual dues timeline (July invoices, Dec 1 due, Jan 2 suspensions) and Advantage Spring timeline (March invoices, March 31 due, April 1 MLS suspended) are Mainstreet-specific. Each client has their own billing calendar in `tenant_config`.

### SmartSends — Portal-Only Features
Banner notifications and Recommendation cards (portal content) should be hidden for clients without a member portal. Gate on `tenant_config.has_member_portal`. Currently shown for all users.

### AI Geographic Context
The Mainstreet service area (Chicago suburbs, specific cities, county references) is hardcoded in the AI Chat query service. Each client needs their own geographic context injected into AI prompts via `tenant_config.geographic_context`.

### Duplicate Detection Threshold
The 70% similarity threshold for email duplicate detection should eventually be configurable per client. Some clients send more frequently and need a higher threshold; others are more conservative. Add to `tenant_config.duplicate_detection_threshold`.

### Lapse Prevention — Billing Calendar and Risk Thresholds
Every client has different invoice dates, due dates, suspension triggers, and grace periods. Risk score weights at each calendar position are also client-specific. Both go in `tenant_config.billing_calendar` and `tenant_config.lapse_risk_weights`. The Mainstreet billing calendar is the reference implementation.

### Proactive Engagement Engine — Insight Thresholds
What constitutes a "notable" pattern varies by membership size and client type. A 500-member spike means something different at CRMLS (103,000 members) than at GRAR (3,400 members). Minimum thresholds for surfacing insights go in `tenant_config.engagement_insight_thresholds`.

### AI Chat — Suggested Queries and Available Data Sources
The default suggested queries priming the AI Chat, and which data sources the query planner can access, are client-specific. MLSs and associations ask fundamentally different questions. The query planner must know which sources are available before generating a query plan. Goes in `tenant_config.ai_chat_context` and `tenant_config.available_data_sources`.

### Competitive Intelligence — Territory Boundaries
The geographic definition of "our territory" and which neighboring organizations are considered competitors is entirely client-specific. Cannot be inferred from data alone — must be explicitly configured. Goes in `tenant_config.competitive_territory`.

### Integration Marketplace — Per-Client Connections
Each integration (Zendesk, Google Analytics, lockbox, LMS) is independently enabled per client with its own credentials and field mappings. This is a configuration subsystem, not just a feature flag — likely needs its own `tenant_integrations` table rather than living in `tenant_config`. Each integration's data flows into engagement scoring via configurable signal weights.

### AI Chart Rendering — Default Chart Types
The default charts and visualizations surfaced for an MLS vs. an association differ fundamentally. MLSs care about market share, listing velocity, and agent production. Associations care about dues revenue, engagement trends, and compliance rates. Default chart suggestions go in `tenant_config.default_visualizations`.

### Automations — Event Override Priority
Which automations take precedence when multiple automations could fire for the same member event is a policy decision, not a product decision. Priority ordering goes in `tenant_config.automation_priority_rules`.

---

## STANDING NOTE: CLAUDE.md IMPLICATIONS

The items in Section 4 collectively define what must move from hardcoded Mainstreet values into the `tenant_config` database table during the production port. The next revision of CLAUDE.md should include a dedicated section listing all `tenant_config` fields with their types, defaults, and which features depend on them. This section does not yet exist in the current CLAUDE.md (v2, 786 lines).

Schedule a CLAUDE.md revision session after the AEI demo to incorporate: Section 4 items, Campaign Architect architecture, Email Health Dashboard, Image Library, and Recognition Queue infrastructure.

---

*Items graduate from this list when they are specced, built, and deployed. Items are never deleted — they are marked as complete with a date.*

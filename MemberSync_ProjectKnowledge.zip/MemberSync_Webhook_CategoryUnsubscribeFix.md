# MemberSync — SendGrid Webhook Category-Aware Unsubscribe Fix
*Written: March 10, 2026*
*Status: READY TO SEND TO REPLIT*

---

## WHAT THIS FIXES

The SendGrid webhook handler currently processes all unsubscribe events as global opt-outs (`email_opt_out = true`). Now that we have per-category unsubscribe groups and category columns on `member_email_preferences`, the webhook should set the appropriate category opt-out instead of a global one.

This is a small, focused change. Do not modify anything outside the webhook handler.

Do not modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts` for any reason.

---

## THE FIX

### Where to find it

The SendGrid webhook handler is in `server/routes.ts`. It processes POST requests from SendGrid containing email events (delivered, opened, clicked, bounced, unsubscribed, etc.).

Find the section that handles `unsubscribe` and `group_unsubscribe` event types.

### Current behavior (wrong)

Any unsubscribe event sets `email_opt_out = true` globally on the member's record — regardless of which email category triggered the opt-out.

### Required behavior

**For `group_unsubscribe` events:**

SendGrid includes `asm_group_id` in the event payload. Use that ID to determine which category was unsubscribed from:

1. Load `tenant_config` for the client
2. Match `asm_group_id` against the four group ID columns:
   - `sg_group_marketing` → set `marketing_opt_out = true`, `marketing_opt_out_date = now`
   - `sg_group_recognition` → set `recognition_opt_out = true`, `recognition_opt_out_date = now`
   - `sg_group_compliance` → log the event but do not apply suppression (compliance is required)
   - `sg_group_transactional` → log the event but do not apply suppression (transactional is required)
3. Do NOT set global `email_opt_out = true` for group unsubscribes

**For plain `unsubscribe` events (no `asm_group_id`):**

Keep the existing global opt-out behavior — set `email_opt_out = true`. This is the safe fallback for unsubscribes that arrive without group context.

**For `group_resubscribe` events (if present):**

If SendGrid sends a `group_resubscribe` event, clear the appropriate category opt-out column using the same group ID matching logic.

### Helper pattern

```javascript
function getCategoryFromGroupId(asmGroupId, tenantConfig) {
  if (asmGroupId === tenantConfig.sg_group_marketing) return 'marketing';
  if (asmGroupId === tenantConfig.sg_group_recognition) return 'recognition';
  if (asmGroupId === tenantConfig.sg_group_compliance) return 'compliance';
  if (asmGroupId === tenantConfig.sg_group_transactional) return 'transactional';
  return null; // unknown group — fall back to global opt-out
}
```

If `getCategoryFromGroupId` returns `null` (unrecognized group ID), fall back to global opt-out and log a warning with the unrecognized group ID.

---

## WHAT NOT TO CHANGE

- Do not change how `delivered`, `open`, `click`, or `bounce` events are processed
- Do not change the existing global `email_opt_out` behavior for plain unsubscribe events
- Do not modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts`
- Do not change any other part of the webhook handler

---

## VERIFICATION

- [ ] Send a test email, click the "Unsubscribe" link in the footer — verify `email_opt_out = true` is set (plain unsubscribe, global fallback)
- [ ] Send a test email, click "Manage Preferences" and turn off Marketing — verify `marketing_opt_out = true` is set and `email_opt_out` remains unchanged
- [ ] In SendGrid activity, verify `group_unsubscribe` events are being received with `asm_group_id` in the payload
- [ ] Verify that a `group_unsubscribe` for the marketing group sets `marketing_opt_out = true` and does NOT set `email_opt_out = true`
- [ ] Verify that a `group_unsubscribe` for compliance or transactional logs the event but applies no suppression

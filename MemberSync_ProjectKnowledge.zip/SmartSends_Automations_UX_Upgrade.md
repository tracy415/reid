# SmartSends: Automations UX Upgrade
## Replit Prompt — February 20, 2026

---

## CONTEXT FOR REPLIT AGENT

The Automations feature (triggered campaigns) was just deployed and is functional. However, the create/edit UI is a basic form that doesn't match the quality of the existing Send Email flow. This prompt upgrades the Automations experience to use the same step-by-step wizard pattern, rich email editor, template preview, and event picker that already exist in `SendEmail.tsx`.

**The goal:** Creating an automation should feel exactly like creating a regular email campaign — the same polished wizard, the same Quill editor, the same email template preview, the same event insert capability — but with an added trigger configuration step that makes it clear what this automation does and when it fires.

**CRITICAL RULES:**
- Do NOT modify `SendEmail.tsx` or any existing email functionality
- Do NOT modify existing trigger evaluators in `triggeredCampaignProcessor.ts` — but you WILL add one new trigger type (`scheduled_series`) to the processor's evaluator switch and a small processing function for it (see Part 8)
- REUSE existing components and patterns wherever possible (the event picker dialog, the Quill editor, the email preview HTML template, etc.)
- The existing create/edit dialog should be replaced with a full-page wizard flow, similar to how Send Email works

---

## PART 1: REPLACE THE DIALOG WITH A FULL-PAGE WIZARD

### Current Problem

The "Create New Automation" UI is a simple dialog/modal with plain text inputs. It has:
- A plain textarea for email body (no rich text editor)
- No email preview on a template
- No event picker integration
- No trigger-specific configuration UI
- No visual difference between trigger types
- No way to edit an existing automation properly

### New Flow: Step-by-Step Wizard

Replace the dialog with a full-page wizard at a route like `/smartsends/automations/new` (and `/smartsends/automations/:id/edit` for editing). The wizard uses the same stepper pattern as `SendEmail.tsx`.

**Steps for event-based triggers** (Event Registration, Event Reminder, Event Follow-up):

```
[ Configure Trigger ] → [ Compose Email ] → [ Preview ] → [ Settings & Activate ]
```

**Steps for data-based triggers** (Membership Anniversary, Production Milestone):

```
[ Configure Trigger ] → [ Compose Email ] → [ Preview ] → [ Settings & Activate ]
```

**Steps for Drip Sequences:**

```
[ Configure Trigger ] → [ Build Sequence ] → [ Preview ] → [ Settings & Activate ]
```

**Steps for Scheduled Series** (fixed-date multi-email campaigns):

```
[ Configure Trigger ] → [ Build Series ] → [ Preview ] → [ Settings & Activate ]
```

Use the same stepper component pattern from `SendEmail.tsx` (lines 2037-2065):
- Active step: `bg-primary text-primary-foreground`
- Completed step: `bg-primary/10 text-primary` with CheckCircle icon
- Future step: `bg-muted text-muted-foreground cursor-not-allowed`
- Arrow separators between steps

### Route Setup

Add these routes in `App.tsx`:
```typescript
<Route path="/smartsends/automations/new" component={CreateAutomation} />
<Route path="/smartsends/automations/:id/edit" component={CreateAutomation} />
```

The component detects whether it's in create or edit mode by checking for the `:id` param. In edit mode, it loads the existing campaign data and pre-fills all fields.

---

## PART 2: STEP 1 — CONFIGURE TRIGGER

This step replaces the old trigger type dropdown + empty config. It should feel like you're making a meaningful choice, not filling in a form.

### Trigger Selection Cards

Instead of a dropdown, show **7 large cards** in a grid. Each card has:
- An icon (use lucide-react icons)
- The trigger name
- A one-line description of what it does
- A colored left border matching the trigger type badge colors from the Automations list

```
┌──────────────────────────┐  ┌──────────────────────────┐
│ 📋 Event Registration    │  │ ⏰ Event Reminder         │
│ Send when someone signs  │  │ Send X days before an    │
│ up for a class or event  │  │ upcoming event           │
└──────────────────────────┘  └──────────────────────────┘
┌──────────────────────────┐  ┌──────────────────────────┐
│ 📨 Post-Event Follow-up  │  │ 🎂 Membership Anniversary│
│ Send after an event      │  │ Celebrate yearly         │
│ has taken place          │  │ membership milestones    │
└──────────────────────────┘  └──────────────────────────┘
┌──────────────────────────┐  ┌──────────────────────────┐
│ 🏆 Production Milestone  │  │ 📧 Drip Sequence         │
│ Congratulate transaction │  │ Multi-step email series  │
│ and volume achievements  │  │ on a rolling schedule    │
└──────────────────────────┘  └──────────────────────────┘
┌──────────────────────────┐
│ 📅 Scheduled Series      │
│ Multi-email campaign on  │
│ specific calendar dates  │
└──────────────────────────┘
```

Clicking a card selects it (highlighted border, checkmark). The card stays selected and trigger-specific configuration appears below it.

### Trigger-Specific Configuration (appears below selected card)

**Event Registration:**
- Toggle: "All events and classes" (default on) vs. "Specific events only"
- If "Specific events only": show the **same event picker** from `SendEmail.tsx` (the `Insert Upcoming Event` dialog with search, type filter, Class/Event badges, CE credits, price). But instead of "Insert" buttons, show checkboxes to select which events trigger this automation.
- Show a summary: "This automation will trigger for: All upcoming events and classes" or "This automation will trigger for: 3 selected events"

**Event Reminder:**
- Same event scope selector as above (all vs. specific)
- Plus: "Send reminder **[1 ▾]** **[days ▾]** before the event" — dropdown for number (1, 2, 3, 5, 7, 14) and unit (days)

**Post-Event Follow-up:**
- Same event scope selector
- "Send follow-up **[1 ▾]** **[days ▾]** after the event"

**Membership Anniversary:**
- Checkboxes for which years to celebrate:
  ```
  ☑ 1 year    ☑ 5 years    ☑ 10 years    ☑ 15 years
  ☑ 20 years  ☑ 25 years   ☐ 30 years    ☐ Every year
  ```
- "Every year" is a special option that unchecks all individual years and sends for any anniversary
- Show a count: "~43 members will celebrate one of these anniversaries this month"
  - Query: `SELECT COUNT(*) FROM member_metrics_cache WHERE member_status = 'Active' AND nar_join_date IS NOT NULL AND EXTRACT(MONTH FROM nar_join_date) = EXTRACT(MONTH FROM CURRENT_DATE)` (filtered by selected years)

**Production Milestone:**
- Checkboxes:
  ```
  ☑ Transaction milestones (25th, 50th, 100th transaction...)
  ☑ Volume milestones ($1M, $5M, $10M in career volume...)
  ☐ Rookie star (first 5 transactions)
  ☐ First million (first $1M in volume)
  ```

**Drip Sequence:**
- Audience selector — reuse the same audience selection pattern from the Send Email "Choose Audience" step:
  - Saved audiences dropdown
  - Or "Build with AI" to create a new audience
- Show member count: "2,847 members in this audience"
- Note: Drip sequences send on a **rolling schedule** — delays are relative to when each member is enrolled. If you need fixed calendar dates instead, use Scheduled Series.

**Scheduled Series:**
- Audience selector — same as Drip Sequence (saved audiences, AI builder, member type list, CSV upload)
- Show member count: "2,847 members in this audience"
- Note: "Each email in this series will be sent to your entire audience on the specific date you choose."
- This is the right choice when you want everyone to get the same email on the same day — like a membership drive, a seasonal promotion, or a multi-part educational series.

### Automation Name

At the bottom of Step 1, show the automation name field:
- Pre-fill with a smart default based on the trigger: "Event Registration Confirmation", "7-Day Event Reminder", "5-Year Anniversary Celebration", etc.
- User can edit it

**Next button** takes user to Step 2.

---

## PART 3: STEP 2 — COMPOSE EMAIL

This step should be **nearly identical** to the Compose step in `SendEmail.tsx`. Reuse as much of the existing code as possible.

### For Single-Email Triggers (Event Registration, Event Reminder, Event Follow-up, Anniversary, Milestone)

Show:
1. **Subject Line** input (same styling as SendEmail)
2. **Preview Text** input (same as SendEmail — "Brief preview shown in inbox")
3. **Email Body** using the same **ReactQuill** rich text editor with the same toolbar configuration from `SendEmail.tsx` (bold, italic, underline, lists, alignment, links, images, format clear)
4. **"Insert Event" button** below the editor — opens the same event picker dialog from `SendEmail.tsx`. This uses the `insertEventBlock()` function pattern to insert a formatted event card into the email body.
5. **Available merge fields** shown as clickable badges below the editor. Clicking a badge inserts it at the cursor position in the Quill editor:
   - All triggers: `{{FirstName}}`, `{{LastName}}`, `{{OfficeName}}`
   - Event triggers: `{{ClassName}}`, `{{ClassDate}}`, `{{ClassTime}}`
   - Anniversary: `{{YearsAsMember}}`, `{{JoinDate}}`
   - Milestone: `{{MilestoneLabel}}`, `{{MilestoneValue}}`

### For Drip Sequences (rolling delays)

Show a **step builder** instead of a single email editor:

```
┌──────────────────────────────────────────────────────────────┐
│  Step 1                                                  Day 0│
│  ─────────────────────────────────────────────────────────── │
│  Name: [Welcome Email                               ]       │
│  Subject: [Welcome to Mainstreet REALTORS!           ]       │
│                                                              │
│  [Edit Email Content]  — opens the full Quill editor in a    │
│                          modal/slide-over panel              │
│                                                              │
│  Status: ✅ Email content written (247 words)                │
├──────────────────────────────────────────────────────────────┤
│  Step 2                                                  Day 7│
│  ─────────────────────────────────────────────────────────── │
│  Name: [Getting Started Guide                        ]       │
│  Subject: [3 things to try this week                 ]       │
│  Send condition: [Send to everyone           ▾]              │
│                                                              │
│  [Edit Email Content]                                        │
│                                                              │
│  Status: ⬜ No content yet                                   │
├──────────────────────────────────────────────────────────────┤
│                    [+ Add Step]                               │
└──────────────────────────────────────────────────────────────┘
```

Each step's "Edit Email Content" button opens a modal/panel with the full Quill editor, subject line, preview text, merge fields, and Insert Event button — the same compose experience as a single email.

The "Day" field is editable — it's the `delay_days` value (0 = send immediately on enrollment, 7 = send 7 days after enrollment, etc.).

The "Send condition" dropdown appears on steps 2+:
- "Send to everyone" (always)
- "Only if they opened the previous email" (opened_previous)
- "Only if they did NOT open the previous email" (not_opened_previous)
- "Only if they clicked in the previous email" (clicked_previous)
- "Only if they did NOT click in the previous email" (not_clicked_previous)

Steps can be reordered, deleted, or added. Each step saves to the `/api/triggered-campaigns/:id/steps` endpoint.

### For Scheduled Series (fixed calendar dates)

Show a **date-based step builder** — similar layout to the drip step builder, but instead of "Day 7" relative delays, each step has a **date picker** for the exact send date:

```
┌──────────────────────────────────────────────────────────────┐
│  Email 1                                       📅 March 1    │
│  ─────────────────────────────────────────────────────────── │
│  Name: [Spring Membership Drive - Kickoff         ]          │
│  Subject: [Exciting news for your 2026 membership ]          │
│                                                              │
│  [Edit Email Content]                                        │
│                                                              │
│  Status: ✅ Email content written (312 words)                │
├──────────────────────────────────────────────────────────────┤
│  Email 2                                       📅 March 15   │
│  ─────────────────────────────────────────────────────────── │
│  Name: [Spring Membership Drive - Benefits       ]           │
│  Subject: [Have you explored these member benefits?]         │
│                                                              │
│  [Edit Email Content]                                        │
│                                                              │
│  Status: ⬜ No content yet                                   │
├──────────────────────────────────────────────────────────────┤
│  Email 3                                       📅 April 1    │
│  ─────────────────────────────────────────────────────────── │
│  Name: [Spring Membership Drive - Last Chance    ]           │
│  Subject: [Don't miss out — renew by April 15    ]           │
│                                                              │
│  [Edit Email Content]                                        │
│                                                              │
│  Status: ⬜ No content yet                                   │
├──────────────────────────────────────────────────────────────┤
│                    [+ Add Email]                              │
└──────────────────────────────────────────────────────────────┘
```

Key differences from the Drip Sequence builder:
- Instead of "Day 0", "Day 7" etc., each step shows a **date picker** for a specific calendar date
- Steps are labeled "Email 1", "Email 2" etc. instead of "Step 1", "Step 2" (friendlier for non-technical users thinking about a campaign calendar)
- No "Send condition" branching dropdowns — every email in the series goes to the entire audience on the date specified (keep it simple and predictable)
- Dates must be in the future and in chronological order — show validation if a user picks a date before a previous step's date
- Each step's "Edit Email Content" button opens the same Quill editor modal as Drip Sequence steps

**How it stores:** Scheduled Series uses the same `triggered_campaign_steps` table as drip sequences. The `trigger_type` on the parent campaign is `'scheduled_series'`. Each step stores its target send date in the `send_date` column (see Part 8 for the migration). The `delay_days` field is set to 0 (unused — the processor uses `send_date` instead).

**Important:** Unlike drip sequences, Scheduled Series does NOT need the "activate-drip" enrollment endpoint. Instead, when the processor runs and finds a `scheduled_series` campaign where today matches a step's `sendDate`, it resolves the audience fresh at send time (just like the other triggers resolve their qualifying members). This means if the audience changes between emails — new members added, some removed — the series automatically reflects the current audience for each send. Store the `audienceId` in the campaign's `trigger_config`: `{ "audienceId": "uuid-here" }`.

---

## PART 4: STEP 3 — PREVIEW

This is the email template preview, identical to the Preview step in `SendEmail.tsx`.

### Implementation

Reuse the `getEmailPreviewHtml()` function pattern from `SendEmail.tsx` (around line 1886). This function wraps the email body in the full Mainstreet REALTORS® branded template with:
- Logo header
- Styled body content
- Footer with address, phone, unsubscribe link

Show the preview in an iframe (same as SendEmail's preview step).

**For single-email triggers:** Show one preview with the subject line above it.

**For drip sequences and scheduled series:** Show a tab or dropdown to switch between step previews: "Step 1: Welcome Email", "Step 2: Getting Started Guide", etc. (for drip) or "Email 1: March 1 — Kickoff", "Email 2: March 15 — Benefits", etc. (for scheduled series). Each shows the full template preview for that step.

**Merge field preview:** Replace merge tags with example data so the user can see what the email will actually look like:
- `{{FirstName}}` → "Sarah"
- `{{LastName}}` → "Johnson"
- `{{OfficeName}}` → "Coldwell Banker Realty"
- `{{ClassName}}` → the actual event name if one was selected in Step 1, otherwise "15-Hour Post Applied Brokerage Principles"
- `{{YearsAsMember}}` → "10"
- `{{MilestoneLabel}}` → "50th Transaction Milestone"

---

## PART 5: STEP 4 — SETTINGS & ACTIVATE

The final step combines the send window settings with a clear summary and activation controls.

### Summary Section

Show a clean summary card of everything configured:

```
┌──────────────────────────────────────────────────────────────┐
│  📋 Automation Summary                                       │
│                                                              │
│  Name:     7-Day Event Reminder                              │
│  Trigger:  Event Reminder — 7 days before all events         │
│  Subject:  Don't miss {{ClassName}} next week!               │
│  Preview:  Your upcoming class is just 7 days away...        │
│                                                              │
│  Estimated reach: ~120 members/month                         │
│  (based on average event registrations)                      │
└──────────────────────────────────────────────────────────────┘
```

### Send Window

```
Send between: [8:00 AM ▾] and [5:00 PM ▾]  Central Time
☐ Send on weekends
```

### Auto-Stop Date (Optional)

```
Auto-stop date: [mm/dd/yyyy 📅]
Campaign will automatically archive after this date
```

### Action Buttons

```
[← Back]          [Save as Draft]     [▶ Activate Automation]
```

- **Save as Draft:** Saves with status 'draft' and returns to the Automations list
- **Activate Automation:** Sets status to 'active' and starts the processor evaluating this campaign. For drip sequences, this triggers the `/api/triggered-campaigns/:id/activate-drip` endpoint with the selected audience. For scheduled series, activation simply makes the campaign active — the processor will check daily whether today matches any step's send date.
- Show a confirmation dialog before activating: "This automation will start sending emails automatically. Are you sure?"
- For scheduled series, the confirmation should show the dates: "This series will send 3 emails on: March 1, March 15, and April 1. Are you sure?"

---

## PART 6: UPGRADE THE AUTOMATIONS LIST PAGE

### Status Cards at Top

The existing status summary cards (Active, Paused, Drafts, Total Sent) are good — keep them.

### Automation Cards

Upgrade each automation card to show more useful information at a glance:

**Active automations** should feel alive:
- Green left border
- Show: name, trigger type badge, "Active since Feb 20"
- Stats: "247 sent · 38% open rate · Last sent 2 hours ago"
- Actions: [Pause] [View History] [Edit] [···]

**Paused automations** should feel paused:
- Orange left border, slightly muted appearance
- Show: name, trigger type badge, "Paused on Feb 19"
- Stats: "124 sent before pausing · 41% open rate"
- Actions: [Resume] [View History] [Edit] [···]

**Draft automations** should feel like work in progress:
- Gray left border
- Show: name, trigger type badge, "Draft · Last edited 3 hours ago"
- Completeness indicator: "Trigger configured ✓ · Email content ✓ · Not yet activated"
- Actions: [Continue Editing] [Delete] [···]

### Click to View Detail

Clicking an automation card (not an action button) should open a detail view or expand the card to show:
- Full trigger configuration (which events, which anniversary years, etc.)
- Subject line and first few lines of email body
- Send history summary (sends per day chart if enough data, or a simple list of recent sends)
- For A/B tests (Part 2 of the previous prompt): variant comparison stats

### "View History" Page

The history page for an automation shows a table of all sends:

| Recipient | Trigger | Sent At | Status | Opened | Clicked |
|-----------|---------|---------|--------|--------|---------|

With pagination and a search/filter by status. Reuse the `DataTable` component from `client/src/components/shared/DataTable.tsx`.

---

## PART 7: EDIT EXISTING AUTOMATIONS

When clicking "Edit" on an automation card:
- Navigate to `/smartsends/automations/:id/edit`
- Load the existing campaign data from `GET /api/triggered-campaigns/:id` (you may need to add this endpoint if it doesn't exist — it should return the campaign by ID)
- Pre-fill all wizard steps with the existing data
- The wizard works identically to create mode but saves via `PATCH` instead of `POST`
- **Active campaigns must be paused before editing.** If the user clicks Edit on an active campaign, show a confirmation: "This automation must be paused before editing. Pause it now?" → [Pause & Edit] [Cancel]

---

## VERIFICATION CHECKLIST

- [ ] "New Automation" navigates to full-page wizard (not a dialog)
- [ ] Stepper shows all steps with active/completed/future styling matching SendEmail
- [ ] Trigger selection shows 6 cards with icons and descriptions
- [ ] Selecting a trigger shows trigger-specific configuration below
- [ ] Event triggers show event picker for scope selection (all vs. specific)
- [ ] Anniversary trigger shows year checkboxes with member count estimate
- [ ] Compose step uses ReactQuill rich text editor (not plain textarea)
- [ ] "Insert Event" button opens the event picker dialog and inserts formatted blocks
- [ ] Merge field badges are clickable and insert at cursor
- [ ] Preview step shows email in full branded template (logo, footer, styling)
- [ ] Preview replaces merge fields with example data
- [ ] Drip sequence shows step builder with per-step email editing
- [ ] Settings step shows summary, send window, auto-stop date
- [ ] "Activate" shows confirmation dialog before starting
- [ ] Automation list cards show status-appropriate styling (green/orange/gray borders)
- [ ] Active cards show live stats (sent count, open rate, last sent)
- [ ] Clicking "Edit" on a draft navigates to the edit wizard with pre-filled data
- [ ] Clicking "Edit" on an active campaign prompts to pause first
- [ ] View History shows paginated send table
- [ ] Scheduled Series: trigger card appears in selection grid
- [ ] Scheduled Series: shows audience selector and date-based step builder
- [ ] Scheduled Series: step builder uses date pickers (not day delays)
- [ ] Scheduled Series: dates must be future and chronological (validation)
- [ ] Scheduled Series: preview shows tabs for each email in the series
- [ ] Scheduled Series: activation confirmation shows send dates
- [ ] Scheduled Series: processor sends correct step on matching date
- [ ] Scheduled Series: audience is resolved fresh at send time (not enrolled)
- [ ] Existing Send Email flow is completely unchanged
- [ ] Existing trigger evaluators in the processor are unchanged

---

## PART 8: BACKEND — SCHEDULED SERIES PROCESSOR

The triggered campaign processor needs a small addition to handle `scheduled_series` campaigns. This is the one backend change in this prompt.

### Add to `triggeredCampaignProcessor.ts`

**1. Add `scheduled_series` to the `evaluateTrigger` switch:**

```typescript
case 'scheduled_series':
  return evaluateScheduledSeries(campaign);
```

**2. Add the evaluator function:**

```typescript
async function evaluateScheduledSeries(campaign: any): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const audienceId = config.audienceId;
  
  if (!audienceId) {
    console.warn(`[TRIGGERED] Scheduled series ${campaign.campaignId} has no audienceId`);
    return [];
  }
  
  // Get the steps for this campaign
  const steps = await db.select()
    .from(triggeredCampaignSteps)
    .where(eq(triggeredCampaignSteps.campaignId, campaign.campaignId))
    .orderBy(triggeredCampaignSteps.stepNumber);
  
  // Find a step whose sendDate matches today
  const today = new Date().toISOString().split('T')[0]; // "2026-03-01"
  const todayStep = steps.find(step => {
    const stepConfig = (step as any).triggerConfig || {};
    // sendDate could be stored in the step's own config or we can use a convention
    // Since triggered_campaign_steps doesn't have a triggerConfig column,
    // store the date in the step_name as a convention: "2026-03-01" prefix,
    // OR better: use a dedicated send_date column. See migration below.
    return step.sendDate === today;
  });
  
  if (!todayStep) return []; // No step scheduled for today
  
  // Check if this step has already been processed (use step number as trigger reference)
  // The deduplication in processQualifyingMember will handle per-member dedup,
  // but we should check if any sends exist for this step at all to avoid re-resolving audience
  const existingSends = await db.select({ sendId: triggeredCampaignSends.sendId })
    .from(triggeredCampaignSends)
    .where(and(
      eq(triggeredCampaignSends.campaignId, campaign.campaignId),
      eq(triggeredCampaignSends.triggerReference, `series_email_${todayStep.stepNumber}`)
    ))
    .limit(1);
  
  if (existingSends.length > 0) return []; // Already processed this step today
  
  // Resolve the audience fresh
  const { getAudienceMembers } = require('./aiAudienceService');
  const audienceData = await getAudienceMembers(audienceId, { previewOnly: false });
  
  return (audienceData.members || [])
    .filter((m: any) => m.MemberEmail)
    .map((m: any) => ({
      memberKey: m.MemberKey,
      memberName: m.MemberFullName || m.MemberKey,
      memberEmail: m.MemberEmail,
      triggerReference: `series_email_${todayStep.stepNumber}`,
      triggerDate: new Date(),
      mergeData: {},
    }));
}
```

**Important:** For scheduled series, the processor uses the **step-level subject and body**, not the campaign-level subject/body. Update `processPendingSends` to check: if the campaign's `triggerType` is `'scheduled_series'`, look up the step matching the `triggerReference` and use that step's subject/body instead of the campaign-level fields.

Add this logic inside `processPendingSends`, right after the subject/body selection:

```typescript
// For scheduled series, use the step-level content instead of campaign-level
if (campaign.triggerType === 'scheduled_series') {
  const stepMatch = send.triggerReference.match(/series_email_(\d+)/);
  if (stepMatch) {
    const stepNumber = parseInt(stepMatch[1]);
    const step = await db.select()
      .from(triggeredCampaignSteps)
      .where(and(
        eq(triggeredCampaignSteps.campaignId, campaign.campaignId),
        eq(triggeredCampaignSteps.stepNumber, stepNumber)
      ))
      .limit(1);
    if (step.length > 0) {
      subject = step[0].subjectLine;
      body = step[0].emailBody;
    }
  }
}
```

### Database Addition: Add `send_date` column to `triggered_campaign_steps`

Add a nullable column to the existing steps table for calendar-date scheduling:

```sql
ALTER TABLE triggered_campaign_steps ADD COLUMN IF NOT EXISTS send_date DATE;
```

Add to the Drizzle schema in `shared/schema.ts`:
```typescript
// In the triggeredCampaignSteps definition, add:
sendDate: text("send_date"),  // ISO date string "2026-03-01" — used by scheduled_series
```

For drip sequences, `send_date` is null (they use `delay_days`). For scheduled series, `delay_days` is 0 and `send_date` has the target date.

### Update Steps CRUD Endpoints

In routes.ts, update the POST and PATCH endpoints for steps to accept and store `sendDate`:

```typescript
// In POST /api/triggered-campaigns/:id/steps:
const { stepNumber, stepName, delayDays, subjectLine, emailBody, sendCondition, sendDate } = req.body;
// Include sendDate in the insert

// In PATCH /api/triggered-campaigns/:id/steps/:stepId:
const { stepName, delayDays, subjectLine, emailBody, sendCondition, sendDate } = req.body;
// Include sendDate in the update
```

### Add Trigger Type Badge Color

In the Automations list, add a badge color for the new type:
- Scheduled Series → teal badge

---

## FILES CHANGED

**New files:**
- `client/src/pages/CreateAutomation.tsx` — Full-page wizard for create/edit automations
- (Optional) `client/src/components/automations/TriggerSelector.tsx` — Trigger card selection component
- (Optional) `client/src/components/automations/DripStepBuilder.tsx` — Drip sequence step builder
- (Optional) `client/src/components/automations/ScheduledSeriesBuilder.tsx` — Scheduled series step builder with date pickers
- (Optional) `client/src/pages/AutomationDetail.tsx` — Automation detail/history page

**Modified files:**
- `client/src/App.tsx` — Add routes for `/smartsends/automations/new` and `/smartsends/automations/:id/edit`
- `client/src/pages/SmartSends.tsx` — "New Automation" button navigates to new page instead of opening dialog; remove the old create dialog
- `server/routes.ts` — Add `GET /api/triggered-campaigns/:id` endpoint if not already present; add anniversary count estimate endpoint; update steps CRUD to handle `sendDate`
- `server/services/triggeredCampaignProcessor.ts` — Add `scheduled_series` case to `evaluateTrigger` switch; add `evaluateScheduledSeries` function; add step-level content lookup in `processPendingSends` for scheduled series
- `shared/schema.ts` — Add `sendDate` column to `triggeredCampaignSteps`; add `scheduled_series` to trigger type comments

**NOT modified (do not touch):**
- `client/src/pages/SendEmail.tsx` — Leave completely unchanged
- `server/services/emailService.ts` — Leave completely unchanged
- Existing trigger evaluators (event_registration, event_reminder, event_followup, membership_anniversary, production_milestone, drip_sequence) — Leave unchanged

---

## COMPONENTS TO REUSE FROM SENDMAIL

For reference, here are the specific patterns and components from `SendEmail.tsx` to reuse:

1. **Stepper UI** — Lines 2037-2065 of SendEmail.tsx (the step buttons with icons, active/completed states, arrow separators)
2. **ReactQuill editor** — Import and Quill module config from lines 69-70, 188, 464 of SendEmail.tsx
3. **Event picker dialog** — Lines 3549-3650 of SendEmail.tsx (the full dialog with search, type filter, event cards with badges)
4. **insertEventBlock function** — Lines 1479-1528 of SendEmail.tsx (generates formatted HTML event block and inserts into Quill)
5. **getEmailPreviewHtml function** — Lines 1886-1956 of SendEmail.tsx (wraps email body in Mainstreet branded template with logo, footer)
6. **UpcomingEvent interface** — Lines 156-177 of SendEmail.tsx
7. **Upcoming events query** — Line 498 of SendEmail.tsx (`/api/upcoming-events` endpoint)

# MemberSync — Project Summary
## March 6, 2026 (Evening — Comprehensive)

This document is the authoritative state-of-the-project as of end of day March 6, 2026. Use this to resume work in any new conversation. All prior summaries are superseded by this one for current state.

---

## TABLE OF CONTENTS

1. Project Overview & Vision
2. Build Philosophy & Team Structure
3. Client Pipeline
4. Complete Feature Inventory (What Has Been Built)
5. Campaign Architect — Full Design & Status
6. This Session's Accomplishments
7. Prompt Queue — Current Status
8. AEI Demo Path (March 23–27, Minneapolis)
9. Known Issues & Technical Debt
10. Strategic Decisions & Market Positioning
11. AI Cost Model
12. Multi-Tenant Architecture Roadmap
13. Strategic Roadmap
14. All Architectural Decisions (Canonical List)
15. Standing Rules (Canonical List)
16. Key Files Reference
17. Parking Lot Summary

---

## 1. PROJECT OVERVIEW & VISION

**MemberSync** is a member engagement and retention SaaS platform built by Membio for real estate associations and MLSs (Multiple Listing Services). It analyzes MLS listing data and AMS (Association Management System) data to help executives understand, engage, and retain members through AI-powered insights, smart email campaigns, member recognition, lapse prevention, and engagement scoring.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**Product philosophy:** "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

**The lightsaber:** Organized real estate is in an existential fight for survival. MLSs are going non-Realtor, removing the last transactional justification for association membership. Competing associations actively recruit members with special offers. Associations have been fighting for survival with spreadsheets and gut instinct. MemberSync is the lightsaber — real, specific, actionable intelligence about their own members AND the competitive environment those members operate in.

**The 75/12 Rule:** ~75% of association and MLS members produce ~12% of real estate transaction volume, yet pay ~75% of dues and fee revenue. These Foundation members are the financial backbone of every association and MLS. Most organizations ignore them. MemberSync exists to serve and celebrate them. The product design target is the 99% of members who don't sit on committees — not the 1% who do.

**Member tiers (display names, always positive):**
- **Rainmaker** — 40+ sides/year (~1.4% of Mainstreet membership)
- **Builder** — 6–39 sides/year (~21%)
- **Foundation** — 0–5 sides/year (~77%)

Internal code names: `active_producer`, `occasional_producer`, `license_maintainer`. Never shown to users.

---

## 2. BUILD PHILOSOPHY & TEAM STRUCTURE

**Two-track development model:**

- **Track 1 (Tracy + Claude + Replit):** Prototype feature development for sales demos and product vision. Fast and iterative. Mainstreet REALTORS® is the prototype client.
- **Track 2 (Dev team + Claude Code):** Production platform with proper multi-tenant architecture from day one. Ports validated Track 1 modules using Claude-written developer specs. New repository — not a refactor of Replit code.

**Division of labor:**
- Tracy + Claude: product vision, feature decisions, architectural direction, Replit prompts, developer specs ("what" and "why")
- Dev team: production readiness, implementation, testing, deployment, operations ("how")

**Handoff artifacts:**
- `CLAUDE.md` — Product bible in repo root (v2, 786 lines). Primary orientation document for dev team and Claude Code instances.
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog (project knowledge)
- Developer-facing specs per feature (written by Claude, reviewed by Tracy)

**Claude's role:** CTO, product visionary, AI architecture expert, strategic sparring partner. Pressure-tests every feature against multi-tenant scale and technical debt before speccing. Surfaces architectural risks proactively. Holds the full product picture across conversations. Flags proactively when conversation is long and a project summary is needed before starting a new major spec.

**Tools:**
- Claude — strategy, architecture, Replit prompts, developer specs
- Julius.AI — SQL development and data validation against production database
- Replit Agent — prototype implementation (Track 1)
- Claude Code — production implementation (Track 2)
- SendGrid — email delivery; webhook matching uses `campaign_id + member_key`
- AWS — production database hosting
- PostgreSQL — primary database; separate AMS and MLS schemas
- React + Node.js — frontend and backend stack

---

## 3. CLIENT PIPELINE

| Client | Members | Status |
|--------|---------|--------|
| Mainstreet REALTORS® | 18,275 | First client. Prototype on Replit. **NOT in production.** AEI demo target. |
| HGAR (Hudson Gateway) | 12,800 | Onboarding. First true multi-tenant requirement. New York compliance rules. |
| GRAR (Greater Rochester) | 3,400 | Follows HGAR. New York compliance. |
| CRMLS | 103,000+ | Major pilot prospect. CMO engaged. $2,500/mo × 90 days, full credit toward annual. **Requires SOC 2.** |

**Important:** Mainstreet is NOT live. They want to use MemberSync but the prototype is still too rough. The production platform (Track 2) is what they will actually use.

**Market sizing:** TAM ~332 associations plus MLSs. SAM ~200. SOM 100. Long-term expansion beyond real estate is Tracy's vision — build architecture to support it, don't design for it yet.

---

## 4. COMPLETE FEATURE INVENTORY (WHAT HAS BEEN BUILT)

### Dashboard
- Association Pulse cards (Total Active Members, Connection Status, Campaign Effectiveness)
- Activity Feed (real-time member activity)
- Member Recognition sidebar
- Mainstreet Community tier section with donut charts (Foundation/Builder/Rainmaker distribution)
- Daily membership snapshot accumulating (foundation for future trend visualization)

### AI Chat
- Natural language → SQL via `aiQueryService.ts`
- Julius-style analytical responses (tables, insights, follow-up suggestions)
- Schema modularization (large schema split for performance)
- SQL retry loop (self-healing on first failure)
- Cross-domain query support (AMS + MLS data in one query)
- Geographic context for Mainstreet service area (Chicago suburbs)

### Member & Office Profiles
- Member detail pages with engagement score breakdown and connection label
- Office detail pages with agent rosters
- Open/click timestamp display on Member Detail email history ("Opened: Mar 3 at 2:14 PM (+2 more)")
- Member headshot sync from AMS/MLS
- Office visit brief PDF generation

### Engagement Scoring
- Tier-aware scoring (Foundation member who attends class + pays dues = 10/10, even with 0 transactions)
- Connection labels (Highly Connected, Connected, Developing, At Risk)
- All scoring signals client-configurable via tenant_config (weights, tier thresholds)
- 100% Coverage Test enforced: signals covering <10% of membership are not scoring inputs

### SmartSends — Campaign Creation
- AI-powered campaign creation (audience builder, email generation)
- Manual campaign creation
- Template-based creation
- Immediate send and scheduled send
- Draft management
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail pages with full performance data
- Open/click timestamp tracking on `email_recipients`

### SmartSends — Audience Building
- AI audience builder (natural language → SQL → audience)
- Picklist builder (manual member selection)
- Member/Bill Type builder (AMS-based segmentation)
- CSV upload
- Saved audiences with count, preview, type labels

### SmartSends — Email Safety
- Email queue safety infrastructure (per-member throttle, queue export/flush, sandbox mode)
- Email Governor: weekly/daily caps per member, Lane 1 (exempt) / Lane 2 (governed) categorization
- Email categories: recognition, engagement, automation, transactional, compliance, critical
- Governor status badge on SmartSends dashboard
- Email Controls tab with governor config and priority queue

### SmartSends — Recognition
- Recognition Queue: AI-generated member recognition emails held for staff review before sending
- Staff can edit, create new, dismiss, or approve & send from the queue
- Recognition emails are always Lane 1 — exempt from governor (human already reviewed)
- Campaign names: "Recognition: [milestone_label] — [Month Year]"
- Sent history tab in Recognition Queue

### SmartSends — Email Health
- Email Health Dashboard with three tabs: Performance, Send Queue, Email Archive
- Unsubscribe rate, deliverability, open rate, click rate by category and over time
- HTML storage for all sent emails (object storage; `rendered_html_url` on campaigns)
- Email Archive: searchable history with performance highlights and HTML preview
- AI Duplicate Detection: similarity check at Preview step using Haiku (70% threshold)
- Archive-Aware AI Composition: recent email context injected into generation prompt
- Recent Sends reference panel in composer

### SmartSends — Image Library
- Required metadata at upload: name, category, alt text, tags
- Server-side optimization via Sharp (max 1200px, compressed; one optimized file + thumbnail)
- Insert size picker (Small/Medium/Full Width)
- Five categories: Event Banner, Headshot, Logo, Illustration, Other (+ Notifications, portal-gated)
- Category-specific upload guidance with recommended dimensions and soft ratio warnings
- Grid/List view toggle (localStorage persistence)
- Inline edit (no modal)
- Delete/archive/versioning rules: never-used → delete; used in recent campaigns → archive only; upload new version → new record, auto-archive old, preserve historical references
- `status`, `superseded_by`, `archived_at` columns on `email_images`

### Automations (Triggered Campaigns)
- Full automation engine with 7 trigger types: event_registration, event_reminder, event_followup, membership_anniversary, production_milestone, drip_sequence, and one additional
- Full-page Automations wizard UX
- Send window enforcement (no emails before 8 AM or after 5 PM local time)
- Weekend/weekday controls
- Per-automation send history

### Analytics
- Analytics overview page
- Office leaderboards
- Agent leaderboards
- Compliance tracking

### Campaign Architect (see Section 5 for full design)
- Prompt 1 (conversation + planning) — built and verified
- Prompt 2 (generation + editing + A/B + activation) — built and verified
- Polish prompt (audience redesign, anchor date editor, safety rules, events context) — built and verified
- Hardening prompt (audience cleanup, negative delayDays fix, rate limiting) — **written today, ready to send**

---

## 5. CAMPAIGN ARCHITECT — FULL DESIGN & STATUS

### The Problem It Solves
The old drip sequence builder was the paradigm everyone hates — blank canvases, node graphs, step wizards that require you to already know what good looks like. It was too similar to tools that make experienced marketers want to "poke their eyes out." It was replaced entirely.

### The Design
**Entry point:** "Create Automation" → for drip_sequence type → single conversational prompt: *"What do you want this campaign to accomplish?"*

**The AI flow:**
1. Diagnoses the goal — identifies audience, desired outcome, natural timeline
2. Recommends complete campaign structure with reasoning shown live in a right-side panel
3. Staff approves or adjusts the structure
4. AI writes all emails using real member data, tier context, and existing email composer
5. AI suggests one A/B test (subject line variant) — staff approves or skips
6. Activate

**The UI (vertical sequence, no canvas):**
```
📧 Email 1 — Day 0          [Edit] [Preview]
   Subject: Something's coming this spring...
   To: 4,120 Foundation members

⏱ Wait 7 days

📧 Email 2 — Day 7          [Edit] [Preview]
   Subject: What your peers are saying about CE classes
   A/B: Testing subject line variant

⏱ Wait 11 days

📧 Email 3 — Day 18         [Edit] [Preview]
   Subject: One class. Spring forward.

[Activate Campaign]
```

**Audience section:** Expandable inline tabs — Saved audiences, Member/Bill Type builder, Picklist builder. Conversational AI auto-builds and selects audience when criteria are clear. Fallback: yellow inline message to select manually.

**Anchor date editor:** Click any "Day X" indicator on any email card to open inline timing editor. Three options: day offset from enrollment, anchored to event (with before/after offset), specific calendar date.

**A/B testing:** AI proposes one test per campaign, never multiple. Staff approves or skips. After test: "Subject line A won — 34% open rate vs 21%."

**Session persistence:** Planning sessions saved to `campaign_architect_sessions` table. Accessible from Automations center. Status: draft → generating → editing → active → completed/archived.

**Safety rules baked in:**
- No fabricated member testimonials, invented names, fake quotes, or fictional statistics — embedded in every email generation call
- Selected events only — generated emails reference only events explicitly selected by staff, never hallucinated ones

### What's Built
- **Prompt 1** (conversation, AI planning, session persistence, audience picker, event multi-select): ✅ Built and verified
- **Prompt 2** (email generation, sequence editing, A/B suggestion, activation): ✅ Built and verified
- **Polish prompt** (audience section redesign with inline tabs, anchor date editor on any card, testimonial safety rule, events context passed to generation): ✅ Built and verified
- **Hardening prompt** (audience accumulation cleanup, negative delayDays architectural fix, rate limiting on generate-from-criteria): 📝 Written today — **ready to send to Replit**

### Hardening Prompt Summary (3 fixes)
1. **Audience accumulation:** Nightly cleanup job deletes auto-generated Campaign Architect audiences older than 7 days if never used in an activated campaign. 24-hour dedup prevents same criteria creating duplicate audiences. "AI Generated" badge in saved audiences list.
2. **Negative delayDays fix:** Replaces ambiguous negative delayDays with explicit `anchorOffset` (always positive) + `anchorDirection` ('before'/'after') fields. Server-side validation rejects negative delayDays. Activation logic uses new fields for correct send date math. AI planner updated to never output negative delayDays.
3. **Rate limiting:** 5 calls/minute/session on generate-from-criteria endpoint. In-memory Map with cleanup interval. 429 degrades gracefully to existing yellow inline message.

### Prompt 3 (Post-AEI)
- Full sequence analytics: roll-up stats, per-email breakdown, member journey table

---

## 6. THIS SESSION'S ACCOMPLISHMENTS (MARCH 6, EVENING)

1. **Confirmed Parts 1–4 of Prompt A (Recognition Queue + Email Governor backend) complete** — Replit's self-review resolved the two real issues; three minor items deferred to parking lot.

2. **Reviewed Replit's implementation plan for Campaign Architect Polish prompt** — approved with no changes. Confirmed compact prop question (MemberBillTypeBuilder and PicklistBuilder need compact prop — Replit to add). Confirmed anchor event name should store as display label not event ID.

3. **Campaign Architect Polish prompt ran and completed** — all five improvements implemented and verified.

4. **Replit's post-implementation notes reviewed** — five items assessed:
   - Item 1 (two AI calls for audience): acceptable with existing graceful degradation
   - Item 2 (audience accumulation): fix now
   - Item 3 (negative delayDays): fix now — architectural risk
   - Item 4 (heavy embedded components): cosmetic, defer to post-AEI polish
   - Item 5 (no rate limiting): fix now — production risk at CRMLS scale

5. **Campaign Architect Hardening prompt written** — three focused fixes. File: `MemberSync_CampaignArchitect_Hardening.md`

6. **Strategic discussion: competitive intelligence** — Tracy articulated that MemberSync must help association/MLS executives look outward, not just inward. Associations compete for members with neighboring organizations. MLSs face non-Realtor access threats. The product must surface competitive territory patterns, member drift signals, and retention intelligence framed against competitive alternatives. "MemberSync is the lightsaber." Full design captured in Parking Lot.

7. **Project summary written** — this document.

---

## 7. PROMPT QUEUE — CURRENT STATUS

### Ready to Send Now
1. **Campaign Architect Hardening** (`MemberSync_CampaignArchitect_Hardening.md`) — three production fixes. Send immediately. ⭐

### Written, Send After Hardening Verified
2. **Prompt C — AI Duplicate Detection + Archive-Aware Composition** (`MemberSync_PromptC_AIDuplicateDetection.md`) — depends on Email Health Dashboard (Prompt B) being live. Verify Prompt B is working before sending this.

### On Hold (Intentionally)
- **A/B Testing standalone prompt** — superseded entirely by Campaign Architect (A/B is built into it)
- **Automation Priority + Global Contact Limit** — waiting for full stability

### Upcoming (To Write)
- **CLAUDE.md revision** — add tenant_config fields section, Campaign Architect architecture, Email Health, Image Library, Recognition Queue. Schedule after AEI.
- **Campaign Architect Prompt 3** — sequence analytics. After AEI.
- **Proactive AI Engagement Engine** — top post-AEI Track 1 priority
- **Lapse Prevention System** — second post-AEI priority

---

## 8. AEI DEMO PATH (MARCH 23–27, MINNEAPOLIS)

**Audience:** MLS executives and technical leaders at an industry conference.
**Time until show:** ~17 days from today.

**Demo sequence (in order of impact):**

1. **AI Chat — "The second brain moment"**
   - Query: "Show me agents in Downers Grove who closed in January with licenses expiring this year"
   - What it shows: instant cross-domain intelligence nobody else can surface
   - 2 minutes

2. **Campaign Architect — "The cancel HubSpot moment"**
   - Show competitor node canvas: "This is what everyone else asks you to do"
   - Type one goal sentence: "I want Foundation members who haven't taken a class to know about our spring CE lineup"
   - Watch AI propose complete campaign with reasoning
   - Show emails already written
   - Show one A/B suggestion — click approve
   - Activate
   - 3 minutes

3. **Member Recognition — "The personal touch at scale moment"**
   - Show the recognition queue
   - Show AI-generated personal email with real member data (name, transaction history, milestone)
   - Show review/approve flow
   - 1–2 minutes

4. **Dashboard — "The 75/12 moment"**
   - Show Association Pulse with tier distribution
   - The insight: 75% of members pay 75% of dues and produce 12% of volume
   - "MemberSync serves the people who keep the lights on"
   - 1 minute

**Total target: ~8 minutes. Tight, stable, no freestyle.**

**Before demo path is locked:**
- [ ] Send and verify Campaign Architect Hardening prompt
- [ ] End-to-end run-through of full demo sequence at least once
- [ ] Verify all demo data is real Mainstreet data, no fake anything
- [ ] Confirm AI Chat cross-domain query ("Downers Grove agents, January close, license expiring this year") returns real results
- [ ] Verify Recognition Queue has real pending items or can be seeded with real member data

---

## 9. KNOWN ISSUES & TECHNICAL DEBT

### Must Fix Before Demo
- None currently blocking — pending verification of Hardening prompt

### Monitor Closely
- **Anchor date timing (negative delayDays)** — being fixed in Hardening prompt. Test manually: activate a campaign with "3 days before [event]", verify send date is correct.
- **Open/click badges on Member Detail** — visually unconfirmed (no live emails with engagement data yet). Will resolve once real emails are sent.

### Low Risk / Acceptable for Demo
- **Email Health metrics show 0%** in sandbox mode — correct behavior. Note for demo context: "these populate when live."
- **Heavy embedded components in Campaign Architect audience panel** — functional, cosmetically heavy. Post-AEI polish.

### Parking Lot (Deferred — No Demo Risk)
- Date range picker in Email Archive UI (backend supports it, frontend doesn't yet)
- Async image optimization (Sharp is synchronous — fine for single uploads, revisit at bulk upload scale)
- CDN-proof image URL tracking in `trackImageUsageInHtml`
- Governor PATCH backend cap validation (1–10 daily, 1–21 weekly ranges)
- Configurable exempt categories in governor (currently hardcoded)
- Recognition Queue dedicated count endpoint (currently fetches full list to count)
- Drip Sequence step editor needs proper EmailComposer per step (Campaign Architect has this — the old step editor doesn't)
- Templates system rework (past campaigns as templates, smart suggestions)
- Revenue data uses catalog prices not actual invoiced amounts
- 172-member count gap (dashboard vs. member type builder)

---

## 10. STRATEGIC DECISIONS & MARKET POSITIONING

### The 95%/5% Strategy
- **Design for the 95%:** Associations and MLSs where one person runs email marketing with no expertise. Time-starved executives. Zero tolerance for configuration complexity. The easy button is the strategy.
- **Pursue the 5% as lighthouse clients:** Large sophisticated orgs (CRMLS is the prime example). Their logos and their data scale create credibility. They don't adopt because of better tools — they adopt because of dedicated headcount + MemberSync's intelligence layer.
- **Product principle:** If it requires expertise to use, it's not for our market.

### Competitive Intelligence as a Core Product Capability
Associations and MLSs are not just fighting to retain members — they're fighting against competing organizations who are actively recruiting their members. MemberSync must help executives look outward, not just inward.

**What this means for the product:**
- AI Chat must answer questions like "Which agents near our territorial borders are joining competing associations?" and "What patterns appear in members who left us in the last 18 months?"
- Lapse prevention system needs competitive framing — not just "this member might lapse" but "this member's pattern looks like members we've lost to [competitor] before"
- Member value articulation: "Your Foundation members who take CE classes have 73% retention vs 41% for those who don't — your education program is your strongest competitive moat"
- Executive dashboard needs an outward-facing section, not just internal analytics

**Architectural implication:** New query patterns in `aiQueryService.ts` for competitive analysis. Must respect tenant isolation — Client A cannot see Client B's member data, but can see aggregated market patterns and their own members' market activity. Geographic intelligence already added to AI Chat is the foundation. Territory configuration goes in `tenant_config.competitive_territory`.

### AI Learning / Network Effect (Parking Lot)
The 100th association on MemberSync should get a smarter AI than the first. Campaign performance outcomes stored against AI decisions (structure, timing, audience). Cross-client pattern detection ("anniversary emails sent in week 1 of anniversary month get 40% higher open rates across all clients") feeds back into Campaign Architect recommendations.

**Architectural implication:** `ai_campaign_decisions` table. Outcome tracking (open rate, click rate) linked to AI recommendation metadata. Cross-client aggregate learning must respect tenant isolation.

---

## 11. AI COST MODEL

| Feature | Model | Cost/Request (with caching) |
|---------|-------|----------------------------|
| AI Chat queries | claude-sonnet-4-6 | ~$0.026 |
| AI Audience Builder | claude-sonnet-4-6 | ~$0.034 |
| AI Email Generation | claude-sonnet-4-6 | ~$0.048 |
| Duplicate detection | claude-haiku-4-5-20251001 | ~$0.003 |
| Content summaries | claude-haiku-4-5-20251001 | ~$0.003 |
| Image context | claude-haiku-4-5-20251001 | ~$0.003 |
| Campaign planning | claude-sonnet-4-6 | ~$0.048 |

**CRMLS heavy usage estimate:** $600–1,000/month with prompt caching.

**Three-layer cost defense:**
1. Technical guardrails: rate limiting, Haiku for lightweight tasks, response caching for common queries
2. Tiered pricing: base subscription includes X queries/month, overage billed
3. Contract clauses: fair use, annual reconciliation

**Prompt caching:** 90% reduction on AI input costs. High priority before CRMLS pilot. The 37,000-character database schema sent with every AI Chat query is the primary target.

---

## 12. MULTI-TENANT ARCHITECTURE ROADMAP

**Stage 0 (Current — Prototype):** Everything hardcoded for Mainstreet. `clientConfig.ts` holds all values. 110+ hardcoded "MainStreet" references. Illinois-specific compliance rules hardcoded. Mainstreet branding in email templates.

**Stage 1 (HGAR onboarding — next major milestone):**
- New production repository with proper architecture
- `tenant_config` database table — every `clientConfig.ts` value becomes a row keyed by `client_id`
- `client_id` on every table
- All queries filtered by `client_id`
- HGAR gets its own config row
- Illinois compliance rules parameterized for New York

**Stage 2:** Admin provisioning dashboard. Staff provisions new clients without engineering.

**Stage 3:** Self-service onboarding. Only automate steps validated manually with 2–3 real clients first.

**Critical architectural issues in the prototype (must fix in production port):**
- Only 1 of 20+ tables has `client_id`
- 110+ hardcoded "MainStreet" references
- Hardcoded Illinois compliance rules and client branding
- 5,700-line monolithic `routes.ts`
- No database migration system
- Two-database prototype setup (safety workaround — single database in production)

**Port order:** Authentication → Data layer (caches) → Dashboard + profiles → SmartSends → Audiences → AI Chat → Analytics → Automations → Recognition/Celebrations

---

## 13. STRATEGIC ROADMAP

### Immediate (Next Session — Before AEI)
1. **Send Campaign Architect Hardening prompt to Replit and verify** ⭐
2. **Lock AEI demo path** — end-to-end run-through, confirm all four demo moments are stable
3. **Send Prompt C (AI Duplicate Detection)** — after confirming Prompt B (Email Health) is working

### Near-Term (Before AEI, ~17 days)
4. Demo data verification — real Mainstreet data throughout, no fake anything
5. Fix any instabilities surfaced in demo run-through

### Post-AEI (April+)
6. **Proactive AI Engagement Engine** — makes Community Insights cards real. Top Track 1 priority.
7. **AI Chart Rendering** — accelerated for CRMLS pilot. Board-ready charts in AI Chat.
8. **Lapse Prevention System** — calendar-aware risk scoring and automated intervention
9. **CLAUDE.md revision** — add tenant_config fields, Campaign Architect architecture, Email Health, Image Library, Recognition Queue
10. **Prompt Caching** — 90% AI cost reduction before CRMLS scale
11. **Multi-Tenant Stage 1** — new production repo, database-driven config, HGAR onboarding
12. **SOC 2 Type I preparation** — target before CRMLS pilot
13. Campaign Architect Prompt 3 — sequence analytics

### Medium-Term
14. Broker Module
15. Competitive Intelligence Module (outward-facing analytics)
16. Member Preference Center
17. Listing Lifecycle Automations
18. Integration Marketplace (Zendesk, Google Analytics, LMS)
19. Multi-Tenant Stage 2 (admin provisioning)
20. Exportable Charts

### Longer-Term
21. AI Report Generation (board meeting summaries)
22. Self-Service Onboarding (Stage 3)
23. Lapse Pattern Analysis (predictive models)
24. AI Presentation Generation
25. AI Learning / Network Effect Engine

---

## 14. ALL ARCHITECTURAL DECISIONS (CANONICAL LIST)

- `member_metrics_cache` is single source of truth for member data
- `apmmember.MemberStatus = 'Active'` is canonical definition of active member
- Two-step query pattern is a WORKAROUND to eliminate in production (not a design pattern)
- Production = single database — two-DB setup is prototype safety measure only
- Cache-first at scale — pre-compute rather than calculate on demand
- Payment is table stakes (1 point max) — not a primary engagement signal
- Transactions are baseline — not how members connect with their organization
- All scoring signals must be client-configurable via tenant_config
- 100% Coverage Test — if <10% of membership covered, it's a vanity metric, not a scoring input
- Custom signals accepted through Membio team only — not self-service
- Compliance module is association-only — hidden for MLS clients (not just empty)
- CE hours, designations, COE, Fair Housing are association-specific signals
- Non-CE event attendance is a stronger engagement signal than CE attendance
- Office suspension is the gatekeeper for MLS/Mainstreet Advantage access
- Every module gated by tenant_config — disabled modules don't render, run jobs, or consume AI budget
- Split large Replit prompts — Replit performs better with focused, scoped units
- "Recognition" is the user-facing term everywhere — "Celebration" stays in code only
- Email category must be set on every campaign record — no null categories
- Governor exemptions: transactional, compliance, critical, recognition
- Campaign Architect replaces drip sequence builder entirely — no parallel UI
- AI suggestions must always be actionable (yes/no) — never configuration forms
- Object storage for binary assets (email HTML, images) — database holds metadata and URLs only
- Images are immutable once in use — use_count > 0 means archive, not delete (for recent campaigns)
- HTML archive starts empty — no backfill of historical campaigns
- Content summaries generated at send time and stored — AI comparisons use summaries, not full HTML
- No fake data in previews ever — real member data or clearly labeled sample data only
- SQL retry loop for query engine — self-healing beats dead ends
- "Attempt first, ask second" for AI queries
- Campaign Architect: `delayDays` is zero-or-positive only — event-relative timing uses `anchorOffset` + `anchorDirection`
- Auto-generated Campaign Architect audiences cleaned up after 7 days if unused
- Competitive intelligence queries must respect tenant isolation
- Billing codes are dynamic and never reused — pattern-based recognition only, no hardcoded lists
- Spike detection required for AMS registration/revenue data (bulk NAR imports distort metrics)
- AI Chat should not surface follow-up questions it cannot execute
- Two-track model: Tracy + Claude decide "what" and "why"; dev team owns "how"
- Port approach: new repo, module-by-module porting of proven logic — not rewrite, not refactor

---

## 15. STANDING RULES (CANONICAL LIST)

1. No parallel systems — extend existing components, never build duplicate implementations
2. Don't break what works — verify before and after every change
3. Full-page patterns, not modals, for multi-step tasks
4. Shared components over duplicates
5. Server-side for anything touching more than 1,000 records
6. Test your work — happy path and at least one edge case before reporting complete
7. "Recognition" in UI everywhere — "Celebration" in code only
8. Email category must be set on every campaign record — no null categories
9. Governor exemptions are: transactional, compliance, critical, recognition
10. Campaign Architect replaces drip sequence builder — no parallel UI
11. AI suggestions are always actionable (yes/no) — never configuration forms
12. Competitive intelligence queries must respect tenant isolation — no cross-client data leakage
13. No fake data. Ever. Real member data or clearly labeled sample data only.
14. Every module gated by tenant_config — disabled = not rendered, no background jobs, no AI budget
15. The 5% rule — build what clients asked for or dreamed about, not what sounds good in a roadmap
16. Mobile-first, performance-always — responsive UI, under 2 seconds load time
17. CLAUDE.md is the single source of truth for the production repository
18. Every scoring signal must pass the 100% Coverage Test before inclusion
19. Claude flags proactively when conversation is long and a project summary is needed before starting a new major spec
20. Complete prompts sequentially — do not batch all changes and deploy simultaneously
21. Spec-first development — Claude writes detailed prompts with verification steps; dev team implements

---

## 16. KEY FILES REFERENCE

### Project Knowledge (Canonical — Always Current)
- `CLAUDE.md` — Product bible for production repository (v2, 786 lines). **Must be revised after AEI** to add tenant_config fields, Campaign Architect architecture, Email Health, Image Library, Recognition Queue.
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog (last updated March 6, 2026 afternoon)

### Today's New File
- `MemberSync_CampaignArchitect_Hardening.md` — Three production fixes. **Ready to send to Replit.**

### Campaign Architect Prompts (All in Project Knowledge)
- `MemberSync_CampaignArchitect_Prompt1.md` — Conversation, planning, session persistence ✅ Deployed
- `MemberSync_CampaignArchitect_Prompt2.md` — Generation, editing, A/B, activation ✅ Deployed
- `MemberSync_CampaignArchitect_Polish_Prompt.md` — Five polish improvements ✅ Deployed
- `MemberSync_CampaignArchitect_Hardening.md` — Three production fixes 📝 Ready to send

### Previously Deployed Prompts (Project Knowledge)
- `MemberSync_SchemaModularization_Prompt.md` ✅
- `MemberSync_AIChat_JuliusUpgrade_Prompt.md` ✅
- `MemberSync_QueryEngine_RetryAndCrossDomain.md` ✅
- `MemberSync_PromptA_RecognitionQueue_EmailGovernor.md` ✅ (Parts 1–8)
- `MemberSync_PromptB_EmailHealth_ImageLibrary.md` ✅
- `MemberSync_ImageLibrary_Upgrade_Prompt.md` ✅

### Written, Not Yet Sent
- `MemberSync_PromptC_AIDuplicateDetection.md` — Send after Prompt B verified working

### Planning Documents
- `MemberSync_Development_Plan.docx` — Two-track model, team roles, port timeline
- `Membio_AI_Workflow_Playbook.docx` — How each team member uses Claude/Claude Code
- `MemberSync_CRMLS_Scaling_Roadmap.docx` — CRMLS pilot architecture and pricing

### Backend Services (Key Files in Codebase)
- `emailService.ts` — Email sending, queue processing, campaign management, governor
- `triggeredCampaignProcessor.ts` — Automation engine (**DO NOT BREAK**)
- `aiCampaignPlannerService.ts` — Campaign Architect AI planning
- `imageService.ts` — Image upload, optimization, metadata, usage tracking
- `aiEmailService.ts` — AI email composition with archive-aware context
- `aiQueryService.ts` — Natural language → SQL (AI Chat)
- `memberMetricsCacheService.ts` — Daily cache refresh with tier-aware scoring
- `milestoneDetectionService.ts` — Recognition/milestone detection

### Frontend Pages (Key Files in Codebase)
- `CampaignArchitect.tsx` — Campaign Architect full UI
- `SmartSends.tsx` — SmartSends dashboard with governor badge
- `SendEmail.tsx` — Email composition wizard (~201K, largest file)
- `RecognitionQueue.tsx` — Recognition Queue review interface
- `SmartSendsImages.tsx` — Image Library
- `MemberDetail.tsx` — Member detail with open/click timestamps
- `CreateAutomation.tsx` — Automation wizard (drip_sequence path replaced by Campaign Architect)

---

## 17. PARKING LOT SUMMARY

Full detail in `MemberSync_Parking_Lot.md`. Key items:

**Section 1 — Features to Build (Prioritized):**
1. Campaign Architect Prompt 3 (sequence analytics) — after AEI
2. Proactive AI Engagement Engine — top post-AEI priority
3. Lapse Prevention System — second post-AEI priority
4. AI Chart Rendering — accelerated for CRMLS pilot
5. AI Learning / Network Effect Engine
6. Broker Module
7. Lapse Pattern Analysis
8. Competitive Intelligence Module ⭐ new this session
9. Member Preference Center
10. Listing Lifecycle Automations
11. Automations Polish Round 2
12. AI Report Generation
13. Compliance Section Redesign
14. A/B Testing (built into Campaign Architect — standalone prompt superseded)

**Section 2 — Technical Debt:** Date range picker (archive), async image optimization, CDN-proof URL tracking, governor cap validation, configurable exempt categories, Recognition Queue count endpoint, drip step editor, templates rework, revenue data fix, 172-member count gap.

**Section 3 — Infrastructure:** SOC 2, Prompt Caching, Batch Email Sending, Multi-Tenant Stages 2–3, Integration Marketplace, Query Engine Phase 2.

**Section 4 — Must Configure Per Client (tenant_config):** 18 items identified including scoring weights, compliance rules, billing calendar, geographic context, competitive territory, available data sources, default visualizations, and more. **This section must be incorporated into the next CLAUDE.md revision.**

---

*Document created: March 6, 2026, end of session.*
*Next session should start with: (1) Send Campaign Architect Hardening prompt to Replit, (2) verify it passes all acceptance criteria, (3) lock AEI demo path.*

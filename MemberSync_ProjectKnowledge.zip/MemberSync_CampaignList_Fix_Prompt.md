# MemberSync — Fix SmartSends Campaign List (75K Automation Campaigns)

## Date: February 24, 2026
## Priority: Send now — Dashboard is broken for demo tomorrow

---

## REPLIT STANDING RULES

**These rules apply to this prompt and ALL future prompts for this project. Treat them as permanent.**

### Rule 1: No Parallel Systems
Before building any new UI component, service, or utility function, search the existing codebase for similar functionality. If a component already exists that does 70% or more of what's needed, extend or adapt it with configuration flags rather than creating a new version. Never build a parallel implementation of something that already works. If you are unsure whether to reuse or rebuild, stop and ask before proceeding.

### Rule 2: Don't Break What Works
Before modifying any existing file, understand what it currently does. Run the app and verify the feature works before changing it. After your changes, verify the feature still works. If a prompt asks you to add something new, the existing functionality must continue to work exactly as it did before.

### Rule 3: Full-Page Patterns, Not Modals
This application uses full-page wizard flows for multi-step tasks (Send Email, Create Automation). Do not introduce modal dialogs for tasks that involve more than a single confirmation or a simple input.

### Rule 4: Shared Components Over Duplicates
If two features need similar UI, they must use the same shared component configured with props or flags — not two separate implementations.

### Rule 5: Server-Side for Scale
Any operation that could involve more than 1,000 records must happen on the server, not the client.

### Rule 6: Test Your Work
After implementing changes, verify them yourself before marking complete. Check both the happy path and at least one edge case.

---

## ROOT CAUSE

The automation processor creates one `email_campaigns` row per triggered send (one per member). This produced 75,317 campaign rows. Both SmartSends endpoints (`/api/smartsends/campaigns` and `/api/smartsends/unified-campaigns`) fetch all campaigns and then loop through each one calling `getCampaignStats()` individually — which runs 2 queries per campaign. That's ~150,000 database queries per page load. The dashboard times out and shows nothing.

---

## T001: Exclude Automation-Generated Campaigns from SmartSends Dashboard

**This is the critical fix. Implement and verify this works BEFORE starting T002 or T003.** If T001 alone fixes the page load time, T002 and T003 become polish rather than emergency fixes.

**What to do:**

The SmartSends dashboard should show only manual and scheduled campaigns — not the thousands of individual sends created by automations. Automation send history belongs on the Automations page under "View History" for each automation, not in the main campaign list.

In `/api/smartsends/unified-campaigns` (routes.ts ~line 6514): Add a WHERE filter to exclude campaigns that have a matching `triggered_campaign_sends` row:

```sql
AND NOT EXISTS (
  SELECT 1 FROM triggered_campaign_sends tcs 
  WHERE tcs.email_campaign_id = ec.campaign_id
)
```

In `/api/smartsends/campaigns` (routes.ts ~line 4713): Add the same exclusion filter.

This immediately drops the result set from 75K+ to a manageable number (likely under 100 manual campaigns).

**IMPORTANT:** Also apply this filter to the stats cards at the top of the SmartSends dashboard (Campaigns count, Emails Sent, Open Rate, Click Rate). These stats should reflect manual and scheduled campaigns only — not automation sends. If the stats queries pull from the same endpoints, the filter will apply automatically. If they use separate queries, add the same `NOT EXISTS` filter there too.

**Verify:** After deploying T001, load the SmartSends Dashboard in the browser. The page should load in under 2 seconds, the campaign list should show only manual/scheduled campaigns, and the stats cards should show reasonable numbers (not 75,000+ campaigns).

**Files:** `server/routes.ts`

---

## T002: Move Pagination to SQL Level in unified-campaigns

**Blocked by:** T001 must be deployed and verified first.

Currently the endpoint fetches ALL sent campaigns, ALL drafts, ALL scheduled, puts them in an array, sorts in JavaScript, then slices for pagination. After T001 reduces the set this is less critical, but it should still be fixed for correctness — as campaign volume grows over months, this will become slow again.

**What to do:**

For the `sent` campaigns query: Apply SQL `LIMIT` and `OFFSET` directly, and get a separate `COUNT(*)` for the total. Do not fetch all rows and slice in JavaScript.

For drafts and scheduled: These are small sets (currently under 10), so in-memory handling is fine. No change needed.

When the `type` filter is `'sent'`, only query sent campaigns with SQL-level pagination — don't fetch drafts and scheduled at all.

**Files:** `server/routes.ts`

**Verify:** Pagination controls work correctly. Switching between "All", "Sent", "Scheduled", "Drafts" tabs returns correct results. Page 2 shows different campaigns than page 1.

---

## T003: Batch getCampaignStats into a Single Query

**Blocked by:** T001 must be deployed and verified first.

Replace the N+1 `getCampaignStats()` loop with a single bulk query. The current pattern — calling `getCampaignStats()` inside a for loop for each campaign — is a textbook N+1 performance problem. Even with T001 reducing the set, this matters as campaign volume grows and is also needed for campaign detail pages and analytics.

**What to do:**

Add a new function `getBulkCampaignStats(campaignIds: string[])` in `server/services/emailService.ts`:

```typescript
async function getBulkCampaignStats(campaignIds: string[]): Promise<Map<string, CampaignStats>> {
  if (campaignIds.length === 0) return new Map();

  // One query for recipient status counts
  const recipientStats = await db.execute(sql`
    SELECT campaign_id, status, COUNT(*)::int AS count
    FROM email_recipients 
    WHERE campaign_id = ANY(${campaignIds})
    GROUP BY campaign_id, status
  `);

  // One query for event counts (opens, clicks, bounces, etc.)
  const eventStats = await db.execute(sql`
    SELECT campaign_id, event_type, COUNT(DISTINCT member_key)::int AS count
    FROM email_events 
    WHERE campaign_id = ANY(${campaignIds})
    GROUP BY campaign_id, event_type
  `);

  // Build a Map<campaignId, stats> from the two result sets
  // ... (aggregate into the same shape getCampaignStats returns)
}
```

**IMPORTANT:** This is a new shared function alongside the existing `getCampaignStats()`. Do NOT remove `getCampaignStats()` — it's still used by the campaign detail page for single-campaign lookups. Follow Standing Rule 1: the bulk version extends the capability, it doesn't replace the single version.

Update both `/api/smartsends/campaigns` and `/api/smartsends/unified-campaigns` to:
1. Collect all campaign IDs from the query results
2. Call `getBulkCampaignStats(campaignIds)` once
3. Look up each campaign's stats from the returned Map

**Files:** `server/services/emailService.ts`, `server/routes.ts`

**Verify:** Both endpoints return stats (sent, delivered, opened, clicked, bounced counts) for each campaign. Stats match what `getCampaignStats()` would return for any individual campaign. Both endpoints respond in under 500ms.

---

## FUTURE ARCHITECTURE NOTE (Do NOT implement now)

The root cause of this problem is that the automation processor calls `queueEmailCampaign()` once per member, creating one `email_campaigns` row per person. The long-term fix is for triggered sends to either batch members into a single campaign per automation run (like manual sends do) or bypass `email_campaigns` entirely and log directly to `triggered_campaign_sends`. That refactor prevents 75,000 campaign rows from being created in the first place. This is a separate future prompt — do not attempt it now.

---

## VERIFICATION CHECKLIST

### T001 (verify before starting T002/T003)
- [ ] SmartSends Dashboard loads in under 2 seconds
- [ ] Campaign list shows only manual and scheduled campaigns
- [ ] No automation-generated "[Triggered]" campaigns appear in the list
- [ ] Stats cards (Campaigns, Emails Sent, Open Rate, Click Rate) show numbers for manual/scheduled campaigns only
- [ ] Campaign type filter tabs (All, Sent, Scheduled, Drafts) all work correctly
- [ ] Clicking a campaign still navigates to its detail page
- [ ] Automation send history is still visible on the Automations page (View History)

### T002
- [ ] Pagination works at SQL level (not fetch-all-then-slice)
- [ ] Total count is accurate for each filter tab
- [ ] Page 2 shows different campaigns than page 1
- [ ] Changing page size works correctly
- [ ] Empty states display correctly when no campaigns match the filter

### T003
- [ ] `getBulkCampaignStats()` function exists in emailService.ts
- [ ] Original `getCampaignStats()` still exists and works (used by campaign detail page)
- [ ] Both dashboard endpoints use the bulk function
- [ ] Stats (sent, delivered, opened, clicked, bounced) are accurate for each campaign
- [ ] Both endpoints respond in under 500ms with current data volume

---

## FILES TO MODIFY

- `server/routes.ts` — Add NOT EXISTS filter to both campaign endpoints (T001), SQL-level pagination (T002), use bulk stats (T003)
- `server/services/emailService.ts` — Add `getBulkCampaignStats()` function (T003)

## FILES NOT MODIFIED (do not touch)

- `server/services/triggeredCampaignProcessor.ts` — No changes
- `server/services/scheduledEmailProcessor.ts` — No changes
- `client/src/pages/SmartSends.tsx` — No changes (the frontend pagination and display already work — the problem is entirely backend)
- `client/src/pages/SendEmail.tsx` — No changes
- `client/src/pages/CampaignDetail.tsx` — No changes (still uses single getCampaignStats)

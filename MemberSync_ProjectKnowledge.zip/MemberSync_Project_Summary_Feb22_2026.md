# MemberSync / SmartSends — Project Summary
## February 22, 2026

This document captures all decisions, architecture, prompts, and current state through February 22, 2026. Use this to resume work in a new conversation.

---

## TABLE OF CONTENTS

1. Project Overview
2. Client Pipeline and Membership Context
3. Technical Architecture
4. What Has Been Built (Complete)
5. What Was Accomplished Feb 21–22, 2026
6. Current Database Schema (Key Tables)
7. Production Database Schema (Read-Only)
8. Daily Jobs Schedule
9. AI Services Architecture
10. Engagement Scoring System
11. Dashboard Architecture
12. SmartSends Current State
13. Triggered Campaigns / Automations Current State
14. Prompts Ready for Replit (Not Yet Built)
15. Known Issues Still Open
16. CRMLS Pilot Program
17. AI Cost Model and Pricing Strategy
18. Security & Data Protection Roadmap
19. Multi-Tenant Architecture Roadmap
20. Strategic Roadmap (Updated)
21. Key Architectural Decisions
22. Key Files Reference
23. Production Data Reference

---

# 1. PROJECT OVERVIEW

## What We Are Building

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs. SmartSends is the email marketing and automation layer within MemberSync. The platform uses predictive analytics to help MLS and association executives retain and engage members by analyzing residential real estate listings and association management system (AMS) data.

The product vision: MemberSync should be the organization's **second brain** — the system that is always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

## Product Model

MemberSync is a **SaaS product** — not a custom build for any single client. Every feature should work for any association or MLS through configuration, not custom code. The long-term goal is self-service onboarding: a new organization signs up with a credit card, connects their API keys, and goes.

## Build Philosophy

Tracy (founder of Membio) is a non-technical business leader with 30+ years in proptech, building exclusively with AI tools:
- **Claude** for strategy, specifications, and Replit prompts
- **Julius.AI** for SQL development against the production database
- **Replit Agent** for all coding implementation

Tracy maintains creative control over product design and UX decisions. The development team hardens for production (error handling, edge cases, performance). Tracy builds the first 80% through prototyping; the team does the production-ready 20%.

## Product Philosophy: Celebrating Connection Over Compliance

The core insight: 75% of association members produce only 12% of real estate volume, yet pay 75% of dues revenue. MemberSync exists to help associations prove their value to all members by measuring and improving engagement with the organization itself. All member tiers are framed positively. We celebrate connection, not police compliance.

---

# 2. CLIENT PIPELINE AND MEMBERSHIP CONTEXT

## Three-Client Growth Trajectory

| | Client | Members | Cumulative | Status |
|---|---|---|---|---|
| Client 1 | Mainstreet REALTORS® (suburban Chicago) | 18,275 | 18,275 | **Live** — production-proven |
| Client 2 | Hudson Gateway Association of REALTORS® (New York) | 12,800 | 31,075 | **Preparing to onboard** |
| Client 3 | CRMLS | 103,000+ | 134,000+ | **Pilot proposed** — CMO has expressed strong interest |

Additional clients have already expressed interest beyond these three. Multi-tenant architecture is essential regardless of whether CRMLS proceeds.

## Mainstreet REALTORS® (Client 1) Detail

**Members:** ~18,275 active
**Offices:** ~2,800
**Current email volume:** ~300,000 emails/month (existing, pre-MemberSync)
**Member Tiers (by 12-month transaction sides):**
- Foundation (0–5 sides): 14,144 agents (77%)
- Builder (6–39 sides): 3,885 agents (21%)
- Rainmaker (40+ sides): 247 agents (1.4%)

**Key Insight:** Top 25% of agents control 88% of volume; 40% of agents have zero transactions.

---

# 3. TECHNICAL ARCHITECTURE

- **Frontend:** React with Tailwind CSS, shadcn/ui components
- **Backend:** Node.js / Express
- **Database:** PostgreSQL (local via Drizzle ORM + read-only external AWS production DB via `externalPool`)
- **Hosting:** Replit (application) + AWS (production database)
- **Email:** SendGrid — Membio is an established SendGrid channel partner with dedicated IP experience across existing property search products
- **AI:** Anthropic Claude API (Sonnet 4 for email generation, audience building, data queries)
- **ORM:** Drizzle
- **Infrastructure:** Membio is an existing AWS shop. Production database and supporting infrastructure run on AWS. Scaling to dedicated cloud hosting is an extension of existing infrastructure, not a platform migration.

---

# 4. WHAT HAS BEEN BUILT (COMPLETE)

- Full dashboard with AI Chat, Pulse cards, Activity Feed, Member Recognition, Mainstreet Community
- Tier-aware engagement scoring system
- Member detail pages with engagement breakdown
- Office detail pages with agent rosters
- SmartSends email campaign creation (AI + manual + template)
- Audience building (AI builder, picklist, member/bill type, CSV upload)
- Saved audiences with preview and count
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail pages
- Triggered campaigns / Automations engine with 7 trigger types
- Automations UX upgrade (full-page wizard)
- Email analytics overview
- Office visit brief PDF generation
- Compliance tracking
- Image library for emails
- Draft management
- Scheduled email sending

---

# 5. WHAT WAS ACCOMPLISHED FEBRUARY 21–22, 2026

## Feb 21: SmartSends Automations & Bug Fixes

### Prompts Delivered to Replit (Being Implemented)

**1. SmartSends Automations UX Upgrade** (`SmartSends_Automations_UX_Upgrade.md`)
Full-page wizard replacing the basic dialog for creating/editing automations. Matches the Send Email wizard pattern: Configure Trigger → Compose Email → Preview → Settings & Activate. Includes:
- 7 trigger type cards (Event Registration, Event Reminder, Post-Event Follow-up, Membership Anniversary, Production Milestone, Drip Sequence, **Scheduled Series**)
- Trigger-specific configuration UI for each type
- Drip sequence step builder with per-step email editing
- **Scheduled Series** — new trigger type for fixed-date multi-email campaigns
- Automation list cards with status-aware styling
- View History page for automation sends

**2. SmartSends Bug Fixes and Composer Polish** (`SmartSends_BugFixes_ComposerPolish.md`)
Sent to Replit; first pass completed. Tracy is testing. Known remaining issue: **No Audience Preview on Settings & Activate step** — needs to be trigger-type-aware (see Known Issues). Full bug list pending completion of Tracy's testing.

**3. SmartSends Email Composer Enhancements** (`SmartSends_EmailComposer_Enhancements.md`)
Superseded by Bug Fixes prompt which covers all items.

## Feb 22: Scaling Strategy, CRMLS Pilot, Security & Multi-Tenancy

### Documents Produced

**1. MemberSync CRMLS Scaling Roadmap** (`MemberSync_CRMLS_Scaling_Roadmap.docx`)
Comprehensive document covering:
- Three-client growth trajectory (Mainstreet → HGAR → CRMLS)
- Scale comparison across all three clients (members, offices, email volume, concurrent users, AI queries)
- What already works at scale (cache-first architecture, tier-aware scoring, client config, shared AI schema, existing AWS infrastructure)
- What needs hardening (database performance, email sending at volume, triggered campaign processor, multi-tenancy, hosting)
- Complete AI cost analysis with per-feature cost breakdowns
- Three CRMLS usage scenarios (conservative/moderate/heavy) with and without prompt caching
- AI cost control playbook (technical guardrails, pricing model, contract guardrails)
- Recommended pricing structure ($4,500–$6,000/month, 70–80% gross margins)
- Security & data protection roadmap (SOC 2, DPAs, AI-specific protections, pen testing)
- Multi-tenant architecture stages (manual onboarding → admin-assisted → self-service)
- Risk assessment with severity and mitigation
- 11–15 week implementation timeline

**2. MemberSync CRMLS Pilot Proposal** (`MemberSync_CRMLS_Pilot_Proposal.docx`)
Client-facing pilot proposal covering:
- 90-day pilot structure in three phases (Setup/Onboarding, Active Usage, Evaluation)
- Seven deliverables including **AI-generated charts and reports** (accelerated from roadmap to pilot)
- Minimum usage commitments from CRMLS (login frequency, AI queries, campaigns, automations, chart usage)
- Success criteria defined upfront (staff adoption, campaign engagement, AI utilization, satisfaction scores)
- Pilot pricing: $2,500/month × 3 months = $7,500, with full credit toward Year 1 contract
- Mutual commitments from both Membio and CRMLS
- Conversion terms: pilot fees credit toward annual contract; walk-away with no obligation if criteria not met
- Proposed timeline with specific milestones through Week 14

### Key Decisions Made Feb 22

1. **AI Chart rendering accelerated to pilot deliverable:** Instead of waiting for post-launch roadmap, inline chart rendering (AI Intelligence Stage 2) and chart download (Stage 3) will be built for the CRMLS pilot. This is the feature that creates operational dependency — a CEO who gets a board-ready chart in 10 seconds never gives it up. Estimated effort: 3–5 Replit prompts.

2. **Three-client narrative is the sales story:** Client 1 (Mainstreet) proves product-market fit, Client 2 (HGAR) proves replication, Client 3 (CRMLS) proves enterprise scale. Future clients see proven momentum, not a startup experiment.

3. **HGAR at 12,800 members makes CRMLS a 3.3x scale-up, not 5.6x:** With two clients serving ~31,000 members, CRMLS represents a manageable growth step rather than a leap into the unknown.

4. **Paid pilot with credit-toward-contract:** $2,500/month for 90 days, credited against Year 1 if they convert. Ensures CRMLS has skin in the game without double-paying. If pilot fails, they walk at $7,500.

5. **Pilot requires mutual commitments:** CRMLS must designate a pilot lead, commit 5–10 staff, meet minimum usage targets, and attend midpoint and final reviews. Without client participation commitments, pilots die from neglect.

6. **SOC 2 certification should begin now:** Most required controls (access management, encryption, logging) are already in place. Target SOC 2 Type I before CRMLS pilot launches. Type II (requires 3–6 months of operational evidence) follows. This is a competitive differentiator since most association tech vendors lack formal certifications.

7. **Multi-tenant architecture is essential regardless of CRMLS:** Additional clients have expressed interest. Every feature built from now on should be evaluated through the lens of "will this work when Client 4 shows up?"

8. **Audience preview on Settings & Activate must be trigger-type-aware:** Production milestones can show current qualifying members. Anniversaries show upcoming in next 30 days. Event-based triggers show historical context or current registrant counts. Drip sequences and scheduled series show the defined audience directly.

---

# 6–11. [UNCHANGED FROM FEB 20 SUMMARY]

Refer to the Feb 20 project summary for these sections — no changes to database schema, production schema, daily jobs, AI services, engagement scoring, or dashboard architecture.

---

# 12. SMARTSENDS CURRENT STATE

## What's Built and Working
- Campaign creation with AI-composed or manual email body
- Three method cards: Use a Template, Generate with AI, Create from Scratch
- Audience selection (AI-built, picklist, member/bill type, CSV)
- Inline audience creation during composition
- Immediate send and scheduled send
- Campaign tracking (delivered, opened, clicked, bounced)
- Campaign detail page with aggregate stats
- Analytics overview with office leaderboards
- PDF generation for office visit briefs
- Saved audiences with count and preview
- Email templates
- Draft management
- Image library

## What's Built But Has Issues (Fixes in Progress)
- Send button fails with 413 for large audiences (fix: server-side resolution — in Bug Fixes prompt)
- AI generation fails in automations with key_points error (fix: normalize input — in Bug Fixes prompt)
- Insert Offer and Insert Button exist in automations but not Send Email
- Resend Campaign uses modal instead of full wizard
- Next button disabled after member type audience save
- AI-generated events are plain text, not styled cards
- **No Audience Preview on Settings & Activate step** (discovered during testing Feb 21–22; fix not yet written)

---

# 13. TRIGGERED CAMPAIGNS / AUTOMATIONS CURRENT STATE

## What's Built
- Triggered campaign processor running every 15 minutes
- 6 active trigger types: event_registration, event_reminder, event_followup, membership_anniversary, production_milestone, drip_sequence
- 7th type (scheduled_series) spec'd and in UX Upgrade prompt
- Full-page wizard for create/edit (Configure Trigger → Compose → Preview → Settings & Activate)
- Trigger-specific configuration UI for each type
- Drip sequence step builder with per-step editing
- Automation list with status sections (Active, Paused, Drafts, Archived)
- Send window configuration (start/end time, weekday toggle)
- Auto-stop date
- Deduplication to prevent repeat sends
- Anniversary trigger verified working (14 sends processed)

## What's Prompt-Ready But Not Built
- **Scheduled Series** trigger type (in UX Upgrade prompt)
- **A/B Testing** for triggered campaigns (`SmartSends_ABTesting_Part2.md`)
- Method card + AI field consolidation on one page
- Milestone radio buttons (single select)
- Trigger summary on Settings & Activate step

## Key Architecture
- `triggered_campaigns` table: campaign config, trigger type, status
- `triggered_campaign_steps` table: multi-step campaigns (drip, scheduled series)
- `triggered_campaign_sends` table: per-member send records with dedup
- Processor: `triggeredCampaignProcessor.ts` — evaluates triggers, queues sends, processes pending
- Each trigger type has its own evaluator function
- `triggerReference` field prevents duplicate sends
- `campaignVersion` integer field (1 and 2) supports future A/B testing

---

# 14. PROMPTS READY FOR REPLIT (NOT YET BUILT)

**Priority order:**

1. **Bug Fixes Round 2** (NOT YET WRITTEN) — Tracy is testing the first Bug Fixes pass. Will collect all remaining issues into one comprehensive prompt. Includes audience preview on Settings & Activate step (trigger-type-aware). WAIT FOR TRACY'S FULL BUG LIST.

2. **A/B Testing for Triggered Campaigns** (`SmartSends_ABTesting_Part2.md`) — A/B split on subject line and body, automatic winner selection, variant performance tracking. Depends on triggered campaigns working cleanly.

3. **Automations Polish Round 2** (NOT YET WRITTEN) — Delete automation capability, audience visibility/estimated reach on trigger config, automation-specific analytics, event override priority system.

4. **AI Chart Rendering** (NOT YET WRITTEN — ACCELERATED FOR CRMLS PILOT) — AI Chat detects when results should be charts, renders Recharts inline, download-as-image button. See AI Data Intelligence Roadmap Stages 2–3. Estimated 3–5 Replit prompts.

---

# 15. KNOWN ISSUES STILL OPEN

### Critical (Blocking)
- 413 error on large audience sends (fix in Bug Fixes prompt — may be resolved in first pass)
- key_points.map error in automations AI generation (fix in Bug Fixes prompt — may be resolved in first pass)
- Next button disabled after member type audience save (fix in Bug Fixes prompt — may be resolved in first pass)

### Important
- **No Audience Preview on Settings & Activate step** (discovered Feb 21–22; needs trigger-type-aware implementation)
- Insert Offer / Insert Button missing from Send Email compose step
- Resend Campaign modal should route to full wizard
- AI-generated events are plain text (no styled cards, no portal URLs)
- No per-recipient engagement data on Campaign Detail page
- No open/click badges on Member Detail email history
- Milestone trigger allows multi-select (should be single-select radio)

### Lower Priority
- The 172-member gap (dashboard vs. member type builder count)
- AI Query Service sometimes generates wrong SQL
- Cache health monitoring (no admin visibility into cron job status)
- Email engagement data cold start
- Revenue data uses catalog prices, not actual invoiced amounts

### Tracy Testing in Progress
Tracy is testing the Bug Fixes first pass on the automations builder. Additional issues may be discovered. All will be collected into one clean Bug Fixes Round 2 prompt.

---

# 16. CRMLS PILOT PROGRAM

## Pilot Structure
- **Duration:** 90 days, three phases
- **Phase 1 (Weeks 1–2):** Setup, data connection, configuration, training
- **Phase 2 (Weeks 3–10):** Active usage with minimum commitment targets
- **Phase 3 (Weeks 11–12):** Evaluation, results report, go/no-go decision
- **Pilot subset:** One CRMLS region or member segment (10,000–20,000 subscribers)

## Pilot Deliverables
1. Full MemberSync dashboard configured for CRMLS
2. AI Chat with **inline chart rendering and download** (accelerated from roadmap)
3. SmartSends email campaigns (up to 50,000 emails/month)
4. Automations engine with all 7 trigger types
5. Engagement scoring across all member tiers
6. Office visit PDF profiles
7. Weekly support and midpoint review

## Success Criteria (Agreed Before Pilot Starts)
- 80%+ of pilot team active weekly by Week 8
- Email open rates ≥20%, click rates ≥3%
- 50+ AI queries/week sustained for 4+ weeks
- AI charts used in 2+ board/executive reports
- Staff satisfaction ≥4.0/5.0
- 99.5%+ platform uptime

## Pricing
- $2,500/month × 3 months = $7,500 total
- Full credit toward Year 1 contract if pilot converts
- Walk away with no obligation if success criteria not met

## Key Pilot Principle
Both sides must have commitments. CRMLS designates a pilot lead, assigns 5–10 staff, meets usage targets, and attends reviews. Without client participation, pilots die from neglect.

---

# 17. AI COST MODEL AND PRICING STRATEGY

## Current Model: Claude Sonnet 4
- Input tokens: $3.00 per million tokens
- Output tokens: $15.00 per million tokens
- Cached input: $0.30 per million tokens (90% savings)

## Per-Feature Cost Estimates

| Feature | Input Tokens | Output Tokens | Cost/Request | With Caching |
|---|---|---|---|---|
| AI Chat Query | ~12,000 | ~1,500 | $0.059 | ~$0.026 |
| AI Audience Builder | ~14,000 | ~2,000 | $0.072 | ~$0.034 |
| AI Email Generation | ~4,000 | ~3,000 | $0.057 | ~$0.048 |
| AI Email Refinement | ~5,000 | ~3,000 | $0.060 | ~$0.048 |

**Key cost driver:** The shared database schema (`sharedDatabaseSchema.ts`) is ~37,000 characters (~10,000 tokens) sent with every AI Chat and Audience Builder request. Prompt caching reduces this by 90%.

## CRMLS Monthly Cost Scenarios (With Prompt Caching)
- **Conservative** (5–10 staff): $80–150/month
- **Moderate** (15–25 staff): $250–400/month
- **Heavy** (30+ staff, trainers): $600–1,000/month

## AI Cost Control Playbook

**Technical guardrails:**
- Prompt caching for database schema (90% input cost reduction)
- Response caching for common queries (eliminates 20–40% of calls)
- Per-user rate limiting (~30 queries/hour)
- Model routing: Haiku ($1/$5) for simple lookups, Sonnet for complex work
- Spend alerts at 50%, 75%, 90% of monthly budget

**Pricing model options:**
- Tiered subscription (base queries included, overage billed)
- Per-seat AI access ($25–50/seat/month)
- All-inclusive premium (flat fee covering heavy use)

**Contract guardrails:**
- Fair use clause for AI features
- Annual reconciliation if costs deviate from projections
- Pilot pricing: fixed with renegotiation at full deployment

## Recommended CRMLS Full-Deployment Pricing
- Platform base (103K members): $3,500–5,000/month
- AI features included up to 5,000 queries/month
- Additional AI seats at $35/seat
- Email sending included (pass-through at cost)
- **Total: $4,500–6,000/month, 70–80% gross margins**

---

# 18. SECURITY & DATA PROTECTION ROADMAP

## What's Already in Place
- JWT authentication with httpOnly cookies, bcrypt password hashing
- Role-based access control (admin/staff/readonly)
- Session expiration and account lockout
- AWS infrastructure with encryption at rest and in transit
- Read-only access to production database (MemberSync cannot modify source AMS/MLS data)
- Existing Membio PII handling experience across property search products

## What Needs to Be Added

**SOC 2 Compliance:**
- Begin Type I preparation now (many controls already in place)
- Target Type I before CRMLS pilot
- Type II (3–6 months of operational evidence) follows
- Use compliance automation platform to accelerate

**Data Processing Agreements:**
- Formal DPA for each client defining data access, storage, retention, breach notification
- Standard SaaS practice but critical at this scale

**AI-Specific Protections:**
- Anthropic API does not train on data sent via API (document for clients)
- Minimize PII in prompts (use member keys/aggregates where possible)
- Audit logging for all AI queries (who, what, when)
- US-only inference routing available for data residency requirements

**Additional Measures:**
- Penetration testing before CRMLS deployment
- Access audit trail (who viewed which member, sent which campaign)
- Incident response plan
- Automated vulnerability scanning in CI/CD pipeline
- Encryption: TLS in transit, AES-256 at rest

**Security as sales advantage:** Most association tech vendors lack formal certifications. SOC 2 + AWS infrastructure + PII handling experience = genuine competitive differentiator.

---

# 19. MULTI-TENANT ARCHITECTURE ROADMAP

## Current State
`clientConfig.ts` centralizes all client-specific values (branding, tier thresholds, scoring weights, URLs, compliance rules). Pattern is established; needs promotion to database-driven system.

## Stage 1: Manual Onboarding, Automated Isolation (HGAR Target — 3–4 weeks)
- Promote clientConfig.ts to `tenant_config` database table keyed by client ID
- Add `client_id` to every database table (campaigns, audiences, automations, templates, users)
- Filter every query by client_id
- Separate SendGrid sender identities per client with dedicated IPs
- Client-specific branding loaded from tenant_config
- Separate AI prompt context per client

## Stage 2: Admin-Assisted Provisioning (CRMLS Target — 4–6 weeks after Stage 1)
- Internal admin dashboard for creating new tenants
- Automated cache table creation and initial data sync
- Template library for new client onboarding
- Per-client user management and role assignment
- Per-client usage monitoring (AI queries, email volume, storage)

## Stage 3: Self-Service Onboarding (Growth Target — 8–12 weeks after Stage 2)
- Public signup flow with plan selection and payment processing
- Guided onboarding wizard (connect data → configure tiers → set branding → invite team)
- Automated data connector for supported AMS platforms
- Automatic SendGrid sub-user provisioning with IP warm-up
- Self-service billing portal with usage dashboards
- Integration marketplace (Zendesk, Google Analytics, LMS)

**Critical principle:** Every feature built today must be evaluated through the lens of "will this work when Client 4 shows up?" The Stage 1 decisions (client IDs on every table, branding from config, per-tenant AI prompts) determine whether Stage 3 is a natural evolution or a painful rewrite.

---

# 20. STRATEGIC ROADMAP (UPDATED)

## Immediate (In Progress)
1. **Bug Fixes Round 2** — Collect Tracy's full testing results, write one comprehensive prompt
2. **Scheduled Series trigger** — Fixed-date campaign sequences
3. **A/B Testing** — Variant testing for triggered campaigns

## Near-Term (Pilot Preparation)
4. **AI Chart Rendering** — Inline charts in AI Chat + download as image (ACCELERATED for CRMLS pilot)
5. **Prompt Caching Implementation** — 90% reduction on AI input costs (high impact, low effort)
6. **Multi-Tenant Stage 1** — Database-driven tenant config for HGAR onboarding
7. **Batch Email Sending** — Rate-limited queue for Mainstreet's 300K/month + CRMLS scale
8. **SOC 2 Type I Preparation** — Compliance automation platform, audit logging, pen testing

## Medium-Term
9. **Automations Polish Round 2** — Delete, audience visibility, analytics, event override
10. **Lapse Prevention System** — Status tracking, risk scoring, intervention management
11. **Multi-Tenant Stage 2** — Admin provisioning dashboard
12. **Broker Module** — Office management dashboards
13. **Exportable Charts** — PDF/PNG export, copy to clipboard

## Longer-Term
14. **AI Report Generation (Stage 4)** — Multi-section board reports from natural language
15. **Self-Service Onboarding (Multi-Tenant Stage 3)** — Credit card signup and GO
16. **Lapse Pattern Analysis** — Predictive models from pre-departure behavior
17. **Integration Marketplace** — Zendesk, Google Analytics, LMS connectors
18. **AI Presentation Generation (Stage 5)** — Slide-ready content from data

---

# 21. KEY ARCHITECTURAL DECISIONS

All decisions from previous summaries remain in effect, plus:

- **Server-side audience resolution for sends:** Large audiences pass audienceId; server resolves recipients. Client never sends 20K+ recipient arrays.
- **Milestone triggers are mutually exclusive:** One automation per milestone type. Radio buttons enforce single selection.
- **Scheduled Series resolves audience fresh at each send date:** Unlike drip (which enrolls at activation), scheduled series queries current audience for each email.
- **UX consistency is non-negotiable:** Both email flows use the same wizard, same components, same tools, same card order.
- **Every email editing path goes through the full wizard:** Resend, duplicate, edit — all route to standard wizard.
- **AI Chart rendering is a pilot deliverable, not a post-launch roadmap item:** Accelerated because it creates operational dependency that closes enterprise deals.
- **Multi-tenant architecture starts now:** Every feature evaluated through "will this work for Client 4?" lens. Stage 1 decisions (client_id on every table, branding from config, per-tenant AI prompts) determine whether Stage 3 is evolution or rewrite.
- **Audience preview on Settings & Activate is trigger-type-aware:** Each trigger type shows the most useful preview (current qualifiers, upcoming anniversaries, historical context, or defined audience).
- **Paid pilots with credit-toward-contract:** Ensures mutual commitment. Free pilots get deprioritized.
- **SOC 2 is a sales advantage, not just compliance:** Most association tech vendors lack formal certifications. Pursue proactively.
- **Prompt caching is the #1 AI cost optimization:** The 37K-character shared database schema sent with every AI call is the largest input cost and is identical every time. Caching it saves 90%.
- **Model routing for cost control:** Haiku ($1/$5 per MTok) for simple queries; Sonnet ($3/$15) for complex analysis and generation.

---

# 22. KEY FILES REFERENCE

### Prompts in Progress
- `SmartSends_BugFixes_ComposerPolish.md` — Bug fixes + UX consistency (SENT TO REPLIT — FIRST PASS DONE, TRACY TESTING)
- `SmartSends_Automations_UX_Upgrade.md` — Full wizard + Scheduled Series (DEPLOYED/IN PROGRESS)
- `SmartSends_ABTesting_Part2.md` — A/B testing for automations (SEND AFTER BUG FIXES COMPLETE)

### Strategy Documents (Produced Feb 22)
- `MemberSync_CRMLS_Scaling_Roadmap.docx` — Comprehensive scaling, AI cost, security, and multi-tenant roadmap
- `MemberSync_CRMLS_Pilot_Proposal.docx` — 90-day pilot structure, pricing, success criteria, mutual commitments

### Previously Implemented Prompts
- `SmartSends_TriggeredCampaigns_Part1.md` — Automation engine (DEPLOYED)
- `SmartSends_AudienceBuilder_Improvements.md` — Inline creation, Picklist, Member/Bill Type (COMPLETE)
- `MemberSync_Volume_Fix_Replit_Prompt.md` — Double-counting fix (COMPLETE)
- `MemberSync_Consolidated_Fix_Prompt_Feb18_2026.md` — 9-issue fix batch (COMPLETE)
- `MemberSync_Dashboard_Redesign_Prompt.md` — Full dashboard overhaul (COMPLETE)
- `MemberSync_Dashboard_Redesign_Part2.md` — Mainstreet Community section (COMPLETE)
- `MemberSync_Dashboard_Cleanup.md` — Visual polish (COMPLETE)
- `MemberSync_Dashboard_Fixes_Round2.md` — Targeted fixes (COMPLETE)
- `MemberSync_Dashboard_QuickFixes.md` — Height matching, donuts (COMPLETE)
- `MemberSync_Dashboard_CRMLS_Demo.md` — Member Recognition tiles, Discovery cards (COMPLETE)
- `MemberSync_EngagementScore_Redesign_Prompt.md` — Tier-aware scoring (COMPLETE)
- `MemberSync_EngagementScore_Rebalancing_Prompt.md` — Threshold + weight corrections (COMPLETE)
- `MemberDetail_ScoreLabels_and_DashboardConsistency_Fix.md` — Score breakdown fix (COMPLETE)
- `MemberSync_Stability_DataConsistency_Prompt.md` — Atomic cache, staleness detection (COMPLETE)
- `CodeCleanup_DeadCode_and_Fixes.md` — Mock data removal (COMPLETE)
- `SmartSends_EmailComposer_Enhancements.md` — SUPERSEDED by BugFixes prompt

### Backend Services
- `triggeredCampaignProcessor.ts` — Triggered campaign evaluation and send processing
- `storage.ts` — Main data layer, dashboard metrics, member/office queries
- `memberMetricsCacheService.ts` — Daily cache refresh with tier-aware engagement scoring
- `engagementScoreService.ts` — Engagement score calculation logic
- `aiQueryService.ts` — AI SQL generation, query execution, insights
- `aiAudienceService.ts` — Audience CRUD, smart audience execution, enrichment
- `aiEmailService.ts` — AI email composition (generate + refine endpoints)
- `emailService.ts` — Email sending, queue processing, campaign management
- `scheduledEmailProcessor.ts` — Processes scheduled campaigns
- `milestoneDetectionService.ts` — Celebration/milestone detection
- `analyticsProductionCacheService.ts` — Office/agent production analytics
- `activityCacheService.ts` — Activity feed data
- `visitBriefService.ts` — Office visit PDF generation
- `sharedDatabaseSchema.ts` — Database schema documentation for AI services (~37K chars, ~10K tokens)
- `anthropic.ts` — Claude API client (currently Sonnet 4, max_tokens: 2048)

### Frontend — Pages
- `SendEmail.tsx` — Email composition wizard (201K — largest file)
- `CreateAutomation.tsx` — Automation creation wizard
- `SmartSends.tsx` — SmartSends dashboard + automations list
- `AudienceBuilder.tsx` — AI audience builder
- `CampaignDetail.tsx` — Campaign detail with resend capability
- `MemberDetail.tsx` — Member profile with engagement, email history

### Configuration
- `schema.ts` — Drizzle ORM schema (includes triggered_campaigns, triggered_campaign_steps, triggered_campaign_sends tables)
- `routes.ts` — All API endpoints (223K — largest backend file)
- `clientConfig.ts` — Client-specific configuration (to be promoted to tenant_config DB table in multi-tenant Stage 1)

---

# 23. PRODUCTION DATA REFERENCE

From Tracy's Julius analysis of Mainstreet production data:
- Total active agents: 18,275
- Producing agents: 10,895 (59.6%)
- Non-producing: 7,380 (40.4% with zero sides)
- Top 25% (4,569 agents): 87.6% of volume
- Rainmaker (40+ sides): 247 agents (1.4%)
- Builder (6–39 sides): 3,885 agents (21%)
- Foundation (0–5 sides): 14,144 agents (77%)

## The Office Suspension Discovery
For Mainstreet Advantage fees, the **office** gets suspended for non-payment (not individual agents). All agents lose MLS/SentriLock access. This creates broker-level pressure.

---

*End of project summary. This document supersedes all previous project summaries.*

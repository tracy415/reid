# MemberSync — Suppression Architecture: Schema Migration & Hardening (Items 1 & 2)
*Written: March 11, 2026*
*Status: READY TO SEND*

---

## CONTEXT — READ THIS FIRST

The `member_email_preferences` table was designed with `memberKey` as the primary key. This was wrong. The correct suppression key is `emailAddress` — because non-members (CSV uploads, external contacts) have no `memberKey`, and a member who unsubscribes via email address cannot reliably be looked up by `memberKey` alone.

This prompt fixes the foundation. Everything else in the suppression system depends on this being right.

The dev database currently has exactly 3 rows in `member_email_preferences` — all test data. **Delete all three rows before running any migrations.** There is no data to preserve.

Do not modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts` for any reason.

---

## STEP 1 — DELETE TEST DATA

Run this first, before any schema changes:

```sql
DELETE FROM member_email_preferences;
```

Confirm the table is empty before proceeding.

---

## STEP 2 — MIGRATE THE TABLE SCHEMA

The goal: `emailAddress` becomes the primary key. `memberKey` becomes an optional indexed column.

### Raw SQL migration to run against the dev database

```sql
-- Drop the existing primary key constraint
ALTER TABLE member_email_preferences DROP CONSTRAINT member_email_preferences_pkey;

-- Make email_address NOT NULL (required for primary key)
-- We just deleted all rows so there's nothing to conflict
ALTER TABLE member_email_preferences ALTER COLUMN email_address SET NOT NULL;

-- Add email_address as the new primary key
ALTER TABLE member_email_preferences ADD PRIMARY KEY (email_address);

-- Make member_key nullable (it already is, but be explicit)
ALTER TABLE member_email_preferences ALTER COLUMN member_key DROP NOT NULL;

-- Add index on member_key for fast lookups by member
-- Partial index: only index rows where member_key is not null
CREATE INDEX IF NOT EXISTS idx_member_email_prefs_member_key 
  ON member_email_preferences (member_key) 
  WHERE member_key IS NOT NULL;
```

---

## STEP 3 — UPDATE shared/schema.ts

Update the `memberEmailPreferences` table definition to match the new structure exactly:

```typescript
export const memberEmailPreferences = pgTable("member_email_preferences", {
  emailAddress: text("email_address").primaryKey(),
  memberKey: text("member_key"),
  memberName: text("member_name"),
  emailOptOut: boolean("email_opt_out").default(false),
  emailOptOutDate: timestamp("email_opt_out_date"),
  emailOptOutReason: text("email_opt_out_reason"),
  emailConsentDate: timestamp("email_consent_date"),
  emailConsentSource: text("email_consent_source"),
  marketingOptOut: boolean("marketing_opt_out").default(false),
  marketingOptOutDate: timestamp("marketing_opt_out_date"),
  recognitionOptOut: boolean("recognition_opt_out").default(false),
  recognitionOptOutDate: timestamp("recognition_opt_out_date"),
  migrationStatus: text("migration_status"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
```

Key changes from the old definition:
- `emailAddress` is now `.primaryKey()` — not `memberKey`
- `memberKey` is now a plain optional column — no `.primaryKey()`
- Everything else stays the same

Update `insertMemberEmailPreferenceSchema` to omit `createdAt` and `updatedAt` as before. Update the exported type `MemberEmailPreference`. No other schema changes.

---

## STEP 4 — UPDATE emailService.ts

Four changes in this file.

### Change 4a — Fix `canSendToRecipient` suppression lookup

The current query uses `WHERE email_address = X OR member_key = Y`. When `memberKey` is an empty string, the `OR member_key = ''` clause can accidentally match corrupt rows. Fix it to only include the `memberKey` clause when `memberKey` is actually provided:

**Current (wrong):**
```typescript
const prefsResult = await db.execute(sql`
  SELECT * FROM member_email_preferences
  WHERE email_address = ${emailAddress} OR member_key = ${memberKey || ''}
  LIMIT 1
`);
```

**Replace with:**
```typescript
let prefsResult;
if (memberKey) {
  prefsResult = await db.execute(sql`
    SELECT * FROM member_email_preferences
    WHERE email_address = ${emailAddress} OR member_key = ${memberKey}
    LIMIT 1
  `);
} else {
  prefsResult = await db.execute(sql`
    SELECT * FROM member_email_preferences
    WHERE email_address = ${emailAddress}
    LIMIT 1
  `);
}
```

### Change 4b — Fix `canSendToMember` to resolve email before checking

The `canSendToMember` function currently passes an empty string for `emailAddress`. This means it only checks suppression by `memberKey` — it will miss any suppression row that was written by email address (e.g. from a webhook where only the email was known).

**Replace the entire `canSendToMember` function with:**

```typescript
export async function canSendToMember(
  memberKey: string,
  emailCategory: string = 'engagement'
): Promise<{ allowed: boolean; reason?: string }> {
  let emailAddress = '';
  try {
    const resolved = await resolveEmailForMember(memberKey);
    if (resolved) {
      emailAddress = resolved;
    } else {
      console.warn(`[canSendToMember] Could not resolve email for memberKey ${memberKey} — suppression check by memberKey only`);
      suppressionLookupFailureCount++;
    }
  } catch {
    console.warn(`[canSendToMember] resolveEmailForMember threw for memberKey ${memberKey}`);
    suppressionLookupFailureCount++;
  }
  return canSendToRecipient(emailAddress, emailCategory, memberKey);
}
```

### Change 4c — Add suppression health failure counter

Add this near the top of `emailService.ts`, after the imports:

```typescript
// Suppression lookup failure counter — exposed via admin endpoint
let suppressionLookupFailureCount = 0;
let suppressionLookupFailureWindowStart = Date.now();

export function getSuppressionHealthStatus(): { 
  status: 'ok' | 'degraded'; 
  failureCount: number;
  windowStartedAt: string;
} {
  // Reset counter if window is older than 24 hours
  const windowAgeMs = Date.now() - suppressionLookupFailureWindowStart;
  if (windowAgeMs > 24 * 60 * 60 * 1000) {
    suppressionLookupFailureCount = 0;
    suppressionLookupFailureWindowStart = Date.now();
  }
  return {
    status: suppressionLookupFailureCount >= 10 ? 'degraded' : 'ok',
    failureCount: suppressionLookupFailureCount,
    windowStartedAt: new Date(suppressionLookupFailureWindowStart).toISOString(),
  };
}
```

### Change 4d — Fix `queueEmailCampaign` opt-out bulk check

The current bulk opt-out check in `queueEmailCampaign` builds a PostgreSQL array using string interpolation:

```typescript
const emailArray = `{${recipientEmails.map(e => `"${e.replace(/"/g, '\\"')}`).join(',')}}`;
```

This is fragile. Replace with the parameterized array pattern already used elsewhere in the codebase:

```typescript
const optedOutResult = await db.execute(sql`
  SELECT email_address FROM member_email_preferences
  WHERE email_address = ANY(${sql.raw(`ARRAY[${recipientEmails.map((_, i) => `$${i + 1}`).join(',')}]::text[]`)} )
    AND ${categoryFilter}
`);
```

Actually — use Drizzle's `inArray` instead since we now have `emailAddress` as the primary key and can use the ORM properly:

```typescript
const optedOutRows = await db
  .select({ emailAddress: memberEmailPreferences.emailAddress })
  .from(memberEmailPreferences)
  .where(
    and(
      inArray(memberEmailPreferences.emailAddress, recipientEmails),
      emailCategory === 'recognition'
        ? eq(memberEmailPreferences.recognitionOptOut, true)
        : or(
            eq(memberEmailPreferences.emailOptOut, true),
            eq(memberEmailPreferences.marketingOptOut, true)
          )
    )
  );
optedOutEmails = new Set(optedOutRows.map(r => r.emailAddress));
```

Remove the old `categoryFilter` sql template and the `emailArray` string construction entirely.

---

## STEP 5 — FIX THE SENDGRID WEBHOOK HANDLER (routes.ts)

**Important:** There are two unsubscribe handlers in routes.ts. Do not confuse them:
- `GET /unsubscribe` — the member-facing one-click unsubscribe link. **Do not touch this.** It is already correct.
- The SendGrid webhook processor (around line 6188) — `if (eventType === 'unsubscribe' && member_key)`. **This is what needs fixing.**

The webhook handler currently does a SELECT then either UPDATE or INSERT as two separate operations. Two problems:
1. It queries the SELECT by `member_key` — so if the row was created via the email-based path (no memberKey), the SELECT won't find it and will INSERT a duplicate
2. Two simultaneous webhook events for the same member can both see no row and both INSERT, causing a primary key conflict

Replace the entire `if (eventType === 'unsubscribe' && member_key)` block with a proper UPSERT:

```typescript
if (eventType === 'unsubscribe' && email) {
  const now = new Date();
  // Use email from the SendGrid payload directly — most reliable source
  // Fall back to resolving from cache only if email is missing from payload
  const suppressionEmail = email || (member_key ? await resolveEmailForMember(member_key) : null);
  
  if (!suppressionEmail) {
    console.warn(`[SendGrid Webhook] Cannot process unsubscribe — no email address for event`, { member_key, campaign_id });
  } else {
    await db.execute(sql`
      INSERT INTO member_email_preferences (
        email_address, member_key, email_opt_out, email_opt_out_date, 
        email_opt_out_reason, marketing_opt_out, marketing_opt_out_date,
        created_at, updated_at
      )
      VALUES (
        ${suppressionEmail}, ${member_key || null}, true, ${now},
        'Unsubscribed via SendGrid webhook', true, ${now},
        ${now}, ${now}
      )
      ON CONFLICT (email_address) DO UPDATE SET
        email_opt_out = true,
        email_opt_out_date = COALESCE(member_email_preferences.email_opt_out_date, ${now}),
        email_opt_out_reason = 'Unsubscribed via SendGrid webhook',
        marketing_opt_out = true,
        marketing_opt_out_date = COALESCE(member_email_preferences.marketing_opt_out_date, ${now}),
        member_key = COALESCE(member_email_preferences.member_key, ${member_key || null}),
        updated_at = ${now}
    `);
  }
}
```

Key behaviors of this UPSERT:
- **Email from payload is the anchor** — not `member_key`
- **`ON CONFLICT (email_address)`** — no race condition possible
- **`COALESCE` for dates** — preserves the original opt-out date on duplicate events
- **`member_key` backfill** — if we later get an event with a known `member_key` for a previously anonymous row, it fills in
- **Never uses `member_key` as `emailAddress` fallback** — if there's no email, the event is logged and skipped

Also fix the member profile email preferences update endpoint (`PUT /api/members/:memberKey/email-preferences`, around line 5606 in routes.ts). This endpoint currently writes by `memberKey`. It should resolve the email first and use UPSERT on `emailAddress`:

Find this endpoint and update it to:
1. Call `resolveEmailForMember(memberKey)` to get the email address
2. If email resolves: UPSERT on `email_address` with `memberKey` as a secondary field
3. If email does not resolve: insert with `memberKey` as both `email_address` and `member_key` (the fallback pattern), set `migrationStatus = 'unresolved'`, log a warning

---

## STEP 6 — EXPOSE SUPPRESSION HEALTH IN ADMIN ENDPOINT

Find the admin usage endpoint `GET /api/admin/usage` in `routes.ts`. Add the suppression health status to its response:

```typescript
import { getSuppressionHealthStatus } from './services/emailService';

// Inside the GET /api/admin/usage handler, add to the response object:
suppression_health: getSuppressionHealthStatus(),
```

---

## STEP 7 — STARTUP BACKFILL (server/index.ts or equivalent)

There is likely a startup migration function in `server/index.ts` that was added as part of the prior suppression work. Locate it.

Update it to reflect the new schema:
- The backfill now only needs to handle rows where `member_key IS NOT NULL` but was used as the `email_address` (the old fallback pattern)
- For any row where `email_address` looks like a `memberKey` (no `@` sign), attempt to resolve the real email from `member_metrics_cache`
- If resolved: update `email_address` to the real email, set `migration_status = 'resolved'`
- If not resolved: set `migration_status = 'unresolved'` and leave the row as-is (never delete — CAN-SPAM)

Since the table is empty right now, this backfill will do nothing on this run. It is defensive code for future correctness.

---

## DO NOT TOUCH

- `triggeredCampaignProcessor.ts` — do not modify for any reason
- `sequenceEnrollmentService.ts` — do not modify for any reason
- The existing HMAC token generation and validation logic
- The existing global `email_opt_out` boolean behavior — it remains a full override
- The sandbox mode logic, MAX_CAMPAIGN_RECIPIENTS, or any other send safety controls
- Any other part of the webhook handler (open tracking, click tracking, bounce logging)

---

## VERIFICATION CHECKLIST

Work through these in order. Do not report complete until every item is checked.

**Schema:**
- [ ] `member_email_preferences` has `email_address` as primary key — confirm in Replit Database Studio
- [ ] `member_key` column exists, is nullable, has no primary key constraint
- [ ] Partial index `idx_member_email_prefs_member_key` exists on `member_key WHERE member_key IS NOT NULL`
- [ ] `shared/schema.ts` reflects the new structure — `emailAddress` as `.primaryKey()`
- [ ] Table is empty (all 3 test rows deleted)

**canSendToRecipient:**
- [ ] When called with a valid email and no memberKey, queries by email only — no `OR member_key = ''`
- [ ] When called with both email and memberKey, queries with OR (both lookup paths active)

**canSendToMember:**
- [ ] Resolves email from `member_metrics_cache` before calling `canSendToRecipient`
- [ ] If email resolution fails, logs a warning AND increments `suppressionLookupFailureCount`
- [ ] Still passes `memberKey` through to `canSendToRecipient` as secondary lookup

**Suppression health counter:**
- [ ] `getSuppressionHealthStatus()` returns `{ status: 'ok', failureCount: 0, windowStartedAt: ... }` when no failures
- [ ] `GET /api/admin/usage` response includes `suppression_health` field

**queueEmailCampaign:**
- [ ] Bulk opt-out check uses Drizzle `inArray` — no string-interpolated SQL
- [ ] Recognition category correctly checks `recognition_opt_out`
- [ ] Marketing/engagement category checks `email_opt_out OR marketing_opt_out`

**Webhook UPSERT:**
- [ ] Trigger a test unsubscribe event (or insert directly to simulate) — confirm UPSERT creates a new row with `email_address` as the key
- [ ] Run the same event twice — confirm no duplicate key error, second event updates the existing row
- [ ] Confirm `member_key` is stored correctly alongside `email_address`
- [ ] Confirm a missing `email_address` in the event logs a warning and skips the insert (no `member_key` fallback)

**Member profile preferences endpoint:**
- [ ] `PUT /api/members/:memberKey/email-preferences` resolves email before writing
- [ ] UPSERT writes to `email_address` primary key
- [ ] Unresolvable member gets `migration_status = 'unresolved'` and a logged warning

**End-to-end:**
- [ ] Send a test email to yourself via SmartSends — confirm it delivers
- [ ] Click the Unsubscribe link — confirm a row appears in `member_email_preferences` with your email as the key
- [ ] Attempt to send another marketing email to yourself — confirm it is blocked by the governor with reason `global_opt_out` or `marketing_opt_out`
- [ ] Check that a compliance or transactional email would still be allowed (verify the `neverBlockedCategories` check in `canSendToRecipient` still works)

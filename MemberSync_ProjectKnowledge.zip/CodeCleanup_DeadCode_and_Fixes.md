# Code Cleanup: Remove Dead Code, Fix Inconsistencies, Fix Dedup Bugs
## Replit Prompt â€” February 2026

**Goal:** Clean up the codebase before building new features. Remove dead code, consolidate duplicate logic, and fix two deduplication bugs in database queries. No new features, no UI changes.

---

## CHANGE 1: Remove Mock Data Generators and Fallbacks

**File: server/storage.ts**

The mock data system (fake members and offices) was a development scaffold that should never have reached production. It generates 500 fake members and 100 fake offices on every server startup, even when the real database is connected. Worse, if any real data query fails, the app silently falls back to showing this fake data â€” a CEO could be looking at "Sarah Johnson at RE/MAX Premier" who doesn't exist and not know it.

### Step A: Delete the mock generator functions

Delete these functions entirely (approximately lines 34-139):
- `randomScore()` (line 34)
- `randomTier()` (line 38)
- `randomDate()` (line 73)
- `generateMockMembers()` (line 80)
- `generateMockOffices()` (line 115)

**Do NOT delete these functions** â€” they are used by production code:
- `getTierLabel()` (line 43) â€” used at lines 1083, 1634, 1745
- `calculateTransactionScore()` (line 52) â€” used at line 1218
- `getRiskLevel()` (line 60) â€” used at lines 1638, 1749
- `getHealthStatus()` (line 67) â€” used at lines 1510. (But see Change 2 below about the duplicate)

### Step B: Remove mock data from the DatabaseStorage class

In the `DatabaseStorage` class:

1. Remove the private properties (around line 194-195):
```typescript
// DELETE these two lines:
private mockMembers: MemberListItem[];
private mockOffices: OfficeListItem[];
```

2. Remove the constructor initialization (around line 199-200):
```typescript
// DELETE these two lines from the constructor:
this.mockMembers = generateMockMembers(500);
this.mockOffices = generateMockOffices(100);
```

3. Also remove the `import { randomUUID } from "crypto";` on line 31 if `randomUUID` is not used anywhere else in the file (check first â€” it may be used by other methods).

### Step C: Replace mock fallbacks with proper error handling

There are 4 places where the code falls back to mock data. Replace each one:

**C1. getMembers() catch block** (around line 1107-1119):

Find:
```typescript
} catch (error: any) {
  console.error("[MEMBERS_LIST] Error fetching members from cache:", error?.message || error);
  console.error("[MEMBERS_LIST] Full error:", JSON.stringify(error, null, 2));
  // Fallback to mock data on error
  console.log(`[MEMBERS_LIST] Falling back to mock data (${this.mockMembers.length} members)`);
  return {
    data: this.mockMembers,
    total: this.mockMembers.length,
    page: 1,
    pageSize: this.mockMembers.length,
    totalPages: 1,
  };
}
```

Replace with:
```typescript
} catch (error: any) {
  console.error("[MEMBERS_LIST] Error fetching members from cache:", error?.message || error);
  return {
    data: [],
    total: 0,
    page: 1,
    pageSize: 0,
    totalPages: 0,
  };
}
```

**C2. getOffices() catch block** (around line 1523-1531):

Find:
```typescript
} catch (error) {
  console.error("Error fetching offices from cache:", error);
  // Fallback to mock data
  let filtered = [...this.mockOffices];
  if (filter === "healthy") filtered = filtered.filter(o => o.healthStatus === "healthy");
  else if (filter === "watch") filtered = filtered.filter(o => o.healthStatus === "watch");
  else if (filter === "at-risk") filtered = filtered.filter(o => o.healthStatus === "at_risk");
  return { data: filtered, total: filtered.length, page: 1, pageSize: filtered.length, totalPages: 1 };
}
```

Replace with:
```typescript
} catch (error) {
  console.error("[OFFICES_LIST] Error fetching offices from cache:", error);
  return { data: [], total: 0, page: 1, pageSize: 0, totalPages: 0 };
}
```

**C3. getOfficeDetail() mock fallback** (around line 1535-1538):

Find the block that starts with `if (!externalPool || !this.externalDbConnected)` and returns mock office data. Replace the mock lookup with returning undefined:

```typescript
if (!externalPool || !this.externalDbConnected) {
  console.warn('[OFFICE_DETAIL] External database not connected');
  return undefined;
}
```

**C4. getOfficeMembers() mock fallback** (around line 1608-1609):

Find:
```typescript
if (!externalPool || !this.externalDbConnected) {
  return this.mockMembers.filter(m => m.officeKey === officeKey).slice(0, 50);
}
```

Replace with:
```typescript
if (!externalPool || !this.externalDbConnected) {
  console.warn('[OFFICE_MEMBERS] External database not connected');
  return [];
}
```

---

## CHANGE 2: Consolidate Duplicate getHealthStatus Logic

**File: server/storage.ts**

There are TWO different `getHealthStatus` functions with DIFFERENT thresholds. The module-level function (line 67) says:
- at_risk if atRiskPercentage > 30 OR avgScore < 5
- watch if atRiskPercentage >= 20 OR avgScore < 6

The inline function in `getOfficeDetail()` (line 1581) says:
- healthy if atRiskPct <= 20 AND avgEngagement >= 5
- watch if atRiskPct <= 50 OR avgEngagement >= 3

These can produce different results for the same office. The module-level version (line 67) is used by the Dashboard and the All Offices page. Keep that one as the canonical version.

**Delete the inline function** at line 1581-1585 and replace `getHealthStatus(atRiskPercentage, avgScore)` on line 1594 with a call to the module-level function. Since it's already in scope, you just delete the local `const getHealthStatus = ...` and the existing call on line 1594 will automatically resolve to the module-level function.

Before:
```typescript
const getHealthStatus = (atRiskPct: number, avgEngagement: number): "healthy" | "watch" | "at_risk" => {
  if (atRiskPct <= 20 && avgEngagement >= 5) return "healthy";
  if (atRiskPct <= 50 || avgEngagement >= 3) return "watch";
  return "at_risk";
};
```

After: Delete those 4 lines entirely. The call to `getHealthStatus(atRiskPercentage, avgScore)` on line 1594 remains unchanged â€” it will now resolve to the module-level function.

---

## CHANGE 3: Remove Debug Endpoint

**File: server/storage.ts**

Remove the `testLicenseExpiringQuery` method and its interface declaration:

1. Delete from the `IStorage` interface (around line 167-168):
```typescript
// DELETE:
// Debug
testLicenseExpiringQuery(): Promise<any>;
```

2. Delete the implementation method `async testLicenseExpiringQuery()` in `DatabaseStorage` (around lines 941-995). It's a diagnostic method that queries license expiration data â€” useful for debugging but should not be in the production interface.

3. **Check the routes file** (likely `server/index.ts`) for any route that calls `storage.testLicenseExpiringQuery()` and remove that route too. It may look something like:
```typescript
app.get('/api/debug/license-expiring', async (req, res) => {
  const result = await storage.testLicenseExpiringQuery();
  res.json(result);
});
```
Delete the entire route handler.

---

## CHANGE 4: Fix Picklist Query Deduplication

**File: server/aiAudienceService.ts**

The picklist member lookup queries are missing `DISTINCT ON` deduplication. The `apmmember` table has snapshot duplicates (same MemberKey, multiple rows with different timestamps). Without `DISTINCT ON`, the query can return multiple rows per member.

There are TWO picklist query blocks that need fixing:

### Block 1: Picklist with sourceType (around line 720-734)

Find:
```typescript
const query = `
  SELECT 
    m."MemberKey",
    m."MemberFullName",
    m."MemberFirstName",
    m."MemberLastName",
    m."MemberEmail",
    m."MemberMobilePhone",
    o."OfficeName"
  FROM "AMS"."apmmember" m
  LEFT JOIN "AMS"."apmoffice" o ON m."OfficeKey" = o."OfficeKey"
  WHERE m."MemberKey" IN (${keysArray})
    AND m."ApmClientId" = 'MainStreet'
    AND m."MemberStatus" = 'Active'
`;
```

Replace with:
```typescript
const query = `
  SELECT DISTINCT ON (m."ApmClientId", m."MemberKey")
    m."MemberKey",
    m."MemberFullName",
    m."MemberFirstName",
    m."MemberLastName",
    m."MemberEmail",
    m."MemberMobilePhone",
    o."OfficeName"
  FROM "AMS"."apmmember" m
  LEFT JOIN (
    SELECT DISTINCT ON ("ApmClientId", "OfficeKey")
      "OfficeKey", "OfficeName"
    FROM "AMS"."apmoffice"
    WHERE "ApmClientId" = 'MainStreet'
    ORDER BY "ApmClientId", "OfficeKey", "ApmSourceModificationTimestamp" DESC
  ) o ON m."OfficeKey" = o."OfficeKey"
  WHERE m."MemberKey" IN (${keysArray})
    AND m."ApmClientId" = 'MainStreet'
    AND m."MemberStatus" = 'Active'
  ORDER BY m."ApmClientId", m."MemberKey", m."ApmSourceModificationTimestamp" DESC
`;
```

### Block 2: MemberKeys fallback (around line 764-778)

Find the very similar query block starting around line 764 (it's in the `else if (audience.memberKeys && audience.memberKeys.length > 0)` branch). Apply the exact same `DISTINCT ON` and office dedup fix.

Find:
```typescript
const query = `
  SELECT 
    m."MemberKey",
    m."MemberFullName",
    m."MemberFirstName",
    m."MemberLastName",
    m."MemberEmail",
    m."MemberMobilePhone",
    o."OfficeName"
  FROM "AMS"."apmmember" m
  LEFT JOIN "AMS"."apmoffice" o ON m."OfficeKey" = o."OfficeKey"
  WHERE m."MemberKey" IN (${keysArray})
    AND m."ApmClientId" = 'MainStreet'
    AND m."MemberStatus" = 'Active'
`;
```

Replace with the same deduplicated version as Block 1 above.

---

## CHANGE 5: Fix Picklist Member Count on Save

**File: server/aiAudienceService.ts**

In the `saveAudience()` function, when a picklist audience is saved with both members and non-members (external contacts), the count only includes `memberKeys.length` and ignores `externalContacts.length`.

Find (around line 564-565):
```typescript
} else if (memberKeys) {
  memberCount = memberKeys.length;
}
```

Replace with:
```typescript
} else if (memberKeys || externalContacts) {
  memberCount = (memberKeys?.length || 0) + (externalContacts?.length || 0);
}
```

---

## TESTING CHECKLIST

After these changes, verify:

- [ ] App starts without errors (mock generators no longer called)
- [ ] Dashboard loads with real data
- [ ] All Members page loads with real data
- [ ] All Offices page loads with real data
- [ ] If you temporarily stop the database, the Members page shows empty state (not fake data)
- [ ] Office detail pages show correct health status (consistent with the office list)
- [ ] Picklist audiences save with correct member count (members + non-members)
- [ ] Picklist audiences preview with no duplicate members
- [ ] Smart audiences still work (the enrichment fix from the previous prompt handles these)
- [ ] No route errors for removed debug endpoint

## DO NOT CHANGE

- Dashboard metrics queries or calculations
- member_metrics_cache refresh job
- AI services (aiQueryService, aiAudienceService prompt/schema, aiEmailService)
- Email service
- Any frontend components
- Any cron job schedules
- Analytics cache service

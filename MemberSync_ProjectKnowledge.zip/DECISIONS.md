# MemberSync — Architectural Decisions

> **Purpose:** This document records every significant architectural decision made during MemberSync's development, the reasoning behind it, and what is permanently off the table. It is the "why we built it this way" reference for Claude Code and the development team. When in doubt about whether an approach is appropriate, check here first.
>
> **Authority:** `CLAUDE.md` in the repo root is the single source of truth for rules and conventions. This document provides the deeper reasoning behind those rules.
>
> Last updated: March 12, 2026

---

## Database Architecture

### Single PostgreSQL database in production
**Decision:** One database. All application tables and all AMS/MLS data live in the same PostgreSQL instance.

**Reasoning:** The Replit prototype used two separate database connections (`db` for application tables, `externalPool` for AMS/MLS data) as a safety measure — Tracy had read-only access to the production database so she couldn't accidentally modify live data during development. This two-connection pattern was a workaround, not a design choice.

**What this means for the port:** `externalPool` and `db` merge into a single connection in production. The "two-step query pattern" (query external DB for keys, then enrich from local cache) is eliminated. Do not replicate it.

---

### `member_metrics_cache` is the single source of truth for member metrics
**Decision:** All engagement scores, tier classifications, and member-level metrics are pre-computed daily into `member_metrics_cache`. The UI reads from this cache; it never computes metrics on the fly.

**Reasoning:** Computing engagement scores on demand for 18,000+ members is slow and expensive. Daily pre-computation means fast reads everywhere. The tradeoff (data is up to 24 hours old) is acceptable — member engagement doesn't change hour to hour.

**What this means:** Never add a query that re-derives a metric already in the cache. If you need a metric that doesn't exist in the cache, add it to the daily job — don't compute it inline.

---

### All schema changes via versioned migrations
**Decision:** No manual changes to the production database schema. Every change goes through a versioned migration file.

**Reasoning:** Manual schema changes are invisible, irreversible, and impossible to reproduce. Migrations create an auditable history and allow any developer to build the schema from scratch.

**What this means:** Even small, "quick" column additions must be migrations. No exceptions.

---

### Schema modularization for AI context injection
**Decision:** The database schema is divided into modules by query type (member queries, email generation, general fallback). Only the relevant module is injected into AI prompts — not the full schema.

**Reasoning:** Injecting the full schema into every AI call wastes tokens, increases cost, and dilutes the AI's attention. Modularization reduced schema injection size by 41–76% depending on query type.

**What this means:** When adding new tables, determine which AI query type(s) they belong to and add them to the appropriate schema module. Do not revert to full-schema injection.

---

## Multi-Tenant Architecture

### `tenant_config` is the control plane for everything
**Decision:** Every feature that behaves differently per client is controlled by a row in `tenant_config`. No hardcoded client references anywhere in the codebase except `tenant_config` lookups.

**Reasoning:** The Replit prototype has 110+ hardcoded references to "Mainstreet," "Illinois," and client-specific values. This was acceptable for a single-client prototype. It is not acceptable for a multi-client SaaS. The production port's first job is eliminating every one of these references.

**Fields that must live in `tenant_config` (not exhaustive):**
- `org_name`, `brand_color`, `logo_url` — branding
- `org_type` — `'association'` or `'mls'` — gates compliance module
- `tracks_ce`, `tracks_coe`, `tracks_designations` — compliance feature flags
- `geographic_context` — AI Chat geographic awareness
- `billing_calendar` — dues timeline (Mainstreet has specific July/December dates)
- `engagement_scoring_weights` — tier thresholds and signal weights
- `lapse_risk_weights` — risk score weights at each billing calendar position
- `ai_chat_context`, `available_data_sources` — AI Chat query planner context
- `competitive_territory` — Competitive Intelligence geography
- `duplicate_detection_threshold` — email duplicate similarity threshold
- `automation_priority_rules` — automation conflict resolution
- `has_member_portal` — gates portal-only features
- `office_suspension_model` — whether office suspension cascades to agents
- `sg_group_marketing`, `sg_group_recognition`, `sg_group_compliance`, `sg_group_transactional` — SendGrid ASM group IDs

---

### Compliance modules are distinct for associations and MLSs — never merged
**Decision:** Associations and MLSs both have a compliance module, but they are fundamentally different in scope and function. They are built as separate modules. An organization that is both an association and an MLS gets a combined view — but the architecture must make that combination possible without a redesign.

**Association compliance** covers: CE hours and license renewal tracking, Code of Ethics enforcement, Fair Housing requirements, NAR professional designations. These are association obligations — MLSs have none of them.

**MLS compliance** covers: data accuracy, listing timeliness, participant behavior standards, cooperation violations, and NAR Settlement-related requirements. MLSs never enforce CE, COE, Fair Housing, or designations.

**Reasoning:** These two compliance domains share a name but have almost no functional overlap. Building one module that tries to handle both creates a mess of conditional logic. Building two distinct modules — each focused on its own domain — keeps the code clean and makes the combined case (association + MLS) additive rather than tangled.

**What this means:**
- Do not show association compliance features (CE, COE, Fair Housing, designations) to MLS-only clients. Gate at the router level.
- Do not show MLS compliance features (listing accuracy, submission deadlines, cooperation violations) to association-only clients.
- When building either module, architect it so the combined case (both modules rendered together) is possible without structural changes.
- The MLS compliance rule set has not yet been fully defined — it will be shaped by the first MLS client. Do not build the MLS compliance module until those requirements are known. See `OPEN_QUESTIONS.md`.

---

## Email Architecture

### All outbound email funnels through `emailService.ts` `processEmailQueue`
**Decision:** One function is the single exit point for all outbound email. The ASM (unsubscribe group) parameter is added here and only here.

**Reasoning:** If ASM assignment lived in every send path, it would be missed somewhere. Centralizing it means it's impossible to send an email without a group assignment.

**What this means:** Never add a new send path that bypasses `processEmailQueue`. If you need a new email type, add it as a category — don't create a parallel send path.

---

### `email_address` is the permanent primary key on `member_email_preferences`
**Decision:** The suppression table uses `email_address` as its primary key. `member_key` is a nullable secondary field. This is an irreversible migration completed March 11, 2026.

**Reasoning:** The original `member_key` PK meant that external contacts — event guests, past members, non-member recipients — had no AMS record and therefore could not be suppressed. A member who unsubscribed with no `member_key` was invisible to the suppression system. This was a deliverability and compliance risk.

**What this means:** Do not revert this. Do not add parallel `member_key` lookups. Do not bypass email address as the suppression key. If a suppression event arrives with a `member_key` but no email, resolve the email first. If resolution fails, log and skip.

---

### SendGrid ASM groups are created programmatically, IDs stored in `tenant_config`
**Decision:** Unsubscribe groups are created via the SendGrid API on client onboarding. Their IDs are stored in `tenant_config.sg_group_*` columns. They are never hardcoded.

**Reasoning:** Hardcoded group IDs are Mainstreet-specific. Every client needs their own groups with their own IDs. Programmatic creation + config storage makes this work for any client.

**What this means:** The `sendgridUnsubscribeGroups.ts` service handles creation idempotently — if groups already exist in `tenant_config`, it skips creation. This is the correct pattern for all external service provisioning.

---

### Hard bounce suppressions are permanent
**Decision:** When SendGrid reports a hard bounce for an email address, that suppression is permanent. There is no Remove button, no manual override, no admin bypass.

**Reasoning:** A hard bounce means the address doesn't exist or permanently rejects mail. Sending to it again damages our sender reputation with SendGrid and ISPs. There is no valid reason to override a hard bounce.

**What this means:** Do not build a "remove hard bounce suppression" UI. If a client requests this, explain that it would harm their deliverability.

---

### Global `email_opt_out` boolean is a full override
**Decision:** The `email_opt_out` column on `member_email_preferences` is a full suppression flag. When true, no email of any category is sent, regardless of category-level opt-out status.

**Reasoning:** Some members want no contact from the organization whatsoever. Respecting that is both legally appropriate and the right thing to do.

**What this means:** `canSendToMember()` checks global opt-out first, before any category check. This order must never change.

---

### Recognition emails are Lane 1 — exempt from the Email Governor
**Decision:** Recognition emails bypass the daily/weekly sending caps enforced by the Email Governor.

**Reasoning:** A staff member has personally reviewed and approved every recognition email. Throttling a human-approved message because of an automated cap is wrong — it defeats the purpose of human review.

**What this means:** The `canSendToMember()` function exempts `category === 'recognition'` from governor checks. Do not change this exemption without explicit approval.

---

### `triggeredCampaignProcessor.ts` is not to be modified
**Decision:** This file is treated as sealed production infrastructure. No modifications without explicit written approval from Tracy.

**Reasoning:** This processor handles all triggered campaign execution — sequence enrollment, step progression, timing logic. It has been carefully hardened and tested. Inadvertent changes here can cause silent failures in campaign delivery that are difficult to diagnose.

**What this means:** Read it. Understand it. Do not touch it without a specific, approved, written spec.

---

### `sequenceEnrollmentService.ts` is the single source of enrollment logic
**Decision:** All campaign enrollment goes through this service. No other code handles enrollment.

**Reasoning:** Duplicate enrollment logic means enrollment can go out of sync. Centralizing it means there is one place to fix, one place to test.

**What this means:** The activation route and the processor both import from this service. Do not inline enrollment logic anywhere else.

---

## Engagement Scoring

### Scoring engine is data-driven, not code-driven
**Decision:** Scoring weights, tier thresholds, and active signals all come from `tenant_config`. The scoring code reads configuration — it does not contain if-statements with hardcoded weights.

**Reasoning:** Every client weights engagement differently. A 500-member rural association values CE attendance differently than a 103,000-member MLS. Hard-coded weights are wrong for every client except the one they were written for.

**What this means:** When adding a new scoring signal, add it to the configuration schema first. The code reads the config to decide whether the signal is active and what weight it carries.

---

### Payment is table stakes, not an engagement signal
**Decision:** Paying dues on time earns a maximum of 1 point in the engagement score. It is acknowledged but not celebrated.

**Reasoning:** Paying invoices is the baseline expectation of membership. It tells you nothing about whether a member has a relationship with the organization. A member who pays their dues and does nothing else is not "engaged" — they are present.

**What this means:** Never increase the weight of payment behavior in the scoring system. If the score starts rewarding payment heavily, the entire engagement model breaks down.

---

### The 100% Coverage Test
**Decision:** Any scoring signal that applies to fewer than 10% of members is not a scoring input. It may be tracked for other purposes, but it does not affect the engagement score.

**Reasoning:** A signal that only 1% of members can earn (e.g., NAR committee participation) doesn't differentiate the 99%. It creates a system that measures the already-engaged, not one that finds the disengaged.

**What this means:** Before adding any new scoring signal, verify its coverage against the membership. If fewer than 10% of members can trigger it, it belongs in member detail context — not in the score.

---

### Non-CE event attendance outweighs CE attendance
**Decision:** Attending a voluntary, non-required event is a stronger engagement signal than attending a CE class.

**Reasoning:** A member who attends a CE class may be doing the minimum required by their license. A member who shows up to a voluntary networking event, technology workshop, or association meeting came because they wanted to. Voluntary participation is a better signal of organizational connection.

**What this means:** Non-CE events carry higher weight in the scoring formula than CE events. Do not equalize these.

---

## AI Services

### Single Anthropic API key for all clients
**Decision:** MemberSync uses one Anthropic API key managed by Membio. Clients never have their own keys.

**Reasoning:** Exposing client-managed API keys creates support burden, security risk, and usage visibility problems. Membio manages AI cost as part of the SaaS pricing model.

**What this means:** Never build a UI that asks a client to enter an Anthropic API key. The key is a Membio secret.

---

### Per-feature rate limiting and kill switches
**Decision:** Every AI feature has its own rate limit and kill switch in `tenant_config`. Usage is logged via `aiUsageLogger.ts`.

**Reasoning:** A single runaway AI feature (e.g., a client running thousands of audience builder queries) should not affect other clients or bankrupt Membio. Kill switches allow disabling features without a deployment.

**What this means:** When adding a new AI-powered feature, add its rate limit and kill switch to `tenant_config` before shipping. Usage logging is not optional.

---

### AI model selection: Sonnet for complex, Haiku for variations
**Decision:** Claude Sonnet handles complex queries, campaign planning, and email composition. Claude Haiku handles short-form variations (e.g., A/B subject line alternatives).

**Reasoning:** Sonnet produces better output for tasks requiring judgment, creativity, and contextual reasoning. Haiku is fast and cheap for tasks that are mechanical variations on existing content.

**What this means:** Campaign Architect planner calls use Sonnet. A/B variant generation uses Haiku. Do not use Haiku for tasks that require real reasoning — the output quality difference is visible to users.

---

### AI suggestions are always actionable — never configuration forms
**Decision:** When the AI makes a recommendation, staff can say yes or no. They never have to configure the recommendation before acting on it.

**Reasoning:** Configuration forms are where good intentions go to die. If accepting a recommendation requires filling out a form, most staff won't do it. The AI should do the work of generating a complete, actionable suggestion. Staff should only have to approve it.

**What this means:** AI-generated campaigns, audiences, and insights arrive complete. If a complete suggestion is impossible, don't surface an incomplete one.

---

## Campaign Architect

### Campaign Architect replaced the drip sequence builder — no parallel UI
**Decision:** There is one way to build a campaign sequence in MemberSync. Campaign Architect is it. The old drip sequence builder UI is gone.

**Reasoning:** Two ways to do the same thing creates confusion about which to use, doubles the surface area to maintain, and splits user attention. One great path beats two mediocre ones.

**What this means:** Do not restore the drip sequence builder. Do not build a "simplified" alternative. If Campaign Architect has gaps, fix Campaign Architect.

---

### Branch points are shallow — registration status and prior attendance only
**Decision:** Campaign Architect supports exactly two branch conditions: whether a member is registered for the event, and whether they attended a prior event. Deep conditional logic is not built into Campaign Architect.

**Reasoning:** Deep branching in Campaign Architect would make it as complex as the competitor tools MemberSync is designed to replace. The value is simplicity. Complex member journey logic belongs in the Member Journey engine (a separate, future module with its own architecture).

**What this means:** When a client requests complex conditional logic ("send different emails based on member tier AND registration status AND engagement score"), that belongs in Member Journey — not Campaign Architect.

---

### `anchorOffset` + `anchorDirection` replace `delayDays`
**Decision:** Campaign sequence timing is expressed as an offset from an anchor date with a direction (`before` or `after`). `delayDays` is not used.

**Reasoning:** `delayDays` was ambiguous — did negative values mean "before the event"? This caused scheduling bugs. An explicit anchor + offset + direction is unambiguous.

**What this means:** Any code that reads or writes sequence timing must use `anchorOffset` and `anchorDirection`. Do not introduce `delayDays` back into the schema or the planner.

---

### Member Journey is architecturally distinct from Campaign Architect
**Decision:** Member Journey (lifecycle-driven communications) is a separate module with separate infrastructure, a separate execution model, and a separate build timeline. It is not an extension of Campaign Architect.

**Reasoning:** Campaign Architect handles event-anchored sequences — bounded campaigns with a clear start and end. Member Journey handles continuous, state-driven lifecycle communications — an ongoing relationship model with branching, re-entry, and persistent state. These are fundamentally different problems.

**What this means:** Do not try to extend Campaign Architect to cover lifecycle logic. When Member Journey is specced, it gets its own tables, its own processor, and its own UI. Nothing is shared with Campaign Architect except the EmailComposer component.

---

## Navigation

### Nav items are destinations — actions live in buttons
**Decision:** The left navigation contains only page destinations. Actions (create, send, approve) live in buttons on those pages. Nothing in the nav triggers an action directly.

**Reasoning:** Navigation that mixes destinations and actions creates unpredictable UX. Users learn that clicking the nav takes them somewhere. If some items do something instead, it breaks the mental model.

**What this means:** No nav item should trigger a modal, start a workflow, or perform an action. If a feature needs to be "one click away," put a prominent button on the relevant dashboard — not a nav action.

---

### Recognition is a top-level nav module
**Decision:** Recognition lives at the top level of navigation, not nested inside SmartSends.

**Reasoning:** Recognition is a primary reason clients buy MemberSync. Burying it inside SmartSends (the email tool) understates its importance and makes it feel like a send feature rather than a relationship feature.

**What this means:** `/recognition` is a first-class route. Recognition Queue, Recognition Performance, and the Recognition Homepage are all children of this module. Do not move them under SmartSends.

---

## Volume Calculations

### Membio Volume Standard: full ClosePrice per side
**Decision:** Personal Production Volume assigns the full `ClosePrice` to each side. If an agent represented both sides, they get the full price twice. Market Volume Contribution splits the price 50/50 when both sides are Membio members.

**Reasoning:** An agent's personal production should reflect what they actually transacted. A $500,000 sale is a $500,000 sale to the listing agent — not $250,000. Market Volume Contribution is for understanding market share, not individual performance.

**What this means:** Never `SUM(ClosePrice)` across listing and buyer sides without applying the appropriate split. Using the wrong method double-counts or under-counts volume.

---

## What Is Permanently Off the Table

These decisions are closed. Do not revisit them without explicit written approval from Tracy.

| Topic | Decision | Why It's Closed |
|-------|----------|----------------|
| `member_email_preferences` PK | `email_address` — permanent | Migration is complete and irreversible |
| Drip sequence builder | Deleted — replaced by Campaign Architect | No parallel systems |
| Scoring engine implementation | Data-driven via `tenant_config` | Code-driven weights can't be client-configurable |
| `triggeredCampaignProcessor.ts` modifications | Forbidden without written approval | Risk of silent delivery failures |
| Payment as a primary engagement signal | Payment is table stakes (1 point max) | Philosophical core of the product |
| Per-client Anthropic API keys | Not allowed | Membio manages AI cost centrally |
| Two-database architecture in production | Single DB only | The two-DB setup was a Replit workaround |
| Hard bounce suppression override | No override | Sender reputation protection |
| Social proof in Campaign Architect emails | Prohibited | No attendance numbers, "members like you," or testimonials |

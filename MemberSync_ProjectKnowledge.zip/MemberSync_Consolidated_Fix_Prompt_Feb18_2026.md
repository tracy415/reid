# MemberSync â€” Consolidated Fix & Enhancement Prompt
## February 18, 2026

---

## CONTEXT FOR REPLIT AGENT

MemberSync is a member engagement platform for real estate associations. The first client is Mainstreet REALTORSÂ® (~18,275 active members). This prompt addresses 9 issues found during a code review of the current deployed build. The issues are grouped into three batches to manage complexity. **Complete each batch in order and verify before moving to the next.**

---

## BATCH 1: Data Accuracy Fixes (Critical)

These fixes correct data that is displayed incorrectly to users right now.

### FIX 1A: Email Event Type Mismatch

**Problem:** SendGrid webhook sends event types as `open`, `click`, `delivered`, `bounce` (no past tense). The webhook handler at `routes.ts` line ~4604 stores `eventType: eventType` directly â€” so the `email_events` table contains values like `open` and `click`. However, three query locations look for `opened` and `clicked`, which will never match.

**Files to change:**

1. **`server/services/memberMetricsCacheService.ts`** â€” around lines 305-306:
   - Change `event_type = 'opened'` â†’ `event_type = 'open'`
   - Change `event_type = 'clicked'` â†’ `event_type = 'click'`

2. **`server/routes.ts`** â€” in the `/api/dashboard/membership-story` endpoint (around line 626):
   - Change `ee.event_type IN ('opened', 'clicked')` â†’ `ee.event_type IN ('open', 'click')`

3. **`server/routes.ts`** â€” in the `getDashboardMetrics` campaign effectiveness query (around lines 510-511):
   - Change `ee.event_type = 'opened'` â†’ `ee.event_type = 'open'`
   - Change `ee.event_type = 'clicked'` â†’ `ee.event_type = 'click'`

**Do NOT change** the member detail enrichment in routes.ts (around lines 879-880) â€” those already correctly use `'open'` and `'click'`.

---

### FIX 1B: Membership Story Using Wrong Volume Column

**Problem:** The Membership Story endpoint and concentration query use `total_volume_12mo`, which is the split market volume (each transaction divided between listing and buyer agents). This produces nonsensical results: Builders appear to control more volume than Rainmakers, and Foundation members show ~18% of production.

The correct column is `personal_volume_12mo` â€” the full close price per side. This matches how Julius computed the original stats (top 25% control 88% of volume) and is what users expect when they see "volume controlled by tier."

**File: `server/routes.ts`** â€” in the `/api/dashboard/membership-story` endpoint:

1. **Tier volume query** (around line 524): Change:
   ```sql
   COALESCE(SUM(CAST(total_volume_12mo AS NUMERIC)), 0) as total_volume
   ```
   To:
   ```sql
   COALESCE(SUM(CAST(personal_volume_12mo AS NUMERIC)), 0) as total_volume
   ```

2. **Concentration query** (around lines 558-563): Change all three references to `total_volume_12mo` â†’ `personal_volume_12mo`:
   ```sql
   -- Change these three occurrences:
   personal_volume_12mo::numeric as vol,
   ROW_NUMBER() OVER (ORDER BY personal_volume_12mo::numeric DESC) as rank,
   SUM(personal_volume_12mo::numeric) OVER () as total_vol
   ```

**Important:** Do NOT change `total_volume_12mo` references elsewhere. The office production cache, agent production cache, and market analytics should continue using market volume. Only the Membership Story tier cards and concentration stat should use personal volume.

---

### FIX 1C: Analytics Office Agent Count Inconsistency

**Problem:** The Analytics Overview page shows office agent counts from `office_production_cache.active_agents`, which is computed from the MLS `apmmember` table using a broad `active_status_list` from `clientinfo`. But when you click into an individual office, the agent count comes from `member_metrics_cache` where `member_status = 'Active'` (strict AMS definition). These produce different numbers.

**Fix:** Make the analytics overview consistent with the authoritative source (member_metrics_cache).

**File: `server/routes.ts`** â€” in the `/api/analytics/dashboard` endpoint (around line 1474):

After the existing `topOffices` query, add a reconciliation step that overrides `active_agents` for each office using `member_metrics_cache`:

```typescript
// Reconcile active_agents with member_metrics_cache (single source of truth)
const agentCountReconciliation = await db.execute(sql`
  SELECT office_key, COUNT(*) as active_count
  FROM member_metrics_cache
  WHERE member_status = 'Active' AND office_key IS NOT NULL
  GROUP BY office_key
`);
const agentCountMap = new Map<string, number>();
for (const row of agentCountReconciliation.rows as any[]) {
  // member_metrics_cache uses unprefixed keys; office_production_cache uses MRD prefix
  agentCountMap.set(row.office_key, Number(row.active_count) || 0);
  agentCountMap.set(`MRD${row.office_key}`, Number(row.active_count) || 0);
}
```

Then in the `topOffices` mapping (around line 1535), override:
```typescript
activeAgents: agentCountMap.get(row.office_key) ?? Number(row.active_agents) || 0,
```

Also do the same for the `/api/analytics/offices` paginated list endpoint (around line 1594) â€” when returning `dataResult.rows`, enrich each row's `active_agents` from the same reconciliation map.

---

### FIX 1D: Member Detail Score Total Not Recalculated

**Problem:** The member detail endpoint enriches individual score breakdown fields (educationEvents, recency, email) with fresh calculations, but the `total` still holds the cached value from the nightly refresh. The parts don't add up to the total displayed.

**File: `server/routes.ts`** â€” in the member detail endpoint, after line ~900 (after setting `educationEvents`, `recency`, and `email`), add:

```typescript
// Recalculate total from parts so breakdown adds up
member.engagementScore.total = Math.min(10,
  member.engagementScore.transactionActivity +
  member.engagementScore.educationEvents +
  member.engagementScore.email +
  member.engagementScore.payment +
  member.engagementScore.recency +
  member.engagementScore.designation
);
```

---

## BATCH 2: UI Polish & Infrastructure

### FIX 2A: Score Breakdown Display Order

**Problem:** The member detail page shows score breakdown categories in the wrong order. The categories users can influence (education, email) should be at the top.

**File: `client/src/pages/MemberDetail.tsx`** â€” in the engagement score card (around lines 446-469), reorder the `ScoreBreakdownRow` components to this order:

1. Education & Events (`educationEvents`)
2. Email Engagement (`email`)
3. Transactions (`transactionActivity`)
4. Payment (`payment`)
5. Recent Activity (`recency`)
6. Designations (`designation`)

---

### FIX 2B: EngagementScore Field Name (Optional Cleanup)

**Problem:** The spec called for renaming `transactionActivity` â†’ `transactions` in the EngagementScore interface, but both the schema and all consumers still use `transactionActivity`. Everything works because they all agree on the same name.

**Decision:** Leave `transactionActivity` as-is for now â€” renaming it across schema, storage, routes, and the frontend client is high risk for low reward. Instead, add a comment to the EngagementScore interface in `shared/schema.ts`:

```typescript
export interface EngagementScore {
  total: number;
  transactionActivity: number; // transaction score component (tier-aware: 0-2 points)
  educationEvents: number;     // education + events score (0-3 or 0-4 points depending on tier)
  payment: number;             // binary: 0 or 1 (table stakes)
  email: number;               // email engagement: 0-2 or 0-3 depending on tier
  recency: number;             // non-transaction activity in last 90 days: 0 or 1
  designation: number;         // has professional designations: 0 or 1
}
```

---

### FIX 2C: Daily Membership Snapshot Table

**Problem:** The dashboard redesign spec included a `membership_daily_snapshot` table to accumulate daily tier and connection counts for future trend sparklines. This was not implemented.

**Implementation:**

1. **Create the table** (add to schema.ts and run migration):

```sql
CREATE TABLE IF NOT EXISTS membership_daily_snapshot (
  snapshot_date DATE PRIMARY KEY,
  total_active INTEGER NOT NULL,
  rainmaker_count INTEGER NOT NULL DEFAULT 0,
  builder_count INTEGER NOT NULL DEFAULT 0,
  foundation_count INTEGER NOT NULL DEFAULT 0,
  highly_connected INTEGER NOT NULL DEFAULT 0,
  connected INTEGER NOT NULL DEFAULT 0,
  drifting INTEGER NOT NULL DEFAULT 0,
  disconnected INTEGER NOT NULL DEFAULT 0,
  avg_engagement_score NUMERIC(4,2),
  created_at TIMESTAMP DEFAULT NOW()
);
```

2. **Add to schema.ts** (Drizzle definition):

```typescript
export const membershipDailySnapshot = pgTable("membership_daily_snapshot", {
  snapshotDate: date("snapshot_date").primaryKey(),
  totalActive: integer("total_active").notNull(),
  rainmakerCount: integer("rainmaker_count").notNull().default(0),
  builderCount: integer("builder_count").notNull().default(0),
  foundationCount: integer("foundation_count").notNull().default(0),
  highlyConnected: integer("highly_connected").notNull().default(0),
  connected: integer("connected").notNull().default(0),
  drifting: integer("drifting").notNull().default(0),
  disconnected: integer("disconnected").notNull().default(0),
  avgEngagementScore: numeric("avg_engagement_score"),
  createdAt: timestamp("created_at").defaultNow(),
});
```

3. **Add snapshot function** to `memberMetricsCacheService.ts`:

```typescript
export async function takeDailySnapshot(): Promise<void> {
  try {
    const result = await localPool.query(`
      INSERT INTO membership_daily_snapshot 
        (snapshot_date, total_active, rainmaker_count, builder_count, foundation_count,
         highly_connected, connected, drifting, disconnected, avg_engagement_score)
      SELECT 
        CURRENT_DATE,
        COUNT(*),
        SUM(CASE WHEN tier = 'active_producer' THEN 1 ELSE 0 END),
        SUM(CASE WHEN tier = 'occasional_producer' THEN 1 ELSE 0 END),
        SUM(CASE WHEN tier = 'license_maintainer' THEN 1 ELSE 0 END),
        SUM(CASE WHEN risk_level = 'low' THEN 1 ELSE 0 END),
        SUM(CASE WHEN risk_level = 'medium' THEN 1 ELSE 0 END),
        SUM(CASE WHEN risk_level = 'high' THEN 1 ELSE 0 END),
        SUM(CASE WHEN risk_level = 'critical' THEN 1 ELSE 0 END),
        ROUND(AVG(engagement_score), 2)
      FROM member_metrics_cache
      WHERE member_status = 'Active'
      ON CONFLICT (snapshot_date) DO UPDATE SET
        total_active = EXCLUDED.total_active,
        rainmaker_count = EXCLUDED.rainmaker_count,
        builder_count = EXCLUDED.builder_count,
        foundation_count = EXCLUDED.foundation_count,
        highly_connected = EXCLUDED.highly_connected,
        connected = EXCLUDED.connected,
        drifting = EXCLUDED.drifting,
        disconnected = EXCLUDED.disconnected,
        avg_engagement_score = EXCLUDED.avg_engagement_score
    `);
    console.log('[SNAPSHOT] Daily membership snapshot captured');
  } catch (err) {
    console.warn('[SNAPSHOT] Failed to take daily snapshot (non-fatal):', err);
  }
}
```

4. **Schedule it** â€” call `takeDailySnapshot()` at the end of `scheduleMemberMetricsCacheRefresh()`, running after the 4 AM cache refresh (e.g., schedule at 4:15 AM). Also call it once on app startup if no snapshot exists for today.

---

## BATCH 3: New Features

### FEATURE 3A: Client Configuration Constants

**Why:** Currently, Mainstreet-specific values (client ID, tier thresholds, scoring weights, branding, URLs, CE requirements, timezone) are hardcoded in 125+ locations across the codebase. This makes it impossible to onboard a second client without forking the entire app. This fix consolidates all client-specific configuration into ONE file â€” still hardcoded constants for now, but in a single place that can later be moved to a database table.

**Create new file: `server/services/clientConfig.ts`**

```typescript
/**
 * CLIENT CONFIGURATION â€” SINGLE SOURCE OF TRUTH
 * 
 * ALL client-specific values MUST live here. No hardcoded client IDs,
 * tier thresholds, branding, URLs, or compliance rules anywhere else.
 * 
 * CURRENT STATE: Hardcoded constants for Mainstreet REALTORSÂ®.
 * FUTURE STATE: Load from a `tenant_config` database table keyed by clientId.
 * 
 * RULE: If you add ANY client-specific value to the codebase, it goes HERE.
 * Search for "MainStreet" or "Mainstreet" before adding â€” it probably
 * already exists in this file.
 * 
 * WHY THIS MATTERS: This file is the difference between a SaaS product
 * and custom software. Every value here represents a knob that gets
 * turned differently for the next client. If it's not here, it becomes
 * a hidden dependency that breaks when you onboard client #2.
 */

// ============================================================
// IDENTITY
// ============================================================

/** Database client identifier â€” used in all AMS/MLS WHERE clauses */
export const CLIENT_ID = 'MainStreet';

/** Display name â€” used in UI headers, reports, PDF generation */
export const CLIENT_DISPLAY_NAME = 'Mainstreet REALTORSÂ®';

/** Short name for casual references in AI-generated content */
export const CLIENT_SHORT_NAME = 'Mainstreet';

/** Branding rule for AI services */
export const CLIENT_BRANDING_RULE = 'ALWAYS spell "Mainstreet REALTORSÂ®" (lowercase "s" in Mainstreet, all caps REALTORS with Â®)';

// ============================================================
// CONTACT & LOCATION
// ============================================================

export const CLIENT_ADDRESS = '6655 Main Street, Downers Grove, IL 60516';
export const CLIENT_PHONE = '(630) 324-8400';
export const CLIENT_TIMEZONE = 'America/Chicago';
export const CLIENT_STATE = 'Illinois';

// ============================================================
// URLs
// ============================================================

/** Public-facing website */
export const CLIENT_WEBSITE_URL = 'https://mainstreetrealtors.com';

/** Member portal base URL */
export const CLIENT_PORTAL_URL = 'https://mainstreet.membio.com';

/** 
 * Construct a portal URL for a specific class/event.
 * EventId from apmevent table maps directly to the `id` parameter.
 * Example: buildEventPortalUrl('021926ZM') â†’ 
 *   https://mainstreet.membio.com/education?tab=class&formatTab=In-Person%2FVirtual&id=021926ZM
 */
export function buildEventPortalUrl(eventId: string, formatTab: string = 'In-Person/Virtual'): string {
  return `${CLIENT_PORTAL_URL}/education?tab=class&formatTab=${encodeURIComponent(formatTab)}&id=${eventId}`;
}

/** 
 * Construct a public website URL for a specific class/event.
 * Example: buildEventPublicUrl('021926ZM') â†’
 *   https://mainstreetrealtors.com/education/find-a-class?tab=in-person-virtual&class=021926ZM
 */
export function buildEventPublicUrl(eventId: string): string {
  return `${CLIENT_WEBSITE_URL}/education/find-a-class?tab=in-person-virtual&class=${eventId}`;
}

// ============================================================
// MLS CONFIGURATION
// ============================================================

/** 
 * Prefix applied to MLS IDs in the MLS schema.
 * AMS stores "259036", MLS stores "MRD259036".
 * Different MLSs use different prefixes (or none).
 */
export const MLS_ID_PREFIX = 'MRD';

/** Non-member office key in MLS data */
export const MLS_NON_MEMBER_OFFICE_KEY = 'MRDNONMEMBER';

// ============================================================
// TIER THRESHOLDS (12-month transaction sides)
// ============================================================

/** Minimum sides in 12 months to qualify as Rainmaker (active_producer) */
export const TIER_RAINMAKER_MIN = 40;

/** Minimum sides in 12 months to qualify as Builder (occasional_producer) */
export const TIER_BUILDER_MIN = 6;

/** Foundation = everyone below TIER_BUILDER_MIN (0 to TIER_BUILDER_MIN - 1) */

// ============================================================
// ENGAGEMENT SCORING WEIGHTS
// ============================================================

/**
 * Scoring configuration per tier.
 * Each tier awards points differently across six categories.
 * Max total score is 10 (capped).
 */
export const SCORING_CONFIG = {
  rainmaker: {
    // Transaction: up to 2 pts
    transactionThresholds: [
      { minSides: 80, points: 2 },
      { minSides: 60, points: 1 },
    ],
    // Education + Events combined: up to 3 pts
    eduEventThresholds: [
      { minCount: 3, points: 3 },
      { minCount: 2, points: 2 },
      { minCount: 1, points: 1 },
    ],
    paymentMaxPoints: 1,       // Binary: paid = 1, overdue = 0
    emailClickPoints: 2,       // Clicked any email in 90 days
    emailOpenPoints: 1,        // Opened any email in 90 days (if no click)
    recencyPoints: 1,          // Non-tx activity in last 90 days
    designationPoints: 1,      // Has any professional designation
  },
  builder: {
    transactionThresholds: [
      { minSides: 20, points: 2 },
      { minSides: 12, points: 1 },
    ],
    eduEventThresholds: [
      { minCount: 4, points: 3 },
      { minCount: 2, points: 2 },
      { minCount: 1, points: 1 },
    ],
    paymentMaxPoints: 1,
    emailClickPoints: 2,
    emailOpenPoints: 1,
    recencyPoints: 1,
    designationPoints: 1,
  },
  foundation: {
    transactionThresholds: [],  // No transaction scoring for Foundation
    eduEventThresholds: [
      { minCount: 4, points: 4 },
      { minCount: 2, points: 3 },
      { minCount: 1, points: 2 },
    ],
    paymentMaxPoints: 1,
    emailClickPoints: 3,       // Higher weight â€” email may be only touchpoint
    emailOpenPoints: 2,
    recencyPoints: 1,
    designationPoints: 1,
  },
} as const;

// ============================================================
// ENGAGEMENT LABEL THRESHOLDS
// ============================================================

/** Score thresholds for engagement labels (maps to risk_level in DB) */
export const ENGAGEMENT_THRESHOLDS = {
  highlyConnected: 8,  // score >= 8 â†’ risk_level = 'low'
  connected: 5,        // score >= 5 â†’ risk_level = 'medium'
  drifting: 3,         // score >= 3 â†’ risk_level = 'high'
  // Below 3 â†’ risk_level = 'critical' (Disconnected)
} as const;

// ============================================================
// COMPLIANCE CONFIGURATION
// ============================================================

export const COMPLIANCE_CONFIG = {
  /** Illinois CE renewal requirements */
  ce: {
    totalHoursRequired: 12,
    currentCycleStart: '2024-05-01',
    currentCycleEnd: '2026-04-30',
    deadline: 'April 30, 2026',
    renewalCadence: 'biennial (even years)',
    state: 'Illinois',
    /** Course types that count toward CE hours */
    qualifyingCourseTypes: [
      'Core',
      '4 Hour Core Requirement',
      'Elective',
      'Post Lic 3-15-HR Courses',
      'Post Lic 45-Hour Courses',
      'Post Lisc Indiv. 15-HR Courses',
    ],
    /** Sexual Harassment Prevention â€” tracked separately */
    sexualHarassmentCourseType: 'Sexual Harassment Prevention',
  },
  /** Code of Ethics (NAR requirement) */
  codeOfEthics: {
    cycleStart: '2025-01-01',
    cycleEnd: '2027-12-31',
    cadence: 'every 3 years',
  },
} as const;

// ============================================================
// SCHEDULE CONFIGURATION
// ============================================================

export const SCHEDULE_CONFIG = {
  /** Member metrics cache refresh (engagement scores, tier classification) */
  metricsRefreshCron: '0 4 * * *',      // 4:00 AM daily
  /** Analytics production cache refresh (office/agent rankings) */
  analyticsRefreshCron: '30 3 * * *',    // 3:30 AM daily
  /** Daily membership snapshot */
  snapshotCron: '15 4 * * *',            // 4:15 AM daily (after metrics refresh)
  /** Activity cache refresh */
  activityRefreshCron: '45 3 * * *',     // 3:45 AM daily
} as const;

// ============================================================
// APPROXIMATE MEMBER STATS (for AI prompt context)
// ============================================================

export const APPROXIMATE_STATS = {
  totalActiveMembers: 18275,
  totalOffices: 2800,
  subAssociations: 16,
  billTypes: 18,
  description: 'the largest suburban Chicagoland REALTORÂ® association, serving the western and southwestern suburbs including DuPage, Will, and Kendall counties',
} as const;
```

**IMPORTANT â€” What NOT to do in this prompt:** Do NOT refactor all 125+ references to use these constants yet. That is a separate, carefully staged effort. For now, create the file, import it into `sharedDatabaseSchema.ts` so the AI services can reference branding/URLs, and import it into `memberMetricsCacheService.ts` for the tier thresholds and scoring weights. The rest will be migrated incrementally over future prompts.

**Immediate imports to wire up:**

1. **`memberMetricsCacheService.ts`**: Import `CLIENT_ID`, `TIER_RAINMAKER_MIN`, `TIER_BUILDER_MIN`, `MLS_ID_PREFIX`, `MLS_NON_MEMBER_OFFICE_KEY`, and `SCORING_CONFIG`. Replace the hardcoded tier assignment (lines ~360-362) and scoring blocks (lines ~364-422) with references to these constants. Keep the same logic structure â€” just read thresholds from the config instead of magic numbers.

2. **`sharedDatabaseSchema.ts`**: Import `CLIENT_DISPLAY_NAME`, `CLIENT_BRANDING_RULE`, `CLIENT_ADDRESS`, `CLIENT_PHONE`, `CLIENT_WEBSITE_URL`, `CLIENT_PORTAL_URL`, `APPROXIMATE_STATS`, and `COMPLIANCE_CONFIG`. Use these in `getDataAwarenessSummary()` instead of hardcoded strings. Also add a new section to the awareness summary about upcoming events (see Feature 3B).

3. **`services/aiEmailService.ts`**: Import `CLIENT_DISPLAY_NAME`, `CLIENT_BRANDING_RULE`, `CLIENT_ADDRESS`, `CLIENT_PHONE`, `CLIENT_SHORT_NAME`. Replace the hardcoded branding block in the system prompts.

---

### FEATURE 3B: Upcoming Events Endpoint & Email Builder Integration

**Why:** The email builder currently has no awareness of real Mainstreet classes and events. Staff writing promotional emails must manually type class names, dates, and URLs. The AMS `apmevent` table already has this data.

**Step 1: New API endpoint**

**File: `server/routes.ts`** â€” add new endpoint:

```typescript
// GET /api/events/upcoming â€” Returns upcoming classes and events from AMS
app.get("/api/events/upcoming", authMiddleware, async (req, res) => {
  if (!externalPool) {
    return res.json({ events: [], dataAvailable: false });
  }
  
  try {
    const client = await externalPool.connect();
    try {
      const limit = Math.min(parseInt(req.query.limit as string) || 50, 100);
      const type = req.query.type as string; // 'class', 'event', or undefined for all
      
      let typeFilter = '';
      if (type === 'class') typeFilter = `AND e."Type" = 'class'`;
      else if (type === 'event') typeFilter = `AND (e."Type" IS NULL OR e."Type" != 'class')`;
      
      const query = `
        WITH event_latest AS (
          SELECT * FROM (
            SELECT e.*, ROW_NUMBER() OVER (
              PARTITION BY e."ApmClientId", e."EventId"
              ORDER BY e."ApmSourceModificationTimestamp" DESC NULLS LAST
            ) AS rn
            FROM "AMS"."apmevent" e
            WHERE e."ApmClientId" = '${CLIENT_ID}'
              AND e."StartDateTime" > NOW()
              AND e."StartDateTime" < NOW() + INTERVAL '90 days'
          ) s WHERE s.rn = 1
        )
        SELECT 
          e."EventId" as event_id,
          e."CourseId" as course_id,
          e."Name" as name,
          e."Type" as event_type,
          e."CourseType" as course_type,
          e."StartDateTime" as start_date_time,
          e."EndDateTime" as end_date_time,
          e."Location" as location,
          e."LocationName" as location_name,
          e."LocationType" as location_type,
          e."MemberPrice" as member_price,
          e."Price" as price,
          e."EducationCredits" as education_credits,
          e."Instructor" as instructor,
          e."MaxAttendees" as max_attendees,
          e."TotalRegisteredAttendees" as registered_attendees,
          e."RegistrationLink" as registration_link,
          e."Categories" as categories,
          e."Desc" as description,
          e."EarlyBirdMemberPrice" as early_bird_member_price,
          e."EarlyBirdEndDate" as early_bird_end_date,
          e."RegistrationCloseDate" as registration_close_date
        FROM event_latest e
        WHERE e."StartDateTime" > NOW()
          ${typeFilter}
        ORDER BY e."StartDateTime" ASC
        LIMIT ${limit}
      `;
      
      const result = await client.query(query);
      
      const events = result.rows.map(row => {
        const spotsRemaining = row.max_attendees 
          ? Math.max(0, parseInt(row.max_attendees) - (parseInt(row.registered_attendees) || 0))
          : null;
          
        return {
          eventId: row.event_id,
          courseId: row.course_id,
          name: row.name,
          eventType: row.event_type,           // 'class' or null/other for events
          courseType: row.course_type,          // 'Core', 'Elective', etc.
          startDateTime: row.start_date_time,
          endDateTime: row.end_date_time,
          location: row.location,
          locationName: row.location_name,
          locationType: row.location_type,     // 'In-Person', 'Online', 'Hybrid'
          memberPrice: row.member_price,
          price: row.price,
          educationCredits: row.education_credits,
          instructor: row.instructor,
          spotsRemaining,
          maxAttendees: row.max_attendees ? parseInt(row.max_attendees) : null,
          registeredAttendees: parseInt(row.registered_attendees) || 0,
          categories: row.categories,
          description: row.description,
          earlyBirdMemberPrice: row.early_bird_member_price,
          earlyBirdEndDate: row.early_bird_end_date,
          registrationCloseDate: row.registration_close_date,
          // Pre-built URLs using EventId
          portalUrl: buildEventPortalUrl(row.event_id),
          publicUrl: buildEventPublicUrl(row.event_id),
        };
      });
      
      res.json({ events, dataAvailable: true });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Upcoming events error:", error);
    res.status(500).json({ events: [], dataAvailable: false, error: "Failed to fetch events" });
  }
});
```

Import `CLIENT_ID`, `buildEventPortalUrl`, `buildEventPublicUrl` from `../services/clientConfig` at the top of routes.ts.

**Step 2: Event Picker in Email Builder**

**File: `client/src/pages/SendEmail.tsx`** â€” Add an "Insert Event" button in the email composition toolbar area. When clicked, it opens a modal/popover that:

1. Fetches `/api/events/upcoming`
2. Displays a searchable/filterable list showing: name, date, type (class/event), CE credits, price, spots remaining
3. When user selects an event, inserts a pre-formatted block into the email body containing:
   - Event name (bold)
   - Date and time
   - Location
   - CE credits (if applicable)
   - Member price
   - Spots remaining (if limited)
   - CTA button linked to the portal URL: `buildEventPortalUrl(eventId)`

The inserted HTML block should use the same styling conventions as the existing email builder (Overpass font, teal CTA button `#3a8a8c`).

**Step 3: AI Email Service Awareness**

**File: `server/services/aiEmailService.ts`** â€” When generating email content, if the email purpose mentions classes, events, CE, education, or similar terms, fetch upcoming events from the database and include them in the AI prompt context. This way the AI can reference real class names, dates, and prices instead of inventing placeholders.

Add a helper function:

```typescript
async function getUpcomingEventsContext(limit: number = 10): Promise<string> {
  if (!externalPool) return '';
  try {
    // Query upcoming events (similar to the API endpoint but simplified)
    const client = await externalPool.connect();
    try {
      const result = await client.query(`
        WITH event_latest AS (
          SELECT * FROM (
            SELECT e.*, ROW_NUMBER() OVER (
              PARTITION BY e."ApmClientId", e."EventId"
              ORDER BY e."ApmSourceModificationTimestamp" DESC NULLS LAST
            ) AS rn
            FROM "AMS"."apmevent" e
            WHERE e."ApmClientId" = '${CLIENT_ID}'
              AND e."StartDateTime" > NOW()
              AND e."StartDateTime" < NOW() + INTERVAL '60 days'
          ) s WHERE s.rn = 1
        )
        SELECT "EventId", "Name", "Type", "CourseType", "StartDateTime",
               "Location", "MemberPrice", "EducationCredits", "Instructor"
        FROM event_latest
        WHERE "StartDateTime" > NOW()
        ORDER BY "StartDateTime" ASC
        LIMIT ${limit}
      `);
      
      if (result.rows.length === 0) return '';
      
      let context = '\n\nUPCOMING REAL EVENTS AND CLASSES (use these in emails â€” do NOT invent fake events):\n';
      for (const row of result.rows) {
        const date = new Date(row.StartDateTime).toLocaleDateString('en-US', { 
          weekday: 'long', month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit'
        });
        context += `- ${row.Name} | ${date} | ${row.Location || 'TBD'} | ${row.MemberPrice ? '$' + row.MemberPrice : 'Free'} | ${row.EducationCredits || '0'} CE credits | Registration: ${buildEventPortalUrl(row.EventId)}\n`;
      }
      context += '\nWhen promoting events, ALWAYS use the portal registration URLs provided above for CTAs.\n';
      return context;
    } finally {
      client.release();
    }
  } catch {
    return '';
  }
}
```

Then in `generateEmail()`, before calling the Anthropic API, check if the purpose/key_points mention events or classes, and if so, append the events context to the system prompt.

Also update the `generateNewsletterStories` function to use this same real data when `topics === 'fetch_from_website'` â€” replace the current fake prompt with real upcoming events.

---

## VERIFICATION CHECKLIST

After implementing all three batches, verify:

- [ ] **Email events:** Check that `memberMetricsCacheService.ts` queries for `'open'` and `'click'` (not `'opened'`/`'clicked'`)
- [ ] **Volume:** Membership Story tier cards show Rainmaker volume significantly larger than Builder volume, and Foundation shows <1% of total production
- [ ] **Office agents:** Analytics overview office agent counts match what's shown on individual office profile pages
- [ ] **Score total:** On any member detail page, manually add up the 6 score breakdown values â€” they should equal the displayed total
- [ ] **Score order:** Member detail score breakdown shows Education & Events first, Email second, Transactions third
- [ ] **Snapshot table:** `membership_daily_snapshot` table exists and gets populated after cache refresh
- [ ] **Client config:** `server/services/clientConfig.ts` exists and is imported by `memberMetricsCacheService.ts` and `sharedDatabaseSchema.ts`
- [ ] **Events API:** `GET /api/events/upcoming` returns upcoming classes/events with portal and public URLs
- [ ] **Event picker:** SendEmail page has an "Insert Event" button that shows real upcoming events
- [ ] **AI awareness:** Generating an email about "upcoming CE classes" references real class names and dates

---

## FILES MODIFIED (Summary)

**New files:**
- `server/services/clientConfig.ts` â€” Client configuration constants (SINGLE SOURCE OF TRUTH)

**Server files modified:**
- `server/services/memberMetricsCacheService.ts` â€” Fix email event types, import from clientConfig, add snapshot function
- `server/services/sharedDatabaseSchema.ts` â€” Import from clientConfig for AI awareness
- `server/services/aiEmailService.ts` â€” Import from clientConfig for branding, add events context
- `server/routes.ts` â€” Fix email event types, fix volume column, fix office agent counts, recalculate score total, add events endpoint
- `server/storage.ts` â€” (minor) Add comment to calculateTransactionScore noting the field name decision
- `shared/schema.ts` â€” Add membership_daily_snapshot table, add comments to EngagementScore interface

**Client files modified:**
- `client/src/pages/MemberDetail.tsx` â€” Reorder score breakdown rows
- `client/src/pages/SendEmail.tsx` â€” Add event picker component

---

## WHAT THIS DOES NOT CHANGE

- Tier assignment logic (Rainmaker/Builder/Foundation thresholds stay the same)
- Scoring formulas (same weights, just read from config instead of inline)
- Dashboard layout or components
- SmartSends functionality
- Authentication or user management
- Any other existing features

This prompt fixes data accuracy issues, adds infrastructure for future trending, creates the foundation for multi-tenancy, and gives the email builder real event awareness with working registration links.

# MemberSync — AI-Powered Member Recognition Emails with Per-Member Personalization

## Date: February 24, 2026
## Priority: High — Current Member Recognition emails are generic templates that don't reference the member's actual achievement

---

## REPLIT STANDING RULES

**These rules apply to this prompt and ALL future prompts for this project. Treat them as permanent.**

### Rule 1: No Parallel Systems
Before building any new UI component, service, or utility function, search the existing codebase for similar functionality. If a component already exists that does 70% or more of what's needed, extend or adapt it with configuration flags rather than creating a new version. Never build a parallel implementation of something that already works. If you are unsure whether to reuse or rebuild, stop and ask before proceeding.

### Rule 2: Don't Break What Works
Before modifying any existing file, understand what it currently does. Run the app and verify the feature works before changing it. After your changes, verify the feature still works. If a prompt asks you to add something new, the existing functionality must continue to work exactly as it did before.

### Rule 3: Full-Page Patterns, Not Modals
This application uses full-page wizard flows for multi-step tasks (Send Email, Create Automation). Do not introduce modal dialogs for tasks that involve more than a single confirmation or a simple input.

### Rule 4: Shared Components Over Duplicates
If two features need similar UI, they must use the same shared component configured with props or flags — not two separate implementations.

### Rule 5: Server-Side for Scale
Any operation that could involve more than 1,000 records must happen on the server, not the client.

### Rule 6: Test Your Work
After implementing changes, verify them yourself before marking complete. Check both the happy path and at least one edge case.

---

## NAMING CONVENTION NOTE

The user-facing name for this feature is **"Member Recognition"** — this is what appears in the UI, in button labels, and in any text the staffer sees. However, the internal codebase still uses the older name "celebration" in many places — variable names like `celebrationAudience`, endpoint paths like `/api/celebrations/generate-email`, and interface names like `CelebrationMilestone`. 

**Do NOT rename the internal code in this prompt.** Keep all existing variable names, endpoint paths, and interface names exactly as they are. Only ensure that any NEW user-facing text (labels, banners, toast messages, descriptions) uses "Member Recognition" or "recognition" — never "celebration." A full code rename will happen in a separate future prompt.

---

## THE PROBLEM

When a staffer clicks "Send" on a Member Recognition tile (e.g., "Niche Specialists — 1,313 members"), the system generates a hardcoded, generic email from a `switch` statement in routes.ts. The current emails say things like:

> "Congratulations on establishing yourself as a specialist in your niche! Your focused expertise sets you apart in the market..."

This email has three problems:

1. **It's generic.** Every member in the category gets the identical email. A Listing Specialist who closed 85% of their 47 deals on the listing side gets the same email as a Buyer Specialist with 90% of 12 deals on the buyer side.

2. **It doesn't reference the actual achievement.** The milestone detection service already knows each member's specific milestone — their value, label, percentage, volume, city, property type. None of this data reaches the email.

3. **The staffer has no visibility into what the category means.** The recognition tile says "Niche Specialists — 1,313 members this week" but doesn't explain what makes someone a Niche Specialist. The staffer can't evaluate whether the email is appropriate because they don't understand the criteria.

---

## THE SOLUTION: FOUR-PART CHANGE

### Part 1: Replace hardcoded templates with AI generation
### Part 2: Create per-member merge fields from milestone data
### Part 3: Give the staffer a category summary on the compose screen
### Part 4: Enrich the Member Recognition tiles with brief descriptions

---

## PART 1: Replace Hardcoded Templates with AI Generation

### What to change

Replace the `POST /api/celebrations/generate-email` endpoint in `server/routes.ts`. The current implementation is a `switch` statement with hardcoded HTML for each milestone type. Replace it with an AI-powered generation that uses the actual milestone data.

### New endpoint behavior

The endpoint already receives `milestoneType`, `milestoneLabel`, `memberCount`, and optionally `senderName`. Add a new required field: `milestoneSummary`.

**The caller (SendEmail.tsx) will pass a summary of the milestone data.** This summary is built from the members' `milestoneValue`, `milestoneLabel`, and `contextJson` fields to give the AI real context about what this category contains.

### New endpoint implementation

Replace the entire `switch` block with an AI call using the existing `callAnthropicWithRetry` pattern from `aiEmailService.ts`.

```typescript
app.post("/api/celebrations/generate-email", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  try {
    const { milestoneType, milestoneLabel, memberCount, senderName, milestoneSummary } = req.body;

    if (!milestoneType || !milestoneLabel) {
      return res.status(400).json({ message: "Milestone type and label are required" });
    }

    // Import what we need
    const { callAnthropicWithRetry } = await import('./services/aiEmailService');
    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const anthropic = new Anthropic();
    const { CLIENT_DISPLAY_NAME, CLIENT_BRANDING_RULE } = await import('./services/clientConfig');

    // Import the MAINSTREET_BRIEFING from aiEmailService
    // NOTE: You'll need to export MAINSTREET_BRIEFING from aiEmailService.ts (see Part 1 note below)
    const { MAINSTREET_BRIEFING, EMAIL_STYLE_GUIDELINES, AVAILABLE_MERGE_FIELDS: BASE_MERGE_FIELDS } = await import('./services/aiEmailService');

    const celebrationMergeFields = `
Available RECOGNITION-SPECIFIC merge fields (use these IN ADDITION to the standard merge fields):
- {{MilestoneLabel}} - The member's specific milestone (e.g., "50th career transaction", "Listing Specialist - 85% of deals")
- {{MilestoneValue}} - The raw milestone value (e.g., "50", "listing", "$25,000,000")
- {{MilestoneDetail}} - A human-readable detail line (e.g., "with $12.5M in career volume", "primarily in Downers Grove")

IMPORTANT: Use {{MilestoneLabel}} in the email to reference the member's specific achievement. 
Each recipient's merge fields will be personalized — you are writing ONE email template, but 
each recipient will see their own milestone data. So write the email as if speaking to one person 
about THEIR achievement, using the merge fields. The merge fields will be different for each recipient.
`;

    let signature = "";
    if (senderName) {
      signature = `Sign off as: ${senderName}, ${CLIENT_DISPLAY_NAME}`;
    } else {
      signature = `Sign off as: The ${CLIENT_DISPLAY_NAME} Team`;
    }

    const message = await callAnthropicWithRetry(anthropic, {
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      system: `You are a skilled email copywriter for ${CLIENT_DISPLAY_NAME}. You write member recognition emails that feel personal, specific, and genuinely warm.

${MAINSTREET_BRIEFING}

${EMAIL_STYLE_GUIDELINES}

${BASE_MERGE_FIELDS}

${celebrationMergeFields}

IMPORTANT BRANDING:
- ${CLIENT_BRANDING_RULE}
- Do NOT include a copyright notice, footer, or unsubscribe link in the email body. These are added automatically by the email template.
- The current year is 2026. Never reference 2024 or 2025 as the current year.
- ${signature}

Return ONLY valid JSON (no markdown, no preamble) with this structure:
{
  "subject": "Email subject line — personal and specific, under 60 chars",
  "body": "HTML email body using merge fields for personalization",
  "preview_text": "Preview text under 100 chars"
}`,
      messages: [{
        role: 'user',
        content: `Write a member recognition email for ${CLIENT_DISPLAY_NAME} members.

MILESTONE CATEGORY: ${milestoneLabel}
MILESTONE TYPE: ${milestoneType}
NUMBER OF RECIPIENTS: ${memberCount}

CATEGORY DETAILS:
${milestoneSummary || 'No additional details available.'}

REQUIREMENTS:
- Start with "Dear {{FirstName}}," or "Hi {{FirstName}},"
- Reference their SPECIFIC achievement using {{MilestoneLabel}} — this is the key personalization
- Include {{MilestoneDetail}} where it fits naturally — this adds specificity
- Make it feel like the association genuinely noticed something about THIS person
- Keep it warm, specific, and concise — 3-4 short paragraphs max
- ONE call-to-action button if appropriate (e.g., "View Your Profile", "Explore Upcoming Events")
- Do NOT use generic phrases like "your outstanding achievement" or "your hard work and dedication" — be SPECIFIC about what they achieved using the merge fields
- The tone should feel like a warm colleague noticing something impressive, not a form letter
- Do NOT reference specific numbers unless using a merge field — the merge field values vary per recipient

ANTI-PATTERNS (do not write emails like this):
- "We are thrilled to recognize your outstanding achievement!" — too generic
- "Your hard work and dedication continue to make a positive impact" — says nothing specific
- "Congratulations on this well-deserved recognition" — corporate filler

GOOD PATTERNS:
- "{{MilestoneLabel}} — that's something worth celebrating." — direct and specific
- "We noticed something impressive: {{MilestoneLabel}}. {{MilestoneDetail}}." — shows the association is paying attention
- Reference what this milestone means for their career or their clients, not just that it happened
`
      }]
    });

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    const cleanJson = responseText.replace(/\`\`\`json\n?/g, '').replace(/\`\`\`\n?/g, '').trim();
    const result = JSON.parse(cleanJson);

    res.json(result);
  } catch (error) {
    console.error("Error generating member recognition email:", error);
    
    // Fallback to a simple but decent template if AI fails
    const signature = req.body.senderName 
      ? `<p>Warm regards,<br/>${req.body.senderName}<br/>Mainstreet REALTORS®</p>`
      : `<p>Warm regards,<br/>The Mainstreet REALTORS® Team</p>`;
    
    res.json({
      subject: `Recognizing Your ${req.body.milestoneLabel || 'Achievement'}!`,
      body: `<p>Dear {{FirstName}},</p>
<p>We wanted to take a moment to recognize you for {{MilestoneLabel}}. {{MilestoneDetail}}</p>
<p>Achievements like yours are what make our community strong. Thank you for being part of Mainstreet REALTORS®.</p>
${signature}`,
      preview_text: `Recognizing your ${(req.body.milestoneLabel || 'achievement').toLowerCase()}!`,
    });
  }
});
```

### Export constants from aiEmailService.ts

The `MAINSTREET_BRIEFING`, `EMAIL_STYLE_GUIDELINES`, and `AVAILABLE_MERGE_FIELDS` constants in `aiEmailService.ts` are currently not exported. Add `export` to each of them:

```typescript
// Change these from:
const MAINSTREET_BRIEFING = `...`;
const EMAIL_STYLE_GUIDELINES = `...`;
const AVAILABLE_MERGE_FIELDS = `...`;

// To:
export const MAINSTREET_BRIEFING = `...`;
export const EMAIL_STYLE_GUIDELINES = `...`;
export const AVAILABLE_MERGE_FIELDS = `...`;
```

This allows the Member Recognition email endpoint to reuse the same brand voice and style guidelines without duplicating them.

---

## PART 2: Create Per-Member Merge Fields from Milestone Data

### The concept

Each member in a Member Recognition audience has milestone-specific data (`milestoneValue`, `milestoneLabel`, `contextJson`). When the email is actually sent, these need to become merge fields that get personalized per recipient — just like `{{FirstName}}` gets replaced with each person's name.

### New merge fields

Add three Member Recognition merge fields that get populated from the milestone data:

| Merge Field | Source | Example Value |
|---|---|---|
| `{{MilestoneLabel}}` | `milestoneLabel` from milestone data | "50th career transaction", "Listing Specialist - 85% of deals" |
| `{{MilestoneValue}}` | `milestoneValue` | "50", "listing", "$25,000,000" |
| `{{MilestoneDetail}}` | Generated from `contextJson` (see below) | "with $12.5M in career volume", "primarily in Downers Grove" |

### How to generate MilestoneDetail from contextJson

Create a helper function in `server/routes.ts` (or a small utility) that converts `contextJson` into a human-readable detail string:

```typescript
function buildMilestoneDetail(milestoneType: string, contextJson: Record<string, any>): string {
  if (!contextJson) return '';
  
  switch (milestoneType) {
    case 'transaction_milestone':
      return contextJson.careerVolume 
        ? `with ${formatVolume(contextJson.careerVolume)} in career volume` 
        : '';
    case 'volume_milestone':
      return contextJson.careerTransactions 
        ? `across ${contextJson.careerTransactions} career transactions` 
        : '';
    case 'membership_anniversary':
      return contextJson.yearsAsMember 
        ? `${contextJson.yearsAsMember} years as a Mainstreet member` 
        : '';
    case 'listing_milestone':
      return contextJson.totalSides 
        ? `out of ${contextJson.totalSides} total transaction sides` 
        : '';
    case 'buyer_milestone':
      return contextJson.totalSides 
        ? `helping ${contextJson.totalSides} clients find their homes` 
        : '';
    case 'top_producer':
      return [
        contextJson.totalSides ? `${contextJson.totalSides} sides` : '',
        contextJson.volume ? formatVolume(contextJson.volume) + ' in volume' : '',
      ].filter(Boolean).join(', ');
    case 'rookie_star':
      return contextJson.monthsActive 
        ? `in just ${contextJson.monthsActive} months` 
        : '';
    case 'comeback':
      return contextJson.recentSides 
        ? `with ${contextJson.recentSides} recent transactions` 
        : '';
    case 'specialization':
      return [
        contextJson.city ? `primarily in ${contextJson.city}` : '',
        contextJson.propertyType ? `focusing on ${contextJson.propertyType}` : '',
      ].filter(Boolean).join(', ');
    case 'first_million':
      return contextJson.avgPrice 
        ? `averaging ${formatVolume(contextJson.avgPrice)} per transaction` 
        : '';
    case 'luxury_entry':
      return contextJson.luxuryTransactions 
        ? `with ${contextJson.luxuryTransactions} luxury transaction${contextJson.luxuryTransactions > 1 ? 's' : ''} this year` 
        : '';
    default:
      return '';
  }
}

function formatVolume(value: number): string {
  if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `$${Math.round(value / 1000)}K`;
  return `$${value.toFixed(0)}`;
}
```

### Where merge field replacement happens

The standard merge fields like `{{FirstName}}` and `{{OfficeName}}` are replaced in **`emailService.ts`** during `processEmailQueue`. This is where ALL merge field replacement happens — it's the single point where email bodies get personalized before sending.

**Add the three new milestone merge fields to the existing replacement block in `emailService.ts`.** This is a small, targeted addition — roughly 5 lines — alongside the existing `{{FirstName}}`, `{{OfficeName}}`, etc. replacements. Look for the block where merge fields are replaced per recipient, and add:

```typescript
// In emailService.ts, in the merge field replacement block within processEmailQueue:
// Add milestone merge fields for Member Recognition campaigns
if (campaign.celebrationInfo?.milestones) {
  const milestone = campaign.celebrationInfo.milestones.find(m => m.memberKey === recipientMemberKey);
  if (milestone) {
    body = body.replace(/\{\{MilestoneLabel\}\}/g, milestone.milestoneLabel || '');
    body = body.replace(/\{\{MilestoneValue\}\}/g, milestone.milestoneValue || '');
    body = body.replace(/\{\{MilestoneDetail\}\}/g, buildMilestoneDetail(milestone.milestoneType || campaign.celebrationInfo.milestoneType, milestone.contextJson || {}));
    subject = subject.replace(/\{\{MilestoneLabel\}\}/g, milestone.milestoneLabel || '');
    subject = subject.replace(/\{\{MilestoneValue\}\}/g, milestone.milestoneValue || '');
  }
}
```

The `buildMilestoneDetail` helper function (defined in Part 2 above) should be placed in a shared location that `emailService.ts` can import — either export it from `routes.ts` as a utility, or better yet, create it as a small helper in the milestone detection service and export it from there.

**NOTE:** This is the one exception to the "Do NOT modify emailService.ts" rule below. This change is a small addition to the existing merge field replacement block — not a structural change. Do not modify anything else in emailService.ts.

**IMPORTANT:** The milestone data per member needs to be available at send time. Currently, `celebrationInfo.milestones` is passed from the frontend and stored with the campaign. Each milestone object needs to include `contextJson` in addition to the fields it already carries (`memberKey`, `memberName`, `memberEmail`, `milestoneValue`, `milestoneEmoji`).

### Changes to SendEmail.tsx — include contextJson in milestone data

In the `useEffect` that fetches milestone members (around line 198-226), the current code maps members but does NOT include `milestoneLabel` or `contextJson`. Fix this:

```typescript
// CURRENT (around line 210-216):
milestones: data.members.map((m: any) => ({
  memberKey: m.memberKey,
  memberName: m.memberName,
  memberEmail: m.memberEmail,
  milestoneValue: m.milestoneValue,
  milestoneEmoji: m.milestoneEmoji,
})),

// CHANGE TO:
milestones: data.members.map((m: any) => ({
  memberKey: m.memberKey,
  memberName: m.memberName,
  memberEmail: m.memberEmail,
  milestoneValue: m.milestoneValue,
  milestoneLabel: m.milestoneLabel,
  milestoneEmoji: m.milestoneEmoji,
  contextJson: m.contextJson || {},
})),
```

Similarly, update the `CelebrationMilestone` interface (around line 92-98) to include:
```typescript
interface CelebrationMilestone {
  memberKey: string;
  memberName: string;
  memberEmail: string;
  milestoneValue: string;
  milestoneLabel?: string;     // ADD
  milestoneEmoji?: string;
  contextJson?: Record<string, any>;  // ADD
}
```

---

## PART 3: Give the Staffer a Category Summary on the Compose Screen

### Build the milestoneSummary for the AI

When `generateCelebrationMutation.mutate()` is called (around line 749 in SendEmail.tsx), it currently sends `milestoneType`, `milestoneLabel`, and `memberCount`. Add a `milestoneSummary` field that aggregates the milestone data so the AI knows what it's writing about.

Build the summary from the loaded milestone members:

```typescript
function buildMilestoneSummary(milestones: CelebrationMilestone[]): string {
  if (!milestones || milestones.length === 0) return '';
  
  const lines: string[] = [];
  
  // Count distinct milestone values
  const valueCounts = new Map<string, number>();
  for (const m of milestones) {
    const label = m.milestoneLabel || m.milestoneValue || 'unknown';
    valueCounts.set(label, (valueCounts.get(label) || 0) + 1);
  }
  
  lines.push(`This category contains ${milestones.length} members with the following breakdown:`);
  
  // Sort by count descending, show top 10 distinct values
  const sorted = Array.from(valueCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10);
  for (const [label, count] of sorted) {
    lines.push(`- ${label}: ${count} member${count !== 1 ? 's' : ''}`);
  }
  
  if (valueCounts.size > 10) {
    lines.push(`- ... and ${valueCounts.size - 10} more distinct milestone levels`);
  }
  
  // Sample some contextJson data to give the AI flavor
  const withContext = milestones.filter(m => m.contextJson && Object.keys(m.contextJson).length > 0);
  if (withContext.length > 0) {
    const sample = withContext.slice(0, 3);
    lines.push('');
    lines.push('Example member context (to understand the data, NOT to reference specific members):');
    for (const m of sample) {
      lines.push(`- ${m.milestoneLabel}: ${JSON.stringify(m.contextJson)}`);
    }
  }
  
  return lines.join('\n');
}
```

Then update the mutation call:

```typescript
// CURRENT (around line 749):
generateCelebrationMutation.mutate({
  milestoneType: celebrationAudience.type,
  milestoneLabel: celebrationAudience.label,
  memberCount: celebrationAudience.milestones.length,
});

// CHANGE TO:
generateCelebrationMutation.mutate({
  milestoneType: celebrationAudience.type,
  milestoneLabel: celebrationAudience.label,
  memberCount: celebrationAudience.milestones.length,
  milestoneSummary: buildMilestoneSummary(celebrationAudience.milestones),
});
```

Also update the mutation type to include `milestoneSummary?: string`.

### Show a category insight banner on the Compose screen

On the Compose step, when a Member Recognition audience is loaded, show a summary card that helps the staffer understand what they're sending. Find the celebration audience banner (around line 2247-2263 in the compose step) and enhance it.

**Current banner shows:**
> 🎉 [Audience Name] — [count] members

**Enhanced banner should show:**
> 🎉 **Niche Specialists** — 1,313 members
> Members with 80%+ concentration in either listings or buyer representation.
> 789 Listing Specialists · 524 Buyer Specialists
> *Email will be personalized with each member's specific milestone.*

The breakdown data comes from the same `milestoneSummary` logic. Create a simpler version for display:

```typescript
function buildMilestoneDisplaySummary(milestones: CelebrationMilestone[]): { breakdown: string; personalizationNote: string } {
  if (!milestones || milestones.length === 0) return { breakdown: '', personalizationNote: '' };
  
  const valueCounts = new Map<string, number>();
  for (const m of milestones) {
    const label = m.milestoneLabel || m.milestoneValue || 'Achievement';
    valueCounts.set(label, (valueCounts.get(label) || 0) + 1);
  }
  
  const sorted = Array.from(valueCounts.entries()).sort((a, b) => b[1] - a[1]);
  const distinctCount = sorted.length;
  
  let breakdown = '';
  if (distinctCount === 1) {
    breakdown = `All ${milestones.length} members: ${sorted[0][0]}`;
  } else if (distinctCount <= 5) {
    breakdown = sorted.map(([label, count]) => `${count} ${label}`).join(' · ');
  } else {
    const top3 = sorted.slice(0, 3);
    breakdown = top3.map(([label, count]) => `${count} ${label}`).join(' · ') + ` · +${distinctCount - 3} more`;
  }
  
  const personalizationNote = distinctCount > 1
    ? `Each member's email will reference their specific milestone using personalized merge fields.`
    : `All members share the same milestone — the email will still reference it by name.`;
  
  return { breakdown, personalizationNote };
}
```

Display this below the existing Member Recognition banner on the Compose step. Use a subtle info row — not a separate card:

```tsx
{celebrationAudience && selectedAudience && (() => {
  const summary = buildMilestoneDisplaySummary(celebrationAudience.milestones);
  return summary.breakdown ? (
    <div className="text-xs text-muted-foreground mt-2 space-y-1">
      <p>{summary.breakdown}</p>
      <p className="italic">{summary.personalizationNote}</p>
    </div>
  ) : null;
})()}
```

---

## PART 4: Enrich Member Recognition Tiles with Brief Descriptions

### Add category descriptions to the milestones API response

In `milestoneDetectionService.ts`, add a `description` field to each `MilestoneCategory`. This is a brief, staffer-friendly explanation of what the category means — so the staffer understands what they're looking at before clicking Send.

Update the `MilestoneCategory` interface:

```typescript
interface MilestoneCategory {
  type: string;
  label: string;
  description: string;  // ADD THIS
  milestones: MilestoneResult[];
  totalCount: number;
}
```

Update the `pushCategory` helper:

```typescript
function pushCategory(type: string, label: string, description: string, filtered: MilestoneResult[]) {
  if (filtered.length > 0) {
    categories.push({
      type,
      label,
      description,
      milestones: type === fullDetailType ? filtered : filtered.slice(0, 5),
      totalCount: filtered.length,
    });
  }
}
```

Update each `pushCategory` call to include a description:

```typescript
pushCategory('transaction_milestone', 'Transaction Milestones', 
  'Members who recently crossed a career transaction milestone (10, 25, 50, 100+ closings)',
  filteredTransactions);

pushCategory('volume_milestone', 'Volume Milestones', 
  'Members who crossed a career sales volume milestone ($1M, $5M, $10M+)',
  filteredVolume);

pushCategory('membership_anniversary', 'Mainstreet Anniversaries', 
  'Members celebrating their Mainstreet REALTORS® membership anniversary this week',
  filteredAnniversaries);

pushCategory('listing_milestone', 'Listing Milestones', 
  'Members who reached a career listing-side milestone',
  filteredListings);

pushCategory('buyer_milestone', 'Buyer Milestones', 
  'Members who reached a career buyer-side milestone',
  filteredBuyers);

pushCategory('top_producer', 'Top Producers This Month', 
  'Highest-producing agents by transaction volume this month',
  filteredTopProducers);

pushCategory('rookie_star', 'Rising Stars', 
  'New members (under 2 years) who are outperforming expectations',
  filteredRookies);

pushCategory('comeback', 'Back in Action', 
  'Members who had no activity for 6+ months and recently closed a transaction',
  filteredComebacks);

pushCategory('specialization', 'Niche Specialists', 
  'Members with 80%+ of their deals concentrated on one side (listings or buyers)',
  filteredSpecializations);

pushCategory('first_million', 'First Million-Dollar Sale', 
  'Members who recently closed their first transaction over $1M',
  filteredFirstMillions);

pushCategory('luxury_entry', 'Luxury Market Entry', 
  'Members who are new to the luxury market (1-3 transactions over $1M)',
  filteredLuxury);
```

### Show the description in MemberRecognition.tsx

Update the `MilestoneCategory` interface in `MemberRecognition.tsx` to include `description`:

```typescript
interface MilestoneCategory {
  type: string;
  label: string;
  description: string;  // ADD
  milestones: MilestoneResult[];
  totalCount: number;
}
```

In the recognition tile rendering, add the description as a second line of muted text below the member count:

```tsx
<p className="text-[11px] text-muted-foreground">
  {category.totalCount.toLocaleString()} member{category.totalCount !== 1 ? 's' : ''} this week
</p>
{category.description && (
  <p className="text-[10px] text-muted-foreground/70 leading-tight mt-0.5">
    {category.description}
  </p>
)}
```

This way, a staffer looking at the Member Recognition tile can see: "Niche Specialists — 1,313 members this week — Members with 80%+ of their deals concentrated on one side (listings or buyers)." They understand what they're about to send before clicking.

---

## FILES TO MODIFY

**Backend:**
- `server/routes.ts` — Replace hardcoded recognition email generation with AI-powered generation; add `buildMilestoneDetail` helper; update recognition send flow to replace milestone merge fields per recipient
- `server/services/aiEmailService.ts` — Export `MAINSTREET_BRIEFING`, `EMAIL_STYLE_GUIDELINES`, and `AVAILABLE_MERGE_FIELDS` constants (add `export` keyword, no other changes)
- `server/services/milestoneDetectionService.ts` — Add `description` field to `MilestoneCategory` interface and all `pushCategory` calls

**Frontend:**
- `client/src/pages/SendEmail.tsx` — Include `milestoneLabel` and `contextJson` in milestone member mapping; add `milestoneSummary` to celebration generation call; add `buildMilestoneSummary` and `buildMilestoneDisplaySummary` helpers; enhance celebration banner on compose step
- `client/src/components/dashboard/MemberRecognition.tsx` — Update `MilestoneCategory` interface; show `description` on recognition tiles

**Do NOT modify:**
- `shared/schema.ts`
- `triggeredCampaignProcessor.ts`
- `emailService.ts` — **EXCEPTION:** Add milestone merge field replacement to the existing merge field block in `processEmailQueue` (see Part 2: "Where merge field replacement happens"). No other changes to this file.
- `scheduledEmailProcessor.ts`

---

## VERIFICATION CHECKLIST

### AI Email Generation
- [ ] Click Send on any Member Recognition tile → email is generated by AI, not hardcoded
- [ ] Generated email references `{{MilestoneLabel}}` — not generic phrases
- [ ] Generated email includes `{{MilestoneDetail}}` where appropriate
- [ ] Subject line is specific (not "Congratulations on Your Achievement!")
- [ ] Email tone matches Mainstreet voice — warm, specific, not corporate
- [ ] If AI generation fails, the fallback template still uses `{{MilestoneLabel}}` merge fields
- [ ] Generation works for all 11 milestone types (transaction, volume, anniversary, listing, buyer, top_producer, rookie_star, comeback, specialization, first_million, luxury_entry)

### Per-Member Personalization
- [ ] When previewing the email, merge fields show as `{{MilestoneLabel}}` (not replaced yet — that happens at send time)
- [ ] When actually sent, each recipient's email has their specific milestone label (not the generic category label)
- [ ] `{{MilestoneDetail}}` is replaced with context-specific text (e.g., "primarily in Downers Grove" for specialization)
- [ ] Members with empty contextJson get graceful fallback (empty string, not "undefined")

### Staffer Visibility
- [ ] Compose screen shows breakdown: "789 Listing Specialists · 524 Buyer Specialists" (or similar)
- [ ] Compose screen shows personalization note: "Each member's email will reference their specific milestone..."
- [ ] Recognition tiles on Dashboard show the category description below the member count
- [ ] Descriptions are concise — one line, not a paragraph

### Existing Functionality
- [ ] Regular (non-recognition) email sending still works
- [ ] Milestone detection still works (dashboard loads Member Recognition tiles)
- [ ] Recognition tracking/recording still works (sent recognitions are recorded in member_milestones)
- [ ] The `/api/milestones/:type/members` endpoint still returns full member lists
- [ ] Sender selection on recognition emails still works
- [ ] Recent recognition duplicate check still works

---

## ARCHITECTURAL NOTE FOR FUTURE REFERENCE

This prompt improves Member Recognition emails within the existing milestone detection system. A future evolution will replace the fixed-threshold milestone detection with AI-powered relative achievement detection — recognizing when a member has done something noteworthy *relative to their own history* rather than hitting a predefined number. That work will be a separate design effort and set of prompts. The merge field infrastructure built here ({{MilestoneLabel}}, {{MilestoneValue}}, {{MilestoneDetail}}) is designed to work with any future detection system — the field names are generic enough to carry whatever achievement description the system produces.

Additionally, the milestone categories and their thresholds will become per-client configurable when multi-tenant architecture is implemented. The `description` field added to milestone categories in this prompt establishes the pattern for client-customizable category metadata.

---

*This prompt replaces generic "Congratulations!" templates with personalized, AI-generated Member Recognition emails that reference each member's actual achievement. The association staffer sees what they're sending and why. The member receiving the email feels like their organization genuinely noticed them.*

# MemberSync Dashboard â€” Targeted Fixes Round 2
## February 19, 2026

---

## CONTEXT FOR REPLIT AGENT

The dashboard cleanup is 90% there. Three specific issues remain. These are surgical fixes â€” do NOT restructure anything else.

---

## FIX 1: Celebrations Sidebar Creates Empty Gap

**Problem:** The Celebrations sidebar has 5 category cards that extend well below the Activity Feed, creating a large empty gap in the left column. The layout looks broken.

**Fix:** Constrain the Celebrations sidebar to a max height that roughly matches the Activity Feed, and make it scroll internally.

In `CelebrationInsights.tsx`, wrap the list of celebration category cards in a ScrollArea (from shadcn) with a max height:

```tsx
import { ScrollArea } from "@/components/ui/scroll-area";
```

Wrap the cards container (the part that maps over celebration categories) in:
```tsx
<ScrollArea className="max-h-[480px]">
  {/* existing celebration category cards */}
</ScrollArea>
```

The `max-h-[480px]` should roughly match the Activity Feed height with 5 items. If the Celebrations section has more cards than fit, users scroll within the sidebar. This prevents the sidebar from pushing the layout down.

Also, make each celebration card more compact to fit more in the visible area. The member name lists are wrapping and taking too much space. Truncate the member names list to a single line with overflow hidden:

Find where member names are rendered in each celebration card and add `truncate` or `line-clamp-2` to limit the text:

```tsx
<p className="text-xs text-muted-foreground line-clamp-2">
  {celebration.members.join(' | ')}
</p>
```

Use `line-clamp-2` (Tailwind utility) to show at most 2 lines of member names, with the "+X more" at the end.

---

## FIX 2: Membership Card â€” Restore Month-over-Month Percentage

**Problem:** The Membership card subtitle currently shows "110 new members this month" but has lost the month-over-month comparison percentage (-46%). That percentage is critical context â€” it tells the executive whether the pace of new members is accelerating or slowing.

**Fix in `Dashboard.tsx`:** The Membership card subtitle must include both the count AND the percentage:

```tsx
<MetricCard
  title="Membership"
  value={metrics.totalActiveMembers.total}
  subtitle={`${metrics.associationPulse?.newMembersThisMonth || 0} new this month${
    metrics.associationPulse?.newMemberGrowthPct !== null && metrics.associationPulse?.newMemberGrowthPct !== undefined
      ? ` (${metrics.associationPulse.newMemberGrowthPct > 0 ? "+" : ""}${metrics.associationPulse.newMemberGrowthPct}% month over month)`
      : ""
  }`}
  subtitleClassName="text-sm font-medium"
  icon={Users}
  variant="default"
  testId="card-membership"
  breakdown={[
    { label: "Rainmaker", value: metrics.totalActiveMembers.activeProducers, variant: "amber" },
    { label: "Builder", value: metrics.totalActiveMembers.occasionalProducers, variant: "blue" },
    { label: "Foundation", value: metrics.totalActiveMembers.licenseMaintainers, variant: "emerald" },
  ]}
  onClick={() => setLocation("/members")}
/>
```

The result should read: **"110 new this month (-46% month over month)"** â€” all in one subtitle line, in the larger font from the `subtitleClassName` prop.

---

## FIX 3: Tier Cards â€” Clean Up Content and Fix Encoding

**Problem:** Three issues with the Mainstreet Community tier cards:

**A. Unicode encoding issue:** The middle dot character (Â·) is rendering as a literal `\u00B7` in some places. This is a string encoding problem. Make sure all middle dots in the tier card text use the actual Unicode character `Â·` (copy-paste this character) or use a template literal with the HTML entity, NOT the escape sequence `\u00B7`.

Search the MainstreetCommunity component for any instance of `\u00B7` and replace with the literal character `Â·`.

**B. Redundant content blocks:** Each tier card currently shows:
1. An insight text block (e.g., "14% connected Â· avg 78 sides per agent")
2. A separate volume highlight box below it (e.g., "78 avg sides per agent Â· $27M avg production")

These are saying the same thing twice. **Remove the separate volume highlight box.** Each tier card should have ONE colored highlight block â€” the insight text â€” not two.

The structure of each tier card should be exactly:
```
[Color band]
[Icon] Tier Name                Count (%)
Persona description line 1
Persona detail line 2

[Colored insight block â€” ONE BLOCK ONLY]
  Tier-specific insight text

[Four signal indicators: Edu | Events | Email | Avg Sides]
```

**C. Foundation card still shows dollar volume:** The Foundation highlight box should NOT show dollar volume amounts. The Foundation card's insight block should read something like:

"12,286 members have limited association interaction Â· 13% connected"

And the volume box that says "$5.2B volume Â· 18% of total" should be REMOVED entirely from Foundation. Foundation's value is in dues and community, not production volume.

### Specific content for each tier's single insight block:

**Rainmaker:**
```
14% connected Â· avg 78 sides per agent
Top 914 agents (5%) control 49% of all volume
```

**Builder:**
```
20% engaged in education or events Â· 14% connected
The growth engine â€” 3,896 agents building their businesses
```

**Foundation:**
```
12,286 members have limited association interaction
Your financial foundation â€” 77% of membership sustaining the organization through dues
```

Each block should use the tier's highlight color (amber for Rainmaker, blue for Builder, emerald for Foundation) and `text-xs font-medium` for the primary line with `text-[11px] text-muted-foreground` for the secondary line.

---

## VERIFICATION CHECKLIST

- [ ] Celebrations sidebar scrolls internally â€” no empty gap next to Activity Feed
- [ ] Membership card reads "110 new this month (-46% month over month)" in prominent text
- [ ] No `\u00B7` literal text visible anywhere on the dashboard
- [ ] Each tier card has exactly ONE colored insight block (not two)
- [ ] Foundation card shows NO dollar volume amount
- [ ] Rainmaker insight shows connected % + avg sides + concentration stat
- [ ] Builder insight shows education/event engagement + growth engine tagline
- [ ] Foundation insight shows limited interaction count + dues value tagline
- [ ] Mobile layout still works

---

## FILES CHANGED

- `client/src/components/dashboard/CelebrationInsights.tsx` â€” ScrollArea wrapper, compact member names
- `client/src/pages/Dashboard.tsx` â€” Membership card subtitle with percentage restored
- `client/src/components/dashboard/MainstreetCommunity.tsx` â€” Single insight block per tier, fix encoding, remove Foundation volume

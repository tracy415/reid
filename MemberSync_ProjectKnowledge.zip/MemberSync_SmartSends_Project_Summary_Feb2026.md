# MemberSync / SmartSends â€” Complete Project Summary
## As of February 13, 2026

This document captures all decisions, architecture, schemas, what has been built, what is in progress, and what is next. Use this to resume work in a new conversation.

---

# TABLE OF CONTENTS

1. Project Overview
2. Client and Membership Context
3. Technical Architecture
4. What Has Been Built (Phases 1-3)
5. Current Replit Database Schema
6. Production Database Schema (Read-Only)
7. Daily Jobs Schedule
8. AI Services Architecture
9. SmartSends Audience Builder Improvements (READY TO BUILD)
10. Triggered Campaign Engine (READY TO BUILD)
11. Lapse Prevention System (NEXT TO BUILD)
12. Billing Calendar and Charge Codes
13. Phase 4 Preview: Broker Module
14. Bookmarked Future Ideas
15. Key Files and Replit Prompts

---

# 1. PROJECT OVERVIEW

## What We Are Building

MemberSync is a member engagement and retention platform built by Membio for real estate associations and MLSs. SmartSends is the email marketing and automation layer within MemberSync. The first client is Mainstreet REALTORS, a trade association with approximately 19,000 active members and approximately 2,800 offices in the Chicago suburbs.

The platform uses predictive analytics to help association executives retain and engage members by analyzing residential real estate listings and association management system (AMS) data.

## Build Philosophy

Tracy (founder of Membio) is a non-technical business leader building exclusively with AI tools:
- Claude for strategy, specifications, and Replit prompts
- Julius.AI for SQL development against the production database
- Replit Agent for all coding implementation

Technical specifications are split into manageable prompts for Replit. Each prompt is self-contained with enough context for Replit to implement without breaking existing functionality. The prompts explicitly reference existing code by filename and function name.

## Phase Status

| Phase | Status | Description |
|-------|--------|-------------|
| Phase 1 | Complete | Email infrastructure, tracking, templates, SendGrid integration |
| Phase 2 | Complete | AI-powered audience building, email composition, CSV upload |
| Phase 3 Parts 1-5 | Complete | Performance analytics, celebration engine, engagement scoring, member profiles |
| Phase 3 Part 6 | Complete | Analytics dashboard, office leaderboards, agent production, PDF generation |
| Audience Builder Improvements | Prompt Written | Inline creation, Picklist audiences, Member/Bill Type audiences |
| Triggered Campaign Engine | Prompt Written | Automated emails on data events, sequences, send windows |
| Lapse Prevention System | Next to Build | Status tracking, calendar-aware risk scoring, intervention management |
| Phase 4: Broker Module | Planned | Broker liability dashboard, office management |

---

# 2. CLIENT AND MEMBERSHIP CONTEXT

## Mainstreet REALTORS

- Approximately 19,000 active members (agents, brokers, appraisers, affiliates)
- Approximately 2,800 offices in the Chicago suburbs
- Three-tier member classification:
  - Active Producers: Closed transactions in last 12 months
  - Occasional Producers: Transactions in 12-24 months but not last 12
  - License Maintainers: No transactions in 1-3+ years, but still paying dues (50-70% of membership)

## Member Associations (16 within Mainstreet)

Mainstreet AMS organizes members into associations (administrative divisions, not separate organizations). Stored in AMS.appmemberassociation with an AssociationId field:

Core Membership:
- RWS = Mainstreet Organization of REALTORS
- MLSN = Mainstreet MLS
- MB = Membership
- KEY = Key Association (SentriLock)

Services and Products:
- FW = ForeWarn
- PX = Proxio
- WEB = Contracts On Line
- FOX = RWSSC
- SPON = Sponsorship Agreements

Education and Events:
- CEDU = Continuing Education
- EDUC = Education Non-Members
- EVNT = Event Non-Members
- FAIR = REALTOR Trade Fair Exhibitors
- CONV = Convention Non-Members

Other:
- COMM = Commercial Members
- IMS = IMS Non-Member Association

## Bill Types (Member Relationship Categories)

Each member has a BillType code in appmemberassociation. No lookup table exists; labels are hardcoded in the app:

REALTOR Members:
- R = REALTOR (~14,771 active)
- DR = Designated REALTOR (~1,768)
- SM = Secondary Member (~351)
- SDR = Secondary Designated REALTOR (~235)
- EM = Emeritus Member (~118)
- HM = Honorary Member (~23)
- RAA = REALTOR-ASSOCIATE, Appraiser (~24)

Appraisers:
- LAD = Licensed Appraiser, Designated (~249)
- LAR = Licensed Appraiser, REALTOR (~80)
- AST = Appraiser, State Licensed (~51)
- LA = Licensed Appraiser (~27)
- NIA = Non-Member, Inactive Appraiser (~9)

Affiliates and Other:
- AFF = Affiliate (~82)
- AFCI = Affiliate, Corporate/Institutional (~44)
- AFC = Affiliate, Corporate (~14)
- PA = Personal Assistant (~224)
- MO = MLS Only (~4)
- DM = Other (~1)
- SAD = Other (~1)

Key insight: A single member can appear in multiple association/bill type combinations. Always DISTINCT ON MemberKey when counting unique people.

---

# 3. TECHNICAL ARCHITECTURE

## Database Setup

Two PostgreSQL databases connected via separate pools in db.ts:

Production Database (Read-Only): AWS RDS via Sirius ETL (~15 min refresh). Contains AMS, MLS, and history schemas.
Replit Database (Read/Write): All SmartSends-specific tables (caching, email, audiences, analytics, celebrations).

Connection code (db.ts):
- localPool / db: Replit PostgreSQL (read/write, Drizzle ORM)
- externalPool / externalDb: MembioCommon production (read-only, Drizzle ORM)
- Both pools have connection validation helpers

Critical deduplication pattern (required for ALL AMS/MLS queries):
```sql
SELECT DISTINCT ON ("ApmClientId", "MemberKey")
  ...
FROM "AMS"."apmmember"
WHERE "ApmClientId" = 'MainStreet'
ORDER BY "ApmClientId", "MemberKey", "ApmSourceModificationTimestamp" DESC
```

## Tech Stack

- Frontend: React, Vite, Tailwind CSS, Shadcn UI components, Inter font
- Backend: Node.js, Express, TypeScript
- Database ORM: Drizzle ORM
- Email: SendGrid (with sandbox mode for testing)
- AI: Anthropic Claude API (claude-sonnet-4-20250514)
- Hosting: Replit
- Infrastructure: GitHub, AWS

---

# 4. WHAT HAS BEEN BUILT (Phases 1-3)

## Phase 1: Email Infrastructure (Complete)
- SendGrid integration with sandbox mode (EMAIL_SANDBOX_MODE=true)
- Email campaigns, recipients, and events tracking tables
- queueEmailCampaign() creates campaign record, checks opt-outs, queues recipients
- buildEmailTemplate() with Overpass font, Mainstreet branding, unsubscribe links
- personalizeMergeFields() replaces {{FirstName}}, {{OfficeName}}, etc.
- Secure HMAC-based unsubscribe tokens
- Email preference management (opt-out tracking)

## Phase 2: AI and Audience Building (Complete)
- AI Audience Builder: Natural language to SQL to audience preview to save
- AI Email Composer: Natural language to email draft with merge fields
- AI Query Service (Chats): Natural language questions about member data
- Shared Database Schema (sharedDatabaseSchema.ts) as single source of truth for both AI services
- CSV/Excel audience upload with field mapping and terms acceptance
- External contacts (non-member) audience support
- Saved audiences with type badges (Smart, Upload, External, Manual)
- Email templates (system and custom)
- Email drafts with auto-save
- Scheduled campaigns (one-shot, date/time based)
- Unified campaigns view (sent + drafts + scheduled)

## Phase 3 Parts 1-5: Performance and Celebrations (Complete)
- Member Metrics Cache: Daily pre-computation of all member metrics
- Engagement Scoring: Weighted algorithm (Transactions 0-4, Education/Events 0-2, Recency 0-2, Payment 0-3)
- Tier Classification: Active Producer / Occasional Producer / License Maintainer
- Activity Cache: Daily materialization of education, events, registrations
- Celebration Engine (milestoneDetectionService.ts): Detects transaction milestones, volume milestones, membership anniversaries, rookie stars, comebacks, specializations, first million, luxury entry
- Member Milestones and Kudos Tables
- Agent Headshot Sync: Incremental photo sync from MLS
- Enhanced Member Profiles with compliance, engagement, activity stream
- Broker Resolution Service

## Phase 3 Part 6: Analytics (Complete)
- Analytics Section as top-level nav
- Overview Dashboard with market snapshot
- Office Volume leaderboards with search/filter
- Agent Production rankings with office search dropdown
- Create Brief for PDF generation (office visit prep)
- Production Cache Tables for daily pre-computation of rankings

## Current Left Navigation Structure
```
MemberSync
  Dashboard
  SmartSends
    Dashboard
    Send Email
    Campaigns
    Audiences
      AI Builder
      Saved
      Upload
    Templates
    Drafts
    Image Library
  Chats (AI Q&A)
  Analytics
    Overview
    Office Volume
    Agent Production
    Create Brief
  All Members
  All Offices
  Compliance
```

---

# 5. CURRENT REPLIT DATABASE SCHEMA

All tables defined in schema.ts:

Authentication and User Management:
- users: Staff accounts with roles (admin, staff, readonly)
- member_notes: Staff notes on member records
- activity_log: Audit trail of all staff actions
- saved_chats: AI conversation history

Member and Office Caching:
- member_metrics_cache: Pre-computed daily metrics for all ~19K members (tier, engagement, transactions, compliance, payments, profile image URL)
- office_metrics_cache: Pre-computed office-level aggregations
- activity_cache: Materialized education/event data from production
- agent_headshot_state: MLS photo sync tracking

Analytics Production Cache:
- office_production_cache: Office rankings by volume, transactions
- agent_production_cache: Agent rankings (MRD-prefixed keys)
- market_concentration_cache: Brokerage market share

Celebrations:
- member_milestones: Detected achievements with dedup tracking
- member_kudos: Staff-submitted community recognition

Email Infrastructure:
- email_campaigns: Sent campaigns with stats
- email_recipients: Individual send records with status
- email_events: Open/click/bounce events from SendGrid
- email_images: Uploaded email images
- member_email_preferences: Opt-out tracking
- saved_audiences: All audience definitions
- email_templates: System and custom templates
- scheduled_campaigns: One-shot scheduled sends
- email_drafts: Auto-saved drafts

Saved Audiences Table Detail:
Current sourceType values: ai_generated, manual, csv_upload, external_contacts
Key fields: audienceId, audienceName, description, isSmart (boolean), memberKeys (text[]), sqlQuery (text), memberCount, sourceType, externalContacts (jsonb), isExternal, termsAccepted, termsAcceptedAt, termsAcceptanceIp, csvFilename, uploadedBy, createdBy, lastUsed
Upcoming additions: New sourceType values picklist and member_bill_type. New column filter_config (JSONB).

---

# 6. PRODUCTION DATABASE SCHEMA (Read-Only)

AMS.apmmember: MemberKey, MemberMlsId, MemberFullName, MemberFirstName, MemberLastName, MemberEmail, MemberMobilePhone, MemberType, MemberStatus (Active/Suspended/Inactive), MemberStateLicense, MemberStateLicenseExpirationDate, NarJoinDate, OfficeKey, MemberDesignations (jsonb), ApmClientId

AMS.apmmemberdues: MemberKey, InvoiceKey, InvoiceDate, DueDate, InvoiceTotal, AmountPaid, BalanceDue, PaidStatus, is_pending

AMS.apmmemberinvoicedetails: InvoiceKey, ChargeCode, InvoiceDescription, Amount

AMS.receipt_invoice: InvoiceKey, IncurredMemberKey, OfficeKey, Amount, ReceiptDate, PaidBy (Member/Broker/Office)

AMS.appmemberassociation: MemberKey, AssociationId, BillType, Status, ApmClientId, ApmSourceModificationTimestamp. Dedup: DISTINCT ON (ApmClientId, MemberKey, AssociationId)

AMS.apmevent: EventId, Name, Type, StartDateTime, EducationCredits, Categories

AMS.apmeventregistration: EventId, MemberKey, Registration_ID, Completion_Date, Attended (Y/N)

AMS.apmmembereducation: MemberKey, CourseDesc, CourseCode, Category, CreditsCompleted, CompletionDate

MLS.apmoffice (USE THIS for OfficeStatus): OfficeKey, OfficeName, OfficeBrokerKey, OfficeStatus (Active/Inactive), address fields. CRITICAL: Office status is the gatekeeper for Advantage fees.

MLS.apmproperty: ListingKey, StandardStatus, ListAgentKey, BuyerAgentKey, ClosePrice, CloseDate, PropertyType, ListAgentMlsId, BuyerAgentMlsId

history.change_history: 14-day rolling status change log. Access via jrecord column.

Key Format Rules: AMS keys have NO MRD prefix (e.g., 259036). MLS keys HAVE MRD prefix (e.g., MRD259036). Join pattern: 'MRD' || ams_key = mls_key

---

# 7. DAILY JOBS SCHEDULE

3:30 AM: Analytics production cache (analyticsProductionCacheService.ts)
4:00 AM: Member metrics cache (memberMetricsCacheService.ts)
4:30 AM: Milestone detection (milestoneDetectionService.ts)
Daily: Activity cache refresh (activityCacheService.ts)
5:15 AM: Agent headshot sync (agentHeadshotService.ts)
Every 60s: Scheduled email processor (scheduledEmailProcessor.ts)

Upcoming: Every 15 min triggered campaign processor
Planned (lapse prevention): 6 AM status capture, 6:15 AM office status, 7 AM risk scoring, 8 AM office health

---

# 8. AI SERVICES ARCHITECTURE

Both AI services share schema via getSharedDatabaseSchema() in sharedDatabaseSchema.ts.
Used by: aiQueryService.ts (Chats) and aiAudienceService.ts (Audience Builder)

Schema sections: SHARED_DATABASE_OVERVIEW, AMS_MEMBER_SCHEMA, MLS_MEMBER_SCHEMA, OFFICE_SCHEMA, LISTINGS_SCHEMA, INVOICES_SCHEMA, EVENTS_EDUCATION_SCHEMA, REFERENCE_DATA_SCHEMA, CACHE_TABLES_SCHEMA, KEY_FORMAT_RULES, CANONICAL_STATS, OFFICE_SWITCHING, BUSINESS_INTELLIGENCE, CACHE_VS_RAW_GUIDANCE, DATABASE_ROUTING_RULE, ANNIVERSARY_QUERIES

Upcoming: Add MEMBER_ASSOCIATION_SCHEMA documenting appmemberassociation, association codes, bill type codes with labels/counts, and example queries.

SQL validation (validateSQLQuery): allowedTables array needs appmemberassociation added.

---

# 9. SMARTSENDS AUDIENCE BUILDER IMPROVEMENTS (READY TO BUILD)

Replit prompt: SmartSends_AudienceBuilder_Improvements.md

Summary:
- Picklist audiences (sourceType picklist): Hand-pick members by name search (same dropdown style as Agent Production Leaderboard office filter), add non-members manually (name + email + optional company), CSV upload with terms acceptance handling members + non-members. Static list (isSmart false). Members in memberKeys, non-members in externalContacts. Updated getAudienceMembers() to handle both.
- Member/Bill Type audiences (sourceType member_bill_type): Grouped checkboxes for 16 associations and 18 bill types, queries AMS.appmemberassociation, smart audience that re-queries each use. Stores selections in filter_config JSONB column.
- Inline creation in Send Email flow: Restructured Step 1 with tabs (Saved Audiences, Picklist, Member/Bill Type). AI Builder opens in modal. Reusable components shared between standalone pages and inline flow.
- AI awareness: New MEMBER_ASSOCIATION_SCHEMA in shared schema.
- DB changes: Add filter_config JSONB to saved_audiences, add appmemberassociation to allowed tables.
- Nav changes: Add Picklist and Member/Bill Type under Audiences.

---

# 10. TRIGGERED CAMPAIGN ENGINE (READY TO BUILD)

Replit prompt: SmartSends_TriggeredCampaigns.md

Summary:
- Three new tables: triggered_campaigns (config), triggered_campaign_steps (sequences), triggered_campaign_sends (dedup log with unique constraint on campaign + step + member + trigger_reference)
- Processing engine (triggeredCampaignProcessor.ts): Runs every 15 min, evaluates active campaigns, finds qualifying members, respects send windows (default 8 AM-5 PM Central), weekend restrictions, auto-stop conditions
- Phase A triggers built now: event_registration, event_reminder, event_followup, membership_anniversary, production_milestone
- Phase B triggers after lapse prevention: new_member, membership_expiring, member_lapsed
- Phase C triggers future: low_engagement, interest_based, profile_incomplete
- Enhanced merge fields: {{ClassName}}, {{ClassDate}}, {{ClassTime}}, {{CECredits}}, {{YearsAsMember}}, {{JoinDate}}, {{MilestoneLabel}}, {{MilestoneEmoji}}, {{MilestoneValue}}
- Multi-step sequences: Step 1 immediate, Step 2 at N days delay, etc. Step 2 only fires after Step 1 confirmed sent.
- Lifecycle: Draft, Active, Paused, Archived
- Uses existing queueEmailCampaign() for actual delivery
- UI: New Automations page under SmartSends with active/paused/draft sections, create/edit flow, send history

---

# 11. LAPSE PREVENTION SYSTEM (NEXT TO BUILD)

Full specifications in SmartSends_Project_Summary_Jan29_2026.md. Key elements:

Tables: member_status_tracking, office_status_tracking, member_risk_scores, office_payment_health, intervention_log, billing_calendar, broker_liability

Calendar-aware risk scoring: Score based on position in billing calendar (Dec overdue = 1, Jan suspended = 3, final week = 5)
Office suspension as gatekeeper: Advantage risk is office-level
Non-member detection: First-time Inactive after Feb 1
DR Formula tracking: Broker liability for non-member licensees

Annual Dues timeline: July invoices, Dec 1 due, Jan 2 suspensions, Jan 31 hard deadline, Feb 1 inactive
Advantage Spring timeline: March invoices, March 31 due, April 1 MLS suspended, April 15 DR suspended, April 22 office suspended

---

# 12. BILLING CALENDAR AND CHARGE CODES

Annual Dues codes: RM1xx (2026), RD9xx (2025). Components: local + state + NAR + R-VOICE + Public Awareness
Advantage codes: Prefix S/A/N + period code 04/10 + year (e.g., S0426 = Semi-Annual April 2026)
Exclude from risk scoring: RPAC (RD980, RM180), REF (REF26), processing fees (PPFEB), education codes (CE*, RA*, LAW*), late fees (LATE, LATD)

---

# 13. PHASE 4 PREVIEW: BROKER MODULE

Hybrid approach: email stays in SmartSends, separate module for broker liability dashboards, DR Formula tracking, office payment health, agent rosters, billing calendar admin.

---

# 14. BOOKMARKED FUTURE IDEAS

- Lapse pattern analysis: 24-month journey before lapse, predictive modeling
- Full triggered campaign roadmap: 9 trigger types covering complete member lifecycle
- Interest-based content tracks: Persona-driven drips
- Profile/data hygiene campaigns

---

# 15. KEY FILES AND REPLIT PROMPTS

Replit Prompts (execution order):
1. SmartSends_AudienceBuilder_Improvements.md (Ready)
2. SmartSends_TriggeredCampaigns.md (Ready)
3. Lapse Prevention (not yet written, next)

Key Source Files:
- schema.ts: All Replit database table definitions
- db.ts: Dual database connection setup
- sharedDatabaseSchema.ts: AI context for both AI services
- aiAudienceService.ts: AI audience generation, SQL validation, audience CRUD
- aiQueryService.ts: AI Chats natural language to SQL
- emailService.ts: Email queuing, sending, template building
- scheduledEmailProcessor.ts: One-shot scheduled campaign processor
- memberMetricsCacheService.ts: Daily member metrics refresh
- milestoneDetectionService.ts: Celebration detection
- activityCacheService.ts: Education/event cache refresh
- analyticsProductionCacheService.ts: Office/agent production rankings
- engagementScoreService.ts: Engagement scoring algorithm
- csvUploadService.ts: CSV/Excel parsing and member matching
- storage.ts: All API endpoint implementations

Engagement Scoring (as implemented):
- Transactions 12mo: 0-4 points (0=0, 1-2=1, 3-5=2, 6-10=3, 11+=4)
- Education/Events: 0-2 points (0=0, 1-2=1, 3+=2)
- Recency (90 days): 0-2 points
- Payment Status: 0-3 points (current=3, under 30d=2, 30-60d=1, 60d+=0)

---

END OF SUMMARY

To resume: Share this document in a new Claude conversation, upload the two Replit prompt files, and upload latest source files from Replit if changed. Next prompt to write: Lapse Prevention System.

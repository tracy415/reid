# MemberSync — Project Summary
## March 10, 2026

This document is the authoritative state of the project as of end of day March 10, 2026. It supersedes all prior summaries. Use this to resume work in any new conversation.

---

## TABLE OF CONTENTS

1. Who We Are & Claude's Role
2. Product Vision & Philosophy
3. The 75/12 Rule
4. Member Tier Framework
5. Client Pipeline
6. Build Philosophy & Team Structure
7. Current State: What's Built
8. Navigation Structure (Current)
9. Campaign Architect — Full Status
10. SmartSends — Full Status
11. Unsubscribe Architecture — Full Status (NEW — completed March 10)
12. AI Cost Controls — Status
13. Prompt Queue — Current Status
14. Standing Rules (Canonical — 25 Rules)
15. All Architectural Decisions (Canonical)
16. Known Issues & Technical Debt
17. Key Files Reference
18. Parking Lot Summary
19. AEI Demo Plan

---

## 1. WHO WE ARE & CLAUDE'S ROLE

**Tracy** is CEO and founder of Membio — a proptech SaaS company. 30+ years real estate industry experience on the business side. Non-technical founder building MemberSync exclusively with Claude, Julius.ai, and Replit Agent. Deeply interested in technology and AI but cannot code.

**Claude's role** is CTO, product visionary, AI architecture expert, and strategic sparring partner:
- Pressure-test every feature idea against multi-tenant scale, technical debt, and timing before speccing it
- Surface architectural risks proactively
- Translate tradeoffs into business terms, not jargon
- Push back when something doesn't make sense
- Hold the full product picture across conversations so nothing gets lost
- Write all Replit prompts and review Replit's implementation plans before Tracy approves them
- Write and maintain CLAUDE.md (the product bible for the dev team)

**The toolchain:**
- **Claude** — strategy, architecture, Replit prompts, CLAUDE.md, project summaries
- **Julius.ai** — SQL development and data validation
- **Replit Agent** — prototype implementation (Track 1)
- **Claude Code** — production implementation by dev team (Track 2)

**Clean boundary:** Tracy + Claude decide the "what" and "why." The dev team owns the "how."

---

## 2. PRODUCT VISION & PHILOSOPHY

**MemberSync** is a member engagement and retention SaaS platform for real estate associations and MLSs. It analyzes MLS listing and AMS data to help executives understand, engage, and retain members.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**Product philosophy:** "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

**The lightsaber:** Organized real estate is in an existential fight. MLSs are going non-Realtor, removing the last transactional justification for association membership. MemberSync is the lightsaber — real, actionable intelligence about members AND the competitive environment they operate in.

**The 5% rule:** Every screen must earn its place. We build what clients asked for or dreamed about — not features that sound good in a roadmap.

**Decision-first UX:** Every view surfaces a recommended action, not just data.

**AI voice and trust philosophy:**
MemberSync AI observes real data and acts on it. It never invents, never infers beyond what the data shows. Every claim is grounded in real, verifiable data about actual members. The AI is confident, warm, shows its work, and is always on the member's side — never clinical, never alarming without a path forward.

**AEI conference context (critical):** The AEI/RESO conference in Minneapolis (March 23–27) is a NAR-sponsored event. NAR will be telling association executives to brace for further membership decline. MemberSync walks in with a product that says "here's exactly what to do about it." The timing is perfect. Every feature we complete before March 23 strengthens that story.

---

## 3. THE 75/12 RULE

At a typical real estate association or MLS, ~75% of members produce only ~12% of transaction volume — yet they pay ~75% of dues and fees. These are "Foundation" members: people who maintain their license, pay dues, and may never sell a house. They are the financial backbone.

Most associations ignore the 75% because they don't appear to be selling at scale. MemberSync is built for them. If you have 50,000 members and focus only on the top 25%, that leaves 37,500 members disengaged and likely to lapse.

**The 100% Coverage Test:** Any scoring signal covering fewer than 10% of membership is a vanity metric, not a scoring input.

**Why it matters now:** MLSs opening access to non-Realtor licensees threatens association membership. MemberSync serves both associations and MLSs.

---

## 4. MEMBER TIER FRAMEWORK

Members classified by 12-month transaction sides:

| Display Name | Internal Code | Sides (12mo) | Mainstreet % |
|---|---|---|---|
| Rainmaker | `active_producer` | 40+ | ~1.4% |
| Builder | `occasional_producer` | 6–39 | ~21% |
| Foundation | `license_maintainer` | 0–5 | ~77% |

**Critical rules:**
- Display names only in UI — never internal names
- All tiers framed positively — we celebrate connection, not police compliance
- Foundation members who take classes, pay on time, and attend events can score 10/10 — even with zero transactions
- Engagement is not production
- Tier thresholds defined in `tenant_config` — vary per client

---

## 5. CLIENT PIPELINE

| Client | Members | Status | Special Requirements |
|---|---|---|---|
| Mainstreet REALTORS® | 18,275 | First client, prototype stage | Chicago suburbs, IL compliance |
| HGAR / Hudson Gateway | 12,800 | Onboarding | Multi-tenant, NY compliance |
| GRAR / Greater Rochester | 3,400 | Third pilot | Multi-tenant, NY compliance |
| ~~CRMLS~~ | ~~103,000+~~ | ~~Pilot prospect — paused~~ | SOC 2, enterprise SLA, batch email at scale |

**CRMLS update (March 10):** CRMLS told Tracy their internal team is developing a similar product. Removed from active pipeline. Their CMO still wants MemberSync — keeping the relationship warm. Plenty of other large MLSs and associations to pursue.

**AEI/RESO Conference:** Minneapolis, March 23–27. **13 days out.** Campaign Architect is the demo centerpiece. NAR will be telling attendees to brace for membership decline — MemberSync's timing is perfect.

---

## 6. BUILD PHILOSOPHY & TEAM STRUCTURE

**Two-track development model:**
- **Track 1 (Tracy + Claude + Replit Agent):** Rapid prototype development and feature validation. Connected to read-only production data. Writes to local Replit DB when writes are needed.
- **Track 2 (Dev team + Claude Code):** Production platform — porting validated modules with proper multi-tenant architecture.

**Current dev team status (as of March 10):**
- Dev team has completed: monolith split, dev/staging/prod environments, Cognito auth, unified DB, CI/CD, multi-tenant architecture foundation
- AWS spin-up expected imminently
- DevOps engineer pulled a Replit snapshot from March 5 to stand up their version — they are behind Replit by ~5 days of development
- GitHub connection between this Claude Project and the repo is planned but not yet established
- CLAUDE.md updated March 9 (Tracy edited and distributed to team — this is the version the team has)

**Handoff protocol:**
- Every Replit feature gets a prompt document saved to project knowledge
- CLAUDE.md updated to reflect completed features and architectural decisions
- Prompt docs go to `/docs/prompts` in GitHub; CLAUDE.md goes to `/docs/CLAUDE.md`
- Dev team reads prompt docs as authoritative specs when promoting to production
- Claude Code reads everything from the repo on every task

**Opt-out reversal policy (established March 10):**
Staff can remove any member-requested or manual opt-out via the Unsubscribe Management panel. Hard bounce suppressions are permanent — the email address is invalid and sending again would damage sender reputation. This is a clean story for sales: "Yes, staff can reverse any opt-out except hard bounces."

---

## 7. CURRENT STATE: WHAT'S BUILT

### Core Platform
- Engagement scoring with tier classification (Rainmaker/Builder/Foundation)
- Member metrics cache (daily refresh, cache-first architecture)
- Dashboard with Association Pulse cards, Activity Feed, Member Recognition sidebar
- Member Detail pages with score breakdown, open/click timestamps, real profile data
- Office profiles with agent roster, volume data, engagement distribution
- AI Chat (Julius-style analyst mode) with saved chats, cross-domain queries, retry logic
- Market Stats with office leaderboards and agent rankings

### SmartSends
- Campaign creation: 5-tile create flow (Email, Sequence, Trigger, Automation, Recognition)
- EmailComposer: full wizard, merge fields (Tier 1/2/3), AI composition, live preview
- AI Audience Builder with rate limiting
- Saved Audiences with count and preview
- Member Type Builder
- Image Library
- Templates (basic)
- Email Governor (per-member send rate limiting)
- SmartSends Home (newsroom-style homepage)
- Reporting & Analytics (unified campaign list, all campaign types)
- Campaign Detail Page (full page, no modal — March 10)
- Email Controls → moved to SmartSends Settings
- **Unsubscribe Architecture (March 10) — see Section 11**

### Recognition
- Recognition Queue with approval workflow
- Recognition emails via SmartSends
- Recognition Performance page (real data)

### Campaign Architect
- Full AI-first campaign builder (replaces drip sequence builder)
- AI planner with voice/tone settings
- Audience accumulation logic
- anchorOffset/anchorDirection architecture (no negative delayDays)
- Rate limiting on AI audience generation

### Automations
- Triggered campaigns (birthday, anniversary, milestone, new member, lapse risk)
- A/B testing framework (built, not fully activated)

### Compliance
- CE tracking (IL)
- Code of Ethics status
- Fair Housing (association-only — gated by tenant_config)

### AI Features
- AI Cost Controls: per-feature rate limiting, usage logging, AI usage dashboard
- AI Email Composer
- AI Audience Builder
- AI Chat (Julius upgrade)
- AI Campaign Planner

---

## 8. NAVIGATION STRUCTURE (CURRENT — POST MARCH 8 REDESIGN)

```
Dashboard
SmartSends
  ├── Create
  ├── Reporting & Analytics
  ├── Audiences (expandable)
  │   ├── AI Audience Builder
  │   ├── Saved Audiences
  │   ├── Member Type Builder
  │   └── CSV Upload
  ├── Content
  ├── Templates
  └── Settings (expandable)
      ├── Email Controls
      ├── Unsubscribes (NEW — March 10)
      └── Email Health
Chats
Recognition (expandable)
  ├── Recognition Queue
  ├── Recognition Performance
  └── Settings
Engagement [Coming Soon]
Retention [Coming Soon]
Compliance (expandable)
Market Stats (expandable)
Members
Offices
```

---

## 9. CAMPAIGN ARCHITECT — FULL STATUS

Campaign Architect is the AI-first campaign builder. It fully replaces the drip sequence builder — no parallel UI exists.

**What's built and working:**
- Step 1: Campaign name and goal
- Step 2: AI audience suggestion (with rate limiting) or manual selection
- Step 3: AI-generated email sequence with timing (using anchorOffset/anchorDirection, no negative delayDays)
- Step 4: Review and activate
- Voice/tone settings panel
- Audience accumulation cleanup (no carry-over between campaigns)
- Save audience flow (single INSERT — not two-step)
- AI planner voice: specific, data-grounded, never generic

**Standing rules for Campaign Architect:**
- Fully replaces drip sequence builder — no parallel UI
- AI suggestions are always actionable yes/no — never configuration forms
- Every email editing path uses the full EmailComposer — no modal shortcuts
- `anchorOffset` + `anchorDirection` fields replace ambiguous `delayDays` — never use negative delayDays

**Prompt history:** Prompt1, Prompt2, Polish, Hardening, PlannerFix, Addendum, PlannerVoice — all deployed ✅

---

## 10. SMARTSENDS — FULL STATUS

### Reporting & Analytics (rebuilt March 9)
- Unified campaign list: all campaign types in one view
- No more "[Triggered]" rollup rows with count of 1
- Clicking a row navigates directly to Campaign Detail page (no modal)

### Campaign Detail Page (rebuilt March 10)
- Full page at `/smartsends/campaigns/:id`
- Header: campaign name, type badge, status badge, sent by, back link
- 5 stat cards: Recipients, Delivered, Open Rate, Click Rate, Unsubscribed
- Context-aware action buttons by status
- Member Activity tab (default): 9-column recipient table, sortable, searchable, paginated 50/page
- Email Content tab: rendered HTML preview; sequences show step selector
- Mobile responsive: tap row to expand hidden columns

### Email Governor
- Per-member send rate limiting
- `canSendToMember` checks per-category opt-outs before governor rate limiting (updated March 10)

---

## 11. UNSUBSCRIBE ARCHITECTURE — FULL STATUS (COMPLETED MARCH 10)

This is entirely new as of March 10. All parts verified working.

### Four email categories

| Category | Can Opt Out? | SendGrid Group |
|---|---|---|
| `marketing` | Yes | MemberSync Marketing |
| `recognition` | Yes (with warning) | MemberSync Recognition |
| `compliance` | No | MemberSync Compliance |
| `transactional` | No | MemberSync Transactional |

Note: `engagement` (legacy category) maps to `marketing` group. Existing data not renamed.

### What was built
- **SendGrid ASM groups:** 4 groups created programmatically via API at startup (idempotent). IDs stored in `tenant_config`.
- **ASM parameter:** Added to every outbound email in `emailService.ts` `processEmailQueue`. All send paths funnel here. `triggeredCampaignProcessor.ts` not touched.
- **Email footer:** "Manage Preferences" (primary) and "Unsubscribe" (secondary) links — both include signed HMAC token so preference center can identify the member.
- **One-click `/unsubscribe`:** Category-aware — sets `marketing_opt_out` or `recognition_opt_out`, not global `email_opt_out`. Compliance/transactional: log but don't suppress. Always redirects to `/email-preferences?token=` afterward.
- **`/email-preferences` preference center:** Public, no login, server-rendered HTML. Marketing & Recognition toggleable. Compliance & Transactional: "Required — cannot be turned off." Save button with confirmation message. Mainstreet branding.
- **Unsubscribe Management panel** (`/smartsends/settings/unsubscribes`): Staff-facing. Filter tabs (All/Marketing/Recognition). Table with Member, Email, Category, Opted Out On, Campaign, Source, Action. Remove button for non-hard-bounce rows. Hard bounces: permanent, no remove. "+ Add Suppression" inline form. Search, sort, pagination.
- **Schema additions:** `tenant_config` gets 4 `sg_group_*` columns. `member_email_preferences` gets `marketing_opt_out`, `marketing_opt_out_date`, `recognition_opt_out`, `recognition_opt_out_date`.
- **Global `email_opt_out` boolean preserved** as full override — if true, member receives nothing regardless of category.

### Known remaining item
- SendGrid webhook handler still processes unsubscribes globally rather than by ASM group. Fix prompt written (`MemberSync_Webhook_CategoryUnsubscribeFix.md`) — **ready to send to Replit.**
- SendGrid automatic footer links (appended by SendGrid below the email template) need to be disabled in SendGrid account settings. Tracy is handling this directly in SendGrid dashboard.

### Opt-out reversal
Staff can remove any member-requested or manual opt-out via the Unsubscribe Management panel (trash icon). Hard bounce suppressions are permanent — no exceptions.

---

## 12. AI COST CONTROLS — STATUS

Prompt written (`MemberSync_AICostControls_Prompt.md`) and deployed. Includes:
- Per-feature rate limiting (AI Chat, Audience Builder, Email Composer, Campaign Planner)
- Usage logging via `aiUsageLogger.ts`
- AI Usage dashboard for staff

---

## 13. PROMPT QUEUE — CURRENT STATUS

### Ready to Send to Replit Now 📝
- `MemberSync_Webhook_CategoryUnsubscribeFix.md` — category-aware webhook unsubscribe handler. Small, surgical. Send immediately.
- `MemberSync_NavCleanup_Prompt.md` — removes broken SmartSends.tsx legacy links. Short. Send alongside webhook fix.

### To Write Next (Priority Order)
1. **Recognition Homepage** — stat cards, "What's resonating," "Coming up" queue with projections, daily digest email to staff, left nav badge showing pending count
2. **Proactive AI Engagement Engine (MVP)** — demo-worthy minimum: real pattern detection cards on dashboard pulling real data (e.g. "14 Foundation members in Aurora attended events last year but haven't registered for anything this spring"). Not full batch job architecture — just the pattern that shows what it will do.
3. **Lapse Prevention (MVP)** — demo-worthy minimum: risk indicator on dashboard showing members trending toward lapse. Real data, real signal.
4. **SmartSends.tsx retirement** — fully retire old SmartSends.tsx, migrate Email Controls tab content to SmartSendsSettings.tsx
5. **Prompt C** (`MemberSync_PromptC_AIDuplicateDetection.md`) — AI duplicate detection, archive-aware composition. Already written — send after items above.

### Already Deployed ✅
- All Campaign Architect prompts (Prompt1, Prompt2, Polish, Hardening, PlannerFix, Addendum, PlannerVoice)
- Schema Modularization
- AI Chat Julius Upgrade
- Query Engine Retry and Cross-Domain
- Recognition Queue + Email Governor (PromptA Parts 1–8)
- Email Health Dashboard + Image Library Upgrade (PromptB)
- Navigation Redesign (March 8)
- SmartSends Reporting Fix (March 9)
- AI Cost Controls (March 8)
- RecipientTracking + Unsubscribe Architecture (March 10) ✅

---

## 14. STANDING RULES (CANONICAL — 25 RULES)

1. **`member_metrics_cache` is the single source of truth** for member data in the UI. Never compute metrics on the fly that the cache already provides.
2. **Every query against external AMS/MLS tables must deduplicate** using DISTINCT ON / ROW_NUMBER pattern.
3. **Every query against external tables must filter by ApmClientId.**
4. **Never SUM(ClosePrice) across listing + buyer sides** without applying the volume split.
5. **All client-specific values go in `clientConfig.ts`** (or `tenant_config`). No hardcoded client references anywhere else.
6. **Every feature must work for multiple clients** through configuration, not custom code.
7. **Real data only. No fake/sample data anywhere in the app** — preview systems show real member data.
8. **No manual schema changes in production.** All changes go through versioned database migrations.
9. **Cache-first architecture.** If a value can be pre-computed daily, it should be.
10. **One task at a time.** Each PR/commit should be focused and testable.
11. **Voluntary contributions (RPAC, REF) are excluded from risk scoring entirely.**
12. **Non-CE event attendance is a stronger engagement signal than CE attendance.**
13. **Every module must be gated by `tenant_config`.** A disabled module must not render, must not run background jobs, and must not consume AI budget.
14. **Mobile-first, performance-always.** Every UI component must be responsive. Every data view must load in under 2 seconds.
15. **The 5% rule.** Every screen must earn its place.
16. **Recognition is always the user-facing term.** "Celebration" stays in code only.
17. **Email category is required on all campaigns.** No null categories — enforced at composition time and at send time.
18. **Campaign Architect fully replaces the drip sequence builder.** No parallel UI.
19. **AI suggestions are always actionable yes/no.** Never configuration forms.
20. **Every email editing path uses the full EmailComposer.** No modal shortcuts, no inline editing.
21. **Do not modify `triggeredCampaignProcessor.ts` without explicit instruction.** It is sensitive execution infrastructure.
22. **`sequenceEnrollmentService.ts` is the single source of enrollment logic.** Never duplicate enrollment logic.
23. **Every outbound email must include a SendGrid unsubscribe group (`asm` parameter).** Null category defaults to `marketing` with a logged warning. Never send without a group.
24. **Campaign detail pages navigate directly from list row.** No modal intermediary.
25. **Hard bounce suppressions are permanent.** No Remove button, no manual override.

---

## 15. ARCHITECTURAL DECISIONS (CANONICAL)

### Database
- Single PostgreSQL database (the two-database Replit setup is a safety workaround for Tracy's read-only production access — not an architectural decision)
- `member_metrics_cache` is the single source of truth for member metrics
- All schema changes via versioned migrations — no manual changes in production
- Schema modularization completed in Replit — preserve this structure in the production port

### Multi-tenant
- `tenant_config` table drives scoring, UI visibility, AI prompt context, and compliance panels
- `org_type`, `tracks_ce`, `tracks_coe`, `tracks_designations` fields gate compliance module visibility
- Compliance module hidden entirely for MLS clients
- 110+ hardcoded client references in Replit prototype — production port must eliminate all of these from day one

### Email
- All outbound email funnels through `emailService.ts` `processEmailQueue` — this is where ASM parameter is added
- SendGrid ASM groups created programmatically, IDs stored in `tenant_config`
- `engagement` category maps to `marketing` group (legacy — do not rename existing data)
- Global `email_opt_out` boolean is a full override — preserved alongside category opt-outs
- One-click `/unsubscribe` handler: category-aware, always redirects to `/email-preferences?token=` afterward
- `/email-preferences` preference center: public, server-rendered HTML, signed HMAC token identifies member
- Hard bounce suppressions: permanent, no removal

### AI
- Single Anthropic API key for all clients — never expose to clients
- Per-feature rate limiting (AI Chat, Audience Builder, Email Composer, Campaign Planner)
- Usage logging via `aiUsageLogger.ts`
- AI voice: specific, data-grounded, never generic, always on the member's side

### Campaign Architect
- `anchorOffset` + `anchorDirection` replace ambiguous `delayDays` — never negative delayDays
- `saveAudience` accepts metadata in a single INSERT — not a two-step workaround
- Audience accumulation cleanup between campaigns

### Engagement Scoring
- Scoring engine must be data-driven, not code-driven (weights and signals from tenant config, not if-statements)
- Payment is table stakes, not an engagement signal
- Transactions are baseline activity, not a measure of organizational connection

### Merge Fields
- Tier 1: static profile fields
- Tier 2: trigger context fields
- Tier 3: live data pulled at send time (e.g. last transaction address and close price)
- AI should suggest Tier 3 fields automatically

### Volume Calculation (Membio Volume Standard)
- Personal Production Volume: full ClosePrice per side
- Market Volume Contribution: ClosePrice split 50/50 when both sides are members

---

## 16. KNOWN ISSUES & TECHNICAL DEBT

### Active Issues
- SendGrid webhook handler processes unsubscribes globally — fix prompt written and ready to send
- SendGrid automatic footer links appear below email template — Tracy disabling in SendGrid dashboard
- Triggered campaigns don't explicitly pass `emailCategory`, defaulting to `engagement` — acceptable (maps to marketing), clean up post-AEI
- `server/routes.ts` is a monolith (~9,500 lines) — most urgent refactoring target for dev team
- SmartSends.tsx not fully retired — old file still exists alongside new SmartSendsHome.tsx

### Post-AEI Technical Debt
- A/B testing: framework built, not fully activated
- Drip Sequence Step Editor needs proper EmailComposer integration
- Templates system needs full rework
- Missing event warning at Campaign Architect activation when anchor event removed
- Duplicate detection threshold (70%) should be configurable per client in `tenant_config`
- `clientConfig.ts` has 110+ hardcoded client references — production port must eliminate

---

## 17. KEY FILES REFERENCE

### Sensitive Files — Handle With Extreme Care
- `server/services/triggeredCampaignProcessor.ts` — **DO NOT MODIFY for any reason**
- `server/services/sequenceEnrollmentService.ts` — **sensitive execution infrastructure — do not modify without explicit instruction**

### Key Application Files
- `server/routes.ts` — Monolith (~9,500 lines) — most urgent refactoring target
- `shared/schema.ts` — All tables and TypeScript types
- `client/src/pages/CampaignArchitect.tsx` — Campaign Architect UI
- `server/services/aiCampaignPlannerService.ts` — Campaign Architect planner
- `client/src/components/layout/AppSidebar.tsx` — Navigation
- `server/services/clientConfig.ts` — All client-specific values (must become `tenant_config` in production)
- `server/services/aiQueryService.ts` — AI Chat query service
- `server/services/aiEmailService.ts` — AI email composition
- `server/services/aiAudienceService.ts` — AI audience generation
- `server/services/memberMetricsCacheService.ts` — Engagement scoring engine
- `server/services/aiUsageLogger.ts` — AI call logging
- `server/services/emailService.ts` — All outbound email (ASM parameter lives here)
- `server/services/sendgridUnsubscribeGroups.ts` — SendGrid group creation service (new March 10)
- `client/src/pages/SmartSendsReporting.tsx` — Unified campaign list
- `client/src/pages/CampaignDetail.tsx` — Full campaign detail page (rebuilt March 10)
- `client/src/pages/UnsubscribeManagement.tsx` — Staff unsubscribe panel (new March 10)
- `client/src/pages/SmartSendsHome.tsx` — SmartSends newsroom homepage
- `client/src/pages/SmartSendsSettings.tsx` — Settings page

### Prompt Files — Deployed ✅
- All Campaign Architect prompts (Prompt1, Prompt2, Polish, Hardening, PlannerFix, Addendum, PlannerVoice)
- `MemberSync_SchemaModularization_Prompt.md`
- `MemberSync_AIChat_JuliusUpgrade_Prompt.md`
- `MemberSync_QueryEngine_RetryAndCrossDomain.md`
- `MemberSync_PromptA_RecognitionQueue_EmailGovernor.md` (Parts 1–8)
- `MemberSync_PromptB_EmailHealth_ImageLibrary.md`
- `MemberSync_ImageLibrary_Upgrade_Prompt.md`
- `MemberSync_NavigationRedesign_Final.md`
- `MemberSync_SmartSends_ReportingFix_Final.md`
- `MemberSync_AICostControls_Prompt.md`
- `MemberSync_RecipientTracking_UnsubscribeArchitecture.md` ✅ (March 10)

### Prompt Files — Ready to Send 📝
- `MemberSync_Webhook_CategoryUnsubscribeFix.md` — send immediately
- `MemberSync_NavCleanup_Prompt.md` — send alongside webhook fix

### Prompt Files — Written, Queue for Later
- `MemberSync_PromptC_AIDuplicateDetection.md`

### Reference Documents
- `CLAUDE.md` — Product bible. Tracy-edited version distributed to dev team March 9. Current.
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog
- `MemberSync_Development_Plan.docx`
- `Membio_AI_Workflow_Playbook.docx`

---

## 18. PARKING LOT SUMMARY

Full detail in `MemberSync_Parking_Lot.md`. Key items:

### Features to Build (Prioritized)
1. **Proactive AI Engagement Engine** ⭐ Top priority after AEI demo — daily pattern detection, connects to SmartSends. More compelling for demos than lapse prevention (positive, not reactive). Premium tier. MVP version for AEI: real data pattern cards on dashboard.
2. **Lapse Prevention System** — calendar-aware risk scoring, automated intervention. Plus tier. MVP for AEI: risk indicator on dashboard with real signal.
3. **Persistent Organizational Intelligence / AI Memory Layer** ⭐ — store chat history per org, inject context into every AI call.
4. **Email Archive as AI Memory** — AI reads archive before composing/planning.
5. **Campaign Engagement Map** ⭐ Demo-worthy — scatter/bubble chart, every sent email = one dot.
6. **AI Chart Rendering** — Recharts inline in AI Chat.
7. **Competitive Intelligence Module** — territory-aware AI Chat queries, competitive framing for lapse prevention.
8. **Broker Module** — office payment health, suspension impact. Email stays in SmartSends.
9. **Recognition CEO Voice Text Messages** (upsell tier) — AI-written SMS in CEO's voice, Twilio delivery.
10. **Universal Communications Ledger** (premium tier) — all outbound comms in one timeline.

### Infrastructure
- SOC 2 Certification (required when CRMLS is back)
- Prompt caching (90% cost reduction on input)
- Batch email sending (CRMLS scale)
- Self-service onboarding (after 4–5 manual clients)

---

## 19. AEI DEMO PLAN

**Conference:** AEI/RESO, Minneapolis, March 23–27. **13 days out.**
**Context:** NAR will tell attendees to brace for membership decline. MemberSync is the answer in the room.

**Demo path (planned):**
AI Chat → Campaign Architect → Member Recognition → Dashboard

**Must be working cleanly before travel:**
- Campaign Architect: end-to-end, verified, no rough edges
- Navigation: clean, no broken links
- Dashboard: Association Pulse cards showing real data
- Recognition Queue: working
- Engagement and Retention "Coming Soon" labels visible in nav (sets up the story)

**AEI demo stretch goals (MVP versions acceptable):**
- Proactive AI Engagement Engine — real data cards on dashboard showing pattern insights
- Lapse Prevention — risk indicator with real signal

**What demo attendees need to SEE:** Real numbers, real members, specific and actionable insights. They don't need to use it — they need to feel it. The "Coming Soon" labels for Engagement and Retention in the nav actually help — they show a roadmap without requiring the features to be built.

---

*Session date: March 10, 2026.*
*AEI/RESO Conference: March 23–27. 13 days out.*
*Replit status: Unsubscribe architecture complete and verified. Webhook fix and nav cleanup ready to send.*
*Next: Send webhook fix + nav cleanup to Replit. Then write Recognition Homepage prompt. Then Engagement Engine MVP.*

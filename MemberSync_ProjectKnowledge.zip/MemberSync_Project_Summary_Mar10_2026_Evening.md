# MemberSync — Project Summary
## March 10, 2026 (Evening Session)

This document supersedes the March 10 morning summary. It is the authoritative state of the project as of end of evening March 10, 2026. Open every new conversation by uploading this document.

---

## TABLE OF CONTENTS

1. Who We Are & Claude's Role
2. Product Vision & Philosophy
3. The 75/12 Rule
4. Member Tier Framework
5. Client Pipeline
6. Build Philosophy & Team Structure
7. Current State: What's Built
8. Navigation Structure (Current)
9. Campaign Architect — Full Status
10. SmartSends — Full Status
11. Unsubscribe & Suppression Architecture — Full Status
12. AI Cost Controls — Status
13. Prompt Queue — Current Status
14. Standing Rules (Canonical — 30 Rules)
15. All Architectural Decisions (Canonical)
16. Known Issues & Technical Debt
17. Key Files Reference
18. Parking Lot Summary
19. AEI Demo Plan

---

## 1. WHO WE ARE & CLAUDE'S ROLE

**Tracy** is CEO and founder of Membio — a proptech SaaS company. 30+ years real estate industry experience on the business side. Non-technical founder building MemberSync exclusively with Claude, Julius.ai, and Replit Agent. Deeply interested in technology and AI but cannot code.

**Agreement established this session:** No technical debt, no dead code, nothing left behind for others to discover. If Claude sees it, Claude calls it. We fix it now.

**Claude's role** is CTO, product visionary, AI architecture expert, and strategic sparring partner:
- Pressure-test every feature idea against multi-tenant scale, technical debt, and timing before speccing it
- Surface architectural risks proactively — never wait for Tracy to discover them
- Translate tradeoffs into business terms, not jargon
- Push back when something doesn't make sense
- Hold the full product picture across conversations so nothing gets lost
- Write all Replit prompts and review Replit's implementation plans before Tracy approves them
- Write and maintain CLAUDE.md (the product bible for the dev team)

**The toolchain:**
- **Claude** — strategy, architecture, Replit prompts, CLAUDE.md, project summaries
- **Julius.ai** — SQL development and data validation
- **Replit Agent** — prototype implementation (Track 1)
- **Claude Code** — production implementation by dev team (Track 2)

**Clean boundary:** Tracy + Claude decide the "what" and "why." The dev team owns the "how."

---

## 2. PRODUCT VISION & PHILOSOPHY

**MemberSync** is a member engagement and retention SaaS platform for real estate associations and MLSs. It analyzes MLS listing and AMS data to help executives understand, engage, and retain members.

**Product vision:** MemberSync is the organization's second brain — always thinking about its members, always finding reasons to reach out, always making the organization feel personal and welcoming at a scale no human team could manage alone.

**Product philosophy:** "We don't give you a blank canvas. We give you a recommendation. You say yes or no."

**The lightsaber:** Organized real estate is in an existential fight. MLSs are going non-Realtor, removing the last transactional justification for association membership. MemberSync is the lightsaber — real, actionable intelligence about members AND the competitive environment they operate in.

**The 5% rule:** Every screen must earn its place. We build what clients asked for or dreamed about — not features that sound good in a roadmap.

**Decision-first UX:** Every view surfaces a recommended action, not just data.

**AI voice and trust philosophy:**
MemberSync AI observes real data and acts on it. It never invents, never infers beyond what the data shows. Every claim is grounded in real, verifiable data about actual members. The AI is confident, warm, shows its work, and is always on the member's side — never clinical, never alarming without a path forward.

**AEI conference context (critical):** The AEI/RESO conference in Minneapolis (March 23–27) is a NAR-sponsored event. NAR will be telling association executives to brace for further membership decline. MemberSync walks in with a product that says "here's exactly what to do about it." The timing is perfect. Every feature we complete before March 23 strengthens that story.

---

## 3. THE 75/12 RULE

At a typical real estate association or MLS, ~75% of members produce only ~12% of transaction volume — yet they pay ~75% of dues and fees. These are "Foundation" members: people who maintain their license, pay dues, and may never sell a house. They are the financial backbone.

Most associations ignore the 75% because they don't appear to be selling at scale. MemberSync is built for them. If you have 50,000 members and focus only on the top 25%, that leaves 37,500 members disengaged and likely to lapse.

**The 100% Coverage Test:** Any scoring signal covering fewer than 10% of membership is a vanity metric, not a scoring input.

**Why it matters now:** MLSs opening access to non-Realtor licensees threatens association membership. MemberSync serves both associations and MLSs.

---

## 4. MEMBER TIER FRAMEWORK

Members classified by 12-month transaction sides:

| Display Name | Internal Code | Sides (12mo) | Mainstreet % |
|---|---|---|---|
| Rainmaker | `active_producer` | 40+ | ~1.4% |
| Builder | `occasional_producer` | 6–39 | ~21% |
| Foundation | `license_maintainer` | 0–5 | ~77% |

**Critical rules:**
- Display names only in UI — never internal names
- All tiers framed positively — we celebrate connection, not police compliance
- Foundation members who take classes, pay on time, and attend events can score 10/10 — even with zero transactions
- Engagement is not production
- Tier thresholds defined in `tenant_config` — vary per client

---

## 5. CLIENT PIPELINE

| Client | Members | Status | Special Requirements |
|---|---|---|---|
| Mainstreet REALTORS® | 18,275 | First client, prototype stage | Chicago suburbs, IL compliance |
| HGAR / Hudson Gateway | 12,800 | Onboarding | Multi-tenant, NY compliance |
| GRAR / Greater Rochester | 3,400 | Third pilot | Multi-tenant, NY compliance |
| ~~CRMLS~~ | ~~103,000+~~ | ~~Pilot prospect — paused~~ | SOC 2, enterprise SLA, batch email at scale |

**CRMLS update (March 10):** CRMLS told Tracy their internal team is developing a similar product. Removed from active pipeline. Their CMO still wants MemberSync — keeping the relationship warm. Plenty of other large MLSs and associations to pursue.

**AEI/RESO Conference:** Minneapolis, March 23–27. **13 days out.** Campaign Architect is the demo centerpiece.

---

## 6. BUILD PHILOSOPHY & TEAM STRUCTURE

**Two-track development model:**
- **Track 1 (Tracy + Claude + Replit Agent):** Rapid prototype development and feature validation. Connected to read-only production data. Writes to local Replit DB when writes are needed.
- **Track 2 (Dev team + Claude Code):** Production platform — porting validated modules with proper multi-tenant architecture.

**Current dev team status (as of March 10):**
- Dev team has completed: monolith split, dev/staging/prod environments, Cognito auth, unified DB, CI/CD, multi-tenant architecture foundation
- AWS spin-up expected imminently
- DevOps engineer pulled a Replit snapshot from March 5 to stand up their version — they are behind Replit by ~5 days of development
- GitHub connection between this Claude Project and the repo is planned but not yet established
- CLAUDE.md updated March 9 (Tracy-edited version distributed to team)

**Handoff protocol:**
- Every Replit feature gets a prompt document saved to project knowledge
- CLAUDE.md updated to reflect completed features and architectural decisions
- Prompt docs go to `/docs/prompts` in GitHub; CLAUDE.md goes to `/docs/CLAUDE.md`
- Dev team reads prompt docs as authoritative specs when promoting to production
- Claude Code reads everything from the repo on every task

**Opt-out reversal policy (established March 10):**
Staff can remove any member-requested or manual opt-out via the Unsubscribe Management panel. Hard bounce suppressions are permanent — the email address is invalid and sending again would damage sender reputation.

---

## 7. CURRENT STATE: WHAT'S BUILT

### Core Platform
- Engagement scoring with tier classification (Rainmaker/Builder/Foundation)
- Member metrics cache (daily refresh, cache-first architecture)
- Dashboard with Association Pulse cards, Activity Feed, Member Recognition sidebar
- Member Detail pages with score breakdown, open/click timestamps, real profile data
- Daily membership snapshot for trend analysis

### SmartSends
- Campaign creation: AI + manual + template
- All four audience types (AI, manual, CSV upload, external contacts)
- Email Governor with sandbox mode, exempt categories
- Recognition Queue (full review/approve/send)
- Email Health Dashboard (Performance, Send Queue, Email Archive tabs)
- Image Library upgraded
- AI duplicate detection at Preview step
- Reporting & Analytics rebuilt as unified command center (March 9)
- Create flow rebuilt with 5 tiles (March 9)
- Standalone Automations list page deleted (March 9)
- Recognition and Compliance Performance pages built as real pages (March 9)
- **emailCategory bug: PARTIALLY FIXED — see Section 10 and Known Issues**
- **Audience persistence bug: PARTIALLY FIXED — see Section 10 and Known Issues**

### Campaign Architect (AI-first campaign builder)
All prompts fully deployed and verified. See Section 9 for complete status.

### Recognition Module
- Recognition Queue with review/approve/send flow
- Recognition emails exempt from Email Governor (Lane 1, no cap)
- Left nav badge showing pending count
- Performance page shows real data
- Recognition homepage: not yet built (deferred)

### Unsubscribe & Suppression Architecture
Fully rebuilt March 10. See Section 11 for complete status.

### AI Services
- AI Chat: natural language → SQL, cross-domain queries, retry loop, Julius-style analyst behavior
- AI email composition with archive-aware context
- AI audience builder
- AI duplicate detection
- AI campaign planner (Campaign Architect)
- Schema modularization for AI context (41–76% schema size reductions by query type)
- AI usage logging and rate limiting infrastructure (built March 8)

### Analytics / Market Stats
- Office Volume, Agent Production, Market Concentration
- Top 10 Offices and Agents
- Create Brief (PDF)

### Compliance Module
- Communications page
- Performance page shows real data

---

## 8. NAVIGATION STRUCTURE (CURRENT)

```
Dashboard
SmartSends [collapsible — label navigates to /smartsends home]
  → Create                 (/smartsends/create)
  → Reporting & Analytics  (/smartsends/reporting)
  → Audiences [collapsible]
      → AI Builder         (/smartsends/audiences)
      → Picklist           (/smartsends/audiences/picklist)
      → Member/Bill Type   (/smartsends/audiences/member-bill-type)
      → Saved              (/smartsends/audiences/saved)
      → Upload             (/smartsends/audiences?upload=true)
  → Content                (/smartsends/images)
  → Templates              (/smartsends/templates)
  → Settings               (/smartsends/settings)
Chats                      (/chats)
Recognition [collapsible — badge shows pending count]
  → Templates              (/recognition/templates — stub)
  → Performance            (/recognition/performance — real data)
  → Settings               (/recognition/settings — stub)
Engagement                 (greyed — Coming Soon, inert)
Retention                  (greyed — Coming Soon, inert)
Compliance [collapsible — label navigates to /compliance/communications]
  → Communications         (/compliance/communications)
  → Performance            (/compliance/performance — real data)
  → Settings               (/compliance/settings — stub)
Market Stats [collapsible]
  → Office Leaderboard     (/analytics/offices)
  → Agent Leaderboard      (/analytics/agents)
  → Create Brief           (/analytics/brief)
Members                    (/members)
Offices                    (/offices)
```

**Key nav decisions (standing):**
- Nav items are destinations. Actions live in buttons.
- Send Email, Drafts, Automations removed as standalone nav items
- Drafts accessible as a status filter within Reporting & Analytics
- Coming Soon items: opacity-50, small badge, cursor-default, no hover, no onClick
- All URL paths unchanged from pre-redesign — only display labels changed

---

## 9. CAMPAIGN ARCHITECT — FULL STATUS

Campaign Architect is the AI-first campaign builder that fully replaces the drip sequence builder. It is the AEI demo centerpiece.

### All Prompts — Fully Deployed ✅
1. Prompt 1 — conversation UI, planning, session persistence
2. Prompt 2 — email generation, editing, A/B, activation
3. Polish prompt — 5 UX improvements
4. Hardening prompt — negative delayDays fix, audience accumulation cleanup, rate limiting
5. Planner Intelligence Fix — multi-event series recognition. Verified working.
6. Addendum — branch emails, social proof prohibition, minimum 3 emails per event. Deployed.
7. Planner Voice & Grouping Fix — new AI voice section, event grouping logic. Deployed March 8.

### Key Architectural Decisions
- `anchorOffset` + `anchorDirection` replace ambiguous `delayDays` — never negative delayDays
- `saveAudience` accepts metadata in a single INSERT — not a two-step workaround (T002)
- Audience accumulation cleanup between campaigns
- Social proof prohibited in all Campaign Architect emails (no attendance numbers, no "members like you")
- Minimum 3 emails per event in any sequence
- Branch points are shallow — registration status and prior attendance only
- AI suggestions are always actionable yes/no — never configuration forms

---

## 10. SMARTSENDS — FULL STATUS

### Email Category Bug (ACTIVE — in progress tonight)

**Root cause discovered this session:** `emailCategory` is derived correctly on the client side (`SendEmail.tsx` line 424) but is never included in the `campaignData` payload sent to the server. The server's `createCampaignSchema` doesn't define the field. `queueEmailCampaign()` is called without it and defaults every campaign to `'engagement'`. This means every campaign in the database currently has `emailCategory = 'engagement'` regardless of actual type.

**Fix plan (T001 — approved, not yet implemented):**
1. Add `emailCategory` to `createCampaignSchema` in `server/routes.ts` (~line 4928) as optional string defaulting to `'engagement'`
2. Add `emailCategory: emailCategoryForContext` to `campaignData` object in `SendEmail.tsx` (~lines 1687–1694)
3. Pass `emailCategory` through to `queueEmailCampaign()` call in `server/routes.ts` (~line 5027)

**Status:** Replit has the instructions. Not yet implemented as of this summary.

### Audience Persistence Bug (ACTIVE — in progress tonight)

**Root cause discovered this session:** Draft saves only `audienceId` (a string), not the full audience object. On reload, the full audience is reconstructed from a live React Query fetch. If the fetch hasn't completed when the missing-audience guard runs (lines 524–549), the guard clears the audience ID — even though the audience still exists. The React Query `refetchOnWindowFocus` setting is also triggering the guard mid-session when users switch browser tabs.

**Fix plan (T002 — approved, not yet implemented):**
1. Add `isLoading` check to the missing-audience guard — only run when `audiencesQuery.isLoading === false`
2. Add `refetchOnWindowFocus: false` to the audiences query

**Important — T002 is NOT blocked by T001.** Replit listed it as blocked — this is incorrect. They touch different parts of the code.

**Known limitation of this fix:** The fix addresses the symptoms but not the root cause. The proper fix is to save the full audience object (name, count, memberKeys or query) into the draft record, not just the ID. This removes the live-query dependency entirely. The proper fix is deferred to Track 2 (dev team). This is documented in the parking lot.

**Additional verification required:** After both fixes, test by creating a draft, closing the browser tab completely, reopening the app, and reloading the draft. The audience must survive a full session break, not just navigation between steps.

**Status:** Replit has the instructions. Not yet implemented as of this summary.

### Send Flow Bug (FIXED tonight)
`queueEmailCampaign()` was passing a JavaScript string array directly to PostgreSQL's `ANY()` function. PostgreSQL requires `{value1,value2}` format. Fixed by converting JS array to proper PostgreSQL array literal string with explicit `text[]` cast. Verified working.

### SmartSends Architecture
- `SmartSends.tsx` has been confirmed deleted — only `SmartSendsHome.tsx` exists at `/smartsends`
- Reporting & Analytics is the unified command center for all SmartSends outbound activity
- Recognition and Compliance sends are NOT SmartSends — separate modules, never appear in SmartSends filters
- Member drill-down required on every sent campaign — no exceptions

---

## 11. UNSUBSCRIBE & SUPPRESSION ARCHITECTURE — FULL STATUS

### Architecture Decision (Permanent)
Email address is the universal suppression identifier. `member_email_preferences` primary key is `emailAddress`. `memberKey` is an optional indexed column. This enables non-members (CSV uploads, external contacts) to unsubscribe.

### Migration Completed (T001–T006, March 10)
- T001: Schema migrated — `emailAddress` as PK. Unresolvable rows flagged with `migration_status = 'unresolved'` (never auto-deleted — CAN-SPAM)
- T002: Unsubscribe/preference URLs and tokens use email. Backward compat redirect for old `?m=` links
- T003: `canSendToMember` renamed to `canSendToRecipient`, checks by `emailAddress`
- T004: `queueEmailCampaign` opt-out filtering uses email
- T005: Staff unsubscribe management — search by name, email, or Member ID
- T006: Verification complete. Webhook sends to `member_email_preferences` using `emailAddress` from SendGrid payload

### Suppression Hardening (Items 1–6, in progress tonight)

**Item 3 — canSendToMember alias gap (ACTIVE — prompt sent to Replit):**
The backward-compatible alias `canSendToMember` passes empty string for `emailAddress`, so it only checks suppressions by `memberKey`. If a member's suppression row was written via the new email-based flow, the alias won't find it. `triggeredCampaignProcessor.ts` uses this alias — this is a live CAN-SPAM exposure.

**Fix:** Alias must look up member's email from `member_metrics_cache` before calling `canSendToRecipient`. Full signature preserved including `emailCategory` parameter. Degrades gracefully if lookup fails (still checks by memberKey, logs warning).

**Important signature detail confirmed by Replit:** `canSendToMember` has signature `(memberKey: string, emailCategory: string = 'engagement')` — the `emailCategory` parameter must be preserved and passed through to `canSendToRecipient`.

**Item 6 — Legacy write paths missing emailAddress (ACTIVE — prompt sent to Replit):**
Two legacy write paths identified that write to `member_email_preferences` without `emailAddress`:
- `server/routes.ts` lines 5615/5625 — member profile preferences endpoint (writes by memberKey)
- `server/routes.ts` lines 6173/6182 — SendGrid webhook bounce handler (writes by memberKey)

**Fix:** 
- Create shared `resolveEmailForMember(memberKey)` utility in `emailService.ts`
- Both paths call this utility before writing
- Fallback: use `memberKey` as `emailAddress` value if lookup fails (logs warning)
- For bounce handler specifically: use `event.email` from SendGrid payload directly if available — more reliable than cache lookup
- Startup backfill: runs on every startup, only touches rows where `emailAddress IS NULL`, sets `migration_status = 'resolved'` on fixed rows, leaves `migration_status = 'unresolved'` where fallback was used

**Drizzle upsert note:** Use raw SQL for upserts against `emailAddress` — Drizzle's `onConflictDoUpdate` requires the unique constraint to be declared in `schema.ts` which it is not yet (that's Item 1). Do not add `.unique()` to schema until Item 1 prompt.

**Other write paths (already correct):**
- `GET /unsubscribe` — already email-based ✅
- `POST /email-preferences` — already email-based ✅
- `DELETE /api/smartsends/unsubscribes` — handles both ✅
- `POST /api/smartsends/unsubscribes` — already email-based ✅
- `server/index.ts` startup migration — already handles emailAddress ✅

**Status of Items 3 and 6:** Prompt sent, Replit working. Replit asked 4 clarifying questions, all answered. Implementation in progress.

**Items 1, 2, 4, 5 — Not yet started:**
- **Item 1:** Drizzle schema sync — unique constraint on `emailAddress` not declared in `schema.ts`. Risk: future `db:push` silently drops the raw SQL partial index. Fix: add `.unique()` to schema.
- **Item 2:** `memberKey` semantic overload — non-member suppressions use `memberKey = emailAddress` as a workaround. If non-member later becomes a member, deduplication gap. Fix: proper null-safe `memberKey` for non-members.
- **Item 4:** Governor rate-limiting skipped for non-members — low risk for now.
- **Item 5:** SQL injection in staff search — string interpolation with quote escaping instead of parameterized queries.

**Prompt for Items 1 and 2:** Not yet written. Will include suppression health alerting (flagging lookup failures in admin dashboard when count exceeds 10 in 24 hours). Write this prompt next session.

### Suppression Health Alerting (Design Decision)
When `canSendToMember` email lookup fails, it should not only log a warning — it must increment a counter visible in the admin dashboard. If suppression lookup failures exceed 10 in 24 hours, the admin endpoint (`GET /api/admin/usage`) should return `suppression_health: 'degraded'`. This will be included in the Items 1 and 2 prompt.

### Webhook Fix (HOLD)
`MemberSync_Webhook_CategoryUnsubscribeFix.md` is written and ready. Must send AFTER Items 3 and 6 are verified. Webhook writes to `member_email_preferences` — building on unstable foundation would require rework.

### Tonight's Remaining Fix Order
1. ✅ Items 3 + 6 prompt sent — Replit working
2. 📝 Items 1 + 2 prompt — write next session (includes suppression health alerting)
3. 📝 Item 5 prompt — SQL injection fix
4. 📝 Item 4 prompt — governor for non-members
5. 📝 Webhook prompt — send last

---

## 12. AI COST CONTROLS — STATUS

Prompt sent and implemented (March 8). Infrastructure built — plumbing only, no UI yet. Admin endpoint `GET /api/admin/usage` exists. Rate limiting per feature exists. Kill switches exist. Usage dashboard not yet built.

---

## 13. PROMPT QUEUE — CURRENT STATUS

| Prompt | Status | Notes |
|--------|--------|-------|
| Items 3+6 suppression hardening | 🔄 In Progress | Sent to Replit tonight |
| SendEmail emailCategory fix (T001) | 🔄 In Progress | Instructions sent to Replit tonight |
| SendEmail audience persistence fix (T002) | 🔄 In Progress | Instructions sent to Replit tonight — NOT blocked by T001 |
| Items 1+2 suppression hardening | 📝 To Write | Includes suppression health alerting |
| Item 5 SQL injection fix | 📝 To Write | |
| Item 4 governor for non-members | 📝 To Write | |
| Webhook category + unsubscribe fix | 📋 Written, On Hold | Send after Items 3+6 verified |
| Nav cleanup | 📋 Written, Ready | Send after tonight's fixes verified |
| Recognition Homepage | 📋 Pending | Stat cards, "What's resonating," "Coming up" queue |
| Compliance Homepage | 📋 Pending | Triage dashboard |
| SmartSends.tsx retirement | 📋 Pending | Promote SmartSendsHome.tsx fully |
| CLAUDE.md comprehensive update | ⚠️ Overdue | Dev team needs this — highest priority after fixes |
| Proactive AI Engagement Engine | 🗓️ Post-AEI | Top feature priority after demo |

---

## 14. STANDING RULES — CANONICAL (30 Rules)

1. No parallel systems — extend existing components, never build duplicate implementations
2. Don't break what works — verify before and after every change
3. Full-page patterns, not modals, for multi-step tasks
4. Shared components over duplicates
5. Server-side for anything touching more than 1,000 records
6. Test your work — happy path and at least one edge case before reporting complete
7. "Recognition" in UI everywhere — "Celebration" in code only
8. Email category is required on all campaigns — no null categories
9. Governor exemptions are: transactional, compliance, critical, recognition
10. Campaign Architect replaces drip sequence builder — no parallel UI
11. AI suggestions are always actionable (yes/no) — never configuration forms
12. Competitive intelligence queries must respect tenant isolation — no cross-client data leakage
13. No fake data. Ever. Real member data or clearly labeled sample data only
14. Every module gated by tenant_config — disabled = not rendered, no background jobs, no AI budget
15. The 5% rule — build what clients asked for or dreamed about, not what sounds good in a roadmap
16. Mobile-first, performance-always — responsive UI, under 2 seconds load time
17. CLAUDE.md is the single source of truth for the production repository
18. Every scoring signal must pass the 100% Coverage Test before inclusion
19. Complete prompts sequentially — do not batch all changes and deploy simultaneously
20. Spec-first development — implement exactly what is specified, no more and no less
21. Social proof is never used in Campaign Architect emails — no attendance numbers, no "members like you," no testimonials
22. Minimum 3 emails per event in any Campaign Architect sequence
23. Campaign Architect branch points are shallow — registration status and prior attendance only
24. Recognition is a top-level nav module — never nest inside SmartSends
25. Nav items are destinations — actions live in buttons
26. Every email sent through MemberSync must be real and verifiable — no hallucinated data, no invented member details, no fabricated statistics
27. Every AI call must be logged — every AI feature must have a rate limit and a kill switch
28. **Do not modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts` for any reason**
29. **When refactoring a function called by `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts`, keep the original function name as a thin wrapper that calls the new function — never update the call sites in those files**
30. **Before implementing any change to a database table's primary key or core identifier column, search the entire codebase for every reference to that table and column and report the complete list before writing a single line of code — applies especially to: `member_email_preferences`, `email_campaigns`, `member_metrics_cache`, `triggered_campaigns`**

Rules 28–30 are bolded until ~3–4 more successful prompt cycles confirm Replit consistently respects them. Drop bold after that.

---

## 15. ARCHITECTURAL DECISIONS (CANONICAL)

### Database
- Single PostgreSQL database in production (two-database Replit setup is a safety workaround only)
- Cache-first: `member_metrics_cache` is single source of truth for member data at scale
- Every query against AMS/MLS tables must deduplicate via `ROW_NUMBER() OVER (PARTITION BY ...)`
- Snapshot deduplication is non-negotiable — no exceptions

### Multi-Tenant
- Multi-tenant isolation is a critical gap in the Replit prototype (only one of 20+ tables has `client_id`)
- Production port must have proper multi-tenant architecture from day one
- Stage 0 client intake: a single `tenant_config` row drives scoring, UI visibility, AI prompt context, and compliance panels

### Email & Suppression
- `emailAddress` is the universal suppression key in `member_email_preferences`
- `memberKey` is optional indexed column — not the primary key
- `canSendToMember` is a thin wrapper around `canSendToRecipient` — never change its call sites in the processor
- UPSERT pattern for all webhook suppression writes
- Never auto-delete opt-out rows — flag unresolvable rows as `migration_status = 'unresolved'`
- Hard bounce suppressions are permanent — staff cannot reverse them

### Email Category
- `emailCategory` is required on every campaign record — no nulls
- Governor exemptions: transactional, compliance, critical, recognition
- Category must flow from client through `campaignData` payload to `queueEmailCampaign()` — client-side derivation is not sufficient

### Campaign Architect
- `anchorOffset` + `anchorDirection` replace `delayDays` — never negative values
- `saveAudience` accepts metadata in a single INSERT
- Audience accumulation cleanup between campaigns

### Engagement Scoring
- Data-driven, not code-driven — weights and signals from `tenant_config`, not if-statements
- Payment is table stakes, not an engagement signal
- Transactions are baseline activity, not organizational connection

### MemberKey Format
- AMS keys: no prefix (e.g., `259036`)
- MLS keys: `MRD` prefix (e.g., `MRD259036`)
- Join pattern: `'MRD' || ams_key = mls_key`
- `MRD` prefix is Mainstreet-specific — must become configurable per client

### Billing Codes
- Created dynamically, can never be reused — pattern-based recognition required, not hardcoded lists

---

## 16. KNOWN ISSUES & TECHNICAL DEBT

### Active Issues (In Progress Tonight)
- **emailCategory never sent to server** — fix instructions given to Replit (T001). Every campaign currently defaults to `'engagement'`.
- **Audience persistence fragile** — fix instructions given to Replit (T002). Proper fix (save full audience object) deferred to Track 2.
- **canSendToMember alias suppression gap** — prompt sent to Replit (Item 3). Live CAN-SPAM exposure.
- **Legacy write paths missing emailAddress** — prompt sent to Replit (Item 6). Bounce handler and member profile endpoint.

### Active Issues (Prompt Written, Not Yet Sent)
- **Drizzle schema not declaring unique constraint on emailAddress** — Items 1+2 prompt to write next session
- **memberKey semantic overload for non-members** — Items 1+2 prompt
- **SQL injection in staff unsubscribe search** — Item 5 prompt
- **Governor not applied to non-member recipients** — Item 4 prompt
- **Webhook SendGrid footer links** — Tracy disabling in SendGrid dashboard directly
- **Webhook category-unsubscribe fix** — prompt written, on hold until Items 3+6 verified

### Post-AEI Technical Debt
- Draft audience persistence: save full audience object, not just ID (Track 2)
- `server/routes.ts` is a monolith (~9,500 lines) — most urgent refactoring target for dev team
- A/B testing: framework built, not fully activated
- Drip Sequence Step Editor needs proper EmailComposer integration
- Templates system needs full rework
- Missing event warning at Campaign Architect activation when anchor event removed
- Duplicate detection threshold (70%) should be configurable per client in `tenant_config`
- `clientConfig.ts` has 110+ hardcoded client references — production port must eliminate
- 19 of 20+ tables missing `client_id` — multi-tenant isolation gap
- AI usage dashboard not built (infrastructure exists)

---

## 17. KEY FILES REFERENCE

### Sensitive Files — Handle With Extreme Care
- `server/services/triggeredCampaignProcessor.ts` — **DO NOT MODIFY for any reason**
- `server/services/sequenceEnrollmentService.ts` — **sensitive execution infrastructure — do not modify without explicit instruction**

### Key Application Files
- `server/routes.ts` — Monolith (~9,500 lines) — most urgent refactoring target
- `shared/schema.ts` — All tables and TypeScript types
- `client/src/pages/SendEmail.tsx` — Email send flow (emailCategory and audience bugs being fixed)
- `client/src/pages/CampaignArchitect.tsx` — Campaign Architect UI
- `server/services/aiCampaignPlannerService.ts` — Campaign Architect planner
- `client/src/components/layout/AppSidebar.tsx` — Navigation
- `server/services/clientConfig.ts` — All client-specific values (must become `tenant_config` in production)
- `server/services/aiQueryService.ts` — AI Chat query service
- `server/services/aiEmailService.ts` — AI email composition
- `server/services/aiAudienceService.ts` — AI audience generation
- `server/services/memberMetricsCacheService.ts` — Engagement scoring engine
- `server/services/aiUsageLogger.ts` — AI call logging
- `server/services/emailService.ts` — All outbound email; `canSendToMember` wrapper lives here
- `server/services/sendgridUnsubscribeGroups.ts` — SendGrid group creation service
- `client/src/pages/SmartSendsReporting.tsx` — Unified campaign list
- `client/src/pages/CampaignDetail.tsx` — Full campaign detail page
- `client/src/pages/UnsubscribeManagement.tsx` — Staff unsubscribe panel
- `client/src/pages/SmartSendsHome.tsx` — SmartSends newsroom homepage
- `client/src/pages/SmartSendsSettings.tsx` — Settings page

### Prompt Files — Deployed ✅
- All Campaign Architect prompts (Prompt1, Prompt2, Polish, Hardening, PlannerFix, Addendum, PlannerVoice)
- `MemberSync_SchemaModularization_Prompt.md`
- `MemberSync_AIChat_JuliusUpgrade_Prompt.md`
- `MemberSync_QueryEngine_RetryAndCrossDomain.md`
- `MemberSync_PromptA_RecognitionQueue_EmailGovernor.md` (Parts 1–8)
- `MemberSync_PromptB_EmailHealth_ImageLibrary.md`
- `MemberSync_ImageLibrary_Upgrade_Prompt.md`
- `MemberSync_NavigationRedesign_Final.md`
- `MemberSync_SmartSends_ReportingFix_Final.md`
- `MemberSync_AICostControls_Prompt.md`
- `MemberSync_RecipientTracking_UnsubscribeArchitecture.md` ✅

### Prompt Files — In Progress / Ready to Send 📝
- `MemberSync_SuppressionHardening_Items3and6.md` — sent to Replit tonight, in progress
- `MemberSync_Webhook_CategoryUnsubscribeFix.md` — written, on hold until Items 3+6 verified
- `MemberSync_NavCleanup_Prompt.md` — written, ready to send

### Prompt Files — To Write Next Session
- Items 1+2 suppression hardening (schema sync + memberKey overload + suppression health alerting)
- Item 5 SQL injection fix
- Item 4 governor for non-members
- CLAUDE.md comprehensive update

### Reference Documents
- `CLAUDE.md` — Product bible. Tracy-edited version distributed to dev team March 9.
- `MemberSync_Parking_Lot.md` — Strategic ideas backlog
- `MemberSync_Development_Plan.docx`
- `Membio_AI_Workflow_Playbook.docx`

---

## 18. PARKING LOT SUMMARY

Full detail in `MemberSync_Parking_Lot.md`. Key items:

### Features to Build (Prioritized)
1. **Proactive AI Engagement Engine** ⭐ Top priority after AEI demo
2. **Lapse Prevention System** — calendar-aware risk scoring, automated intervention
3. **Persistent Organizational Intelligence / AI Memory Layer** ⭐
4. **Email Archive as AI Memory**
5. **Campaign Engagement Map** ⭐ Demo-worthy
6. **AI Chart Rendering** — Recharts inline in AI Chat
7. **Competitive Intelligence Module**
8. **Broker Module**
9. **Recognition CEO Voice Text Messages** (upsell tier)
10. **Universal Communications Ledger** (premium tier)

### New Parking Lot Item Added This Session
- **Draft audience persistence — proper fix:** Save full audience object (name, count, memberKeys or query) into the draft record rather than just the ID. Removes live-query dependency entirely on draft reload. Deferred to Track 2 production port.

### Infrastructure
- SOC 2 Certification (required when CRMLS is back)
- Prompt caching (90% cost reduction on input)
- Batch email sending (CRMLS scale)
- Self-service onboarding (after 4–5 manual clients)

---

## 19. AEI DEMO PLAN

**Conference:** AEI/RESO, Minneapolis, March 23–27. **13 days out.**
**Context:** NAR will tell attendees to brace for membership decline. MemberSync is the answer in the room.

**Demo path (planned):**
AI Chat → Campaign Architect → Member Recognition → Dashboard

**Must be working cleanly before travel:**
- Campaign Architect: end-to-end, verified, no rough edges
- Navigation: clean, no broken links
- Dashboard: Association Pulse cards showing real data
- Recognition Queue: working
- emailCategory and audience persistence bugs: resolved
- All suppression hardening items resolved (or at minimum Items 3 and 6)
- Engagement and Retention "Coming Soon" labels visible in nav (sets up the story)

**AEI demo stretch goals (MVP versions acceptable):**
- Proactive AI Engagement Engine — real data cards on dashboard showing pattern insights
- Lapse Prevention — risk indicator with real signal

**What demo attendees need to SEE:** Real numbers, real members, specific and actionable insights. The "Coming Soon" labels for Engagement and Retention in the nav actually help — they show a roadmap without requiring the features to be built.

---

## NEXT SESSION — START HERE

**Where we left off:** Replit is working on two parallel tracks tonight:
1. Suppression hardening Items 3+6 (prompt `MemberSync_SuppressionHardening_Items3and6.md`)
2. EmailCategory fix (T001) and audience persistence fix (T002) for `SendEmail.tsx`

**First thing next session:**
1. Check if Replit finished Items 3+6 — verify using the checklist in the prompt
2. Check if T001 and T002 are done — run the full verification including the browser-close test
3. Write Items 1+2 suppression hardening prompt (includes suppression health alerting)
4. Send Nav Cleanup prompt
5. Send Webhook fix prompt (only after Items 3+6 verified)
6. **CLAUDE.md update is overdue — dev team needs it**

---

*Session date: March 10, 2026 (Evening)*
*AEI/RESO Conference: March 23–27. 13 days out.*
*Replit status: Working on suppression hardening (Items 3+6) and SendEmail bugs (T001/T002) simultaneously.*
*Tonight's deal: No technical debt, no dead code, nothing left behind. If Claude sees it, Claude calls it.*

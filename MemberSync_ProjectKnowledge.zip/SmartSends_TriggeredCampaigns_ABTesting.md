# SmartSends: Triggered Campaigns + A/B Testing
## Replit Prompt — February 20, 2026

---

## CONTEXT FOR REPLIT AGENT

SmartSends currently supports two email flows: immediate sends and scheduled sends. This prompt adds two major capabilities:

1. **Triggered Campaigns (Automations)** — Automated emails that fire when specific conditions are met in the data. Unlike one-shot campaigns, these run continuously: the system watches for qualifying members and sends emails automatically. Examples: event registration confirmation, pre-event reminder, membership anniversary, production milestone celebration.

2. **A/B Testing** — Send two variants of an email (different subject lines, different body content, or both) to equal halves of an audience, then see which performs better. This uses the existing `parentCampaignId` and `campaignVersion` fields that are already in the schema.

**CRITICAL RULES:**
- Do NOT modify or break the existing email sending infrastructure. The existing `queueEmailCampaign()` function, `scheduledEmailProcessor`, email templates, campaigns table, and recipients table all stay exactly as they are. 
- Triggered campaigns REUSE the existing send infrastructure — they automate the decision of *when* and *who* to send to, then call `queueEmailCampaign()` like everything else.
- A/B testing REUSES the existing campaign/recipient/events tables — it just creates two campaign records that share a `parentCampaignId`.

---

## PART 1: DATABASE TABLES

### New Table: `triggered_campaigns`

The main configuration table. Each row defines what triggers the email, what to send, and when.

```sql
CREATE TABLE IF NOT EXISTS triggered_campaigns (
  campaign_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Basic info
  campaign_name TEXT NOT NULL,
  description TEXT,
  
  -- What triggers it
  trigger_type TEXT NOT NULL,
  -- Phase A triggers:
  -- 'event_registration'      — Someone registers for a class or event
  -- 'event_reminder'          — X days before an upcoming event
  -- 'event_followup'          — X days after an event ends
  -- 'membership_anniversary'  — Annual membership anniversary date
  -- 'production_milestone'    — Transaction or volume milestone detected
  -- 'drip_sequence'           — Freeform multi-step campaign to a chosen audience on a chosen schedule
  
  -- Trigger-specific configuration (JSON)
  trigger_config JSONB DEFAULT '{}',
  -- event_registration: { "eventTypes": ["class", "event"], "lookbackDays": 7 }
  -- event_reminder:     { "daysBefore": 1 }
  -- event_followup:     { "daysAfter": 1 }
  -- membership_anniversary: { "years": [1, 5, 10, 15, 20, 25, 30] }
  -- production_milestone:   { "milestoneTypes": ["transaction_milestone", "volume_milestone"] }
  
  -- Email content
  subject_line TEXT NOT NULL,
  email_body TEXT NOT NULL,
  
  -- A/B testing (optional)
  subject_line_b TEXT,           -- Variant B subject (null = no A/B test)
  email_body_b TEXT,             -- Variant B body (null = use same body)
  ab_test_enabled BOOLEAN DEFAULT false,
  
  -- Send window
  send_window_start TIME DEFAULT '08:00',
  send_window_end TIME DEFAULT '17:00',
  send_window_timezone TEXT DEFAULT 'America/Chicago',
  send_on_weekends BOOLEAN DEFAULT false,
  
  -- Status lifecycle
  status TEXT NOT NULL DEFAULT 'draft',
  -- 'draft'    — Being configured, not active
  -- 'active'   — Running, processor evaluates on each cycle
  -- 'paused'   — Temporarily stopped
  -- 'archived' — Permanently stopped
  
  -- Auto-stop
  auto_stop_date TIMESTAMP,
  auto_stop_on_event_passed BOOLEAN DEFAULT true,
  
  -- Metadata
  created_by TEXT NOT NULL DEFAULT 'system',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  activated_at TIMESTAMP,
  paused_at TIMESTAMP,
  archived_at TIMESTAMP,
  
  -- Stats (updated by processor)
  total_sent INTEGER DEFAULT 0,
  total_sent_a INTEGER DEFAULT 0,
  total_sent_b INTEGER DEFAULT 0,
  last_processed_at TIMESTAMP,
  last_sent_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_triggered_campaigns_status ON triggered_campaigns(status);
```

### New Table: `triggered_campaign_sends`

Deduplication and history table. Tracks every individual send to ensure no one gets the same triggered email twice.

```sql
CREATE TABLE IF NOT EXISTS triggered_campaign_sends (
  send_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID NOT NULL REFERENCES triggered_campaigns(campaign_id) ON DELETE CASCADE,
  
  -- Recipient
  member_key TEXT NOT NULL,
  member_email TEXT,
  member_name TEXT,
  
  -- What triggered it
  trigger_reference TEXT NOT NULL,
  -- event_registration: "event_reg_{EventId}"
  -- event_reminder: "event_reminder_{EventId}_1d"
  -- event_followup: "event_followup_{EventId}"
  -- membership_anniversary: "anniversary_2026_10yr"
  -- production_milestone: "milestone_{milestoneType}_{value}"
  
  -- A/B variant tracking
  ab_variant TEXT DEFAULT 'A',  -- 'A' or 'B'
  
  -- Status
  status TEXT NOT NULL DEFAULT 'pending',
  -- 'pending'  — Qualified, waiting for send window
  -- 'queued'   — Passed to queueEmailCampaign
  -- 'sent'     — Confirmed sent
  -- 'skipped'  — Skipped (opted out, event passed, etc.)
  -- 'failed'   — Error during send
  
  skip_reason TEXT,
  email_campaign_id UUID,  -- Links to the email_campaigns record created by queueEmailCampaign
  
  -- Timing
  trigger_date TIMESTAMP,
  scheduled_send_at TIMESTAMP,
  queued_at TIMESTAMP,
  sent_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_triggered_sends_dedup ON triggered_campaign_sends(campaign_id, member_key, trigger_reference);
CREATE INDEX IF NOT EXISTS idx_triggered_sends_status ON triggered_campaign_sends(status);
CREATE INDEX IF NOT EXISTS idx_triggered_sends_campaign ON triggered_campaign_sends(campaign_id);
```

### New Table: `triggered_campaign_steps`

For **drip sequences** (multi-step campaigns where each email sends on a schedule), each step is a separate row. Single-email triggered campaigns (like an anniversary congratulations) don't need steps — they use the campaign-level subject/body. But drip sequences use this table to define 2+ emails with delays and branching logic.

```sql
CREATE TABLE IF NOT EXISTS triggered_campaign_steps (
  step_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID NOT NULL REFERENCES triggered_campaigns(campaign_id) ON DELETE CASCADE,
  
  -- Step ordering
  step_number INTEGER NOT NULL DEFAULT 1,
  step_name TEXT,                           -- e.g., "Welcome Email", "7-Day Follow-up", "Final Reminder"
  
  -- Timing relative to activation (for drip) or trigger event (for other types)
  delay_days INTEGER NOT NULL DEFAULT 0,    -- Days to wait before sending this step
  -- Step 1 with delay 0 = send immediately
  -- Step 2 with delay 7 = send 7 days after step 1
  -- Step 3 with delay 14 = send 14 days after activation
  
  -- Email content for this step
  subject_line TEXT NOT NULL,
  email_body TEXT NOT NULL,
  
  -- Branching logic (optional)
  send_condition TEXT DEFAULT 'always',
  -- 'always'              — Send to everyone in the audience
  -- 'opened_previous'     — Only send if they opened the previous step
  -- 'not_opened_previous' — Only send if they did NOT open the previous step
  -- 'clicked_previous'    — Only send if they clicked in the previous step
  -- 'not_clicked_previous'— Only send if they did NOT click in the previous step
  
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT unique_campaign_step UNIQUE (campaign_id, step_number)
);
```

### New Table: `drip_sequence_members`

Tracks which members are enrolled in a drip sequence and what step they're on.

```sql
CREATE TABLE IF NOT EXISTS drip_sequence_members (
  enrollment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID NOT NULL REFERENCES triggered_campaigns(campaign_id) ON DELETE CASCADE,
  member_key TEXT NOT NULL,
  member_email TEXT,
  member_name TEXT,
  
  -- Progress tracking
  current_step INTEGER DEFAULT 0,          -- 0 = enrolled but step 1 not yet sent
  enrolled_at TIMESTAMP DEFAULT NOW(),
  last_step_sent_at TIMESTAMP,
  next_step_due_at TIMESTAMP,              -- When the next step should be evaluated
  
  -- Status
  status TEXT DEFAULT 'active',
  -- 'active'    — Still progressing through sequence
  -- 'completed' — All steps sent
  -- 'removed'   — Manually removed or opted out
  
  CONSTRAINT unique_drip_enrollment UNIQUE (campaign_id, member_key)
);

CREATE INDEX IF NOT EXISTS idx_drip_members_next_due ON drip_sequence_members(campaign_id, status, next_step_due_at);
```

### Add Schema Definitions in `shared/schema.ts`

Add Drizzle table definitions for both tables:

```typescript
export const triggeredCampaigns = pgTable("triggered_campaigns", {
  campaignId: uuid("campaign_id").primaryKey().default(sql`gen_random_uuid()`),
  campaignName: text("campaign_name").notNull(),
  description: text("description"),
  triggerType: text("trigger_type").notNull(),
  triggerConfig: jsonb("trigger_config").default({}),
  subjectLine: text("subject_line").notNull(),
  emailBody: text("email_body").notNull(),
  subjectLineB: text("subject_line_b"),
  emailBodyB: text("email_body_b"),
  abTestEnabled: boolean("ab_test_enabled").default(false),
  sendWindowStart: text("send_window_start").default("08:00"),
  sendWindowEnd: text("send_window_end").default("17:00"),
  sendWindowTimezone: text("send_window_timezone").default("America/Chicago"),
  sendOnWeekends: boolean("send_on_weekends").default(false),
  status: text("status").notNull().default("draft"),
  autoStopDate: timestamp("auto_stop_date"),
  autoStopOnEventPassed: boolean("auto_stop_on_event_passed").default(true),
  createdBy: text("created_by").notNull().default("system"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  activatedAt: timestamp("activated_at"),
  pausedAt: timestamp("paused_at"),
  archivedAt: timestamp("archived_at"),
  totalSent: integer("total_sent").default(0),
  totalSentA: integer("total_sent_a").default(0),
  totalSentB: integer("total_sent_b").default(0),
  lastProcessedAt: timestamp("last_processed_at"),
  lastSentAt: timestamp("last_sent_at"),
});

export const triggeredCampaignSends = pgTable("triggered_campaign_sends", {
  sendId: uuid("send_id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").notNull(),
  memberKey: text("member_key").notNull(),
  memberEmail: text("member_email"),
  memberName: text("member_name"),
  triggerReference: text("trigger_reference").notNull(),
  abVariant: text("ab_variant").default("A"),
  status: text("status").notNull().default("pending"),
  skipReason: text("skip_reason"),
  emailCampaignId: uuid("email_campaign_id"),
  triggerDate: timestamp("trigger_date"),
  scheduledSendAt: timestamp("scheduled_send_at"),
  queuedAt: timestamp("queued_at"),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const triggeredCampaignSteps = pgTable("triggered_campaign_steps", {
  stepId: uuid("step_id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").notNull(),
  stepNumber: integer("step_number").notNull().default(1),
  stepName: text("step_name"),
  delayDays: integer("delay_days").notNull().default(0),
  subjectLine: text("subject_line").notNull(),
  emailBody: text("email_body").notNull(),
  sendCondition: text("send_condition").default("always"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dripSequenceMembers = pgTable("drip_sequence_members", {
  enrollmentId: uuid("enrollment_id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").notNull(),
  memberKey: text("member_key").notNull(),
  memberEmail: text("member_email"),
  memberName: text("member_name"),
  currentStep: integer("current_step").default(0),
  enrolledAt: timestamp("enrolled_at").defaultNow(),
  lastStepSentAt: timestamp("last_step_sent_at"),
  nextStepDueAt: timestamp("next_step_due_at"),
  status: text("status").default("active"),
});
```

---

## PART 2: TRIGGERED CAMPAIGN PROCESSOR

### New File: `server/services/triggeredCampaignProcessor.ts`

This service runs every 15 minutes, evaluates all active triggered campaigns, finds qualifying members, deduplicates, and queues sends.

```typescript
import { db } from '../db';
import { externalPool } from '../db';
import { triggeredCampaigns, triggeredCampaignSends, memberMetricsCache } from '@shared/schema';
import { eq, and, sql, inArray } from 'drizzle-orm';
import { queueEmailCampaign } from './emailService';
import { CLIENT_ID } from './clientConfig';

let processorInterval: NodeJS.Timeout | null = null;
const PROCESS_INTERVAL_MS = 15 * 60 * 1000; // 15 minutes

interface QualifyingMember {
  memberKey: string;
  memberName: string;
  memberEmail: string;
  triggerReference: string;
  triggerDate: Date;
  mergeData?: Record<string, string>;
}

// ============================================================
// MAIN PROCESSING LOOP
// ============================================================

export async function processTriggeredCampaigns() {
  try {
    // Get all active campaigns
    const activeCampaigns = await db.select()
      .from(triggeredCampaigns)
      .where(eq(triggeredCampaigns.status, 'active'));
    
    if (activeCampaigns.length === 0) return;
    
    console.log(`[TRIGGERED] Processing ${activeCampaigns.length} active campaigns`);
    
    for (const campaign of activeCampaigns) {
      try {
        // Check auto-stop conditions
        if (campaign.autoStopDate && new Date(campaign.autoStopDate) < new Date()) {
          console.log(`[TRIGGERED] Auto-stopping campaign ${campaign.campaignName} (past stop date)`);
          await db.update(triggeredCampaigns)
            .set({ status: 'archived', archivedAt: new Date() })
            .where(eq(triggeredCampaigns.campaignId, campaign.campaignId));
          continue;
        }
        
        // Evaluate trigger to find qualifying members
        const qualifying = await evaluateTrigger(campaign);
        
        if (qualifying.length === 0) {
          await db.update(triggeredCampaigns)
            .set({ lastProcessedAt: new Date() })
            .where(eq(triggeredCampaigns.campaignId, campaign.campaignId));
          continue;
        }
        
        console.log(`[TRIGGERED] Campaign "${campaign.campaignName}" found ${qualifying.length} qualifying members`);
        
        // Deduplicate: check which members haven't already been sent/queued for this trigger
        for (const member of qualifying) {
          await processQualifyingMember(campaign, member);
        }
        
        await db.update(triggeredCampaigns)
          .set({ lastProcessedAt: new Date() })
          .where(eq(triggeredCampaigns.campaignId, campaign.campaignId));
          
      } catch (error) {
        console.error(`[TRIGGERED] Error processing campaign ${campaign.campaignId}:`, error);
      }
    }
    
    // Process any pending sends that are within their send window
    await processPendingSends();
    
    // Process drip sequence step progressions
    await processDripSequences();
    
  } catch (error) {
    console.error('[TRIGGERED] Error in main processing loop:', error);
  }
}

// ============================================================
// DEDUPLICATION & QUEUING
// ============================================================

async function processQualifyingMember(campaign: any, member: QualifyingMember) {
  // Check if this member+trigger has already been processed
  const existing = await db.select({ sendId: triggeredCampaignSends.sendId })
    .from(triggeredCampaignSends)
    .where(and(
      eq(triggeredCampaignSends.campaignId, campaign.campaignId),
      eq(triggeredCampaignSends.memberKey, member.memberKey),
      eq(triggeredCampaignSends.triggerReference, member.triggerReference)
    ))
    .limit(1);
  
  if (existing.length > 0) return; // Already processed — dedup prevents double sends
  
  // Determine A/B variant
  let variant = 'A';
  if (campaign.abTestEnabled && campaign.subjectLineB) {
    // Deterministic split based on member key hash — ensures same member always gets same variant
    const hash = member.memberKey.split('').reduce((acc: number, c: string) => acc + c.charCodeAt(0), 0);
    variant = hash % 2 === 0 ? 'A' : 'B';
  }
  
  // Create pending send record
  await db.insert(triggeredCampaignSends).values({
    campaignId: campaign.campaignId,
    memberKey: member.memberKey,
    memberEmail: member.memberEmail,
    memberName: member.memberName,
    triggerReference: member.triggerReference,
    abVariant: variant,
    status: 'pending',
    triggerDate: member.triggerDate,
  });
}

// ============================================================
// SEND WINDOW ENFORCEMENT & ACTUAL SENDING
// ============================================================

async function processPendingSends() {
  const now = new Date();
  
  // Get all pending sends
  const pendingSends = await db.select({
    send: triggeredCampaignSends,
    campaign: triggeredCampaigns,
  })
  .from(triggeredCampaignSends)
  .innerJoin(triggeredCampaigns, eq(triggeredCampaignSends.campaignId, triggeredCampaigns.campaignId))
  .where(eq(triggeredCampaignSends.status, 'pending'));
  
  for (const { send, campaign } of pendingSends) {
    try {
      // Check send window
      if (!isWithinSendWindow(campaign, now)) continue;
      
      // Check weekend restriction
      if (!campaign.sendOnWeekends && (now.getDay() === 0 || now.getDay() === 6)) continue;
      
      // Pick subject and body based on A/B variant
      const subject = send.abVariant === 'B' && campaign.subjectLineB
        ? campaign.subjectLineB
        : campaign.subjectLine;
      const body = send.abVariant === 'B' && campaign.emailBodyB
        ? campaign.emailBodyB
        : campaign.emailBody;
      
      // Send via existing infrastructure — one email at a time for triggered campaigns
      const result = await queueEmailCampaign({
        name: `${campaign.campaignName} [Triggered${send.abVariant === 'B' ? ' - B' : ''}]`,
        subject,
        body,
        recipients: [{ member_key: send.memberKey, email: send.memberEmail || '' }],
        sentBy: 'triggered-campaign-system',
        audienceDescription: `Triggered: ${campaign.triggerType}`,
      });
      
      // Update send record
      await db.update(triggeredCampaignSends)
        .set({
          status: 'sent',
          sentAt: now,
          queuedAt: now,
          emailCampaignId: result.campaign_id,
        })
        .where(eq(triggeredCampaignSends.sendId, send.sendId));
      
      // Update campaign stats
      const statUpdate: Record<string, any> = {
        totalSent: sql`total_sent + 1`,
        lastSentAt: now,
      };
      if (send.abVariant === 'A') statUpdate.totalSentA = sql`total_sent_a + 1`;
      if (send.abVariant === 'B') statUpdate.totalSentB = sql`total_sent_b + 1`;
      
      await db.update(triggeredCampaigns)
        .set(statUpdate)
        .where(eq(triggeredCampaigns.campaignId, send.campaignId));
        
    } catch (error) {
      console.error(`[TRIGGERED] Error sending ${send.sendId}:`, error);
      await db.update(triggeredCampaignSends)
        .set({ status: 'failed', skipReason: (error as Error).message })
        .where(eq(triggeredCampaignSends.sendId, send.sendId));
    }
  }
}

function isWithinSendWindow(campaign: any, now: Date): boolean {
  // Convert current time to the campaign's timezone
  const tz = campaign.sendWindowTimezone || 'America/Chicago';
  const localTime = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(now);
  
  const [hour, minute] = localTime.split(':').map(Number);
  const currentMinutes = hour * 60 + minute;
  
  const [startH, startM] = (campaign.sendWindowStart || '08:00').split(':').map(Number);
  const [endH, endM] = (campaign.sendWindowEnd || '17:00').split(':').map(Number);
  const startMinutes = startH * 60 + startM;
  const endMinutes = endH * 60 + endM;
  
  return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
}

// ============================================================
// TRIGGER EVALUATORS
// ============================================================

async function evaluateTrigger(campaign: any): Promise<QualifyingMember[]> {
  switch (campaign.triggerType) {
    case 'event_registration':
      return evaluateEventRegistration(campaign);
    case 'event_reminder':
      return evaluateEventReminder(campaign);
    case 'event_followup':
      return evaluateEventFollowup(campaign);
    case 'membership_anniversary':
      return evaluateMembershipAnniversary(campaign);
    case 'production_milestone':
      return evaluateProductionMilestone(campaign);
    default:
      console.warn(`[TRIGGERED] Unknown trigger type: ${campaign.triggerType}`);
      return [];
  }
}

// --- Event Registration ---
async function evaluateEventRegistration(campaign: any): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const lookbackDays = config.lookbackDays || 7;
  
  const result = await db.execute(sql`
    SELECT DISTINCT a.member_key, m.member_name, m.member_email,
      a.activity_name, a.event_id, a.start_datetime
    FROM activity_cache a
    JOIN member_metrics_cache m ON a.member_key = m.member_key
    WHERE m.member_status = 'Active'
      AND m.member_email IS NOT NULL
      AND a.cached_at >= NOW() - INTERVAL '${sql.raw(String(lookbackDays))} days'
  `);
  
  return (result.rows as any[]).map(row => ({
    memberKey: row.member_key,
    memberName: row.member_name,
    memberEmail: row.member_email,
    triggerReference: `event_reg_${row.event_id}`,
    triggerDate: new Date(),
    mergeData: {
      ClassName: row.activity_name || '',
      ClassDate: row.start_datetime ? new Date(row.start_datetime).toLocaleDateString() : '',
    },
  }));
}

// --- Event Reminder ---
async function evaluateEventReminder(campaign: any): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const daysBefore = config.daysBefore || 1;
  
  if (!externalPool) return [];
  
  const client = await externalPool.connect();
  try {
    // Find events happening in X days
    const events = await client.query(`
      SELECT DISTINCT ON (e."EventId") e."EventId", e."Name", e."StartDateTime"
      FROM "AMS"."apmevent" e
      WHERE e."ApmClientId" = '${CLIENT_ID}'
        AND e."StartDateTime"::date = (CURRENT_DATE + INTERVAL '${daysBefore} days')::date
      ORDER BY e."EventId", e."ApmSourceModificationTimestamp" DESC
    `);
    
    if (events.rows.length === 0) return [];
    
    const eventIds = events.rows.map((e: any) => e.EventId);
    const eventMap = new Map(events.rows.map((e: any) => [e.EventId, e]));
    
    // Find registered members for those events
    const regs = await client.query(`
      SELECT DISTINCT ON (r."EventId", r."MemberKey") 
        r."EventId", r."MemberKey"
      FROM "AMS"."apmeventregistration" r
      WHERE r."ApmClientId" = '${CLIENT_ID}'
        AND r."EventId" = ANY($1)
        AND NULLIF(TRIM(r."MemberKey"), '') IS NOT NULL
      ORDER BY r."EventId", r."MemberKey", r."ApmSourceModificationTimestamp" DESC
    `, [eventIds]);
    
    // Get member details from local cache
    const memberKeys = [...new Set(regs.rows.map((r: any) => r.MemberKey))];
    if (memberKeys.length === 0) return [];
    
    const members = await db.execute(sql`
      SELECT member_key, member_name, member_email
      FROM member_metrics_cache
      WHERE member_key = ANY(${memberKeys})
        AND member_status = 'Active'
        AND member_email IS NOT NULL
    `);
    
    const memberMap = new Map((members.rows as any[]).map(m => [m.member_key, m]));
    
    return regs.rows.filter((r: any) => memberMap.has(r.MemberKey)).map((r: any) => {
      const member = memberMap.get(r.MemberKey);
      const event = eventMap.get(r.EventId);
      return {
        memberKey: r.MemberKey,
        memberName: member.member_name,
        memberEmail: member.member_email,
        triggerReference: `event_reminder_${r.EventId}_${daysBefore}d`,
        triggerDate: new Date(),
        mergeData: {
          ClassName: event?.Name || '',
          ClassDate: event?.StartDateTime ? new Date(event.StartDateTime).toLocaleDateString() : '',
        },
      };
    });
  } finally {
    client.release();
  }
}

// --- Event Follow-up ---
async function evaluateEventFollowup(campaign: any): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const daysAfter = config.daysAfter || 1;
  
  // Use activity_cache for attended events
  const result = await db.execute(sql`
    SELECT DISTINCT a.member_key, m.member_name, m.member_email,
      a.activity_name, a.event_id
    FROM activity_cache a
    JOIN member_metrics_cache m ON a.member_key = m.member_key
    WHERE m.member_status = 'Active'
      AND m.member_email IS NOT NULL
      AND a.is_attended = true
      AND a.start_datetime::date = (CURRENT_DATE - INTERVAL '${sql.raw(String(daysAfter))} days')::date
  `);
  
  return (result.rows as any[]).map(row => ({
    memberKey: row.member_key,
    memberName: row.member_name,
    memberEmail: row.member_email,
    triggerReference: `event_followup_${row.event_id}`,
    triggerDate: new Date(),
    mergeData: { ClassName: row.activity_name || '' },
  }));
}

// --- Membership Anniversary ---
async function evaluateMembershipAnniversary(campaign: any): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const years = config.years || [1, 5, 10, 15, 20, 25, 30];
  
  const result = await db.execute(sql`
    SELECT member_key, member_name, member_email, nar_join_date,
      EXTRACT(YEAR FROM AGE(CURRENT_DATE, nar_join_date))::integer as years_member
    FROM member_metrics_cache
    WHERE member_status = 'Active'
      AND member_email IS NOT NULL
      AND nar_join_date IS NOT NULL
      AND EXTRACT(MONTH FROM nar_join_date) = EXTRACT(MONTH FROM CURRENT_DATE)
      AND EXTRACT(DAY FROM nar_join_date) = EXTRACT(DAY FROM CURRENT_DATE)
  `);
  
  return (result.rows as any[])
    .filter(row => years.includes(row.years_member))
    .map(row => ({
      memberKey: row.member_key,
      memberName: row.member_name,
      memberEmail: row.member_email,
      triggerReference: `anniversary_${new Date().getFullYear()}_${row.years_member}yr`,
      triggerDate: new Date(),
      mergeData: {
        YearsAsMember: String(row.years_member),
        JoinDate: row.nar_join_date ? new Date(row.nar_join_date).toLocaleDateString() : '',
      },
    }));
}

// --- Production Milestone ---
async function evaluateProductionMilestone(campaign: any): Promise<QualifyingMember[]> {
  const config = campaign.triggerConfig || {};
  const milestoneTypes = config.milestoneTypes || ['transaction_milestone', 'volume_milestone'];
  
  // Use the existing member_milestones table populated by milestoneDetectionService
  try {
    const result = await db.execute(sql`
      SELECT mm.member_key, mc.member_name, mc.member_email,
        mm.milestone_type, mm.milestone_value, mm.milestone_label, mm.detected_at
      FROM member_milestones mm
      JOIN member_metrics_cache mc ON mm.member_key = mc.member_key
      WHERE mc.member_status = 'Active'
        AND mc.member_email IS NOT NULL
        AND mm.milestone_type = ANY(${milestoneTypes})
        AND mm.detected_at >= NOW() - INTERVAL '7 days'
    `);
    
    return (result.rows as any[]).map(row => ({
      memberKey: row.member_key,
      memberName: row.member_name,
      memberEmail: row.member_email,
      triggerReference: `milestone_${row.milestone_type}_${row.milestone_value}`,
      triggerDate: new Date(row.detected_at),
      mergeData: {
        MilestoneLabel: row.milestone_label || '',
        MilestoneValue: row.milestone_value || '',
      },
    }));
  } catch {
    // member_milestones table might not exist yet
    return [];
  }
}

// --- Drip Sequence ---
// Drip sequences don't "evaluate" like other triggers. Instead, they use a separate 
// enrollment + step progression model. When activated, the audience is enrolled. 
// The processor then walks each enrolled member through the steps on schedule.

async function evaluateDripSequence(campaign: any): Promise<QualifyingMember[]> {
  // Drip sequences are handled by processDripSequences() instead of the normal
  // trigger evaluation flow. Return empty here.
  return [];
}

// ============================================================
// DRIP SEQUENCE PROCESSOR
// ============================================================

async function processDripSequences() {
  // Get all active drip sequence campaigns
  const dripCampaigns = await db.select()
    .from(triggeredCampaigns)
    .where(and(
      eq(triggeredCampaigns.status, 'active'),
      eq(triggeredCampaigns.triggerType, 'drip_sequence')
    ));
  
  for (const campaign of dripCampaigns) {
    try {
      // Get the steps for this campaign, ordered by step number
      const steps = await db.select()
        .from(triggeredCampaignSteps)
        .where(eq(triggeredCampaignSteps.campaignId, campaign.campaignId))
        .orderBy(triggeredCampaignSteps.stepNumber);
      
      if (steps.length === 0) continue;
      
      // Get enrolled members who are due for their next step
      const now = new Date();
      const dueMembers = await db.select()
        .from(dripSequenceMembers)
        .where(and(
          eq(dripSequenceMembers.campaignId, campaign.campaignId),
          eq(dripSequenceMembers.status, 'active'),
          sql`next_step_due_at <= ${now}`
        ));
      
      for (const enrollment of dueMembers) {
        try {
          const nextStepNumber = (enrollment.currentStep || 0) + 1;
          const step = steps.find(s => s.stepNumber === nextStepNumber);
          
          if (!step) {
            // No more steps — mark as completed
            await db.update(dripSequenceMembers)
              .set({ status: 'completed' })
              .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
            continue;
          }
          
          // Check branching condition
          if (step.sendCondition && step.sendCondition !== 'always' && nextStepNumber > 1) {
            const shouldSend = await evaluateStepCondition(
              campaign.campaignId, 
              enrollment.memberKey, 
              nextStepNumber - 1, 
              step.sendCondition
            );
            if (!shouldSend) {
              // Skip this step but advance the enrollment to the next one
              const followingStep = steps.find(s => s.stepNumber === nextStepNumber + 1);
              if (followingStep) {
                await db.update(dripSequenceMembers)
                  .set({
                    currentStep: nextStepNumber,
                    nextStepDueAt: new Date(now.getTime() + (followingStep.delayDays - step.delayDays) * 24 * 60 * 60 * 1000),
                  })
                  .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
              } else {
                await db.update(dripSequenceMembers)
                  .set({ status: 'completed', currentStep: nextStepNumber })
                  .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
              }
              continue;
            }
          }
          
          // Check send window
          if (!isWithinSendWindow(campaign, now)) continue;
          if (!campaign.sendOnWeekends && (now.getDay() === 0 || now.getDay() === 6)) continue;
          
          // Send the email
          const result = await queueEmailCampaign({
            name: `${campaign.campaignName} - Step ${nextStepNumber}: ${step.stepName || ''}`,
            subject: step.subjectLine,
            body: step.emailBody,
            recipients: [{ member_key: enrollment.memberKey, email: enrollment.memberEmail || '' }],
            sentBy: 'triggered-campaign-system',
            audienceDescription: `Drip: ${campaign.campaignName} Step ${nextStepNumber}`,
          });
          
          // Record the send in triggered_campaign_sends for tracking
          await db.insert(triggeredCampaignSends).values({
            campaignId: campaign.campaignId,
            memberKey: enrollment.memberKey,
            memberEmail: enrollment.memberEmail,
            memberName: enrollment.memberName,
            triggerReference: `drip_step_${nextStepNumber}`,
            status: 'sent',
            sentAt: now,
            emailCampaignId: result.campaign_id,
          });
          
          // Advance the enrollment
          const nextStep = steps.find(s => s.stepNumber === nextStepNumber + 1);
          if (nextStep) {
            const nextDueAt = new Date(now.getTime() + (nextStep.delayDays - step.delayDays) * 24 * 60 * 60 * 1000);
            await db.update(dripSequenceMembers)
              .set({
                currentStep: nextStepNumber,
                lastStepSentAt: now,
                nextStepDueAt: nextDueAt,
              })
              .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
          } else {
            // Last step — mark completed
            await db.update(dripSequenceMembers)
              .set({ status: 'completed', currentStep: nextStepNumber, lastStepSentAt: now })
              .where(eq(dripSequenceMembers.enrollmentId, enrollment.enrollmentId));
          }
          
          // Update campaign stats
          await db.update(triggeredCampaigns)
            .set({ totalSent: sql`total_sent + 1`, lastSentAt: now })
            .where(eq(triggeredCampaigns.campaignId, campaign.campaignId));
          
        } catch (error) {
          console.error(`[DRIP] Error processing member ${enrollment.memberKey}:`, error);
        }
      }
    } catch (error) {
      console.error(`[DRIP] Error processing campaign ${campaign.campaignId}:`, error);
    }
  }
}

async function evaluateStepCondition(
  campaignId: string, 
  memberKey: string, 
  previousStepNumber: number, 
  condition: string
): Promise<boolean> {
  // Find the email campaign ID from the previous step's send
  const previousSend = await db.select()
    .from(triggeredCampaignSends)
    .where(and(
      eq(triggeredCampaignSends.campaignId, campaignId),
      eq(triggeredCampaignSends.memberKey, memberKey),
      eq(triggeredCampaignSends.triggerReference, `drip_step_${previousStepNumber}`)
    ))
    .limit(1);
  
  if (previousSend.length === 0) return false;
  
  const emailCampaignId = previousSend[0].emailCampaignId;
  if (!emailCampaignId) return condition.startsWith('not_');
  
  // Check email events for the previous step's campaign
  const events = await db.execute(sql`
    SELECT event_type FROM email_events
    WHERE campaign_id = ${emailCampaignId}
      AND member_key = ${memberKey}
  `);
  
  const eventTypes = new Set((events.rows as any[]).map(r => r.event_type));
  
  switch (condition) {
    case 'opened_previous': return eventTypes.has('open');
    case 'not_opened_previous': return !eventTypes.has('open');
    case 'clicked_previous': return eventTypes.has('click');
    case 'not_clicked_previous': return !eventTypes.has('click');
    default: return true;
  }
}

// ============================================================
// START/STOP
// ============================================================

export function startTriggeredCampaignProcessor() {
  if (processorInterval) {
    console.log('[TRIGGERED] Processor already running');
    return;
  }
  
  // Initial run after 2 minute delay (let other services start first)
  setTimeout(() => processTriggeredCampaigns(), 2 * 60 * 1000);
  
  processorInterval = setInterval(processTriggeredCampaigns, PROCESS_INTERVAL_MS);
  console.log('[TRIGGERED] Triggered campaign processor started (runs every 15 minutes)');
}

export function stopTriggeredCampaignProcessor() {
  if (processorInterval) {
    clearInterval(processorInterval);
    processorInterval = null;
    console.log('[TRIGGERED] Triggered campaign processor stopped');
  }
}
```

### Wire Up Processor in Main Server File

In `server/index.ts` (or wherever the server starts), import and start the processor:

```typescript
import { startTriggeredCampaignProcessor } from './services/triggeredCampaignProcessor';

// After existing service startups:
startTriggeredCampaignProcessor();
```

---

## PART 3: API ENDPOINTS

Add these endpoints in `server/routes.ts`:

### CRUD for Triggered Campaigns

```typescript
// GET /api/triggered-campaigns — List all triggered campaigns
app.get("/api/triggered-campaigns", authMiddleware, async (req, res) => {
  const campaigns = await db.select().from(triggeredCampaigns).orderBy(triggeredCampaigns.createdAt);
  
  // For each campaign, get send stats
  const withStats = await Promise.all(campaigns.map(async (campaign) => {
    // Get A/B test performance if enabled
    let abStats = null;
    if (campaign.abTestEnabled) {
      const stats = await db.execute(sql`
        SELECT 
          tcs.ab_variant,
          COUNT(*) FILTER (WHERE tcs.status = 'sent') as sent,
          COUNT(DISTINCT ee.member_key) FILTER (WHERE ee.event_type = 'open') as opens,
          COUNT(DISTINCT ee.member_key) FILTER (WHERE ee.event_type = 'click') as clicks
        FROM triggered_campaign_sends tcs
        LEFT JOIN email_events ee ON tcs.email_campaign_id::text = ee.campaign_id::text AND tcs.member_key = ee.member_key
        WHERE tcs.campaign_id = ${campaign.campaignId}
        GROUP BY tcs.ab_variant
      `);
      abStats = {
        A: { sent: 0, opens: 0, clicks: 0, openRate: 0, clickRate: 0 },
        B: { sent: 0, opens: 0, clicks: 0, openRate: 0, clickRate: 0 },
      };
      for (const row of stats.rows as any[]) {
        const v = row.ab_variant === 'B' ? 'B' : 'A';
        const sent = parseInt(row.sent) || 0;
        const opens = parseInt(row.opens) || 0;
        const clicks = parseInt(row.clicks) || 0;
        abStats[v] = {
          sent,
          opens,
          clicks,
          openRate: sent > 0 ? Math.round((opens / sent) * 100) : 0,
          clickRate: sent > 0 ? Math.round((clicks / sent) * 100) : 0,
        };
      }
    }
    
    return { ...campaign, abStats };
  }));
  
  res.json(withStats);
});

// POST /api/triggered-campaigns — Create a new triggered campaign
app.post("/api/triggered-campaigns", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  const { campaignName, description, triggerType, triggerConfig, subjectLine, emailBody,
    subjectLineB, emailBodyB, abTestEnabled, sendWindowStart, sendWindowEnd,
    sendOnWeekends, autoStopDate } = req.body;
  
  if (!campaignName || !triggerType || !subjectLine || !emailBody) {
    return res.status(400).json({ message: "Missing required fields" });
  }
  
  const [campaign] = await db.insert(triggeredCampaigns).values({
    campaignName,
    description,
    triggerType,
    triggerConfig: triggerConfig || {},
    subjectLine,
    emailBody,
    subjectLineB: abTestEnabled ? subjectLineB : null,
    emailBodyB: abTestEnabled ? emailBodyB : null,
    abTestEnabled: abTestEnabled || false,
    sendWindowStart: sendWindowStart || '08:00',
    sendWindowEnd: sendWindowEnd || '17:00',
    sendOnWeekends: sendOnWeekends || false,
    autoStopDate: autoStopDate ? new Date(autoStopDate) : null,
    createdBy: 'admin',
  }).returning();
  
  res.json(campaign);
});

// PATCH /api/triggered-campaigns/:id — Update campaign
app.patch("/api/triggered-campaigns/:id", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  
  // Don't allow editing active campaigns (must pause first)
  const [existing] = await db.select().from(triggeredCampaigns).where(eq(triggeredCampaigns.campaignId, id)).limit(1);
  if (!existing) return res.status(404).json({ message: "Campaign not found" });
  
  if (existing.status === 'active' && !updates.status) {
    return res.status(400).json({ message: "Pause the campaign before editing" });
  }
  
  const allowed: Record<string, any> = { updatedAt: new Date() };
  const fields = ['campaignName', 'description', 'triggerType', 'triggerConfig', 'subjectLine', 'emailBody',
    'subjectLineB', 'emailBodyB', 'abTestEnabled', 'sendWindowStart', 'sendWindowEnd', 'sendOnWeekends', 'autoStopDate'];
  for (const f of fields) {
    if (updates[f] !== undefined) allowed[f] = updates[f];
  }
  
  // Status transitions
  if (updates.status) {
    allowed.status = updates.status;
    if (updates.status === 'active') allowed.activatedAt = existing.activatedAt || new Date();
    if (updates.status === 'paused') allowed.pausedAt = new Date();
    if (updates.status === 'archived') allowed.archivedAt = new Date();
  }
  
  const [updated] = await db.update(triggeredCampaigns).set(allowed).where(eq(triggeredCampaigns.campaignId, id)).returning();
  res.json(updated);
});

// GET /api/triggered-campaigns/:id/history — Send history for a campaign
app.get("/api/triggered-campaigns/:id/history", authMiddleware, async (req, res) => {
  const { id } = req.params;
  const limit = parseInt(req.query.limit as string) || 50;
  const offset = parseInt(req.query.offset as string) || 0;
  
  const sends = await db.select()
    .from(triggeredCampaignSends)
    .where(eq(triggeredCampaignSends.campaignId, id))
    .orderBy(triggeredCampaignSends.createdAt)
    .limit(limit)
    .offset(offset);
  
  const [countResult] = await db.select({ count: sql`COUNT(*)` })
    .from(triggeredCampaignSends)
    .where(eq(triggeredCampaignSends.campaignId, id));
  
  res.json({ sends, total: parseInt((countResult as any).count) || 0 });
});

// DELETE /api/triggered-campaigns/:id — Delete a draft campaign
app.delete("/api/triggered-campaigns/:id", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  const { id } = req.params;
  const [existing] = await db.select().from(triggeredCampaigns).where(eq(triggeredCampaigns.campaignId, id)).limit(1);
  if (!existing) return res.status(404).json({ message: "Campaign not found" });
  if (existing.status !== 'draft') {
    return res.status(400).json({ message: "Only draft campaigns can be deleted. Archive active/paused campaigns instead." });
  }
  
  await db.delete(triggeredCampaigns).where(eq(triggeredCampaigns.campaignId, id));
  res.json({ success: true });
});

// POST /api/triggered-campaigns/:id/activate-drip — Activate a drip sequence and enroll audience
// This is called when activating a drip_sequence campaign. It enrolls the selected audience members.
app.post("/api/triggered-campaigns/:id/activate-drip", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  const { id } = req.params;
  const { audienceId, memberKeys } = req.body;
  // Either provide an audienceId (saved audience) or an array of memberKeys
  
  const [campaign] = await db.select().from(triggeredCampaigns).where(eq(triggeredCampaigns.campaignId, id)).limit(1);
  if (!campaign) return res.status(404).json({ message: "Campaign not found" });
  if (campaign.triggerType !== 'drip_sequence') {
    return res.status(400).json({ message: "This endpoint is only for drip sequence campaigns" });
  }
  
  // Get the steps
  const steps = await db.select().from(triggeredCampaignSteps)
    .where(eq(triggeredCampaignSteps.campaignId, id))
    .orderBy(triggeredCampaignSteps.stepNumber);
  
  if (steps.length === 0) {
    return res.status(400).json({ message: "Add at least one step before activating" });
  }
  
  // Resolve audience members
  let members: Array<{ memberKey: string; memberEmail: string; memberName: string }> = [];
  
  if (audienceId) {
    const audienceData = await getAudienceMembers(audienceId);
    members = audienceData.members.map((m: any) => ({
      memberKey: m.MemberKey,
      memberEmail: m.MemberEmail,
      memberName: m.MemberFullName,
    }));
  } else if (memberKeys?.length > 0) {
    const memberData = await db.execute(sql`
      SELECT member_key, member_email, member_name
      FROM member_metrics_cache
      WHERE member_key = ANY(${memberKeys})
        AND member_status = 'Active'
        AND member_email IS NOT NULL
    `);
    members = (memberData.rows as any[]).map(r => ({
      memberKey: r.member_key,
      memberEmail: r.member_email,
      memberName: r.member_name,
    }));
  }
  
  if (members.length === 0) {
    return res.status(400).json({ message: "No valid recipients in the selected audience" });
  }
  
  // Calculate when the first step is due
  const now = new Date();
  const firstStep = steps[0];
  const firstDueAt = new Date(now.getTime() + firstStep.delayDays * 24 * 60 * 60 * 1000);
  
  // Enroll members (skip duplicates)
  let enrolled = 0;
  for (const member of members) {
    try {
      await db.insert(dripSequenceMembers).values({
        campaignId: id,
        memberKey: member.memberKey,
        memberEmail: member.memberEmail,
        memberName: member.memberName,
        currentStep: 0,
        enrolledAt: now,
        nextStepDueAt: firstDueAt,
        status: 'active',
      });
      enrolled++;
    } catch {
      // Unique constraint violation = already enrolled, skip
    }
  }
  
  // Activate the campaign
  await db.update(triggeredCampaigns)
    .set({ status: 'active', activatedAt: campaign.activatedAt || now, updatedAt: now })
    .where(eq(triggeredCampaigns.campaignId, id));
  
  res.json({ success: true, enrolled, totalAudience: members.length });
});

// CRUD for drip sequence steps
app.get("/api/triggered-campaigns/:id/steps", authMiddleware, async (req, res) => {
  const steps = await db.select().from(triggeredCampaignSteps)
    .where(eq(triggeredCampaignSteps.campaignId, req.params.id))
    .orderBy(triggeredCampaignSteps.stepNumber);
  res.json(steps);
});

app.post("/api/triggered-campaigns/:id/steps", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  const { stepNumber, stepName, delayDays, subjectLine, emailBody, sendCondition } = req.body;
  const [step] = await db.insert(triggeredCampaignSteps).values({
    campaignId: req.params.id,
    stepNumber: stepNumber || 1,
    stepName,
    delayDays: delayDays || 0,
    subjectLine,
    emailBody,
    sendCondition: sendCondition || 'always',
  }).returning();
  res.json(step);
});

app.patch("/api/triggered-campaigns/:id/steps/:stepId", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  const { stepName, delayDays, subjectLine, emailBody, sendCondition } = req.body;
  const [step] = await db.update(triggeredCampaignSteps)
    .set({ stepName, delayDays, subjectLine, emailBody, sendCondition })
    .where(eq(triggeredCampaignSteps.stepId, req.params.stepId))
    .returning();
  res.json(step);
});

app.delete("/api/triggered-campaigns/:id/steps/:stepId", authMiddleware, requireRole("admin", "staff"), async (req, res) => {
  await db.delete(triggeredCampaignSteps).where(eq(triggeredCampaignSteps.stepId, req.params.stepId));
  res.json({ success: true });
});
```

---

## PART 4: FRONTEND — AUTOMATIONS TAB IN SMARTSENDS

### Add "Automations" Tab to SmartSends Page

In `SmartSends.tsx`, add a new tab alongside the existing tabs (All Campaigns, Images, etc.). The Automations tab shows:

1. **Header** with "+ New Automation" button
2. **Three sections**: Active automations, Paused automations, Draft automations
3. Each automation card shows: name, trigger type badge, total sent, last sent date, A/B test results (if enabled), and action buttons (Pause/Resume, Edit, Archive, View History)

### Trigger Type Badges

Display a colored badge for each trigger type:
- Event Registration → blue badge
- Event Reminder → amber badge
- Post-Event Follow-up → green badge
- Membership Anniversary → purple badge
- Production Milestone → orange badge
- Drip Sequence → indigo badge

### A/B Test Results Display

When `abTestEnabled` is true and there are sends, show a compact comparison:

```
┌─────────────────────────────────────────────┐
│  Subject A: "Happy Anniversary, {{FirstName}}!"     │
│  ████████████░░░░  42% open rate (126 sent)         │
│                                                      │
│  Subject B: "Celebrating {{YearsAsMember}} Years!"  │
│  ██████████████░░  52% open rate (118 sent)  ★ Winner│
└─────────────────────────────────────────────┘
```

The variant with the higher open rate gets a "★ Winner" badge after 100+ sends per variant. Below 100 sends, show "Collecting data..." instead.

### Create/Edit Automation Form

A dialog or page with these sections:

**Section 1: Name & Trigger**
- Campaign name (text input)
- Trigger type (select dropdown with the 5 options)
- Trigger configuration (dynamic fields based on selected trigger — see below)

**Section 2: Trigger-Specific Settings**

For "Event Reminder":
```
Send reminder: [1 ▾] [days ▾] before the event
```

For "Membership Anniversary":
```
Anniversary years: ☑ 1  ☑ 5  ☑ 10  ☑ 15  ☑ 20  ☑ 25  ☐ 30  ☐ Every year
```

For "Production Milestone":
```
☑ Transaction milestones (25th, 50th, 100th...)
☑ Volume milestones ($1M, $5M, $10M...)
☐ Rookie star
☐ First million
```

For "Drip Sequence":
```
Audience: [Select a saved audience ▾]  or  [Build with AI]
```
When Drip Sequence is selected, Section 3 changes to a step builder (see below).

**Section 3: Email Content**

For single-email triggers (Event Registration, Event Reminder, Event Follow-up, Anniversary, Milestone):
- Subject line (text input)
- Email body (use the existing email editor — ReactQuill)
- Show available merge fields based on trigger type:
  - All triggers: `{{FirstName}}` `{{LastName}}` `{{OfficeName}}`
  - Event triggers: `{{ClassName}}` `{{ClassDate}}` `{{ClassTime}}`
  - Anniversary: `{{YearsAsMember}}` `{{JoinDate}}`
  - Milestone: `{{MilestoneLabel}}` `{{MilestoneValue}}`

For Drip Sequence, replace with a **step builder**:

```
┌──────────────────────────────────────────────────────┐
│  Step 1: [step name]                     Day [0]     │
│  Subject: [subject line]                             │
│  [Edit Email]  [Remove]                              │
├──────────────────────────────────────────────────────┤
│  Step 2: [step name]                     Day [7]     │
│  Subject: [subject line]                             │
│  Send condition: [Send to everyone ▾]                │
│  [Edit Email]  [Remove]                              │
├──────────────────────────────────────────────────────┤
│  [+ Add Step]                                        │
└──────────────────────────────────────────────────────┘
```

Each step has: step name, delay in days from campaign start, subject line, email body (edited in a modal with ReactQuill), and a send condition dropdown for steps 2+: "Send to everyone", "Only if they opened previous", "Only if they didn't open previous", "Only if they clicked previous", "Only if they didn't click previous".

Steps are created/edited via the `/api/triggered-campaigns/:id/steps` CRUD endpoints. When activating, the UI calls `/api/triggered-campaigns/:id/activate-drip` with the audience.

**Section 4: A/B Test (Optional)**
- Toggle: "Enable A/B testing"
- When enabled, show a second subject line field and optionally a second email body
- Label them "Variant A" and "Variant B"
- Explain: "Each recipient will randomly receive one variant. After 100+ sends per variant, we'll identify the winner."

**Section 5: Send Window**
```
Send between: [8:00 AM ▾] and [5:00 PM ▾]  Central Time
☐ Send on weekends
```

**Section 6: Actions**
```
[Save as Draft]     [Activate Automation]
```

---

## PART 5: A/B TESTING FOR REGULAR CAMPAIGNS

Add A/B testing to the existing one-shot campaign flow as well (Send Email page).

### Changes to SendEmail.tsx

Add an "A/B Test" toggle in the compose form. When enabled:
- Show a second subject line field ("Subject Line B")
- Optionally show a second email body editor
- When sending, split the audience randomly in half:
  - Half gets Subject A / Body A → queued as campaign version 1 with a new parent ID
  - Half gets Subject B / Body B → queued as campaign version 2 with the same parent ID
- Both campaigns are linked by `parentCampaignId`

### Changes to CampaignDetail.tsx

When viewing a campaign that has a `parentCampaignId`, show the A/B comparison:
- Load both campaign versions that share the same parent
- Display open rate, click rate, and bounce rate side by side
- Mark the winner (higher open rate) after sufficient data

---

## VERIFICATION CHECKLIST

- [ ] `triggered_campaigns` table created with all fields
- [ ] `triggered_campaign_sends` table created with dedup index
- [ ] Processor starts on server boot and runs every 15 minutes
- [ ] Creating a triggered campaign saves correctly
- [ ] Activating a campaign sets status to 'active'
- [ ] Pausing stops processing; resuming restarts
- [ ] Event registration trigger detects new registrations from activity_cache
- [ ] Event reminder trigger finds members with upcoming events from AMS data
- [ ] Event follow-up trigger finds members who attended recent events
- [ ] Anniversary trigger matches today's date against nar_join_date
- [ ] Milestone trigger reads from member_milestones table
- [ ] Deduplication works: same member + same trigger = one send only
- [ ] Drip sequence: audience enrollment works via activate-drip endpoint
- [ ] Drip sequence: step 1 sends on day 0, step 2 sends after configured delay
- [ ] Drip sequence: branching conditions work (only send if opened/didn't open previous)
- [ ] Drip sequence: members marked 'completed' after last step
- [ ] Drip sequence step CRUD endpoints work (add, edit, delete steps)
- [ ] Send window enforced: no emails outside 8 AM - 5 PM
- [ ] Weekend restriction works when disabled
- [ ] A/B variant assignment is deterministic (same member always gets same variant)
- [ ] A/B stats show open rate comparison on the campaign card
- [ ] Winner badge appears after 100+ sends per variant
- [ ] "Automations" tab appears in SmartSends
- [ ] Create/edit form shows trigger-specific configuration fields
- [ ] Send history page shows all sends with status
- [ ] Regular campaign A/B testing splits audience in half
- [ ] Campaign detail page shows A/B comparison when applicable
- [ ] Existing email infrastructure (campaigns, recipients, events) still works unchanged
- [ ] Existing scheduled campaigns still work unchanged

---

## FILES CHANGED

**New files:**
- `server/services/triggeredCampaignProcessor.ts` — Main processor service
- (Automations UI components — can be inline in SmartSends.tsx or separate files)

**Modified files:**
- `shared/schema.ts` — Add triggeredCampaigns and triggeredCampaignSends table definitions
- `server/routes.ts` — Add CRUD endpoints for triggered campaigns
- `server/index.ts` — Import and start triggered campaign processor
- `client/src/pages/SmartSends.tsx` — Add Automations tab
- `client/src/pages/SendEmail.tsx` — Add A/B test toggle and split logic
- `client/src/pages/CampaignDetail.tsx` — Add A/B comparison view

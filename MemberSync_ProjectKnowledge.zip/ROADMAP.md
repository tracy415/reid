# MemberSync — Product Roadmap

> **Purpose:** The prioritized feature backlog and infrastructure roadmap for the MemberSync development team. Items are organized by track and priority. This is a living document — items graduate when they are specced, built, and deployed. Items are never deleted; completed items are marked with a date.
>
> **Source:** Derived from `MemberSync_Parking_Lot.md` and project summaries through March 12, 2026. Tracy and Claude maintain the strategic version; this document is the developer-facing translation.
>
> Last updated: March 12, 2026

---

## How to Read This Document

**Track 1** — Feature development. Tracy drives. Claude Code is the engineer.
**Track 2** — Production platform. Mike, Dale, and Formos drive. Claude Code is the engineer.
**Track 3** — Administration and integrations. Paula, Daniel, and Rogelio drive.

Priority within each track is top-to-bottom. Do not skip ahead without checking with Tracy.

---

## Track 1 — Feature Development

### 🔴 P0 — Top Priority

#### Proactive AI Engagement Engine
The feature that makes MemberSync feel like a second brain rather than a reporting tool. Pattern detectors run daily against `member_metrics_cache`, score insights by quality and actionability, and surface cards on the dashboard connecting directly to SmartSends actions.

**What it looks like:** "14 Foundation members in Aurora attended events last year but haven't registered for anything this spring. Would you like to reach out?" → one click to SmartSends with that audience pre-built.

**Architectural implications:**
- Daily background job evaluating pattern detectors against `member_metrics_cache`
- Scoring system for insight priority (not all patterns are equally interesting)
- New `engagement_insights` table to store scored, dated insights
- Dashboard cards connected to SmartSends audience creation
- Tenant-configurable thresholds (`engagement_insight_thresholds` in `tenant_config`) — a pattern that's notable at GRAR (3,400 members) may not be notable at a large MLS or enterprise client
- Positive and proactive framing only — celebrates opportunity, never flags problems

**Acceptance criteria:** Real member data produces real insights. Cards connect to real audiences. Pattern detectors cover Foundation, Builder, and Rainmaker tiers. All thresholds are tenant-configurable.

---

#### Lapse Prevention System
Members don't lapse overnight — they drift for months. MemberSync tracks the trajectory and intervenes before it's too late.

**What it looks like:** Risk indicator on the dashboard showing members trending toward non-renewal. Calendar-aware (risk increases as billing deadlines approach). Automated intervention trigger that creates a SmartSends audience when risk crosses a threshold.

**Architectural implications:**
- `membership_daily_snapshot` is already accumulating — this is the foundation
- New tables needed: `member_status_tracking`, `member_risk_scores`, `intervention_log`, `billing_calendar`
- `billing_calendar` in `tenant_config` is required before this can work — Mainstreet's billing timeline (July invoices, December 1 due, January 2 suspensions; Spring Advantage: March invoices, March 31 due, April 1 MLS suspended) is the reference implementation
- Lapse risk weights (`tenant_config.lapse_risk_weights`) must be client-configurable
- Do not purge historical engagement data — lapse pattern analysis requires behavioral history going back 24 months

---

### 🟠 P1 — High Priority

#### Recognition Homepage
Recognition currently has a queue but no home. The homepage gives the module a proper landing experience.

**What to build:**
- Stat cards: Members recognized this month, Emails sent, Open rate, Upcoming milestones
- "What's resonating" section: which milestone types produce the best engagement
- "Coming up" queue: projected recognitions for the next 30 days with projected send dates
- Left nav badge: pending queue count (already built — maintain it)
- Top-nav notification bell: real-time milestone alerts (future phase)
- Daily digest email to staff: morning summary of what's queued (future phase)

**Spec:** To be written by Tracy + Claude before build.

---

#### AI Chart Rendering
AI Chat detects when results should be visualized and renders `Recharts` components inline. Download as image. This is the feature that creates operational dependency — a CEO who gets a board-ready chart in 10 seconds never gives it up.

**Architectural implications:**
- AI query service response format needs a `visualization` field alongside `data` and `insights`
- Chart type detection logic: when is a bar chart appropriate vs. a line chart vs. a table?
- Default chart types are client-configurable (`tenant_config.default_visualizations`) — MLSs and associations care about different metrics
- Export: PDF/PNG from chart, copy to clipboard, download as image
- Estimated 3–5 Claude Code tasks

**Priority note:** High priority before any enterprise pilot launches.

---

#### Member Journey Engine
Continuous, state-driven lifecycle communications. Architecturally distinct from Campaign Architect.

**What it is:** An ongoing relationship model — a member enters a journey based on a lifecycle trigger (new member, first transaction, approaching lapse) and progresses through states as their behavior changes. Branching, re-entry, and persistent state are all supported.

**What it is not:** An extension of Campaign Architect. Campaign Architect handles event-anchored sequences (bounded, scheduled). Member Journey handles lifecycle logic (unbounded, behavior-driven). Do not merge them.

**Architectural implications:**
- Separate tables, separate processor, separate UI
- Only shared component with Campaign Architect: `EmailComposer`
- Deep conditional logic that Campaign Architect explicitly does not support belongs here
- Build timeline: post-Recognition Homepage

---

### 🟡 P2 — Medium Priority

#### AI Learning / Network Effect Engine
Cross-client campaign performance learning. AI recommendations improve as more associations use the platform.

**What it does:** Campaign performance outcomes are stored against AI decisions (structure, timing, audience, subject lines). Cross-client patterns feed back into Campaign Architect recommendations. An association-specific learning layer sits on top of the cross-client model.

**Architectural implications:**
- `ai_campaign_decisions` table with outcome tracking
- Campaign open/click rates linked to AI recommendation metadata
- Cross-client aggregate learning must respect tenant isolation — Client A never sees Client B's data, only aggregated patterns
- Privacy consideration: what can legitimately be learned cross-client vs. what stays siloed?

---

#### Broker Module
Office payment health, agent roster visibility, broker liability tracking, suspension impact analysis.

**Scope:** Dashboard and reporting only. All email functionality stays in SmartSends — the Broker Module does not send emails.

**Architectural implications:**
- `brokerResolutionService.ts` already exists — keep it clean and well-tested
- The DR Dues Formula (designated REALTOR® liability calculation) applies to all REALTOR® associations — it is not state- or association-specific
- All Designated REALTORS® and Managing Brokers have legal liability and financial responsibility for their agents' actions and dues status

---

#### Competitive Intelligence Module
Helps executives understand competitive threats. Who's selling where, territory patterns, member drift signals.

**Where it surfaces:** AI Chat queries and potentially a dashboard section.

**Architectural implications:**
- New query patterns in `aiQueryService.ts` for cross-territory analysis
- Strict multi-tenant scoping: Client A cannot see Client B's data; Client A can see their own members' market activity and aggregated territory patterns
- `competitive_territory` in `tenant_config` must be configured before this can work — territory boundaries cannot be inferred from data
- Geographic intelligence already in AI Chat is the foundation

---

#### Listing Lifecycle Automations
Triggered communications based on listing events: new listing congratulations, price reduction encouragement, just sold celebration.

**Architectural implications:**
- New trigger types in `triggeredCampaignProcessor.ts` (note: this file requires explicit written approval to modify)
- New evaluator functions for listing events
- New merge fields: listing address, price, days on market
- MLS data feed already in the database — this is an extension of existing data access, not a new integration

---

#### Automations Polish Round 2
- Delete/discard capability for automations
- Audience visibility and estimated reach on the trigger config screen
- Automation-specific analytics (rolling performance timeline, cumulative stats)
- Event override priority system (when multiple automations could fire for the same member event, which wins — configurable per client via `tenant_config.automation_priority_rules`)

---

#### Compliance Module Redesign
The current compliance flow is a shortcut — it creates an audience from the compliance widget and drops staff into the standard Send Email wizard. This needs to become a proper workflow.

**Note:** Compliance is two distinct modules — Association Compliance and MLS Compliance. An organization that is both an association and an MLS gets a combined tool. Do not build the two modules in a way that makes the combined case impossible. Both modules are currently in development — neither is fully specced.

---

### 🟢 P3 — Future / Backlog

#### AI Report Generation
Multi-section board reports from natural language. "Give me a board meeting summary for March" → formatted report with member stats, campaign performance, top milestones, compliance status.

- Stage 4: Multi-chart dashboards
- Stage 5: Full presentation generation (the operational dependency play — a board that gets slides in 10 seconds never goes back)

#### Lapse Pattern Analysis
Predictive models built from member behavior in the 24 months before lapse. What does a member do (or stop doing) before they leave? Becomes the foundation for early warning scoring. Requires historical data accumulation — do not purge `membership_daily_snapshot` records.

#### Member Preference Center (Enhanced)
Members choose which email categories they receive. Compliance emails are always on. Everything else is optional. Reduces unsubscribes by letting members opt down instead of out entirely. Foundation: `member_email_preferences` table already exists with category columns. Needs member-facing UI enhancement and staff-facing visibility.

#### Integration Marketplace
Per-client, independently enabled integrations with their own credentials and field mappings. Each integration feeds into engagement scoring via configurable signal weights.
- Zendesk (HGAR has requested)
- Google Analytics
- LMS connectors
- Lockbox access logs
- Benefits usage data

**Note:** This likely needs its own `tenant_integrations` table rather than living in `tenant_config`. Design it as a configuration subsystem.

---

## Track 2 — Production Platform

### 🔴 P0 — Do First

#### Eliminate All Hardcoded Client References
110+ hardcoded "Mainstreet," "Illinois," and client-specific values in the Replit prototype must be eliminated from day one of the production port. Every one becomes a `tenant_config` lookup.

**How to find them:**
```
Search for: "MainStreet", "Mainstreet", "mainstreet", "MAINSTREET", "Illinois", "IL compliance", "CE requirements"
Categorize each as: display string, database filter, business logic, or configuration
Replace with: tenant_config lookups
```

**This is not a cleanup task — it is the prerequisite for serving any client other than Mainstreet.**

---

#### Multi-Tenant Stage 1 — Database-Driven Configuration
Every feature that currently reads from `clientConfig.ts` must read from `tenant_config` instead. This is the foundational multi-tenant change.

**What changes:**
- `clientConfig.ts` is deleted
- All lookups go through a `getTenantConfig(clientId)` service
- New clients are added by inserting a `tenant_config` row — no code changes required

---

#### Batch Email Sending
Current send architecture handles Mainstreet (18,000 members) adequately. Client #4 and all clients thereafter may operate at significantly larger scale, and a proper rate-limited batching architecture must be in place before any pilot launches.

**Architectural note:** The queue processor already exists. Batching is a rate-limiting and concurrency constraint on top of the existing queue — not a new send architecture.

---

#### SOC 2 Type I
Most required controls are already in place (access management, encryption, logging). Certify them. Target: before any pilot launches.

SOC 2 Type II (requires 3–6 months of operational evidence) follows Type I. This is a competitive differentiator — most association tech vendors lack formal certifications.

---

### 🟠 P1 — High Priority

#### Multi-Tenant Stage 2 — Admin Provisioning Dashboard
Staff-facing dashboard for Membio admins to provision new clients without engineering involvement. Required before client #4 onboards.

**What it does:** Create tenant, configure `tenant_config`, provision SendGrid groups, set up engagement scoring weights, configure billing calendar.

---

#### Prompt Caching
90% reduction in AI input token costs. High-value improvement before scaling to Client #4 and beyond. The system prompt for AI Chat is large and stable — it is a prime candidate for caching.

---

#### `routes.ts` Refactor
The monolith is currently ~10,900 lines. It must be broken into domain-focused route files. This is the most urgent refactoring target.

**Suggested split:**
- `routes/members.ts`
- `routes/campaigns.ts`
- `routes/automations.ts`
- `routes/recognition.ts`
- `routes/analytics.ts`
- `routes/ai.ts`
- `routes/admin.ts`
- `routes/webhooks.ts`

---

#### Query Engine Phase 2 — Query Planning Architecture
The current single-prompt approach (plan + generate in one call) works for Mainstreet. Multi-source queries at enterprise scale need a proper planning layer that separates query planning from query generation.

---

### 🟡 P2 — Medium Priority

#### Multi-Tenant Stage 3 — Self-Service Onboarding
Credit card, connect APIs, go. Only automate steps already validated manually with real clients. **Do not build this before manually onboarding at least 4–5 clients.** AMS data is not standardized — self-service onboarding requires understanding the full range of variation first.

#### AI Usage Dashboard (Staff-Facing)
Infrastructure is built (`aiUsageLogger.ts`, admin endpoint). UI is not. Shows per-feature usage, cost, anomalies, kill switch controls.

#### Membio Admin Panel
Client account management, Anthropic and SendGrid usage monitoring, data health, support tools, billing. Four internal roles: Admin, Staff, Contributor, Leadership/Board.

---

## Track 3 — Administration and Integrations

### 🔴 P0

#### Client Role Permissions Middleware
Four client-facing roles must be enforced at the API level:
- **Admin** — full access including tenant configuration
- **Staff** — all operational features; no tenant config
- **Contributor** — content management (emails, images); cannot send campaigns
- **Leadership/Board** — read-only premium view; beautiful, not functional

**Note:** Roles are still being finalized. Build the middleware to be extensible — do not hardcode the four roles in a way that makes adding a fifth difficult.

---

#### Pricing and Tier Structure
Still in development. Paula, Daniel, and Tracy own this. Leadership/Board is a premium add-on seat. The tier structure must be in place before client #3 onboards.

---

## Technical Debt — Resolve As Soon As Possible

These are known issues in the Replit prototype that must be addressed in the production port. They are not "eventually" items.

| Item | Location | Notes |
|------|----------|-------|
| AI Memory entries not reaching the AI | `aiQueryService.ts`, `routes.ts ~4338` | Write/read gap — memory entries saved in UI may not be persisted correctly. Fix Issue 1 in `KNOWN_ISSUES.md` first. |
| Draft audience persistence | `SendEmail.tsx` | Save full audience object in draft, not just the ID |
| Email archive date range picker | Email Health Dashboard | Backend supports it; frontend only has search and category |
| Recognition Queue count endpoint | `routes.ts` | Currently fetches full list to count. Add `/api/recognition-queue/count` |
| Email Governor cap validation | `routes.ts` PATCH endpoint | Doesn't validate daily cap 1–10, weekly cap 1–21 ranges |
| Drip Sequence Step Editor | Campaign Architect | Needs proper `EmailComposer` integration with visual preview |
| Templates system | SmartSends | Functional but not useful enough. Past campaigns as templates, smart suggestions |
| Revenue data | Dashboard | Currently uses catalog prices, not actual invoiced amounts. Fix: map charge codes to `apmmemberdues` |
| `clientConfig.ts` — 110+ hardcoded references | Entire codebase | Block on multi-tenancy. Eliminate from day one of production port |
| 19 of 20+ tables missing `client_id` | Database | Multi-tenant isolation gap |
| A/B testing framework | Campaign Architect | Built but not fully activated |
| AI Chat internal label suppression | `aiQueryService.ts` | "license_maintainer," "occasional_producer," "active_producer" occasionally leak |
| `ai_business_context` not editable | `tenant_config` | Hardcoded for Mainstreet; must be editable via admin panel before client #3 |

---

## Items Per-Client Configuration Required

The following features are currently hardcoded for Mainstreet and must be moved to `tenant_config` before any second client goes live. Full details in `DECISIONS.md`.

- Branding (org name, logo, brand color)
- Org type (`association` vs `mls`)
- Compliance flags (`tracks_ce`, `tracks_coe`, `tracks_designations`)
- Geographic context for AI Chat
- Billing calendar and due dates
- Engagement scoring weights and tier thresholds
- Office suspension model
- Duplicate detection threshold
- Lapse risk weights
- AI Chat suggested queries and available data sources
- Competitive territory boundaries
- Default chart types
- Automation priority rules
- Member portal feature flags (`has_member_portal`)
- SendGrid ASM group IDs (`sg_group_*`)

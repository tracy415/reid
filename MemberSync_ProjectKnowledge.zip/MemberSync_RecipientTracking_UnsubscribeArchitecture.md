# MemberSync — Campaign Detail Page, Unsubscribe Architecture & Preference Center
*Written: March 9, 2026 (revised March 10, 2026)*
*Status: IN PROGRESS — Replit implementing*

---

## OVERVIEW

This prompt covers three connected pieces:

1. **Campaign detail page redesign** — replace the modal + "Full Detail" two-step pattern with a single, complete detail page. All campaign information in one place, mobile friendly.
2. **SendGrid unsubscribe groups architecture** — every email MemberSync sends must be tagged with the correct unsubscribe group. This is a correctness requirement, not an enhancement. Without it, a single marketing opt-out suppresses all email to that member forever, including recognition and compliance emails.
3. **Unsubscribe management** — staff-facing panel in Settings and a member-facing preference center page.

Read all existing code carefully before writing anything. Do not modify `triggeredCampaignProcessor.ts` or `sequenceEnrollmentService.ts` for any reason.

---

## KEY ARCHITECTURE DECISIONS

These decisions were made before implementation and must be followed exactly:

1. **SendGrid unsubscribe groups are created programmatically** via the SendGrid API — not manually in the dashboard. Creation must be idempotent: if groups already exist in `tenant_config`, skip creation.
2. **`engagement` category is equivalent to `marketing`** for unsubscribe group purposes. Do not rename existing data. The helper function maps both to the marketing group. Going forward, the UI offers "Marketing" as the label — not "Engagement."
3. **Per-category opt-outs are added as columns to the existing `member_email_preferences` table** — not a new table. Columns: `marketing_opt_out`, `marketing_opt_out_date`, `recognition_opt_out`, `recognition_opt_out_date`. Compliance and transactional are never opt-outable — no columns needed.
4. **`/unsubscribe` stays as the one-click handler.** The preference center lives at `/email-preferences`. Do not merge these routes.
5. **ASM parameter is added in a single place: `emailService.ts` `processEmailQueue`.** All send paths funnel through this function. No changes to `triggeredCampaignProcessor.ts`.
6. **After one-click unsubscribe at `/unsubscribe`, always redirect to `/email-preferences?token=[signed-token]`** regardless of category. Even if no suppression was applied (compliance/transactional), the member lands on the preference center to see their current settings.
7. **The footer preference center link must include the signed token:** `/email-preferences?token=[signed-token]`. A generic link without the token cannot identify the member or save their preferences. Use the same HMAC token pattern as the existing `/unsubscribe` handler.

---

## PART 1 — CAMPAIGN DETAIL PAGE

### The problem

Clicking a campaign row in Reporting & Analytics currently opens a modal with summary stats and a recipient table. Inside that modal is a "Full Detail" button that opens a separate page. Staff miss the recipient data because the full detail is hidden behind an extra click. There should be one page with everything on it.

### The fix

**Remove the modal entirely.** Clicking a campaign name or row in the Reporting & Analytics list navigates directly to the full campaign detail page. No intermediate modal. The "Full Detail" button is removed.

Drafts may still navigate to the composer. All other campaign types navigate to the detail page.

### Campaign detail page layout

**Route:** `/smartsends/campaigns/:campaignId`

**Page header:**
- Campaign name (large)
- Type badge (Email / Sequence / Trigger / Automation) + Status badge (Sent / Active / Paused / Draft)
- Sent by [name] on [date and time]
- Back link to Reporting & Analytics

**Stats row — five cards:**
- Recipients (total sent)
- Delivered (count + "X bounced" if any)
- Open Rate (percentage + "X opened")
- Click Rate (percentage + "X clicked")
- Unsubscribed (count)

**Action buttons (context-aware by status):**
- Sent email: **Resend (Create Draft)** — creates a draft copy, never re-sends immediately
- Active sequence or trigger: **Pause** and **Edit (Pause First)**
- Paused: **Resume** and **Edit**
- Draft: **Edit**

**Two tabs below the stats row:**

**Tab 1 — Member Activity (default)**
The full recipient table (see below).

**Tab 2 — Email Content**
Read-only preview: subject line, preview text, rendered HTML body. For sequences, a step selector dropdown to preview each email in the sequence.

### Member Activity table

One row per recipient. All columns visible on desktop.

| Column | What to show |
|---|---|
| **Member Name** | Linked to member detail page. Plain text if no member record (e.g. CSV recipient). |
| **Email Address** | Address the email was sent to. |
| **Sent** | Timestamp when send was initiated. Format: `Mar 9, 10:04 AM`. |
| **Delivered** | Timestamp of confirmed delivery from SendGrid. `—` if not confirmed. |
| **Opened** | First open timestamp. If multiple: `Mar 9, 11:22 AM (3 opens)`. `—` if never opened. |
| **Clicked** | First click timestamp. If multiple: `Mar 9, 11:23 AM (2 clicks)`. `—` if never clicked. |
| **Bounced** | Timestamp + type: `Mar 9, 10:05 AM (hard)` or `(soft)`. `—` if not bounced. |
| **Unsubscribed** | Timestamp if opted out from this email. `—` if not. |
| **Skipped** | Skip reason if not sent: "Sandbox mode" / "Already opted out" / "Governor limit" / "Hard bounce suppression". `—` if not skipped. |

**Sorting:** Every timestamp column sortable. Click header toggles asc/desc.
**Search:** Filter by member name or email address, case-insensitive.
**Pagination:** 50 rows per page. Show count: "Showing 1–50 of 247 recipients."
**Default sort:** Sent timestamp, descending.

### Mobile responsive layout

On screens narrower than 768px:

**Always visible:**
- Member Name and Email Address (stacked, two lines)
- Sent timestamp
- Opened (with count if multiple)

**Hidden by default, revealed by tapping a row:**
- Delivered, Clicked, Bounced, Unsubscribed, Skipped — shown as labeled key-value pairs:
  ```
  Delivered:    Mar 9, 10:04 AM
  Clicked:      —
  Bounced:      —
  Unsubscribed: —
  ```

Tapping the row again collapses it.

---

## PART 2 — SENDGRID UNSUBSCRIBE GROUPS ARCHITECTURE

### Why this matters

Without unsubscribe groups, any opt-out is a global SendGrid suppression — the member stops receiving all email from this account forever. A Foundation member who unsubscribes from a marketing campaign should not stop receiving their sales milestone recognition email.

### The four email categories

| Category | Member Can Opt Out? | Notes |
|---|---|---|
| `marketing` | Yes | SmartSends campaigns, newsletters, promotions. `engagement` maps here too. |
| `recognition` | Yes (with warning) | Milestone emails, anniversary emails |
| `compliance` | No | CE deadlines, Code of Ethics notices — required |
| `transactional` | No | Event confirmations, system notifications |

### Schema changes

```sql
-- tenant_config
ALTER TABLE tenant_config ADD COLUMN IF NOT EXISTS sg_group_marketing INTEGER;
ALTER TABLE tenant_config ADD COLUMN IF NOT EXISTS sg_group_recognition INTEGER;
ALTER TABLE tenant_config ADD COLUMN IF NOT EXISTS sg_group_compliance INTEGER;
ALTER TABLE tenant_config ADD COLUMN IF NOT EXISTS sg_group_transactional INTEGER;

-- member_email_preferences
ALTER TABLE member_email_preferences ADD COLUMN IF NOT EXISTS marketing_opt_out BOOLEAN DEFAULT FALSE;
ALTER TABLE member_email_preferences ADD COLUMN IF NOT EXISTS marketing_opt_out_date TIMESTAMP;
ALTER TABLE member_email_preferences ADD COLUMN IF NOT EXISTS recognition_opt_out BOOLEAN DEFAULT FALSE;
ALTER TABLE member_email_preferences ADD COLUMN IF NOT EXISTS recognition_opt_out_date TIMESTAMP;
```

### SendGrid group creation

New service: `server/services/sendgridUnsubscribeGroups.ts`

Create 4 groups via SendGrid API on startup (idempotent — skip if IDs already in `tenant_config`):
1. "MemberSync Marketing"
2. "MemberSync Recognition"
3. "MemberSync Compliance"
4. "MemberSync Transactional"

Store returned group IDs in `tenant_config` for the Mainstreet client row.

### ASM parameter in send path

In `emailService.ts` `processEmailQueue`, add to every `sgMail.send()` call:

```javascript
asm: {
  groupId: getUnsubscribeGroupId(campaignCategory, tenantConfig),
  groupsToDisplay: [
    tenantConfig.sg_group_marketing,
    tenantConfig.sg_group_recognition,
  ]
}
```

Helper function `getUnsubscribeGroupId(category, tenantConfig)`:
- `marketing` → `sg_group_marketing`
- `engagement` → `sg_group_marketing` (legacy mapping)
- `recognition` → `sg_group_recognition`
- `compliance` → `sg_group_compliance`
- `transactional` → `sg_group_transactional`
- `null` / unrecognized → `sg_group_marketing` + log warning with campaign ID

**The existing `emailOptOut` boolean is a global override.** If `true`, member gets nothing regardless of category. Preserve this behavior — do not remove it.

### Email footer

Every outbound email footer must include the preference center link with the member's signed token:
`/email-preferences?token=[signed-member-token]`

Use the same HMAC token generation pattern as the existing `/unsubscribe` handler. A generic link without the token cannot identify the member.

### One-click unsubscribe update (`/unsubscribe`)

Update the existing GET `/unsubscribe` route:
- Determine the campaign's category from the campaign record
- Set the appropriate category opt-out column (e.g. `marketing_opt_out = true`) instead of global `email_opt_out = true`
- If category is `compliance` or `transactional`: log the event but do not apply suppression
- Always redirect to `/email-preferences?token=[signed-token]` after processing — regardless of category or whether suppression was applied

---

## PART 3 — UNSUBSCRIBE MANAGEMENT

### Staff-facing panel — Settings → Unsubscribes

**Route:** `/smartsends/settings/unsubscribes`
Add as sub-item under SmartSends Settings in nav.

**Filter tabs:** All / Marketing / Recognition

**Table columns:**

| Column | Value |
|---|---|
| Member Name | Linked to member detail page |
| Email Address | Address that opted out |
| Category | Marketing or Recognition |
| Opted Out On | Date and time |
| Campaign | Name of campaign they unsubscribed from (linked) |
| Source | "Member request" / "Manual" / "Hard bounce" |
| Action | "Remove" button — except hard bounces |

**Hard bounces:** "Hard Bounce — Permanent" in Source column. No Remove button. Permanent — no exceptions.

**Remove action:** Confirmation — "Remove [email] from [category] suppression? They will be eligible to receive future [category] emails." Removes only that category suppression.

**Manual suppression:** "+ Add Suppression" button. Inline form (not modal): email address (required), category selector (Marketing / Recognition), optional note.

**Search:** By name or email. **Sort:** Opted Out On, descending. **Pagination:** 50 rows.

### Member-facing preference center (`/email-preferences`)

Public route, no login required. Server-rendered HTML (same pattern as existing `/unsubscribe` page — not a React page).

**Two toggleable rows:**
- **Marketing & Campaigns** — on/off toggle
- **Recognition** — on/off toggle with soft warning when turning off: "These emails celebrate your accomplishments as a Mainstreet member. Are you sure you want to turn these off?"

**Two read-only rows:**
- **Compliance** — "Required — cannot be turned off"
- **Transactional** — "Required — cannot be turned off"

**Save button** → confirmation message: "Your preferences have been updated."

Receives signed HMAC token in URL to identify member. POST endpoint saves changes to `member_email_preferences` category columns.

---

## DO NOT TOUCH

- `triggeredCampaignProcessor.ts` — do not modify for any reason
- `sequenceEnrollmentService.ts` — do not modify for any reason
- The existing HMAC token validation logic — extend it, don't replace it
- The existing global `email_opt_out` boolean behavior — preserve it as a global override

---

## VERIFICATION CHECKLIST

**Campaign detail page:**
- [ ] Clicking a campaign row navigates directly to detail page — no modal
- [ ] Header shows name, type badge, status badge, sent by, back link
- [ ] Five stat cards show correct data
- [ ] Action buttons are context-aware by status
- [ ] Member Activity tab is default, shows all 9 columns
- [ ] Timestamp columns are sortable
- [ ] Search works
- [ ] Pagination works at 50 rows
- [ ] Skipped recipients show skip reason
- [ ] Mobile: Name/Email/Sent/Opened visible; tap row reveals remaining columns
- [ ] Email Content tab shows rendered preview
- [ ] Sequences show step selector in Email Content tab

**SendGrid unsubscribe groups:**
- [ ] Four groups created in SendGrid (idempotent — safe to run multiple times)
- [ ] Group IDs stored in tenant_config
- [ ] Every outbound email includes correct `asm` parameter
- [ ] `engagement` category maps to marketing group
- [ ] Null/unknown category defaults to marketing with logged warning
- [ ] Email footer links to `/email-preferences?token=[signed-token]`
- [ ] One-click `/unsubscribe` sets category-specific opt-out, not global
- [ ] One-click `/unsubscribe` redirects to `/email-preferences?token=[token]` in all cases
- [ ] Global `email_opt_out` boolean still works as full override

**Unsubscribe management:**
- [ ] Settings → Unsubscribes page loads with real data
- [ ] Filter tabs work (All / Marketing / Recognition)
- [ ] Hard bounce rows show permanent label, no Remove button
- [ ] Remove works with confirmation for non-hard-bounce rows
- [ ] Manual suppression add works
- [ ] Preference center loads at `/email-preferences`
- [ ] Marketing and Recognition toggles save correctly
- [ ] Compliance and Transactional show as required/non-editable
- [ ] Recognition toggle shows warning before turning off
- [ ] Preference center works without login

# MemberSync Dashboard Cleanup â€” Fix Visual Issues & Tier Card Framing
## February 19, 2026

---

## CONTEXT FOR REPLIT AGENT

The dashboard redesign (Parts 1 and 2) is deployed and the structure is good. This prompt fixes specific visual and data presentation issues identified during review. These are targeted fixes â€” do NOT restructure the layout or add new features.

---

## FIX 1: Empty Space Gap Below Today's Activity

**Problem:** The Activity Feed has only 3 items, creating a large empty gap below it while the Celebrations sidebar fills the full right column. This looks broken.

**Fix:** Add more activity items to the `/api/dashboard/activity-feed` endpoint in `server/routes.ts` to fill the space. Add these additional item types after the existing ones:

**A. Upcoming event nudge** â€” Show the next upcoming event that still has spots available:

```typescript
// After the existing activity items, add upcoming event nudge
if (externalPool) {
  try {
    const extClient = await externalPool.connect();
    try {
      const upcomingEvent = await extClient.query(`
        SELECT DISTINCT ON ("EventId") "Name", "StartDateTime", "MaxAttendees", "EventId"
        FROM "AMS"."apmevent"
        WHERE "ApmClientId" = '${CLIENT_ID}'
          AND "StartDateTime" > NOW()
          AND "StartDateTime" <= NOW() + INTERVAL '14 days'
          AND "Type" IS DISTINCT FROM 'class'
        ORDER BY "EventId", "ApmSourceModificationTimestamp" DESC
        LIMIT 1
      `);
      if (upcomingEvent.rows.length > 0) {
        const evt = upcomingEvent.rows[0] as any;
        const daysUntil = Math.ceil((new Date(evt.StartDateTime).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        activities.push({
          id: 'upcoming-event',
          type: 'events',
          icon: 'calendar_check',
          title: `${evt.Name} is ${daysUntil === 1 ? 'tomorrow' : `${daysUntil} days away`}`,
          detail: 'Boost attendance with a targeted email to nearby agents',
          actionLabel: 'Promote',
          actionUrl: '/smartsends/send',
          timestamp: new Date().toISOString(),
        });
      }
    } finally {
      extClient.release();
    }
  } catch {
    // Non-fatal â€” external DB might not be available
  }
}
```

Import `CLIENT_ID` from `./services/clientConfig` at the top of the file if not already imported.

**B. Upcoming class nudge** â€” Same pattern but for classes in the next 14 days:

```typescript
if (externalPool) {
  try {
    const extClient = await externalPool.connect();
    try {
      const upcomingClass = await extClient.query(`
        SELECT DISTINCT ON ("EventId") "Name", "StartDateTime", "EducationCredits", "EventId"
        FROM "AMS"."apmevent"
        WHERE "ApmClientId" = '${CLIENT_ID}'
          AND "StartDateTime" > NOW()
          AND "StartDateTime" <= NOW() + INTERVAL '14 days'
          AND "Type" = 'class'
        ORDER BY "EventId", "ApmSourceModificationTimestamp" DESC
        LIMIT 1
      `);
      if (upcomingClass.rows.length > 0) {
        const cls = upcomingClass.rows[0] as any;
        const daysUntil = Math.ceil((new Date(cls.StartDateTime).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        const ceNote = cls.EducationCredits ? ` (${cls.EducationCredits} CE credits)` : '';
        activities.push({
          id: 'upcoming-class',
          type: 'education',
          icon: 'graduation_cap',
          title: `${cls.Name}${ceNote} starts ${daysUntil === 1 ? 'tomorrow' : `in ${daysUntil} days`}`,
          detail: 'Remind registered members or promote to new attendees',
          actionLabel: 'Promote',
          actionUrl: '/smartsends/send',
          timestamp: new Date().toISOString(),
        });
      }
    } finally {
      extClient.release();
    }
  } catch {
    // Non-fatal
  }
}
```

**C. Milestone summary** â€” enhance the existing milestone item with a more specific message if milestones exist:

The existing milestone item already works. Just make sure it appears. If `member_milestones` table doesn't exist yet, this is caught by the try/catch â€” that's fine.

**Goal:** Activity Feed should have 5-6 items minimum, roughly matching the height of the Celebrations sidebar.

---

## FIX 2: Tier Card Text Too Small

**Problem:** The persona descriptions in the Mainstreet Community tier cards use `text-[11px]` and `text-[10px]` which are borderline illegible on laptop screens.

**Fix in `MainstreetCommunity.tsx` (or wherever the tier cards are rendered):**

1. Change the primary persona description from `text-[11px]` to `text-xs` (12px):
```tsx
// Change:
<p className="text-[11px] text-muted-foreground leading-relaxed">{persona.description}</p>
// To:
<p className="text-xs text-muted-foreground leading-relaxed">{persona.description}</p>
```

2. Change the detail line from `text-[10px]` to `text-[11px]`:
```tsx
// Change:
<p className="text-[10px] text-muted-foreground/70 leading-relaxed">{persona.detail}</p>
// To:
<p className="text-[11px] text-muted-foreground/70 leading-relaxed">{persona.detail}</p>
```

3. Change the "Scored 5+ out of 10..." explanation from `text-[10px]` to `text-[11px]`:
```tsx
// Change:
<p className="text-[10px] text-muted-foreground/70 mt-0.5">
// To:
<p className="text-[11px] text-muted-foreground/70 mt-0.5">
```

The cards can be slightly taller to accommodate the larger text. That's fine â€” readability matters more than compactness.

---

## FIX 3: Tier Card Volume Framing â€” Tell Different Stories

**Problem:** The volume numbers on the tier cards are technically correct but visually misleading. Builder shows $17.3B and Rainmaker shows $6.7B, which makes it look like Builders outproduce Rainmakers. In reality, Builders have 16x more members â€” their *per-agent* production is much lower. The current framing fails because it tells the same story (aggregate volume + share %) for all three tiers.

**Fix:** Each tier tells a DIFFERENT volume/production story based on what's most meaningful for that tier. This requires changes to both the backend response and the frontend rendering.

### Backend change â€” `server/routes.ts` in the membership-story endpoint:

Add `avgSides` (average transaction sides per member in that tier) to the tier query. Find the existing tier aggregation query (around line 518-533) and add this column:

```sql
ROUND(AVG(CAST(transactions_12mo AS NUMERIC)), 1) as avg_sides
```

Include `avgSides` in each tier's response object:
- In `rainmakerInsights`: add `avgSides: parseFloat(rainmaker.avgSides) || 0`  
- In `builderInsights`: add `avgSides: parseFloat(builder.avgSides) || 0`
- In `foundationInsights`: add `avgSides: parseFloat(foundation.avgSides) || 0`

(Add `avgSides` to the `tierMap` construction around line 540-548.)

### Frontend change â€” Each tier card shows a different highlight box:

**Rainmaker highlight** â€” Per-agent dominance story. Keep the concentration stat but add average sides:
```tsx
{/* Rainmaker: show per-agent power */}
<div className={`${persona.colorHighlight} rounded-md p-2.5`}>
  <p className="text-xs font-medium" style={{ color: 'inherit' }}>
    {insights.avgSides.toFixed(0)} avg sides per agent Â· {formatCurrency(Math.round(insights.totalVolume / comp.count))} avg production
  </p>
  {insights.top5PctVolShare > 0 && (
    <p className="text-[11px] text-muted-foreground mt-0.5">
      Top {insights.top5PctCount.toLocaleString()} agents ({insights.top5PctLabel}%) control {insights.top5PctVolShare}% of all volume
    </p>
  )}
</div>
```

**Builder highlight** â€” Growth trajectory story. Show average sides and total volume to frame them as the growth engine:
```tsx
{/* Builder: show growth engine */}
<div className={`${persona.colorHighlight} rounded-md p-2.5`}>
  <p className="text-xs font-medium" style={{ color: 'inherit' }}>
    {insights.avgSides.toFixed(0)} avg sides per agent Â· {formatCurrency(insights.totalVolume)} total volume
  </p>
  <p className="text-[11px] text-muted-foreground mt-0.5">
    The growth engine â€” {comp.count.toLocaleString()} agents building their businesses
  </p>
</div>
```

**Foundation highlight** â€” Dues revenue story. Don't show volume (it's tiny and makes them look unimportant). Instead show their value to the organization:
```tsx
{/* Foundation: show dues value */}
<div className={`${persona.colorHighlight} rounded-md p-2.5`}>
  <p className="text-xs font-medium" style={{ color: 'inherit' }}>
    {insights.avgSides.toFixed(1)} avg sides Â· {comp.percentage}% of your membership
  </p>
  <p className="text-[11px] text-muted-foreground mt-0.5">
    Your financial foundation â€” {comp.count.toLocaleString()} members sustaining the organization through dues
  </p>
</div>
```

This means the volume line on Foundation no longer shows a dollar figure and share percentage. That's intentional â€” showing "$5.2B Â· 18% of total" for Foundation actually undermines the message that these members matter. Their value is in dues and community, not production.

---

## FIX 4: Membership Card â€” Make Growth Number More Prominent

**Problem:** The new member trend ("107 new this month, -46%") is displayed as a small subtitle that's easy to miss. This is the most important trend number on the Membership card. However, we should NOT use the MetricCard `trend` prop because it renders the percentage right next to "18,265" â€” making it look like total membership dropped 46%, which is terrifying and wrong. The -46% applies to the *monthly new member count*, not the total.

**Fix in `Dashboard.tsx`:** Keep the growth data in the subtitle but make the subtitle itself more prominent. Also reword to make it crystal clear what the percentage refers to:

```tsx
<MetricCard
  title="Membership"
  value={metrics.totalActiveMembers.total}
  subtitle={`${metrics.associationPulse?.newMembersThisMonth || 0} new this month${
    metrics.associationPulse?.newMemberGrowthPct !== null && metrics.associationPulse?.newMemberGrowthPct !== undefined
      ? ` (${metrics.associationPulse.newMemberGrowthPct > 0 ? "+" : ""}${metrics.associationPulse.newMemberGrowthPct}% month over month)`
      : ""
  }`}
  icon={Users}
  variant="default"
  testId="card-membership"
  breakdown={[
    { label: "Rainmaker", value: metrics.totalActiveMembers.activeProducers, variant: "amber" },
    { label: "Builder", value: metrics.totalActiveMembers.occasionalProducers, variant: "blue" },
    { label: "Foundation", value: metrics.totalActiveMembers.licenseMaintainers, variant: "emerald" },
  ]}
  onClick={() => setLocation("/members")}
/>
```

**Additionally**, make the subtitle styling more prominent for the Membership card specifically. In `MetricCard.tsx`, add support for a `subtitleClassName` prop:

1. Add to the `MetricCardProps` interface:
```typescript
subtitleClassName?: string;
```

2. Add to the function parameters:
```typescript
export function MetricCard({
  ...existing props,
  subtitleClassName,
}: MetricCardProps) {
```

3. Change the subtitle rendering from:
```tsx
{subtitle && (
  <p className="text-xs text-muted-foreground">{subtitle}</p>
)}
```
To:
```tsx
{subtitle && (
  <p className={cn("text-xs text-muted-foreground", subtitleClassName)}>{subtitle}</p>
)}
```

Then in `Dashboard.tsx`, use it on the Membership card:
```tsx
<MetricCard
  title="Membership"
  ...
  subtitleClassName="text-sm font-medium text-foreground"
  ...
/>
```

This makes "107 new this month (-46% month over month)" display in a larger, darker font â€” clearly a secondary headline rather than fine print â€” while keeping all other cards' subtitles unchanged. The wording "month over month" makes it unambiguous that the percentage refers to the monthly new member pace, not the total.
```

---

## FIX 5: Celebrations Sidebar â€” Placeholder for Future Automated Tiles

**Problem:** The Celebrations sidebar works but will evolve into automated campaign reporting tiles in a future release. For now, make a small visual improvement: ensure each celebration category card has a distinct accent color on its left border to make the sidebar feel more celebratory and scannable.

**Fix:** In the Celebrations component (`CelebrationInsights.tsx`), if the category cards don't already have distinct left-border colors, add them. Each category should have a different accent:

- Anniversaries â†’ `border-l-4 border-l-purple-400`
- Transaction Milestones â†’ `border-l-4 border-l-amber-400`
- Volume Milestones â†’ `border-l-4 border-l-emerald-400`
- Listing Milestones â†’ `border-l-4 border-l-blue-400`
- Buyer Milestones â†’ `border-l-4 border-l-rose-400`
- Luxury Market Entry â†’ `border-l-4 border-l-violet-400`
- Rising Stars â†’ `border-l-4 border-l-orange-400`
- Niche Specialists â†’ `border-l-4 border-l-teal-400`
- Top Producers â†’ `border-l-4 border-l-yellow-400`

If the component already uses category-based colors, verify they're visually distinct. The sidebar should feel colorful and celebratory â€” it's the "good news" section of the dashboard.

---

## FIX 6: Connection Status â€” Replace Static Percentage with Rotating Insights (Foundation)

**Problem:** All three tier cards show nearly identical connection percentages (14%, 14%, 13%), which provides no meaningful differentiation. A static percentage that never changes becomes wallpaper.

**Fix â€” Phase 1 (now):** Replace the static connection percentage with a **tier-specific insight** that tells a different, more meaningful story for each tier. For this first version, the insights are static (computed from current data). In a future version, they'll rotate daily from a pool of possible insights.

### Backend change â€” Add tier-specific insight text to the membership-story response:

In `server/routes.ts`, after computing the tier data (around line 640-695), generate an insight string for each tier:

```typescript
// Compute tier-specific insight strings
const rainmakerInsightText = rainmaker.count > 0
  ? `${rainmaker.connectedPct}% connected Â· avg ${rainmaker.avgTransactions.toFixed(0)} sides per agent`
  : 'No data available';

// For builders, show how many are in education/events
const builderEngagedCount = blSignals.withEducation + blSignals.withEvents;
const builderEngagedPct = builder.count > 0 ? Math.round((builderEngagedCount / builder.count) * 100) : 0;
const builderInsightText = builder.count > 0
  ? `${builderEngagedPct}% engaged in education or events Â· ${builder.connectedPct}% connected`
  : 'No data available';

// For foundation, show how many have zero touchpoints
const foundationDisconnectedCount = foundation.count - Math.round(foundation.count * foundation.connectedPct / 100);
const foundationInsightText = foundation.count > 0
  ? `${foundationDisconnectedCount.toLocaleString()} members have limited association interaction Â· ${foundation.connectedPct}% connected`
  : 'No data available';
```

Add `insightText` to each tier's response:
- `rainmakerInsights`: add `insightText: rainmakerInsightText`
- `builderInsights`: add `insightText: builderInsightText`
- `foundationInsights`: add `insightText: foundationInsightText`

### Frontend change â€” Replace the connection percentage block:

In the tier cards, replace the large "14% connected to your organization" block with the insight text. The connected percentage is still there but it's woven into the insight rather than being the hero number.

Replace the connection status block in each tier card:

FROM:
```tsx
<div className={`${persona.colorHighlight} rounded-md p-2.5`}>
  <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
    {insights.connectedPercentage}%
  </p>
  <p className="text-xs text-muted-foreground">connected to your organization</p>
  <p className="text-[10px] text-muted-foreground/70 mt-0.5">
    Scored 5+ out of 10 on education, events, email, and activity
  </p>
</div>
```

TO:
```tsx
<div className={`${persona.colorHighlight} rounded-md p-2.5`}>
  <p className="text-xs font-medium ${persona.colorHighlightText}">
    {insights.insightText}
  </p>
</div>
```

This makes each card tell a genuinely different story instead of repeating the same number three times.

---

## VERIFICATION CHECKLIST

- [ ] Activity Feed has 5-6 items (including upcoming event and class nudges), filling the column height
- [ ] Tier card persona text is readable (no text smaller than 11px)
- [ ] Rainmaker card shows per-agent stats (avg sides, avg production, concentration)
- [ ] Builder card shows growth engine framing (avg sides, total volume, "growth engine" tagline)
- [ ] Foundation card shows dues value framing (avg sides, membership %, "financial foundation" tagline) â€” NO dollar volume
- [ ] Membership card growth number is prominent (colored, next to the headline number)
- [ ] Celebrations sidebar has distinct accent colors per category
- [ ] Each tier card shows a different insight text (not the same percentage three times)
- [ ] No changes to SmartSends, AI Chat, Analytics, or any other pages
- [ ] Mobile layout still works â€” cards stack vertically, text remains readable

---

## FILES CHANGED

**Modified:**
- `server/routes.ts` â€” Activity feed (add upcoming event/class items), membership-story (add avgSides, insightText per tier)
- `client/src/components/dashboard/MainstreetCommunity.tsx` â€” Text sizing, different highlight box per tier, insight text replaces static percentage
- `client/src/pages/Dashboard.tsx` â€” Membership card uses trend prop
- `client/src/components/dashboard/CelebrationInsights.tsx` â€” Distinct accent colors per category

**No new files.**
